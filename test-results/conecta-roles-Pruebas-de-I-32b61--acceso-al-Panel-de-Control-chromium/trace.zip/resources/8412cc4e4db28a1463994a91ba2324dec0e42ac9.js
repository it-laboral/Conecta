import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/chunk-UXCBMG7Q.js");import {
  PostulanteService
} from "/chunk-K5PJFGEX.js";
import {
  __spreadProps,
  __spreadValues
} from "/chunk-CZJLB7T5.js";

// src/app/pagina/perfiles/postulante-profile/postulante-profile.ts
import { Component, inject, PLATFORM_ID, Input, ChangeDetectorRef } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import { CommonModule, isPlatformBrowser, Location } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_common.js?v=3d725e17";
import { FormsModule } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_forms.js?v=3d725e17";
import { Router, ActivatedRoute } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_router.js?v=3d725e17";
import { DomSanitizer } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_platform-browser.js?v=3d725e17";
import * as i0 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import * as i1 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_common.js?v=3d725e17";
import * as i2 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_forms.js?v=3d725e17";
var _c0 = () => [];
var _forTrack0 = ($index, $item) => $item.skill_id;
var _forTrack1 = ($index, $item) => $item.categoria_id;
function PostulanteProfile_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "img", 40);
    i0.\u0275\u0275listener("error", function PostulanteProfile_Conditional_4_Template_img_error_0_listener() {
      i0.\u0275\u0275restoreView(_r1);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.perfil.foto = "");
    });
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275property("src", ctx_r1.getFotoUrl(), i0.\u0275\u0275sanitizeUrl);
  }
}
function PostulanteProfile_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 6);
    i0.\u0275\u0275namespaceSVG();
    i0.\u0275\u0275elementStart(1, "svg", 41);
    i0.\u0275\u0275element(2, "path", 42);
    i0.\u0275\u0275elementEnd()();
  }
}
function PostulanteProfile_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "button", 43);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_6_Template_button_click_0_listener() {
      i0.\u0275\u0275restoreView(_r3);
      const fotoInput_r4 = i0.\u0275\u0275reference(3);
      return i0.\u0275\u0275resetView(fotoInput_r4.click());
    });
    i0.\u0275\u0275text(1, " \u{1F4F7} ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(2, "input", 44, 0);
    i0.\u0275\u0275listener("change", function PostulanteProfile_Conditional_6_Template_input_change_2_listener($event) {
      i0.\u0275\u0275restoreView(_r3);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.onFotoSeleccionada($event));
    });
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275property("disabled", ctx_r1.guardando);
  }
}
function PostulanteProfile_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "button", 45);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_17_Template_button_click_0_listener() {
      i0.\u0275\u0275restoreView(_r5);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.volver());
    });
    i0.\u0275\u0275text(1, " \u2190 Volver ");
    i0.\u0275\u0275elementEnd();
  }
}
function PostulanteProfile_Conditional_18_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "span");
    i0.\u0275\u0275text(1, "\u{1F4BE} Guardar Perfil Definitivo");
    i0.\u0275\u0275elementEnd();
  }
}
function PostulanteProfile_Conditional_18_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "span");
    i0.\u0275\u0275text(1, "\u23F3 Guardando...");
    i0.\u0275\u0275elementEnd();
  }
}
function PostulanteProfile_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "button", 46);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_18_Template_button_click_0_listener() {
      i0.\u0275\u0275restoreView(_r6);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.abrirModal("principales"));
    });
    i0.\u0275\u0275text(1, " \u270F\uFE0F Editar Ubicaci\xF3n ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(2, "button", 47);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_18_Template_button_click_2_listener() {
      i0.\u0275\u0275restoreView(_r6);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.guardarPerfilCompleto());
    });
    i0.\u0275\u0275conditionalCreate(3, PostulanteProfile_Conditional_18_Conditional_3_Template, 2, 0, "span")(4, PostulanteProfile_Conditional_18_Conditional_4_Template, 2, 0, "span");
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275property("disabled", ctx_r1.guardando);
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(!ctx_r1.guardando ? 3 : 4);
  }
}
function PostulanteProfile_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 13);
    i0.\u0275\u0275text(1);
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance();
    i0.\u0275\u0275textInterpolate1(" ", ctx_r1.mensajeEstado, " ");
  }
}
function PostulanteProfile_Conditional_24_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "button", 48);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_24_Template_button_click_0_listener() {
      i0.\u0275\u0275restoreView(_r7);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.abrirModal("sobreMi"));
    });
    i0.\u0275\u0275text(1, " \u270F\uFE0F ");
    i0.\u0275\u0275elementEnd();
  }
}
function PostulanteProfile_Conditional_25_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "p", 17);
    i0.\u0275\u0275text(1);
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance();
    i0.\u0275\u0275textInterpolate(ctx_r1.perfil.sobre_mi);
  }
}
function PostulanteProfile_Conditional_26_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, " El postulante a\xFAn no ha cargado su presentaci\xF3n profesional. ");
  }
}
function PostulanteProfile_Conditional_26_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, " Contale a las empresas tu enfoque t\xE9cnico: tecnolog\xEDas principales, orientaci\xF3n y motivaci\xF3n profesional. ");
  }
}
function PostulanteProfile_Conditional_26_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "p", 18);
    i0.\u0275\u0275conditionalCreate(1, PostulanteProfile_Conditional_26_Conditional_1_Template, 1, 0)(2, PostulanteProfile_Conditional_26_Conditional_2_Template, 1, 0);
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(ctx_r1.esVisitante ? 1 : 2);
  }
}
function PostulanteProfile_Conditional_42_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "button", 49);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_42_Template_button_click_0_listener() {
      i0.\u0275\u0275restoreView(_r8);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.irACurriculum());
    });
    i0.\u0275\u0275text(1, " \u270F\uFE0F ");
    i0.\u0275\u0275elementEnd();
  }
}
function PostulanteProfile_Conditional_43_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "button", 58);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_43_Conditional_14_Template_button_click_0_listener() {
      i0.\u0275\u0275restoreView(_r10);
      const ctx_r1 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r1.irACurriculum());
    });
    i0.\u0275\u0275text(1, " \u{1F4DD} Ir a Curriculum ");
    i0.\u0275\u0275elementEnd();
  }
}
function PostulanteProfile_Conditional_43_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 25)(1, "div", 50)(2, "span", 51);
    i0.\u0275\u0275text(3, "\u{1F4C4}");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(4, "div", 52)(5, "strong");
    i0.\u0275\u0275text(6);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(7, "span", 53);
    i0.\u0275\u0275text(8, "\u2713 CV disponible");
    i0.\u0275\u0275elementEnd()()();
    i0.\u0275\u0275elementStart(9, "div", 54)(10, "button", 55);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_43_Template_button_click_10_listener() {
      i0.\u0275\u0275restoreView(_r9);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.verCV());
    });
    i0.\u0275\u0275text(11, " \u{1F441}\uFE0F Ver / Previsualizar ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(12, "button", 56);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_43_Template_button_click_12_listener() {
      i0.\u0275\u0275restoreView(_r9);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.descargarCV());
    });
    i0.\u0275\u0275text(13, " \u2B07\uFE0F Descargar ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275conditionalCreate(14, PostulanteProfile_Conditional_43_Conditional_14_Template, 2, 0, "button", 57);
    i0.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(6);
    i0.\u0275\u0275textInterpolate(ctx_r1.perfil.cv_nombre || "Curriculum_Vitae.pdf");
    i0.\u0275\u0275advance(8);
    i0.\u0275\u0275conditional(!ctx_r1.esVisitante ? 14 : -1);
  }
}
function PostulanteProfile_Conditional_44_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "h4");
    i0.\u0275\u0275text(1, "Sin CV adjuntado");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(2, "p", 60);
    i0.\u0275\u0275text(3, "El postulante a\xFAn no ha subido su Curriculum Vitae.");
    i0.\u0275\u0275elementEnd();
  }
}
function PostulanteProfile_Conditional_44_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "h4");
    i0.\u0275\u0275text(1, "No ten\xE9s un CV adjuntado");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(2, "p", 60);
    i0.\u0275\u0275text(3, " Ingres\xE1 al gestor de CV para cargarlo y configurarlo. ");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(4, "div", 54)(5, "button", 61);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_44_Conditional_4_Template_button_click_5_listener() {
      i0.\u0275\u0275restoreView(_r11);
      const ctx_r1 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r1.irACurriculum());
    });
    i0.\u0275\u0275text(6, " \u{1F680} Cargar / Ir a Curriculum ");
    i0.\u0275\u0275elementEnd()();
  }
}
function PostulanteProfile_Conditional_44_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 26)(1, "div", 59);
    i0.\u0275\u0275text(2, "\u{1F4C4}");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275conditionalCreate(3, PostulanteProfile_Conditional_44_Conditional_3_Template, 4, 0)(4, PostulanteProfile_Conditional_44_Conditional_4_Template, 7, 0);
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275conditional(ctx_r1.esVisitante ? 3 : 4);
  }
}
function PostulanteProfile_Conditional_49_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "button", 62);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_49_Template_button_click_0_listener() {
      i0.\u0275\u0275restoreView(_r12);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.abrirModal("skills"));
    });
    i0.\u0275\u0275text(1, " \u270F\uFE0F ");
    i0.\u0275\u0275elementEnd();
  }
}
function PostulanteProfile_For_52_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "span", 30);
    i0.\u0275\u0275text(1);
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const skill_r13 = ctx.$implicit;
    i0.\u0275\u0275advance();
    i0.\u0275\u0275textInterpolate(skill_r13.nombre);
  }
}
function PostulanteProfile_Conditional_53_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 31)(1, "p", 63);
    i0.\u0275\u0275text(2, "Otras herramientas y conocimientos:");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(3, "p", 64);
    i0.\u0275\u0275text(4);
    i0.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275textInterpolate(ctx_r1.perfil.otras_habilidades);
  }
}
function PostulanteProfile_Conditional_54_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, " El postulante a\xFAn no ha registrado sus habilidades t\xE9cnicas. ");
  }
}
function PostulanteProfile_Conditional_54_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, " Hac\xE9 clic en el l\xE1piz para seleccionar tus habilidades del cat\xE1logo o agregar otras. ");
  }
}
function PostulanteProfile_Conditional_54_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "p", 18);
    i0.\u0275\u0275conditionalCreate(1, PostulanteProfile_Conditional_54_Conditional_1_Template, 1, 0)(2, PostulanteProfile_Conditional_54_Conditional_2_Template, 1, 0);
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(ctx_r1.esVisitante ? 1 : 2);
  }
}
function PostulanteProfile_Conditional_59_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "button", 65);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_59_Template_button_click_0_listener() {
      i0.\u0275\u0275restoreView(_r14);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.abrirModal("redes"));
    });
    i0.\u0275\u0275text(1, " \u270F\uFE0F ");
    i0.\u0275\u0275elementEnd();
  }
}
function PostulanteProfile_Conditional_61_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "a", 35);
    i0.\u0275\u0275text(1, "\u{1F4C1} GitHub");
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275property("href", ctx_r1.perfil.redes.github, i0.\u0275\u0275sanitizeUrl);
  }
}
function PostulanteProfile_Conditional_62_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "a", 36);
    i0.\u0275\u0275text(1, "\u{1F4BC} LinkedIn");
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275property("href", ctx_r1.perfil.redes.linkedin, i0.\u0275\u0275sanitizeUrl);
  }
}
function PostulanteProfile_Conditional_63_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "a", 37);
    i0.\u0275\u0275text(1, "\u{1F310} Web / Portafolio");
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275property("href", ctx_r1.perfil.redes.portfolio, i0.\u0275\u0275sanitizeUrl);
  }
}
function PostulanteProfile_Conditional_64_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, " El postulante no ha vinculado redes profesionales. ");
  }
}
function PostulanteProfile_Conditional_64_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275text(0, " No vinculaste ninguna red profesional a\xFAn. ");
  }
}
function PostulanteProfile_Conditional_64_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "p", 18);
    i0.\u0275\u0275conditionalCreate(1, PostulanteProfile_Conditional_64_Conditional_1_Template, 1, 0)(2, PostulanteProfile_Conditional_64_Conditional_2_Template, 1, 0);
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(ctx_r1.esVisitante ? 1 : 2);
  }
}
function PostulanteProfile_Conditional_65_Template(rf, ctx) {
  if (rf & 1) {
    const _r15 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 66);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_65_Template_div_click_0_listener() {
      i0.\u0275\u0275restoreView(_r15);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.cerrarModal());
    });
    i0.\u0275\u0275elementStart(1, "div", 67);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_65_Template_div_click_1_listener($event) {
      return $event.stopPropagation();
    });
    i0.\u0275\u0275elementStart(2, "div", 68)(3, "div")(4, "h2");
    i0.\u0275\u0275text(5, "\u{1F4CD} Editar Ubicaci\xF3n");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(6, "p");
    i0.\u0275\u0275text(7, "Actualiz\xE1 la ubicaci\xF3n que ver\xE1n las empresas.");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(8, "button", 69);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_65_Template_button_click_8_listener() {
      i0.\u0275\u0275restoreView(_r15);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.cerrarModal());
    });
    i0.\u0275\u0275text(9, "\u2715");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(10, "div", 70)(11, "div", 71)(12, "label", 72);
    i0.\u0275\u0275text(13, "Ciudad");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(14, "input", 73);
    i0.\u0275\u0275twoWayListener("ngModelChange", function PostulanteProfile_Conditional_65_Template_input_ngModelChange_14_listener($event) {
      i0.\u0275\u0275restoreView(_r15);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      i0.\u0275\u0275twoWayBindingSet(ctx_r1.tempUbicacion.ciudad, $event) || (ctx_r1.tempUbicacion.ciudad = $event);
      return i0.\u0275\u0275resetView($event);
    });
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(15, "div", 71)(16, "label", 74);
    i0.\u0275\u0275text(17, "Pa\xEDs");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(18, "input", 75);
    i0.\u0275\u0275twoWayListener("ngModelChange", function PostulanteProfile_Conditional_65_Template_input_ngModelChange_18_listener($event) {
      i0.\u0275\u0275restoreView(_r15);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      i0.\u0275\u0275twoWayBindingSet(ctx_r1.tempUbicacion.pais, $event) || (ctx_r1.tempUbicacion.pais = $event);
      return i0.\u0275\u0275resetView($event);
    });
    i0.\u0275\u0275elementEnd()()();
    i0.\u0275\u0275elementStart(19, "div", 76)(20, "button", 77);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_65_Template_button_click_20_listener() {
      i0.\u0275\u0275restoreView(_r15);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.cerrarModal());
    });
    i0.\u0275\u0275text(21, "Cancelar");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(22, "button", 78);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_65_Template_button_click_22_listener() {
      i0.\u0275\u0275restoreView(_r15);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.guardarUbicacion());
    });
    i0.\u0275\u0275text(23, "\u{1F4BE} Guardar ubicaci\xF3n");
    i0.\u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(14);
    i0.\u0275\u0275twoWayProperty("ngModel", ctx_r1.tempUbicacion.ciudad);
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275twoWayProperty("ngModel", ctx_r1.tempUbicacion.pais);
  }
}
function PostulanteProfile_Conditional_66_Template(rf, ctx) {
  if (rf & 1) {
    const _r16 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 66);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_66_Template_div_click_0_listener() {
      i0.\u0275\u0275restoreView(_r16);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.cerrarModal());
    });
    i0.\u0275\u0275elementStart(1, "div", 67);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_66_Template_div_click_1_listener($event) {
      return $event.stopPropagation();
    });
    i0.\u0275\u0275elementStart(2, "div", 68)(3, "div")(4, "h2");
    i0.\u0275\u0275text(5, "\u{1F4BB} Perfil Profesional");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(6, "p");
    i0.\u0275\u0275text(7, "Contale a las empresas sobre tu perfil y orientaci\xF3n profesional.");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(8, "button", 69);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_66_Template_button_click_8_listener() {
      i0.\u0275\u0275restoreView(_r16);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.cerrarModal());
    });
    i0.\u0275\u0275text(9, "\u2715");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(10, "div", 70)(11, "div", 71)(12, "label", 79);
    i0.\u0275\u0275text(13, "Sobre m\xED");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(14, "textarea", 80);
    i0.\u0275\u0275twoWayListener("ngModelChange", function PostulanteProfile_Conditional_66_Template_textarea_ngModelChange_14_listener($event) {
      i0.\u0275\u0275restoreView(_r16);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      i0.\u0275\u0275twoWayBindingSet(ctx_r1.tempSobreMi.sobre_mi, $event) || (ctx_r1.tempSobreMi.sobre_mi = $event);
      return i0.\u0275\u0275resetView($event);
    });
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(15, "div", 71)(16, "label", 81);
    i0.\u0275\u0275text(17, "Especialidad / Inter\xE9s");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(18, "input", 82);
    i0.\u0275\u0275twoWayListener("ngModelChange", function PostulanteProfile_Conditional_66_Template_input_ngModelChange_18_listener($event) {
      i0.\u0275\u0275restoreView(_r16);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      i0.\u0275\u0275twoWayBindingSet(ctx_r1.tempSobreMi.especialidad, $event) || (ctx_r1.tempSobreMi.especialidad = $event);
      return i0.\u0275\u0275resetView($event);
    });
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(19, "div", 71)(20, "label", 83);
    i0.\u0275\u0275text(21, "Estado acad\xE9mico");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(22, "select", 84);
    i0.\u0275\u0275twoWayListener("ngModelChange", function PostulanteProfile_Conditional_66_Template_select_ngModelChange_22_listener($event) {
      i0.\u0275\u0275restoreView(_r16);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      i0.\u0275\u0275twoWayBindingSet(ctx_r1.tempSobreMi.estado_academico, $event) || (ctx_r1.tempSobreMi.estado_academico = $event);
      return i0.\u0275\u0275resetView($event);
    });
    i0.\u0275\u0275elementStart(23, "option", 85);
    i0.\u0275\u0275text(24, "Estudiante Inicial");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(25, "option", 86);
    i0.\u0275\u0275text(26, "Estudiante Avanzado");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(27, "option", 87);
    i0.\u0275\u0275text(28, "Graduado");
    i0.\u0275\u0275elementEnd()()()();
    i0.\u0275\u0275elementStart(29, "div", 76)(30, "button", 77);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_66_Template_button_click_30_listener() {
      i0.\u0275\u0275restoreView(_r16);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.cerrarModal());
    });
    i0.\u0275\u0275text(31, "Cancelar");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(32, "button", 78);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_66_Template_button_click_32_listener() {
      i0.\u0275\u0275restoreView(_r16);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.guardarSobreMi());
    });
    i0.\u0275\u0275text(33, "\u{1F4BE} Guardar perfil");
    i0.\u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(14);
    i0.\u0275\u0275twoWayProperty("ngModel", ctx_r1.tempSobreMi.sobre_mi);
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275twoWayProperty("ngModel", ctx_r1.tempSobreMi.especialidad);
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275twoWayProperty("ngModel", ctx_r1.tempSobreMi.estado_academico);
  }
}
function PostulanteProfile_Conditional_67_For_17_For_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r18 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "label", 95)(1, "input", 96);
    i0.\u0275\u0275listener("change", function PostulanteProfile_Conditional_67_For_17_For_5_Template_input_change_1_listener() {
      const skill_r19 = i0.\u0275\u0275restoreView(_r18).$implicit;
      const ctx_r1 = i0.\u0275\u0275nextContext(3);
      return i0.\u0275\u0275resetView(ctx_r1.toggleSkill(skill_r19.skill_id));
    });
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(2, "span");
    i0.\u0275\u0275text(3);
    i0.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const skill_r19 = ctx.$implicit;
    const ctx_r1 = i0.\u0275\u0275nextContext(3);
    i0.\u0275\u0275advance();
    i0.\u0275\u0275property("checked", ctx_r1.esSkillSeleccionada(skill_r19.skill_id));
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate(skill_r19.nombre);
  }
}
function PostulanteProfile_Conditional_67_For_17_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 91)(1, "h4");
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(3, "div", 94);
    i0.\u0275\u0275repeaterCreate(4, PostulanteProfile_Conditional_67_For_17_For_5_Template, 4, 2, "label", 95, _forTrack0);
    i0.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const categoria_r20 = ctx.$implicit;
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate(categoria_r20.nombre_categoria);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275repeater(categoria_r20.skills);
  }
}
function PostulanteProfile_Conditional_67_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "p", 18);
    i0.\u0275\u0275text(1, "No se encontraron habilidades con esa b\xFAsqueda.");
    i0.\u0275\u0275elementEnd();
  }
}
function PostulanteProfile_Conditional_67_Template(rf, ctx) {
  if (rf & 1) {
    const _r17 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 66);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_67_Template_div_click_0_listener() {
      i0.\u0275\u0275restoreView(_r17);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.cerrarModal());
    });
    i0.\u0275\u0275elementStart(1, "div", 67);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_67_Template_div_click_1_listener($event) {
      return $event.stopPropagation();
    });
    i0.\u0275\u0275elementStart(2, "div", 68)(3, "div")(4, "h2");
    i0.\u0275\u0275text(5, "\u{1F6E0}\uFE0F Stack T\xE9cnico y Habilidades");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(6, "p");
    i0.\u0275\u0275text(7, "Seleccion\xE1 las tecnolog\xEDas y conocimientos que forman parte de tu perfil.");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(8, "button", 69);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_67_Template_button_click_8_listener() {
      i0.\u0275\u0275restoreView(_r17);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.cerrarModal());
    });
    i0.\u0275\u0275text(9, "\u2715");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(10, "div", 70)(11, "div", 71)(12, "label", 88);
    i0.\u0275\u0275text(13, "Buscar habilidad");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(14, "input", 89);
    i0.\u0275\u0275twoWayListener("ngModelChange", function PostulanteProfile_Conditional_67_Template_input_ngModelChange_14_listener($event) {
      i0.\u0275\u0275restoreView(_r17);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      i0.\u0275\u0275twoWayBindingSet(ctx_r1.busquedaSkill, $event) || (ctx_r1.busquedaSkill = $event);
      return i0.\u0275\u0275resetView($event);
    });
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(15, "div", 90);
    i0.\u0275\u0275repeaterCreate(16, PostulanteProfile_Conditional_67_For_17_Template, 6, 1, "div", 91, _forTrack1);
    i0.\u0275\u0275conditionalCreate(18, PostulanteProfile_Conditional_67_Conditional_18_Template, 2, 0, "p", 18);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(19, "div", 71)(20, "label", 92);
    i0.\u0275\u0275text(21, "Otras herramientas y conocimientos");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(22, "textarea", 93);
    i0.\u0275\u0275twoWayListener("ngModelChange", function PostulanteProfile_Conditional_67_Template_textarea_ngModelChange_22_listener($event) {
      i0.\u0275\u0275restoreView(_r17);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      i0.\u0275\u0275twoWayBindingSet(ctx_r1.tempOtrasHabilidades, $event) || (ctx_r1.tempOtrasHabilidades = $event);
      return i0.\u0275\u0275resetView($event);
    });
    i0.\u0275\u0275elementEnd()()();
    i0.\u0275\u0275elementStart(23, "div", 76)(24, "button", 77);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_67_Template_button_click_24_listener() {
      i0.\u0275\u0275restoreView(_r17);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.cerrarModal());
    });
    i0.\u0275\u0275text(25, "Cancelar");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(26, "button", 78);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_67_Template_button_click_26_listener() {
      i0.\u0275\u0275restoreView(_r17);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.guardarSkills());
    });
    i0.\u0275\u0275text(27, "\u{1F4BE} Guardar habilidades");
    i0.\u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(14);
    i0.\u0275\u0275twoWayProperty("ngModel", ctx_r1.busquedaSkill);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275repeater(ctx_r1.categoriasFiltradas);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275conditional(ctx_r1.categoriasFiltradas.length === 0 ? 18 : -1);
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275twoWayProperty("ngModel", ctx_r1.tempOtrasHabilidades);
  }
}
function PostulanteProfile_Conditional_68_Template(rf, ctx) {
  if (rf & 1) {
    const _r21 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 66);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_68_Template_div_click_0_listener() {
      i0.\u0275\u0275restoreView(_r21);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.cerrarModal());
    });
    i0.\u0275\u0275elementStart(1, "div", 67);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_68_Template_div_click_1_listener($event) {
      return $event.stopPropagation();
    });
    i0.\u0275\u0275elementStart(2, "div", 68)(3, "div")(4, "h2");
    i0.\u0275\u0275text(5, "\u{1F310} Redes y Portafolio");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(6, "p");
    i0.\u0275\u0275text(7, "Agreg\xE1 los enlaces donde las empresas puedan conocer tu trabajo.");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(8, "button", 69);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_68_Template_button_click_8_listener() {
      i0.\u0275\u0275restoreView(_r21);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.cerrarModal());
    });
    i0.\u0275\u0275text(9, "\u2715");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(10, "div", 70)(11, "div", 71)(12, "label", 97);
    i0.\u0275\u0275text(13, "\u{1F4C1} GitHub");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(14, "input", 98);
    i0.\u0275\u0275twoWayListener("ngModelChange", function PostulanteProfile_Conditional_68_Template_input_ngModelChange_14_listener($event) {
      i0.\u0275\u0275restoreView(_r21);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      i0.\u0275\u0275twoWayBindingSet(ctx_r1.tempRedes.github, $event) || (ctx_r1.tempRedes.github = $event);
      return i0.\u0275\u0275resetView($event);
    });
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(15, "div", 71)(16, "label", 99);
    i0.\u0275\u0275text(17, "\u{1F4BC} LinkedIn");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(18, "input", 100);
    i0.\u0275\u0275twoWayListener("ngModelChange", function PostulanteProfile_Conditional_68_Template_input_ngModelChange_18_listener($event) {
      i0.\u0275\u0275restoreView(_r21);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      i0.\u0275\u0275twoWayBindingSet(ctx_r1.tempRedes.linkedin, $event) || (ctx_r1.tempRedes.linkedin = $event);
      return i0.\u0275\u0275resetView($event);
    });
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(19, "div", 71)(20, "label", 101);
    i0.\u0275\u0275text(21, "\u{1F310} Web / Portafolio");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(22, "input", 102);
    i0.\u0275\u0275twoWayListener("ngModelChange", function PostulanteProfile_Conditional_68_Template_input_ngModelChange_22_listener($event) {
      i0.\u0275\u0275restoreView(_r21);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      i0.\u0275\u0275twoWayBindingSet(ctx_r1.tempRedes.portfolio, $event) || (ctx_r1.tempRedes.portfolio = $event);
      return i0.\u0275\u0275resetView($event);
    });
    i0.\u0275\u0275elementEnd()()();
    i0.\u0275\u0275elementStart(23, "div", 76)(24, "button", 77);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_68_Template_button_click_24_listener() {
      i0.\u0275\u0275restoreView(_r21);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.cerrarModal());
    });
    i0.\u0275\u0275text(25, "Cancelar");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(26, "button", 78);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_68_Template_button_click_26_listener() {
      i0.\u0275\u0275restoreView(_r21);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.guardarRedes());
    });
    i0.\u0275\u0275text(27, "\u{1F4BE} Guardar enlaces");
    i0.\u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(14);
    i0.\u0275\u0275twoWayProperty("ngModel", ctx_r1.tempRedes.github);
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275twoWayProperty("ngModel", ctx_r1.tempRedes.linkedin);
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275twoWayProperty("ngModel", ctx_r1.tempRedes.portfolio);
  }
}
function PostulanteProfile_Conditional_69_Template(rf, ctx) {
  if (rf & 1) {
    const _r22 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 103);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_69_Template_div_click_0_listener() {
      i0.\u0275\u0275restoreView(_r22);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.cerrarVistaPreviaCV());
    });
    i0.\u0275\u0275elementStart(1, "div", 104);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_69_Template_div_click_1_listener($event) {
      return $event.stopPropagation();
    });
    i0.\u0275\u0275elementStart(2, "div", 68)(3, "div")(4, "h2");
    i0.\u0275\u0275text(5, "\u{1F441}\uFE0F Vista previa del CV");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(6, "p");
    i0.\u0275\u0275text(7);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(8, "button", 69);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_69_Template_button_click_8_listener() {
      i0.\u0275\u0275restoreView(_r22);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.cerrarVistaPreviaCV());
    });
    i0.\u0275\u0275text(9, "\u2715");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(10, "div", 105);
    i0.\u0275\u0275element(11, "iframe", 106);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(12, "div", 76)(13, "button", 77);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_69_Template_button_click_13_listener() {
      i0.\u0275\u0275restoreView(_r22);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.cerrarVistaPreviaCV());
    });
    i0.\u0275\u0275text(14, "Cerrar");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(15, "button", 78);
    i0.\u0275\u0275listener("click", function PostulanteProfile_Conditional_69_Template_button_click_15_listener() {
      i0.\u0275\u0275restoreView(_r22);
      const ctx_r1 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r1.descargarCV());
    });
    i0.\u0275\u0275text(16, "\u2B07\uFE0F Descargar PDF");
    i0.\u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(7);
    i0.\u0275\u0275textInterpolate(ctx_r1.perfil.cv_nombre || "Curriculum Vitae");
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275property("src", ctx_r1.cvPreviewUrl, i0.\u0275\u0275sanitizeResourceUrl);
  }
}
function inicializarPerfilPostulante() {
  return {
    nombres: "",
    apellidos: "",
    email: "",
    carrera: "",
    foto: "",
    ciudad: "",
    pais: "",
    sobre_mi: "",
    especialidad: "",
    estado_academico: "Estudiante Avanzado",
    cv_url: "",
    cv_nombre: "",
    skills: [],
    otras_habilidades: "",
    redes: {
      github: "",
      linkedin: "",
      portfolio: ""
    }
  };
}
var PostulanteProfile = class _PostulanteProfile {
  // SERVICIOS
  postulanteService = inject(PostulanteService);
  platformId = inject(PLATFORM_ID);
  router = inject(Router);
  route = inject(ActivatedRoute);
  location = inject(Location);
  sanitizer = inject(DomSanitizer);
  cdr = inject(ChangeDetectorRef);
  // 1. RECEPTOR DE ID DESDE PANEL-ADMIN O PADRE
  idPostulanteInput;
  esModoAdmin = false;
  // BANDERAS DE NAVEGACIÓN Y PERMISOS
  esVisitante = false;
  idPostulanteAObtener = 0;
  // DATOS DEL USUARIO
  perfil = inicializarPerfilPostulante();
  // ESTADOS
  guardando = false;
  mensajeEstado = null;
  mostrarVistaPreviaCV = false;
  cvPreviewUrl = null;
  // MODALES
  modalActivo = null;
  // SKILLS
  categoriasSkills = [];
  tempSkillsIds = [];
  tempOtrasHabilidades = "";
  busquedaSkill = "";
  // FOTO
  archivoFotoSeleccionado = null;
  fotoPreview = null;
  // FORMULARIOS TEMPORALES
  tempUbicacion = {
    ciudad: "",
    pais: ""
  };
  tempSobreMi = {
    sobre_mi: "",
    especialidad: "",
    estado_academico: ""
  };
  tempRedes = {
    github: "",
    linkedin: "",
    portfolio: ""
  };
  ngOnInit() {
    this.evaluarYcargarDatos();
  }
  // Detecta cambios si el admin selecciona a otro postulante de la lista
  ngOnChanges(changes) {
    if (changes["idPostulanteInput"] && !changes["idPostulanteInput"].firstChange) {
      const nuevoId = changes["idPostulanteInput"].currentValue;
      if (nuevoId) {
        this.esVisitante = true;
        this.idPostulanteAObtener = Number(nuevoId);
        this.obtenerDatosDelPostulante();
        this.cargarCatalogoSkills();
      }
    }
  }
  evaluarYcargarDatos() {
    const idParam = this.route.snapshot.paramMap.get("id");
    if (this.idPostulanteInput) {
      this.esVisitante = true;
      this.idPostulanteAObtener = Number(this.idPostulanteInput);
    } else if (idParam) {
      this.esVisitante = true;
      this.idPostulanteAObtener = Number(idParam);
    } else {
      this.esVisitante = false;
      this.idPostulanteAObtener = this.obtenerIdDeSesion();
    }
    if (this.idPostulanteAObtener) {
      this.obtenerDatosDelPostulante();
      this.cargarCatalogoSkills();
    }
  }
  obtenerIdDeSesion() {
    if (isPlatformBrowser(this.platformId)) {
      const usuarioSesion = localStorage.getItem("usuario");
      if (usuarioSesion) {
        try {
          const userObj = JSON.parse(usuarioSesion);
          return userObj.id_postulante || userObj.id || 1;
        } catch (error) {
          console.error("Error al leer usuario de localStorage:", error);
        }
      }
    }
    return 1;
  }
  volver() {
    this.location.back();
  }
  // ==========================================
  // GESTIÓN DE CURRICULUM VITAE
  // ==========================================
  obtenerUrlCV() {
    if (!this.perfil?.cv_url)
      return null;
    const backendUrl = "http://localhost:3000";
    return this.perfil.cv_url.startsWith("http") ? this.perfil.cv_url : `${backendUrl}${this.perfil.cv_url}`;
  }
  irACurriculum() {
    if (this.esVisitante)
      return;
    this.router.navigate(["/perfil/curriculum"]);
  }
  verCV() {
    const rawUrl = this.obtenerUrlCV();
    if (rawUrl) {
      this.cvPreviewUrl = this.sanitizer.bypassSecurityTrustResourceUrl(rawUrl);
      this.mostrarVistaPreviaCV = true;
      this.cdr.detectChanges();
    } else {
      this.irACurriculum();
    }
  }
  cerrarVistaPreviaCV() {
    this.mostrarVistaPreviaCV = false;
    this.cvPreviewUrl = null;
  }
  async descargarCV() {
    const url = this.obtenerUrlCV();
    if (!url) {
      this.irACurriculum();
      return;
    }
    try {
      const respuesta = await fetch(url);
      const blob = await respuesta.blob();
      const blobUrl = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = blobUrl;
      link.download = this.perfil.cv_nombre || `CV_${this.perfil.nombres}_${this.perfil.apellidos}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(blobUrl);
    } catch (error) {
      console.error("Error al descargar el PDF:", error);
      window.open(url, "_blank");
    }
  }
  // ==========================================
  // FOTO DE PERFIL
  // ==========================================
  getFotoUrl() {
    if (this.fotoPreview) {
      return this.fotoPreview;
    }
    if (this.perfil?.foto) {
      const foto = this.perfil.foto;
      if (foto.startsWith("http") || foto.startsWith("data:")) {
        return foto;
      }
      const rutaLimpia = foto.startsWith("/") ? foto : `/${foto}`;
      return `http://localhost:3000${rutaLimpia}`;
    }
    return "assets/img/default-avatar.png";
  }
  onFotoError(event) {
    const imgElement = event.target;
    imgElement.src = "assets/img/default-avatar.png";
  }
  onFotoSeleccionada(event) {
    if (this.esVisitante)
      return;
    const input = event.target;
    if (!input.files || !input.files[0])
      return;
    const file = input.files[0];
    if (!file.type.startsWith("image/")) {
      alert("Por favor seleccion\xE1 una imagen v\xE1lida.");
      input.value = "";
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      alert("La imagen no debe superar los 2MB.");
      input.value = "";
      return;
    }
    this.archivoFotoSeleccionado = file;
    const reader = new FileReader();
    reader.onload = () => {
      this.fotoPreview = reader.result;
      this.subirFotoPerfil();
    };
    reader.readAsDataURL(file);
  }
  subirFotoPerfil() {
    if (!this.archivoFotoSeleccionado || !this.idPostulanteAObtener)
      return;
    this.postulanteService.subirFotoPerfil(this.idPostulanteAObtener, this.archivoFotoSeleccionado).subscribe({
      next: (res) => {
        if (res.success) {
          this.perfil.foto = res.fotoUrl || res.data || "";
          this.archivoFotoSeleccionado = null;
          this.fotoPreview = null;
          alert("\xA1Foto de perfil actualizada!");
          this.cdr.detectChanges();
        } else {
          alert(res.message || "No se pudo subir la foto.");
          this.fotoPreview = null;
        }
      },
      error: (err) => {
        console.error("Error al subir foto:", err);
        this.fotoPreview = null;
        alert(err?.error?.message || "Ocurri\xF3 un error al subir la foto de perfil.");
      }
    });
  }
  // ==========================================
  // OBTENER Y GUARDAR PERFIL
  // ==========================================
  obtenerDatosDelPostulante() {
    if (!this.idPostulanteAObtener)
      return;
    this.postulanteService.getPerfil(this.idPostulanteAObtener).subscribe({
      next: (res) => {
        if (res.success && res.data) {
          this.perfil = __spreadProps(__spreadValues(__spreadValues({}, inicializarPerfilPostulante()), res.data), {
            skills: res.data.skills || [],
            redes: res.data.redes || { github: "", linkedin: "", portfolio: "" }
          });
        }
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error("Error al obtener perfil:", err);
        this.cdr.detectChanges();
      }
    });
  }
  guardarPerfilCompleto() {
    if (!this.idPostulanteAObtener) {
      alert("No se identific\xF3 la sesi\xF3n del usuario.");
      return;
    }
    this.guardando = true;
    this.mensajeEstado = null;
    this.postulanteService.actualizarPerfil(this.idPostulanteAObtener, this.perfil).subscribe({
      next: (res) => {
        this.guardando = false;
        if (res.success) {
          this.mensajeEstado = "\xA1Perfil guardado con \xE9xito!";
          setTimeout(() => {
            this.mensajeEstado = null;
            this.cdr.detectChanges();
          }, 4e3);
          this.obtenerDatosDelPostulante();
        } else {
          alert(res.message || "No se pudieron guardar los cambios.");
        }
        this.cdr.detectChanges();
      },
      error: (err) => {
        this.guardando = false;
        console.error("Error al guardar perfil:", err);
        alert(err?.error?.message || "Ocurri\xF3 un error al guardar los datos.");
        this.cdr.detectChanges();
      }
    });
  }
  // ==========================================
  // CATÁLOGO Y GESTIÓN DE SKILLS
  // ==========================================
  get categoriasFiltradas() {
    if (!this.busquedaSkill || !this.busquedaSkill.trim()) {
      return this.categoriasSkills;
    }
    const busqueda = this.busquedaSkill.toLowerCase().trim();
    return this.categoriasSkills.map((cat) => __spreadProps(__spreadValues({}, cat), {
      skills: cat.skills.filter((s) => s.nombre.toLowerCase().includes(busqueda))
    })).filter((cat) => cat.skills.length > 0);
  }
  cargarCatalogoSkills() {
    this.postulanteService.getCatalogoSkills().subscribe({
      next: (res) => {
        if (res.success) {
          this.categoriasSkills = res.data;
          this.cdr.detectChanges();
        }
      },
      error: (err) => console.error("Error al cargar skills:", err)
    });
  }
  toggleSkill(skillId) {
    const idx = this.tempSkillsIds.indexOf(skillId);
    if (idx > -1) {
      this.tempSkillsIds.splice(idx, 1);
    } else {
      this.tempSkillsIds.push(skillId);
    }
  }
  esSkillSeleccionada(skillId) {
    return this.tempSkillsIds.includes(skillId);
  }
  // ==========================================
  // LÓGICA DE MODALES
  // ==========================================
  abrirModal(tipo) {
    if (this.esVisitante)
      return;
    this.modalActivo = tipo;
    switch (tipo) {
      case "principales":
        this.tempUbicacion = {
          ciudad: this.perfil.ciudad,
          pais: this.perfil.pais
        };
        break;
      case "sobreMi":
        this.tempSobreMi = {
          sobre_mi: this.perfil.sobre_mi || "",
          especialidad: this.perfil.especialidad || "",
          estado_academico: this.perfil.estado_academico || "Estudiante Avanzado"
        };
        break;
      case "skills":
        this.busquedaSkill = "";
        this.tempSkillsIds = this.perfil.skills.map((s) => s.skill_id);
        this.tempOtrasHabilidades = this.perfil.otras_habilidades || "";
        break;
      case "redes":
        this.tempRedes = __spreadValues({}, this.perfil.redes);
        break;
    }
  }
  cerrarModal() {
    this.modalActivo = null;
  }
  // ==========================================
  // MÉTODOS DE GUARDADO DESDE MODALES
  // ==========================================
  guardarUbicacion() {
    this.perfil.ciudad = this.tempUbicacion.ciudad;
    this.perfil.pais = this.tempUbicacion.pais;
    this.guardarPerfilCompleto();
    this.cerrarModal();
  }
  guardarSobreMi() {
    this.perfil.sobre_mi = this.tempSobreMi.sobre_mi;
    this.perfil.especialidad = this.tempSobreMi.especialidad;
    this.perfil.estado_academico = this.tempSobreMi.estado_academico;
    this.guardarPerfilCompleto();
    this.cerrarModal();
  }
  guardarSkills() {
    const todasLasSkills = [];
    this.categoriasSkills.forEach((cat) => todasLasSkills.push(...cat.skills));
    this.perfil.skills = todasLasSkills.filter((s) => this.tempSkillsIds.includes(s.skill_id));
    this.perfil.otras_habilidades = this.tempOtrasHabilidades;
    this.guardarPerfilCompleto();
    this.cerrarModal();
  }
  guardarSkillsModal() {
    this.guardarSkills();
  }
  guardarRedes() {
    this.perfil.redes = __spreadValues({}, this.tempRedes);
    this.guardarPerfilCompleto();
    this.cerrarModal();
  }
  static \u0275fac = function PostulanteProfile_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _PostulanteProfile)();
  };
  static \u0275cmp = /* @__PURE__ */ i0.\u0275\u0275defineComponent({ type: _PostulanteProfile, selectors: [["app-postulante-profile"]], inputs: { idPostulanteInput: "idPostulanteInput", esModoAdmin: "esModoAdmin" }, features: [i0.\u0275\u0275NgOnChangesFeature], decls: 70, vars: 29, consts: [["fotoInput", ""], [1, "perfil-container"], [1, "perfil-card", "card-main"], [1, "foto-container"], [1, "avatar-wrapper"], ["alt", "Foto de Perfil", 1, "foto-avatar", 3, "src"], [1, "avatar-placeholder"], [1, "user-info"], [1, "carrera-text"], [1, "email-text"], [1, "ubicacion"], [1, "acciones-header"], ["type", "button", 1, "btn-secundario"], [1, "alert-success-custom"], [1, "perfil-card", "card-sobre-mi"], [1, "card-header-actions"], ["type", "button", "title", "Editar descripci\xF3n", 1, "btn-link-editar"], [1, "texto-descripcion"], [1, "empty-text"], [1, "resumen-tecnico-grid"], [1, "item-resumen"], [1, "label"], [1, "valor"], [1, "perfil-card", "card-cv"], ["type", "button", "title", "Ir al m\xF3dulo de Curriculum", 1, "btn-link-editar"], [1, "cv-content"], [1, "cv-content", "cv-sin-adjuntar"], [1, "perfil-card", "card-skills"], ["type", "button", "title", "Seleccionar habilidades", 1, "btn-link-editar"], [1, "tags-container"], [1, "tag"], [1, "otras-habilidades-display"], [1, "perfil-card", "card-redes"], ["type", "button", "title", "Editar enlaces", 1, "btn-link-editar"], [1, "links-grid"], ["target", "_blank", "rel", "noopener noreferrer", 1, "link-red", "github", 3, "href"], ["target", "_blank", "rel", "noopener noreferrer", 1, "link-red", "linkedin", 3, "href"], ["target", "_blank", "rel", "noopener noreferrer", 1, "link-red", "portfolio", 3, "href"], [1, "modal-overlay"], [1, "modal-overlay", "cv-preview-overlay"], ["alt", "Foto de Perfil", 1, "foto-avatar", 3, "error", "src"], ["xmlns", "http://www.w3.org/2000/svg", "viewBox", "0 0 24 24", "fill", "currentColor", 1, "icon-user"], ["fill-rule", "evenodd", "d", "M7.5 6a4.5 4.5 0 1 1 9 0a4.5 4.5 0 0 1-9 0ZM3.751 20.105a8.25 8.25 0 0 1 16.498 0 .75.75 0 0 1-.437.695A18.683 18.683 0 0 1 12 22.5c-2.786 0-5.433-.6-7.812-1.7a.75.75 0 0 1-.437-.695Z", "clip-rule", "evenodd"], ["type", "button", "title", "Cambiar foto de perfil", 1, "btn-foto-badge", 3, "click", "disabled"], ["type", "file", "accept", "image/png, image/jpeg, image/jpg", 2, "display", "none", 3, "change"], ["type", "button", 1, "btn-secundario", 3, "click"], ["type", "button", 1, "btn-editar", 3, "click"], ["type", "button", 1, "btn-guardar-main", 3, "click", "disabled"], ["type", "button", "title", "Editar descripci\xF3n", 1, "btn-link-editar", 3, "click"], ["type", "button", "title", "Ir al m\xF3dulo de Curriculum", 1, "btn-link-editar", 3, "click"], [1, "cv-adjunto"], [1, "icono-doc"], [1, "cv-info"], [1, "cv-estado"], [1, "cv-acciones"], ["type", "button", 1, "btn-cv", "btn-vista-previa", 3, "click"], ["type", "button", 1, "btn-cv", "btn-descargar", 3, "click"], ["type", "button", 1, "btn-cv", "btn-cambiar"], ["type", "button", 1, "btn-cv", "btn-cambiar", 3, "click"], [1, "cv-upload-icon"], [1, "cv-descripcion"], ["type", "button", 1, "btn-cv", "btn-primary", 3, "click"], ["type", "button", "title", "Seleccionar habilidades", 1, "btn-link-editar", 3, "click"], [1, "subtitulo-habilidades"], [1, "texto-adicional"], ["type", "button", "title", "Editar enlaces", 1, "btn-link-editar", 3, "click"], [1, "modal-overlay", 3, "click"], [1, "modal-container", 3, "click"], [1, "modal-header"], ["type", "button", 1, "btn-cerrar-modal", 3, "click"], [1, "modal-body"], [1, "form-group"], ["for", "ciudad"], ["id", "ciudad", "type", "text", "placeholder", "Ej. Lan\xFAs", 3, "ngModelChange", "ngModel"], ["for", "pais"], ["id", "pais", "type", "text", "placeholder", "Ej. Argentina", 3, "ngModelChange", "ngModel"], [1, "modal-footer"], ["type", "button", 1, "btn-cancelar", 3, "click"], ["type", "button", 1, "btn-primary", 3, "click"], ["for", "sobreMi"], ["id", "sobreMi", "rows", "5", "placeholder", "Cont\xE1 brevemente tu perfil, intereses y objetivos profesionales...", 3, "ngModelChange", "ngModel"], ["for", "especialidad"], ["id", "especialidad", "type", "text", "placeholder", "Ej. Desarrollo Frontend, An\xE1lisis de Datos...", 3, "ngModelChange", "ngModel"], ["for", "estadoAcademico"], ["id", "estadoAcademico", 3, "ngModelChange", "ngModel"], ["value", "Estudiante Inicial"], ["value", "Estudiante Avanzado"], ["value", "Graduado"], ["for", "busquedaSkill"], ["id", "busquedaSkill", "type", "text", "placeholder", "Ej. Angular, Excel, Python...", 3, "ngModelChange", "ngModel"], [1, "skills-modal-list"], [1, "skill-categoria"], ["for", "otrasHabilidades"], ["id", "otrasHabilidades", "rows", "4", "placeholder", "Pod\xE9s agregar otras herramientas, conocimientos o tecnolog\xEDas...", 3, "ngModelChange", "ngModel"], [1, "skills-checkbox-grid"], [1, "skill-checkbox"], ["type", "checkbox", 3, "change", "checked"], ["for", "github"], ["id", "github", "type", "url", "placeholder", "https://github.com/tuusuario", 3, "ngModelChange", "ngModel"], ["for", "linkedin"], ["id", "linkedin", "type", "url", "placeholder", "https://www.linkedin.com/in/tuusuario", 3, "ngModelChange", "ngModel"], ["for", "portfolio"], ["id", "portfolio", "type", "url", "placeholder", "https://tuportfolio.com", 3, "ngModelChange", "ngModel"], [1, "modal-overlay", "cv-preview-overlay", 3, "click"], [1, "modal-container", "cv-preview-modal", 3, "click"], [1, "cv-preview-container"], ["title", "Vista previa del Curriculum Vitae", 1, "cv-preview-frame", 3, "src"]], template: function PostulanteProfile_Template(rf, ctx) {
    if (rf & 1) {
      i0.\u0275\u0275elementStart(0, "div", 1)(1, "div", 2)(2, "div", 3)(3, "div", 4);
      i0.\u0275\u0275conditionalCreate(4, PostulanteProfile_Conditional_4_Template, 1, 1, "img", 5)(5, PostulanteProfile_Conditional_5_Template, 3, 0, "div", 6);
      i0.\u0275\u0275conditionalCreate(6, PostulanteProfile_Conditional_6_Template, 4, 1);
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(7, "div", 7)(8, "h2");
      i0.\u0275\u0275text(9);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(10, "p", 8);
      i0.\u0275\u0275text(11);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(12, "p", 9);
      i0.\u0275\u0275text(13);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(14, "p", 10);
      i0.\u0275\u0275text(15);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(16, "div", 11);
      i0.\u0275\u0275conditionalCreate(17, PostulanteProfile_Conditional_17_Template, 2, 0, "button", 12)(18, PostulanteProfile_Conditional_18_Template, 5, 2);
      i0.\u0275\u0275elementEnd()()();
      i0.\u0275\u0275conditionalCreate(19, PostulanteProfile_Conditional_19_Template, 2, 1, "div", 13);
      i0.\u0275\u0275elementStart(20, "div", 14)(21, "div", 15)(22, "h3");
      i0.\u0275\u0275text(23, "\u{1F4BB} Perfil Profesional");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275conditionalCreate(24, PostulanteProfile_Conditional_24_Template, 2, 0, "button", 16);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275conditionalCreate(25, PostulanteProfile_Conditional_25_Template, 2, 1, "p", 17)(26, PostulanteProfile_Conditional_26_Template, 3, 1, "p", 18);
      i0.\u0275\u0275elementStart(27, "div", 19)(28, "div", 20)(29, "span", 21);
      i0.\u0275\u0275text(30, "Especialidad / Inter\xE9s:");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(31, "span", 22);
      i0.\u0275\u0275text(32);
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(33, "div", 20)(34, "span", 21);
      i0.\u0275\u0275text(35, "Estado acad\xE9mico:");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(36, "span", 22);
      i0.\u0275\u0275text(37);
      i0.\u0275\u0275elementEnd()()()();
      i0.\u0275\u0275elementStart(38, "div", 23)(39, "div", 15)(40, "h3");
      i0.\u0275\u0275text(41, "\u{1F4C4} Curriculum Vitae");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275conditionalCreate(42, PostulanteProfile_Conditional_42_Template, 2, 0, "button", 24);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275conditionalCreate(43, PostulanteProfile_Conditional_43_Template, 15, 2, "div", 25)(44, PostulanteProfile_Conditional_44_Template, 5, 1, "div", 26);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(45, "div", 27)(46, "div", 15)(47, "h3");
      i0.\u0275\u0275text(48, "\u{1F6E0}\uFE0F Stack T\xE9cnico y Habilidades");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275conditionalCreate(49, PostulanteProfile_Conditional_49_Template, 2, 0, "button", 28);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(50, "div", 29);
      i0.\u0275\u0275repeaterCreate(51, PostulanteProfile_For_52_Template, 2, 1, "span", 30, _forTrack0);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275conditionalCreate(53, PostulanteProfile_Conditional_53_Template, 5, 1, "div", 31);
      i0.\u0275\u0275conditionalCreate(54, PostulanteProfile_Conditional_54_Template, 3, 1, "p", 18);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(55, "div", 32)(56, "div", 15)(57, "h3");
      i0.\u0275\u0275text(58, "\u{1F310} Redes y Portafolio");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275conditionalCreate(59, PostulanteProfile_Conditional_59_Template, 2, 0, "button", 33);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(60, "div", 34);
      i0.\u0275\u0275conditionalCreate(61, PostulanteProfile_Conditional_61_Template, 2, 1, "a", 35);
      i0.\u0275\u0275conditionalCreate(62, PostulanteProfile_Conditional_62_Template, 2, 1, "a", 36);
      i0.\u0275\u0275conditionalCreate(63, PostulanteProfile_Conditional_63_Template, 2, 1, "a", 37);
      i0.\u0275\u0275conditionalCreate(64, PostulanteProfile_Conditional_64_Template, 3, 1, "p", 18);
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275conditionalCreate(65, PostulanteProfile_Conditional_65_Template, 24, 2, "div", 38);
      i0.\u0275\u0275conditionalCreate(66, PostulanteProfile_Conditional_66_Template, 34, 3, "div", 38);
      i0.\u0275\u0275conditionalCreate(67, PostulanteProfile_Conditional_67_Template, 28, 3, "div", 38);
      i0.\u0275\u0275conditionalCreate(68, PostulanteProfile_Conditional_68_Template, 28, 3, "div", 38);
      i0.\u0275\u0275conditionalCreate(69, PostulanteProfile_Conditional_69_Template, 17, 2, "div", 39);
      i0.\u0275\u0275elementEnd();
    }
    if (rf & 2) {
      i0.\u0275\u0275advance(4);
      i0.\u0275\u0275conditional(ctx.perfil.foto || ctx.fotoPreview ? 4 : 5);
      i0.\u0275\u0275advance(2);
      i0.\u0275\u0275conditional(!ctx.esVisitante ? 6 : -1);
      i0.\u0275\u0275advance(3);
      i0.\u0275\u0275textInterpolate2("", ctx.perfil.nombres || "Nombre", " ", ctx.perfil.apellidos || "Apellido");
      i0.\u0275\u0275advance(2);
      i0.\u0275\u0275textInterpolate1("\u{1F393} ", ctx.perfil.carrera || "Carrera no especificada");
      i0.\u0275\u0275advance(2);
      i0.\u0275\u0275textInterpolate1("\u2709\uFE0F ", ctx.perfil.email || "correo@ejemplo.com");
      i0.\u0275\u0275advance(2);
      i0.\u0275\u0275textInterpolate1(" \u{1F4CD} ", ctx.perfil.ciudad ? ctx.perfil.ciudad + (ctx.perfil.pais ? ", " + ctx.perfil.pais : "") : "Ubicaci\xF3n no especificada", " ");
      i0.\u0275\u0275advance(2);
      i0.\u0275\u0275conditional(ctx.esVisitante ? 17 : 18);
      i0.\u0275\u0275advance(2);
      i0.\u0275\u0275conditional(ctx.mensajeEstado && !ctx.esVisitante ? 19 : -1);
      i0.\u0275\u0275advance(5);
      i0.\u0275\u0275conditional(!ctx.esVisitante ? 24 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.perfil.sobre_mi ? 25 : 26);
      i0.\u0275\u0275advance(7);
      i0.\u0275\u0275textInterpolate(ctx.perfil.especialidad || "No definida");
      i0.\u0275\u0275advance(5);
      i0.\u0275\u0275textInterpolate(ctx.perfil.estado_academico || "Estudiante Avanzado");
      i0.\u0275\u0275advance(5);
      i0.\u0275\u0275conditional(!ctx.esVisitante ? 42 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.perfil.cv_url ? 43 : 44);
      i0.\u0275\u0275advance(6);
      i0.\u0275\u0275conditional(!ctx.esVisitante ? 49 : -1);
      i0.\u0275\u0275advance(2);
      i0.\u0275\u0275repeater(ctx.perfil.skills || i0.\u0275\u0275pureFunction0(28, _c0));
      i0.\u0275\u0275advance(2);
      i0.\u0275\u0275conditional(ctx.perfil.otras_habilidades ? 53 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional((ctx.perfil.skills.length || 0) === 0 && !ctx.perfil.otras_habilidades ? 54 : -1);
      i0.\u0275\u0275advance(5);
      i0.\u0275\u0275conditional(!ctx.esVisitante ? 59 : -1);
      i0.\u0275\u0275advance(2);
      i0.\u0275\u0275conditional(ctx.perfil.redes.github ? 61 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.perfil.redes.linkedin ? 62 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.perfil.redes.portfolio ? 63 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(!ctx.perfil.redes.github && !ctx.perfil.redes.linkedin && !ctx.perfil.redes.portfolio ? 64 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.modalActivo === "principales" ? 65 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.modalActivo === "sobreMi" ? 66 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.modalActivo === "skills" ? 67 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.modalActivo === "redes" ? 68 : -1);
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.mostrarVistaPreviaCV && ctx.cvPreviewUrl ? 69 : -1);
    }
  }, dependencies: [CommonModule, i1.NgClass, i1.NgComponentOutlet, i1.NgForOf, i1.NgIf, i1.NgTemplateOutlet, i1.NgStyle, i1.NgSwitch, i1.NgSwitchCase, i1.NgSwitchDefault, i1.NgPlural, i1.NgPluralCase, FormsModule, i2.\u0275NgNoValidate, i2.NgSelectOption, i2.\u0275NgSelectMultipleOption, i2.DefaultValueAccessor, i2.NumberValueAccessor, i2.RangeValueAccessor, i2.CheckboxControlValueAccessor, i2.SelectControlValueAccessor, i2.SelectMultipleControlValueAccessor, i2.RadioControlValueAccessor, i2.NgControlStatus, i2.NgControlStatusGroup, i2.RequiredValidator, i2.MinLengthValidator, i2.MaxLengthValidator, i2.PatternValidator, i2.CheckboxRequiredValidator, i2.EmailValidator, i2.MinValidator, i2.MaxValidator, i2.NgModel, i2.NgModelGroup, i2.NgForm, i1.AsyncPipe, i1.UpperCasePipe, i1.LowerCasePipe, i1.JsonPipe, i1.SlicePipe, i1.DecimalPipe, i1.PercentPipe, i1.TitleCasePipe, i1.CurrencyPipe, i1.DatePipe, i1.I18nPluralPipe, i1.I18nSelectPipe, i1.KeyValuePipe], styles: [`
.perfil-container[_ngcontent-%COMP%] {
  width: 100%;
  max-width: 1180px;
  margin: 2rem auto;
  padding: 0 1rem;
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 1.5rem;
  box-sizing: border-box;
}
@media (max-width: 1024px) {
  .perfil-container[_ngcontent-%COMP%] {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}
@media (max-width: 650px) {
  .perfil-container[_ngcontent-%COMP%] {
    grid-template-columns: 1fr;
    gap: 1rem;
    margin: 1rem auto;
    padding: 0 0.75rem;
  }
}
.alert-success-custom[_ngcontent-%COMP%] {
  grid-column: 1/-1;
  width: 100%;
  padding: 0.85rem 1.25rem;
  background-color: #d1fae5;
  border-left: 4px solid #16a34a;
  color: #166534;
  border-radius: 12px;
  font-weight: 600;
  font-size: 0.95rem;
  box-sizing: border-box;
  animation: _ngcontent-%COMP%_slideDown 0.3s ease-in-out;
}
.empty-text[_ngcontent-%COMP%] {
  color: #607080;
  font-size: 0.9rem;
  font-style: italic;
  margin: 0.5rem 0;
  line-height: 1.5;
}
.perfil-card[_ngcontent-%COMP%] {
  background: #ffffff;
  border: 1px solid #c9dfef;
  border-radius: 20px;
  padding: 1.5rem;
  box-shadow: 0 8px 20px rgba(13, 79, 139, 0.05);
  min-width: 0;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
}
.perfil-card[_ngcontent-%COMP%]   .card-header-actions[_ngcontent-%COMP%] {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 1rem;
  margin-bottom: 1.2rem;
  padding-bottom: 0.6rem;
  border-bottom: 2px solid #e7f2fa;
}
.perfil-card[_ngcontent-%COMP%]   .card-header-actions[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {
  color: #0d4f8b;
  font-size: 1.2rem;
  font-weight: 700;
  margin: 0;
}
.perfil-card[_ngcontent-%COMP%]   .card-header-actions[_ngcontent-%COMP%]   .btn-link-editar[_ngcontent-%COMP%] {
  background: transparent;
  border: none;
  cursor: pointer;
  font-size: 1.1rem;
  color: #0d4f8b;
  padding: 0.25rem;
  transition: transform 0.2s ease, color 0.2s ease;
}
.perfil-card[_ngcontent-%COMP%]   .card-header-actions[_ngcontent-%COMP%]   .btn-link-editar[_ngcontent-%COMP%]:hover {
  color: #1976a8;
  transform: scale(1.15);
}
.card-main[_ngcontent-%COMP%] {
  grid-column: 1/-1;
  display: flex;
  align-items: center;
  gap: 2rem;
}
@media (max-width: 650px) {
  .card-main[_ngcontent-%COMP%] {
    flex-direction: column;
    text-align: center;
    gap: 1.25rem;
  }
}
.card-main[_ngcontent-%COMP%]   .foto-container[_ngcontent-%COMP%] {
  display: flex;
  flex-direction: column;
  align-items: center;
  flex-shrink: 0;
}
.card-main[_ngcontent-%COMP%]   .foto-container[_ngcontent-%COMP%]   .avatar-wrapper[_ngcontent-%COMP%] {
  position: relative;
  width: 125px;
  height: 125px;
}
.card-main[_ngcontent-%COMP%]   .foto-container[_ngcontent-%COMP%]   .avatar-wrapper[_ngcontent-%COMP%]   .foto-avatar[_ngcontent-%COMP%] {
  width: 100%;
  height: 100%;
  border-radius: 50%;
  object-fit: cover;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
  border: 3px solid #ffffff;
}
.card-main[_ngcontent-%COMP%]   .foto-container[_ngcontent-%COMP%]   .avatar-wrapper[_ngcontent-%COMP%]   .avatar-placeholder[_ngcontent-%COMP%] {
  width: 100%;
  height: 100%;
  border-radius: 50%;
  background-color: #e7f2fa;
  border: 3px solid #ffffff;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
  display: flex;
  align-items: center;
  justify-content: center;
}
.card-main[_ngcontent-%COMP%]   .foto-container[_ngcontent-%COMP%]   .avatar-wrapper[_ngcontent-%COMP%]   .avatar-placeholder[_ngcontent-%COMP%]   .icon-user[_ngcontent-%COMP%] {
  width: 65px;
  height: 65px;
  fill: #0d4f8b;
  opacity: 0.55;
}
.card-main[_ngcontent-%COMP%]   .foto-container[_ngcontent-%COMP%]   .avatar-wrapper[_ngcontent-%COMP%]   .btn-foto-badge[_ngcontent-%COMP%] {
  position: absolute;
  bottom: 2px;
  right: 2px;
  width: 36px;
  height: 36px;
  border-radius: 50%;
  background-color: #0d4f8b;
  border: 2px solid #ffffff;
  color: #ffffff;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  font-size: 0.95rem;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
  transition: all 0.2s ease;
}
.card-main[_ngcontent-%COMP%]   .foto-container[_ngcontent-%COMP%]   .avatar-wrapper[_ngcontent-%COMP%]   .btn-foto-badge[_ngcontent-%COMP%]:hover:not(:disabled) {
  background-color: #1976a8;
  transform: scale(1.1);
}
.card-main[_ngcontent-%COMP%]   .foto-container[_ngcontent-%COMP%]   .avatar-wrapper[_ngcontent-%COMP%]   .btn-foto-badge[_ngcontent-%COMP%]:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}
.card-main[_ngcontent-%COMP%]   .user-info[_ngcontent-%COMP%] {
  flex: 1;
  min-width: 0;
}
.card-main[_ngcontent-%COMP%]   .user-info[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {
  margin: 0 0 0.25rem;
  color: #0d4f8b;
  font-size: 1.6rem;
  font-weight: 700;
}
.card-main[_ngcontent-%COMP%]   .user-info[_ngcontent-%COMP%]   .carrera-text[_ngcontent-%COMP%] {
  margin: 0 0 0.4rem;
  color: #0d4f8b;
  font-size: 0.95rem;
  font-weight: 600;
}
.card-main[_ngcontent-%COMP%]   .user-info[_ngcontent-%COMP%]   .email-text[_ngcontent-%COMP%] {
  margin: 0 0 0.4rem;
  color: #607080;
  font-size: 0.95rem;
}
.card-main[_ngcontent-%COMP%]   .user-info[_ngcontent-%COMP%]   .ubicacion[_ngcontent-%COMP%] {
  margin: 0 0 1.25rem;
  color: #0d4f8b;
  font-size: 0.95rem;
  font-weight: 500;
}
.card-main[_ngcontent-%COMP%]   .user-info[_ngcontent-%COMP%]   .acciones-header[_ngcontent-%COMP%] {
  display: flex;
  flex-wrap: wrap;
  gap: 0.75rem;
  align-items: center;
}
@media (max-width: 650px) {
  .card-main[_ngcontent-%COMP%]   .user-info[_ngcontent-%COMP%]   .acciones-header[_ngcontent-%COMP%] {
    justify-content: center;
  }
}
.card-sobre-mi[_ngcontent-%COMP%] {
  grid-column: span 2;
}
@media (max-width: 1024px) {
  .card-sobre-mi[_ngcontent-%COMP%] {
    grid-column: 1/-1;
  }
}
.card-sobre-mi[_ngcontent-%COMP%]   .texto-descripcion[_ngcontent-%COMP%] {
  color: #607080;
  line-height: 1.6;
  margin-bottom: 1.25rem;
  font-size: 0.95rem;
}
.card-sobre-mi[_ngcontent-%COMP%]   .resumen-tecnico-grid[_ngcontent-%COMP%] {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 1rem;
  margin-top: 1rem;
}
@media (max-width: 500px) {
  .card-sobre-mi[_ngcontent-%COMP%]   .resumen-tecnico-grid[_ngcontent-%COMP%] {
    grid-template-columns: 1fr;
  }
}
.card-sobre-mi[_ngcontent-%COMP%]   .resumen-tecnico-grid[_ngcontent-%COMP%]   .item-resumen[_ngcontent-%COMP%] {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
  background: #f8fafc;
  border: 1px solid #c9dfef;
  border-left: 4px solid #0d4f8b;
  padding: 0.85rem 1rem;
  border-radius: 12px;
}
.card-sobre-mi[_ngcontent-%COMP%]   .resumen-tecnico-grid[_ngcontent-%COMP%]   .item-resumen[_ngcontent-%COMP%]   .label[_ngcontent-%COMP%] {
  font-size: 0.75rem;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: #607080;
  font-weight: 700;
}
.card-sobre-mi[_ngcontent-%COMP%]   .resumen-tecnico-grid[_ngcontent-%COMP%]   .item-resumen[_ngcontent-%COMP%]   .valor[_ngcontent-%COMP%] {
  font-size: 0.95rem;
  font-weight: 600;
  color: #0d4f8b;
}
.card-cv[_ngcontent-%COMP%] {
  grid-column: span 1;
}
@media (max-width: 1024px) {
  .card-cv[_ngcontent-%COMP%] {
    grid-column: 1/-1;
  }
}
.card-cv[_ngcontent-%COMP%]   .cv-content[_ngcontent-%COMP%] {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}
.card-cv[_ngcontent-%COMP%]   .cv-content[_ngcontent-%COMP%]   .cv-adjunto[_ngcontent-%COMP%] {
  display: flex;
  align-items: center;
  gap: 0.85rem;
  background-color: #e7f2fa;
  padding: 0.85rem 1rem;
  border-radius: 12px;
  border: 1px solid #c9dfef;
}
.card-cv[_ngcontent-%COMP%]   .cv-content[_ngcontent-%COMP%]   .cv-adjunto[_ngcontent-%COMP%]   .icono-doc[_ngcontent-%COMP%] {
  font-size: 1.6rem;
  color: #0d4f8b;
}
.card-cv[_ngcontent-%COMP%]   .cv-content[_ngcontent-%COMP%]   .cv-adjunto[_ngcontent-%COMP%]   .cv-info[_ngcontent-%COMP%] {
  display: flex;
  flex-direction: column;
}
.card-cv[_ngcontent-%COMP%]   .cv-content[_ngcontent-%COMP%]   .cv-adjunto[_ngcontent-%COMP%]   .cv-info[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {
  font-size: 0.9rem;
  color: #0d4f8b;
  word-break: break-all;
}
.card-cv[_ngcontent-%COMP%]   .cv-content[_ngcontent-%COMP%]   .cv-adjunto[_ngcontent-%COMP%]   .cv-info[_ngcontent-%COMP%]   .cv-estado[_ngcontent-%COMP%] {
  font-size: 0.8rem;
  color: #16a34a;
  font-weight: 600;
}
.card-cv[_ngcontent-%COMP%]   .cv-content[_ngcontent-%COMP%]   .cv-acciones[_ngcontent-%COMP%] {
  display: flex;
  flex-direction: column;
  gap: 0.6rem;
}
.card-cv[_ngcontent-%COMP%]   .cv-content[_ngcontent-%COMP%]   .cv-acciones[_ngcontent-%COMP%]   .btn-cv[_ngcontent-%COMP%] {
  width: 100%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  padding: 0.65rem 1rem;
  border-radius: 12px;
  font-weight: 600;
  font-size: 0.88rem;
  cursor: pointer;
  transition: all 0.2s ease;
  border: none;
}
.card-cv[_ngcontent-%COMP%]   .cv-content[_ngcontent-%COMP%]   .cv-acciones[_ngcontent-%COMP%]   .btn-cv.btn-vista-previa[_ngcontent-%COMP%] {
  background-color: #0d4f8b;
  color: #ffffff;
}
.card-cv[_ngcontent-%COMP%]   .cv-content[_ngcontent-%COMP%]   .cv-acciones[_ngcontent-%COMP%]   .btn-cv.btn-vista-previa[_ngcontent-%COMP%]:hover {
  background-color: #1976a8;
}
.card-cv[_ngcontent-%COMP%]   .cv-content[_ngcontent-%COMP%]   .cv-acciones[_ngcontent-%COMP%]   .btn-cv.btn-descargar[_ngcontent-%COMP%] {
  background-color: #e7f2fa;
  color: #0d4f8b;
  border: 1px solid #c9dfef;
}
.card-cv[_ngcontent-%COMP%]   .cv-content[_ngcontent-%COMP%]   .cv-acciones[_ngcontent-%COMP%]   .btn-cv.btn-descargar[_ngcontent-%COMP%]:hover {
  background-color: #d9ebf7;
}
.card-cv[_ngcontent-%COMP%]   .cv-content[_ngcontent-%COMP%]   .cv-acciones[_ngcontent-%COMP%]   .btn-cv.btn-cambiar[_ngcontent-%COMP%] {
  background-color: transparent;
  color: #607080;
  border: 1px dashed #dbe5ec;
}
.card-cv[_ngcontent-%COMP%]   .cv-content[_ngcontent-%COMP%]   .cv-acciones[_ngcontent-%COMP%]   .btn-cv.btn-cambiar[_ngcontent-%COMP%]:hover {
  background-color: #f8fafc;
  color: #0d4f8b;
}
.card-cv[_ngcontent-%COMP%]   .cv-content.cv-sin-adjuntar[_ngcontent-%COMP%] {
  text-align: center;
  padding: 1rem 0;
}
.card-cv[_ngcontent-%COMP%]   .cv-content.cv-sin-adjuntar[_ngcontent-%COMP%]   .cv-upload-icon[_ngcontent-%COMP%] {
  font-size: 2.5rem;
  margin-bottom: 0.5rem;
}
.card-cv[_ngcontent-%COMP%]   .cv-content.cv-sin-adjuntar[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {
  margin: 0 0 0.25rem 0;
  color: #0d4f8b;
}
.card-cv[_ngcontent-%COMP%]   .cv-content.cv-sin-adjuntar[_ngcontent-%COMP%]   .cv-descripcion[_ngcontent-%COMP%] {
  color: #607080;
  font-size: 0.85rem;
  margin-bottom: 1rem;
}
.card-skills[_ngcontent-%COMP%] {
  grid-column: span 1;
}
.card-skills[_ngcontent-%COMP%]   .otras-habilidades-display[_ngcontent-%COMP%] {
  margin-top: 1rem;
  padding-top: 0.75rem;
  border-top: 1px dashed #c9dfef;
}
.card-skills[_ngcontent-%COMP%]   .otras-habilidades-display[_ngcontent-%COMP%]   .subtitulo-habilidades[_ngcontent-%COMP%] {
  font-size: 0.8rem;
  font-weight: 700;
  color: #0d4f8b;
  text-transform: uppercase;
  margin: 0 0 0.35rem 0;
}
.card-skills[_ngcontent-%COMP%]   .otras-habilidades-display[_ngcontent-%COMP%]   .texto-adicional[_ngcontent-%COMP%] {
  font-size: 0.88rem;
  color: #607080;
  margin: 0;
  line-height: 1.4;
}
.tags-container[_ngcontent-%COMP%] {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
}
.tags-container[_ngcontent-%COMP%]   .tag[_ngcontent-%COMP%] {
  background-color: #e7f2fa;
  color: #0d4f8b;
  padding: 0.4rem 0.8rem;
  border-radius: 12px;
  font-size: 0.85rem;
  font-weight: 600;
  border: 1px solid #c9dfef;
}
.card-redes[_ngcontent-%COMP%] {
  grid-column: span 1;
}
.card-redes[_ngcontent-%COMP%]   .links-grid[_ngcontent-%COMP%] {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}
.card-redes[_ngcontent-%COMP%]   .links-grid[_ngcontent-%COMP%]   .link-red[_ngcontent-%COMP%] {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  font-weight: 600;
  color: #0d4f8b;
  text-decoration: none;
  padding: 0.55rem 0.85rem;
  border-radius: 10px;
  background-color: #e7f2fa;
  border: 1px solid #c9dfef;
  transition: all 0.2s ease;
}
.card-redes[_ngcontent-%COMP%]   .links-grid[_ngcontent-%COMP%]   .link-red[_ngcontent-%COMP%]:hover {
  background-color: #d9ebf7;
  color: #1976a8;
  transform: translateX(3px);
}
.btn-editar[_ngcontent-%COMP%], 
.btn-primary[_ngcontent-%COMP%], 
.btn-guardar-main[_ngcontent-%COMP%] {
  background-color: #16a34a;
  color: #ffffff;
  border: none;
  padding: 0.65rem 1.25rem;
  border-radius: 12px;
  cursor: pointer;
  font-weight: 700;
  transition: all 0.2s ease;
}
.btn-editar[_ngcontent-%COMP%]:hover:not(:disabled), 
.btn-primary[_ngcontent-%COMP%]:hover:not(:disabled), 
.btn-guardar-main[_ngcontent-%COMP%]:hover:not(:disabled) {
  background-color: #15803d;
  transform: translateY(-1px);
}
.btn-editar[_ngcontent-%COMP%]:disabled, 
.btn-primary[_ngcontent-%COMP%]:disabled, 
.btn-guardar-main[_ngcontent-%COMP%]:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}
.btn-editar[_ngcontent-%COMP%] {
  background-color: #0d4f8b;
}
.btn-editar[_ngcontent-%COMP%]:hover:not(:disabled) {
  background-color: #1976a8;
}
.btn-secundario[_ngcontent-%COMP%], 
.btn-cancelar[_ngcontent-%COMP%] {
  background-color: #e7f2fa;
  color: #0d4f8b;
  border: 1px solid #c9dfef;
  padding: 0.65rem 1.25rem;
  border-radius: 12px;
  cursor: pointer;
  font-weight: 600;
  transition: all 0.2s ease;
}
.btn-secundario[_ngcontent-%COMP%]:hover, 
.btn-cancelar[_ngcontent-%COMP%]:hover {
  background-color: #d9ebf7;
  border-color: #1976a8;
}
.modal-overlay[_ngcontent-%COMP%] {
  position: fixed;
  inset: 0;
  width: 100vw;
  height: 100vh;
  background: rgba(5, 30, 55, 0.6);
  -webkit-backdrop-filter: blur(4px);
  backdrop-filter: blur(4px);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  padding: 1rem;
  box-sizing: border-box;
}
.modal-overlay[_ngcontent-%COMP%]   .modal-container[_ngcontent-%COMP%] {
  background: #ffffff;
  border-radius: 20px;
  width: 100%;
  max-width: 580px;
  max-height: 90vh;
  display: flex;
  flex-direction: column;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
  overflow: hidden;
}
.modal-overlay[_ngcontent-%COMP%]   .modal-container[_ngcontent-%COMP%]   .modal-header[_ngcontent-%COMP%] {
  flex-shrink: 0;
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 1rem;
  border-bottom: 1px solid #c9dfef;
  padding: 1.25rem 1.5rem;
}
.modal-overlay[_ngcontent-%COMP%]   .modal-container[_ngcontent-%COMP%]   .modal-header[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {
  margin: 0;
  font-size: 1.25rem;
  color: #0d4f8b;
  font-weight: 700;
}
.modal-overlay[_ngcontent-%COMP%]   .modal-container[_ngcontent-%COMP%]   .modal-header[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {
  margin: 0.3rem 0 0;
  color: #607080;
  font-size: 0.85rem;
}
.modal-overlay[_ngcontent-%COMP%]   .modal-container[_ngcontent-%COMP%]   .modal-header[_ngcontent-%COMP%]   .btn-cerrar-modal[_ngcontent-%COMP%] {
  background: transparent;
  border: none;
  font-size: 1.4rem;
  cursor: pointer;
  color: #607080;
  transition: color 0.2s ease;
}
.modal-overlay[_ngcontent-%COMP%]   .modal-container[_ngcontent-%COMP%]   .modal-header[_ngcontent-%COMP%]   .btn-cerrar-modal[_ngcontent-%COMP%]:hover {
  color: #0d4f8b;
}
.modal-overlay[_ngcontent-%COMP%]   .modal-container[_ngcontent-%COMP%]   .modal-body[_ngcontent-%COMP%] {
  flex: 1;
  overflow-y: auto;
  padding: 1.5rem;
  box-sizing: border-box;
}
.modal-overlay[_ngcontent-%COMP%]   .modal-container[_ngcontent-%COMP%]   .modal-body[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%] {
  display: flex;
  flex-direction: column;
  gap: 0.4rem;
  margin-bottom: 1.25rem;
}
.modal-overlay[_ngcontent-%COMP%]   .modal-container[_ngcontent-%COMP%]   .modal-body[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {
  font-size: 0.85rem;
  font-weight: 700;
  color: #0d4f8b;
  text-transform: uppercase;
  letter-spacing: 0.4px;
}
.modal-overlay[_ngcontent-%COMP%]   .modal-container[_ngcontent-%COMP%]   .modal-body[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   input[type=text][_ngcontent-%COMP%], 
.modal-overlay[_ngcontent-%COMP%]   .modal-container[_ngcontent-%COMP%]   .modal-body[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   input[type=url][_ngcontent-%COMP%], 
.modal-overlay[_ngcontent-%COMP%]   .modal-container[_ngcontent-%COMP%]   .modal-body[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   select[_ngcontent-%COMP%], 
.modal-overlay[_ngcontent-%COMP%]   .modal-container[_ngcontent-%COMP%]   .modal-body[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   textarea[_ngcontent-%COMP%] {
  width: 100%;
  padding: 0.75rem 1rem;
  border: 1.5px solid #c9dfef;
  border-radius: 12px;
  font-size: 0.95rem;
  font-family: inherit;
  color: #1e293b;
  background-color: #f8fafc;
  box-sizing: border-box;
  transition: all 0.2s ease;
}
.modal-overlay[_ngcontent-%COMP%]   .modal-container[_ngcontent-%COMP%]   .modal-body[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   input[type=text][_ngcontent-%COMP%]:focus, 
.modal-overlay[_ngcontent-%COMP%]   .modal-container[_ngcontent-%COMP%]   .modal-body[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   input[type=url][_ngcontent-%COMP%]:focus, 
.modal-overlay[_ngcontent-%COMP%]   .modal-container[_ngcontent-%COMP%]   .modal-body[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   select[_ngcontent-%COMP%]:focus, 
.modal-overlay[_ngcontent-%COMP%]   .modal-container[_ngcontent-%COMP%]   .modal-body[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   textarea[_ngcontent-%COMP%]:focus {
  outline: none;
  border-color: #1976a8;
  background-color: #ffffff;
  box-shadow: 0 0 0 3.5px rgba(25, 118, 168, 0.15);
}
.modal-overlay[_ngcontent-%COMP%]   .modal-container[_ngcontent-%COMP%]   .modal-body[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   textarea[_ngcontent-%COMP%] {
  min-height: 100px;
  resize: vertical;
}
.modal-overlay[_ngcontent-%COMP%]   .modal-container[_ngcontent-%COMP%]   .modal-body[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   select[_ngcontent-%COMP%] {
  cursor: pointer;
  appearance: none;
  background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%0d4f8b' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e");
  background-repeat: no-repeat;
  background-position: right 1rem center;
  background-size: 1rem;
  padding-right: 2.5rem;
}
.modal-overlay[_ngcontent-%COMP%]   .modal-container[_ngcontent-%COMP%]   .modal-body[_ngcontent-%COMP%]   .skills-modal-list[_ngcontent-%COMP%] {
  display: flex;
  flex-direction: column;
  gap: 1.25rem;
  margin-bottom: 1.25rem;
}
.modal-overlay[_ngcontent-%COMP%]   .modal-container[_ngcontent-%COMP%]   .modal-body[_ngcontent-%COMP%]   .skills-modal-list[_ngcontent-%COMP%]   .skill-categoria[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {
  font-size: 0.9rem;
  color: #0d4f8b;
  margin: 0 0 0.5rem 0;
  border-bottom: 1px solid #e7f2fa;
  padding-bottom: 0.25rem;
}
.modal-overlay[_ngcontent-%COMP%]   .modal-container[_ngcontent-%COMP%]   .modal-body[_ngcontent-%COMP%]   .skills-modal-list[_ngcontent-%COMP%]   .skill-categoria[_ngcontent-%COMP%]   .skills-checkbox-grid[_ngcontent-%COMP%] {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
  gap: 0.5rem;
}
.modal-overlay[_ngcontent-%COMP%]   .modal-container[_ngcontent-%COMP%]   .modal-body[_ngcontent-%COMP%]   .skills-modal-list[_ngcontent-%COMP%]   .skill-categoria[_ngcontent-%COMP%]   .skills-checkbox-grid[_ngcontent-%COMP%]   .skill-checkbox[_ngcontent-%COMP%] {
  display: flex;
  align-items: center;
  gap: 0.4rem;
  font-size: 0.85rem;
  color: #334155;
  cursor: pointer;
}
.modal-overlay[_ngcontent-%COMP%]   .modal-container[_ngcontent-%COMP%]   .modal-body[_ngcontent-%COMP%]   .skills-modal-list[_ngcontent-%COMP%]   .skill-categoria[_ngcontent-%COMP%]   .skills-checkbox-grid[_ngcontent-%COMP%]   .skill-checkbox[_ngcontent-%COMP%]   input[type=checkbox][_ngcontent-%COMP%] {
  accent-color: #0d4f8b;
  width: 16px;
  height: 16px;
}
.modal-overlay[_ngcontent-%COMP%]   .modal-container[_ngcontent-%COMP%]   .modal-footer[_ngcontent-%COMP%] {
  flex-shrink: 0;
  display: flex;
  justify-content: flex-end;
  gap: 0.75rem;
  padding: 1rem 1.5rem;
  border-top: 1px solid #c9dfef;
  background: #ffffff;
}
.modal-overlay.cv-preview-overlay[_ngcontent-%COMP%]   .cv-preview-modal[_ngcontent-%COMP%] {
  max-width: 90vw;
  width: 90vw;
  height: 88vh;
  max-height: 88vh;
}
@media (max-width: 650px) {
  .modal-overlay.cv-preview-overlay[_ngcontent-%COMP%]   .cv-preview-modal[_ngcontent-%COMP%] {
    max-width: 96vw;
    width: 96vw;
    height: 92vh;
  }
}
.modal-overlay.cv-preview-overlay[_ngcontent-%COMP%]   .cv-preview-modal[_ngcontent-%COMP%]   .cv-preview-container[_ngcontent-%COMP%] {
  flex: 1;
  width: 100%;
  height: 100%;
  min-height: 0;
  background-color: #525659;
}
.modal-overlay.cv-preview-overlay[_ngcontent-%COMP%]   .cv-preview-modal[_ngcontent-%COMP%]   .cv-preview-container[_ngcontent-%COMP%]   .cv-preview-frame[_ngcontent-%COMP%] {
  width: 100%;
  height: 100%;
  border: none;
}
@keyframes _ngcontent-%COMP%_slideDown {
  from {
    opacity: 0;
    transform: translateY(-8px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
/*# sourceMappingURL=postulante-profile.css.map */`] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassMetadata(PostulanteProfile, [{
    type: Component,
    args: [{ selector: "app-postulante-profile", standalone: true, imports: [CommonModule, FormsModule], template: `<div class="perfil-container">\r
\r
  <!-- =====================================================\r
       1. CARD PRINCIPAL\r
       ===================================================== -->\r
  <div class="perfil-card card-main">\r
\r
    <!-- FOTO DE PERFIL -->\r
    <div class="foto-container">\r
      <div class="avatar-wrapper">\r
        @if (perfil.foto || fotoPreview) {\r
          <img [src]="getFotoUrl()" alt="Foto de Perfil" class="foto-avatar" (error)="perfil.foto = ''">\r
        } @else {\r
          <div class="avatar-placeholder">\r
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="icon-user">\r
              <path fill-rule="evenodd" d="M7.5 6a4.5 4.5 0 1 1 9 0a4.5 4.5 0 0 1-9 0ZM3.751 20.105a8.25 8.25 0 0 1 16.498 0 .75.75 0 0 1-.437.695A18.683 18.683 0 0 1 12 22.5c-2.786 0-5.433-.6-7.812-1.7a.75.75 0 0 1-.437-.695Z" clip-rule="evenodd" />\r
            </svg>\r
          </div>\r
        }\r
\r
        <!-- \u{1F4F7} Bot\xF3n cambiar foto (Solo visible para el alumno) -->\r
        @if (!esVisitante) {\r
          <button type="button" class="btn-foto-badge" (click)="fotoInput.click()" [disabled]="guardando" title="Cambiar foto de perfil">\r
            \u{1F4F7}\r
          </button>\r
          <input type="file" #fotoInput (change)="onFotoSeleccionada($event)" accept="image/png, image/jpeg, image/jpg" style="display: none;">\r
        }\r
      </div>\r
    </div>\r
\r
    <!-- DATOS DEL USUARIO -->\r
    <div class="user-info">\r
      <h2>{{ perfil.nombres || 'Nombre' }} {{ perfil.apellidos || 'Apellido' }}</h2>\r
      <p class="carrera-text">\u{1F393} {{ perfil.carrera || 'Carrera no especificada' }}</p>\r
      <p class="email-text">\u2709\uFE0F {{ perfil.email || 'correo@ejemplo.com' }}</p>\r
      <p class="ubicacion">\r
        \u{1F4CD} {{ perfil.ciudad ? perfil.ciudad + (perfil.pais ? ', ' + perfil.pais : '') : 'Ubicaci\xF3n no especificada' }}\r
      </p>\r
\r
      <!-- BOTONES PRINCIPALES -->\r
      <div class="acciones-header">\r
        @if (esVisitante) {\r
          <!-- \u{1F441}\uFE0F Bot\xF3n de navegaci\xF3n para Empresas o Admins -->\r
          <button type="button" class="btn-secundario" (click)="volver()">\r
            \u2190 Volver\r
          </button>\r
        } @else {\r
          <!-- \u270F\uFE0F Controles de edici\xF3n del propio alumno -->\r
          <button type="button" class="btn-editar" (click)="abrirModal('principales')">\r
            \u270F\uFE0F Editar Ubicaci\xF3n\r
          </button>\r
\r
          <button type="button" class="btn-guardar-main" [disabled]="guardando" (click)="guardarPerfilCompleto()">\r
            @if (!guardando) {\r
              <span>\u{1F4BE} Guardar Perfil Definitivo</span>\r
            } @else {\r
              <span>\u23F3 Guardando...</span>\r
            }\r
          </button>\r
        }\r
      </div>\r
    </div>\r
\r
  </div>\r
\r
  <!-- MENSAJE DE GUARDADO -->\r
  @if (mensajeEstado && !esVisitante) {\r
    <div class="alert-success-custom">\r
      {{ mensajeEstado }}\r
    </div>\r
  }\r
\r
  <!-- =====================================================\r
       2. PERFIL PROFESIONAL\r
       ===================================================== -->\r
  <div class="perfil-card card-sobre-mi">\r
    <div class="card-header-actions">\r
      <h3>\u{1F4BB} Perfil Profesional</h3>\r
      <!-- \u270F\uFE0F Bot\xF3n modal (Solo visible para el alumno) -->\r
      @if (!esVisitante) {\r
        <button type="button" class="btn-link-editar" (click)="abrirModal('sobreMi')" title="Editar descripci\xF3n">\r
          \u270F\uFE0F\r
        </button>\r
      }\r
    </div>\r
\r
    @if (perfil.sobre_mi) {\r
      <p class="texto-descripcion">{{ perfil.sobre_mi }}</p>\r
    } @else {\r
      <p class="empty-text">\r
        @if (esVisitante) {\r
          El postulante a\xFAn no ha cargado su presentaci\xF3n profesional.\r
        } @else {\r
          Contale a las empresas tu enfoque t\xE9cnico: tecnolog\xEDas principales, orientaci\xF3n y motivaci\xF3n profesional.\r
        }\r
      </p>\r
    }\r
\r
    <div class="resumen-tecnico-grid">\r
      <div class="item-resumen">\r
        <span class="label">Especialidad / Inter\xE9s:</span>\r
        <span class="valor">{{ perfil.especialidad || 'No definida' }}</span>\r
      </div>\r
      <div class="item-resumen">\r
        <span class="label">Estado acad\xE9mico:</span>\r
        <span class="valor">{{ perfil.estado_academico || 'Estudiante Avanzado' }}</span>\r
      </div>\r
    </div>\r
  </div>\r
\r
\r
 <!-- =====================================================\r
       3. CURRICULUM VITAE\r
       ===================================================== -->\r
  <div class="perfil-card card-cv">\r
    <div class="card-header-actions">\r
      <h3>\u{1F4C4} Curriculum Vitae</h3>\r
      <!-- \u270F\uFE0F Solo visible para el alumno -->\r
      @if (!esVisitante) {\r
        <button type="button" class="btn-link-editar" (click)="irACurriculum()" title="Ir al m\xF3dulo de Curriculum">\r
          \u270F\uFE0F\r
        </button>\r
      }\r
    </div>\r
\r
    @if (perfil.cv_url) {\r
      <div class="cv-content">\r
        <div class="cv-adjunto">\r
          <span class="icono-doc">\u{1F4C4}</span>\r
          <div class="cv-info">\r
            <strong>{{ perfil.cv_nombre || 'Curriculum_Vitae.pdf' }}</strong>\r
            <span class="cv-estado">\u2713 CV disponible</span>\r
          </div>\r
        </div>\r
\r
        <div class="cv-acciones">\r
          <!-- \u{1F441}\uFE0F \u2B07\uFE0F Acciones de lectura (Empresa, Admin y Alumno) -->\r
          <button type="button" class="btn-cv btn-vista-previa" (click)="verCV()">\r
            \u{1F441}\uFE0F Ver / Previsualizar\r
          </button>\r
          <button type="button" class="btn-cv btn-descargar" (click)="descargarCV()">\r
            \u2B07\uFE0F Descargar\r
          </button>\r
\r
          <!-- \u{1F4DD} Edici\xF3n solo para el Alumno -->\r
          @if (!esVisitante) {\r
            <button type="button" class="btn-cv btn-cambiar" (click)="irACurriculum()">\r
              \u{1F4DD} Ir a Curriculum\r
            </button>\r
          }\r
        </div>\r
      </div>\r
    } @else {\r
      <div class="cv-content cv-sin-adjuntar">\r
        <div class="cv-upload-icon">\u{1F4C4}</div>\r
        \r
        @if (esVisitante) {\r
          <h4>Sin CV adjuntado</h4>\r
          <p class="cv-descripcion">El postulante a\xFAn no ha subido su Curriculum Vitae.</p>\r
        } @else {\r
          <h4>No ten\xE9s un CV adjuntado</h4>\r
          <p class="cv-descripcion">\r
            Ingres\xE1 al gestor de CV para cargarlo y configurarlo.\r
          </p>\r
          <div class="cv-acciones">\r
            <button type="button" class="btn-cv btn-primary" (click)="irACurriculum()">\r
              \u{1F680} Cargar / Ir a Curriculum\r
            </button>\r
          </div>\r
        }\r
      </div>\r
    }\r
  </div>\r
\r
  <!-- =====================================================\r
       4. STACK T\xC9CNICO Y HABILIDADES\r
       ===================================================== -->\r
  <div class="perfil-card card-skills">\r
    <div class="card-header-actions">\r
      <h3>\u{1F6E0}\uFE0F Stack T\xE9cnico y Habilidades</h3>\r
      @if (!esVisitante) {\r
        <button type="button" class="btn-link-editar" (click)="abrirModal('skills')" title="Seleccionar habilidades">\r
          \u270F\uFE0F\r
        </button>\r
      }\r
    </div>\r
\r
    <div class="tags-container">\r
      @for (skill of perfil.skills || []; track skill.skill_id) {\r
        <span class="tag">{{ skill.nombre }}</span>\r
      }\r
    </div>\r
\r
    @if (perfil.otras_habilidades) {\r
      <div class="otras-habilidades-display">\r
        <p class="subtitulo-habilidades">Otras herramientas y conocimientos:</p>\r
        <p class="texto-adicional">{{ perfil.otras_habilidades }}</p>\r
      </div>\r
    }\r
\r
    @if ((perfil.skills.length || 0) === 0 && !perfil.otras_habilidades) {\r
      <p class="empty-text">\r
        @if (esVisitante) {\r
          El postulante a\xFAn no ha registrado sus habilidades t\xE9cnicas.\r
        } @else {\r
          Hac\xE9 clic en el l\xE1piz para seleccionar tus habilidades del cat\xE1logo o agregar otras.\r
        }\r
      </p>\r
    }\r
  </div>\r
\r
  <!-- =====================================================\r
       5. REDES Y PORTAFOLIO\r
       ===================================================== -->\r
  <div class="perfil-card card-redes">\r
    <div class="card-header-actions">\r
      <h3>\u{1F310} Redes y Portafolio</h3>\r
      @if (!esVisitante) {\r
        <button type="button" class="btn-link-editar" (click)="abrirModal('redes')" title="Editar enlaces">\r
          \u270F\uFE0F\r
        </button>\r
      }\r
    </div>\r
\r
    <div class="links-grid">\r
      @if (perfil.redes.github) {\r
        <a [href]="perfil.redes.github" target="_blank" rel="noopener noreferrer" class="link-red github">\u{1F4C1} GitHub</a>\r
      }\r
      @if (perfil.redes.linkedin) {\r
        <a [href]="perfil.redes.linkedin" target="_blank" rel="noopener noreferrer" class="link-red linkedin">\u{1F4BC} LinkedIn</a>\r
      }\r
      @if (perfil.redes.portfolio) {\r
        <a [href]="perfil.redes.portfolio" target="_blank" rel="noopener noreferrer" class="link-red portfolio">\u{1F310} Web / Portafolio</a>\r
      }\r
      @if (!perfil.redes.github && !perfil.redes.linkedin && !perfil.redes.portfolio) {\r
        <p class="empty-text">\r
          @if (esVisitante) {\r
            El postulante no ha vinculado redes profesionales.\r
          } @else {\r
            No vinculaste ninguna red profesional a\xFAn.\r
          }\r
        </p>\r
      }\r
    </div>\r
  </div>\r
\r
  <!-- =====================================================\r
       MODAL: EDITAR UBICACI\xD3N\r
       ===================================================== -->\r
  @if (modalActivo === 'principales') {\r
    <div class="modal-overlay" (click)="cerrarModal()">\r
      <div class="modal-container" (click)="$event.stopPropagation()">\r
        <div class="modal-header">\r
          <div>\r
            <h2>\u{1F4CD} Editar Ubicaci\xF3n</h2>\r
            <p>Actualiz\xE1 la ubicaci\xF3n que ver\xE1n las empresas.</p>\r
          </div>\r
          <button type="button" class="btn-cerrar-modal" (click)="cerrarModal()">\u2715</button>\r
        </div>\r
\r
        <div class="modal-body">\r
          <div class="form-group">\r
            <label for="ciudad">Ciudad</label>\r
            <input id="ciudad" type="text" [(ngModel)]="tempUbicacion.ciudad" placeholder="Ej. Lan\xFAs">\r
          </div>\r
\r
          <div class="form-group">\r
            <label for="pais">Pa\xEDs</label>\r
            <input id="pais" type="text" [(ngModel)]="tempUbicacion.pais" placeholder="Ej. Argentina">\r
          </div>\r
        </div>\r
\r
        <div class="modal-footer">\r
          <button type="button" class="btn-cancelar" (click)="cerrarModal()">Cancelar</button>\r
          <button type="button" class="btn-primary" (click)="guardarUbicacion()">\u{1F4BE} Guardar ubicaci\xF3n</button>\r
        </div>\r
      </div>\r
    </div>\r
  }\r
\r
  <!-- =====================================================\r
       MODAL: EDITAR PERFIL PROFESIONAL\r
       ===================================================== -->\r
  @if (modalActivo === 'sobreMi') {\r
    <div class="modal-overlay" (click)="cerrarModal()">\r
      <div class="modal-container" (click)="$event.stopPropagation()">\r
        <div class="modal-header">\r
          <div>\r
            <h2>\u{1F4BB} Perfil Profesional</h2>\r
            <p>Contale a las empresas sobre tu perfil y orientaci\xF3n profesional.</p>\r
          </div>\r
          <button type="button" class="btn-cerrar-modal" (click)="cerrarModal()">\u2715</button>\r
        </div>\r
\r
        <div class="modal-body">\r
          <div class="form-group">\r
            <label for="sobreMi">Sobre m\xED</label>\r
            <textarea id="sobreMi" rows="5" [(ngModel)]="tempSobreMi.sobre_mi" placeholder="Cont\xE1 brevemente tu perfil, intereses y objetivos profesionales..."></textarea>\r
          </div>\r
\r
          <div class="form-group">\r
            <label for="especialidad">Especialidad / Inter\xE9s</label>\r
            <input id="especialidad" type="text" [(ngModel)]="tempSobreMi.especialidad" placeholder="Ej. Desarrollo Frontend, An\xE1lisis de Datos...">\r
          </div>\r
\r
          <div class="form-group">\r
            <label for="estadoAcademico">Estado acad\xE9mico</label>\r
            <select id="estadoAcademico" [(ngModel)]="tempSobreMi.estado_academico">\r
              <option value="Estudiante Inicial">Estudiante Inicial</option>\r
              <option value="Estudiante Avanzado">Estudiante Avanzado</option>\r
              <option value="Graduado">Graduado</option>\r
            </select>\r
          </div>\r
        </div>\r
\r
        <div class="modal-footer">\r
          <button type="button" class="btn-cancelar" (click)="cerrarModal()">Cancelar</button>\r
          <button type="button" class="btn-primary" (click)="guardarSobreMi()">\u{1F4BE} Guardar perfil</button>\r
        </div>\r
      </div>\r
    </div>\r
  }\r
\r
  <!-- =====================================================\r
       MODAL: EDITAR SKILLS\r
       ===================================================== -->\r
  @if (modalActivo === 'skills') {\r
    <div class="modal-overlay" (click)="cerrarModal()">\r
      <div class="modal-container" (click)="$event.stopPropagation()">\r
        <div class="modal-header">\r
          <div>\r
            <h2>\u{1F6E0}\uFE0F Stack T\xE9cnico y Habilidades</h2>\r
            <p>Seleccion\xE1 las tecnolog\xEDas y conocimientos que forman parte de tu perfil.</p>\r
          </div>\r
          <button type="button" class="btn-cerrar-modal" (click)="cerrarModal()">\u2715</button>\r
        </div>\r
\r
        <div class="modal-body">\r
          <div class="form-group">\r
            <label for="busquedaSkill">Buscar habilidad</label>\r
            <input id="busquedaSkill" type="text" [(ngModel)]="busquedaSkill" placeholder="Ej. Angular, Excel, Python...">\r
          </div>\r
\r
          <div class="skills-modal-list">\r
            @for (categoria of categoriasFiltradas; track categoria.categoria_id) {\r
              <div class="skill-categoria">\r
                <h4>{{ categoria.nombre_categoria }}</h4>\r
                <div class="skills-checkbox-grid">\r
                  @for (skill of categoria.skills; track skill.skill_id) {\r
                    <label class="skill-checkbox">\r
                      <input type="checkbox" [checked]="esSkillSeleccionada(skill.skill_id)" (change)="toggleSkill(skill.skill_id)">\r
                      <span>{{ skill.nombre }}</span>\r
                    </label>\r
                  }\r
                </div>\r
              </div>\r
            }\r
\r
            @if (categoriasFiltradas.length === 0) {\r
              <p class="empty-text">No se encontraron habilidades con esa b\xFAsqueda.</p>\r
            }\r
          </div>\r
\r
          <div class="form-group">\r
            <label for="otrasHabilidades">Otras herramientas y conocimientos</label>\r
            <textarea id="otrasHabilidades" rows="4" [(ngModel)]="tempOtrasHabilidades" placeholder="Pod\xE9s agregar otras herramientas, conocimientos o tecnolog\xEDas..."></textarea>\r
          </div>\r
        </div>\r
\r
        <div class="modal-footer">\r
          <button type="button" class="btn-cancelar" (click)="cerrarModal()">Cancelar</button>\r
          <button type="button" class="btn-primary" (click)="guardarSkills()">\u{1F4BE} Guardar habilidades</button>\r
        </div>\r
      </div>\r
    </div>\r
  }\r
\r
  <!-- =====================================================\r
       MODAL: EDITAR REDES Y PORTAFOLIO\r
       ===================================================== -->\r
  @if (modalActivo === 'redes') {\r
    <div class="modal-overlay" (click)="cerrarModal()">\r
      <div class="modal-container" (click)="$event.stopPropagation()">\r
        <div class="modal-header">\r
          <div>\r
            <h2>\u{1F310} Redes y Portafolio</h2>\r
            <p>Agreg\xE1 los enlaces donde las empresas puedan conocer tu trabajo.</p>\r
          </div>\r
          <button type="button" class="btn-cerrar-modal" (click)="cerrarModal()">\u2715</button>\r
        </div>\r
\r
        <div class="modal-body">\r
          <div class="form-group">\r
            <label for="github">\u{1F4C1} GitHub</label>\r
            <input id="github" type="url" [(ngModel)]="tempRedes.github" placeholder="https://github.com/tuusuario">\r
          </div>\r
\r
          <div class="form-group">\r
            <label for="linkedin">\u{1F4BC} LinkedIn</label>\r
            <input id="linkedin" type="url" [(ngModel)]="tempRedes.linkedin" placeholder="https://www.linkedin.com/in/tuusuario">\r
          </div>\r
\r
          <div class="form-group">\r
            <label for="portfolio">\u{1F310} Web / Portafolio</label>\r
            <input id="portfolio" type="url" [(ngModel)]="tempRedes.portfolio" placeholder="https://tuportfolio.com">\r
          </div>\r
        </div>\r
\r
        <div class="modal-footer">\r
          <button type="button" class="btn-cancelar" (click)="cerrarModal()">Cancelar</button>\r
          <button type="button" class="btn-primary" (click)="guardarRedes()">\u{1F4BE} Guardar enlaces</button>\r
        </div>\r
      </div>\r
    </div>\r
  }\r
\r
  <!-- =====================================================\r
       MODAL: VISTA PREVIA DEL PDF\r
       ===================================================== -->\r
  @if (mostrarVistaPreviaCV && cvPreviewUrl) {\r
    <div class="modal-overlay cv-preview-overlay" (click)="cerrarVistaPreviaCV()">\r
      <div class="modal-container cv-preview-modal" (click)="$event.stopPropagation()">\r
        <div class="modal-header">\r
          <div>\r
            <h2>\u{1F441}\uFE0F Vista previa del CV</h2>\r
            <p>{{ perfil.cv_nombre || 'Curriculum Vitae' }}</p>\r
          </div>\r
          <button type="button" class="btn-cerrar-modal" (click)="cerrarVistaPreviaCV()">\u2715</button>\r
        </div>\r
\r
        <div class="cv-preview-container">\r
          <iframe [src]="cvPreviewUrl" class="cv-preview-frame" title="Vista previa del Curriculum Vitae"></iframe>\r
        </div>\r
\r
        <div class="modal-footer">\r
          <button type="button" class="btn-cancelar" (click)="cerrarVistaPreviaCV()">Cerrar</button>\r
          <button type="button" class="btn-primary" (click)="descargarCV()">\u2B07\uFE0F Descargar PDF</button>\r
        </div>\r
      </div>\r
    </div>\r
  }\r
\r
`, styles: [`/* src/app/pagina/perfiles/postulante-profile/postulante-profile.scss */
.perfil-container {
  width: 100%;
  max-width: 1180px;
  margin: 2rem auto;
  padding: 0 1rem;
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 1.5rem;
  box-sizing: border-box;
}
@media (max-width: 1024px) {
  .perfil-container {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}
@media (max-width: 650px) {
  .perfil-container {
    grid-template-columns: 1fr;
    gap: 1rem;
    margin: 1rem auto;
    padding: 0 0.75rem;
  }
}
.alert-success-custom {
  grid-column: 1/-1;
  width: 100%;
  padding: 0.85rem 1.25rem;
  background-color: #d1fae5;
  border-left: 4px solid #16a34a;
  color: #166534;
  border-radius: 12px;
  font-weight: 600;
  font-size: 0.95rem;
  box-sizing: border-box;
  animation: slideDown 0.3s ease-in-out;
}
.empty-text {
  color: #607080;
  font-size: 0.9rem;
  font-style: italic;
  margin: 0.5rem 0;
  line-height: 1.5;
}
.perfil-card {
  background: #ffffff;
  border: 1px solid #c9dfef;
  border-radius: 20px;
  padding: 1.5rem;
  box-shadow: 0 8px 20px rgba(13, 79, 139, 0.05);
  min-width: 0;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
}
.perfil-card .card-header-actions {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 1rem;
  margin-bottom: 1.2rem;
  padding-bottom: 0.6rem;
  border-bottom: 2px solid #e7f2fa;
}
.perfil-card .card-header-actions h3 {
  color: #0d4f8b;
  font-size: 1.2rem;
  font-weight: 700;
  margin: 0;
}
.perfil-card .card-header-actions .btn-link-editar {
  background: transparent;
  border: none;
  cursor: pointer;
  font-size: 1.1rem;
  color: #0d4f8b;
  padding: 0.25rem;
  transition: transform 0.2s ease, color 0.2s ease;
}
.perfil-card .card-header-actions .btn-link-editar:hover {
  color: #1976a8;
  transform: scale(1.15);
}
.card-main {
  grid-column: 1/-1;
  display: flex;
  align-items: center;
  gap: 2rem;
}
@media (max-width: 650px) {
  .card-main {
    flex-direction: column;
    text-align: center;
    gap: 1.25rem;
  }
}
.card-main .foto-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  flex-shrink: 0;
}
.card-main .foto-container .avatar-wrapper {
  position: relative;
  width: 125px;
  height: 125px;
}
.card-main .foto-container .avatar-wrapper .foto-avatar {
  width: 100%;
  height: 100%;
  border-radius: 50%;
  object-fit: cover;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
  border: 3px solid #ffffff;
}
.card-main .foto-container .avatar-wrapper .avatar-placeholder {
  width: 100%;
  height: 100%;
  border-radius: 50%;
  background-color: #e7f2fa;
  border: 3px solid #ffffff;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
  display: flex;
  align-items: center;
  justify-content: center;
}
.card-main .foto-container .avatar-wrapper .avatar-placeholder .icon-user {
  width: 65px;
  height: 65px;
  fill: #0d4f8b;
  opacity: 0.55;
}
.card-main .foto-container .avatar-wrapper .btn-foto-badge {
  position: absolute;
  bottom: 2px;
  right: 2px;
  width: 36px;
  height: 36px;
  border-radius: 50%;
  background-color: #0d4f8b;
  border: 2px solid #ffffff;
  color: #ffffff;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  font-size: 0.95rem;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
  transition: all 0.2s ease;
}
.card-main .foto-container .avatar-wrapper .btn-foto-badge:hover:not(:disabled) {
  background-color: #1976a8;
  transform: scale(1.1);
}
.card-main .foto-container .avatar-wrapper .btn-foto-badge:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}
.card-main .user-info {
  flex: 1;
  min-width: 0;
}
.card-main .user-info h2 {
  margin: 0 0 0.25rem;
  color: #0d4f8b;
  font-size: 1.6rem;
  font-weight: 700;
}
.card-main .user-info .carrera-text {
  margin: 0 0 0.4rem;
  color: #0d4f8b;
  font-size: 0.95rem;
  font-weight: 600;
}
.card-main .user-info .email-text {
  margin: 0 0 0.4rem;
  color: #607080;
  font-size: 0.95rem;
}
.card-main .user-info .ubicacion {
  margin: 0 0 1.25rem;
  color: #0d4f8b;
  font-size: 0.95rem;
  font-weight: 500;
}
.card-main .user-info .acciones-header {
  display: flex;
  flex-wrap: wrap;
  gap: 0.75rem;
  align-items: center;
}
@media (max-width: 650px) {
  .card-main .user-info .acciones-header {
    justify-content: center;
  }
}
.card-sobre-mi {
  grid-column: span 2;
}
@media (max-width: 1024px) {
  .card-sobre-mi {
    grid-column: 1/-1;
  }
}
.card-sobre-mi .texto-descripcion {
  color: #607080;
  line-height: 1.6;
  margin-bottom: 1.25rem;
  font-size: 0.95rem;
}
.card-sobre-mi .resumen-tecnico-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 1rem;
  margin-top: 1rem;
}
@media (max-width: 500px) {
  .card-sobre-mi .resumen-tecnico-grid {
    grid-template-columns: 1fr;
  }
}
.card-sobre-mi .resumen-tecnico-grid .item-resumen {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
  background: #f8fafc;
  border: 1px solid #c9dfef;
  border-left: 4px solid #0d4f8b;
  padding: 0.85rem 1rem;
  border-radius: 12px;
}
.card-sobre-mi .resumen-tecnico-grid .item-resumen .label {
  font-size: 0.75rem;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: #607080;
  font-weight: 700;
}
.card-sobre-mi .resumen-tecnico-grid .item-resumen .valor {
  font-size: 0.95rem;
  font-weight: 600;
  color: #0d4f8b;
}
.card-cv {
  grid-column: span 1;
}
@media (max-width: 1024px) {
  .card-cv {
    grid-column: 1/-1;
  }
}
.card-cv .cv-content {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}
.card-cv .cv-content .cv-adjunto {
  display: flex;
  align-items: center;
  gap: 0.85rem;
  background-color: #e7f2fa;
  padding: 0.85rem 1rem;
  border-radius: 12px;
  border: 1px solid #c9dfef;
}
.card-cv .cv-content .cv-adjunto .icono-doc {
  font-size: 1.6rem;
  color: #0d4f8b;
}
.card-cv .cv-content .cv-adjunto .cv-info {
  display: flex;
  flex-direction: column;
}
.card-cv .cv-content .cv-adjunto .cv-info strong {
  font-size: 0.9rem;
  color: #0d4f8b;
  word-break: break-all;
}
.card-cv .cv-content .cv-adjunto .cv-info .cv-estado {
  font-size: 0.8rem;
  color: #16a34a;
  font-weight: 600;
}
.card-cv .cv-content .cv-acciones {
  display: flex;
  flex-direction: column;
  gap: 0.6rem;
}
.card-cv .cv-content .cv-acciones .btn-cv {
  width: 100%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  padding: 0.65rem 1rem;
  border-radius: 12px;
  font-weight: 600;
  font-size: 0.88rem;
  cursor: pointer;
  transition: all 0.2s ease;
  border: none;
}
.card-cv .cv-content .cv-acciones .btn-cv.btn-vista-previa {
  background-color: #0d4f8b;
  color: #ffffff;
}
.card-cv .cv-content .cv-acciones .btn-cv.btn-vista-previa:hover {
  background-color: #1976a8;
}
.card-cv .cv-content .cv-acciones .btn-cv.btn-descargar {
  background-color: #e7f2fa;
  color: #0d4f8b;
  border: 1px solid #c9dfef;
}
.card-cv .cv-content .cv-acciones .btn-cv.btn-descargar:hover {
  background-color: #d9ebf7;
}
.card-cv .cv-content .cv-acciones .btn-cv.btn-cambiar {
  background-color: transparent;
  color: #607080;
  border: 1px dashed #dbe5ec;
}
.card-cv .cv-content .cv-acciones .btn-cv.btn-cambiar:hover {
  background-color: #f8fafc;
  color: #0d4f8b;
}
.card-cv .cv-content.cv-sin-adjuntar {
  text-align: center;
  padding: 1rem 0;
}
.card-cv .cv-content.cv-sin-adjuntar .cv-upload-icon {
  font-size: 2.5rem;
  margin-bottom: 0.5rem;
}
.card-cv .cv-content.cv-sin-adjuntar h4 {
  margin: 0 0 0.25rem 0;
  color: #0d4f8b;
}
.card-cv .cv-content.cv-sin-adjuntar .cv-descripcion {
  color: #607080;
  font-size: 0.85rem;
  margin-bottom: 1rem;
}
.card-skills {
  grid-column: span 1;
}
.card-skills .otras-habilidades-display {
  margin-top: 1rem;
  padding-top: 0.75rem;
  border-top: 1px dashed #c9dfef;
}
.card-skills .otras-habilidades-display .subtitulo-habilidades {
  font-size: 0.8rem;
  font-weight: 700;
  color: #0d4f8b;
  text-transform: uppercase;
  margin: 0 0 0.35rem 0;
}
.card-skills .otras-habilidades-display .texto-adicional {
  font-size: 0.88rem;
  color: #607080;
  margin: 0;
  line-height: 1.4;
}
.tags-container {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
}
.tags-container .tag {
  background-color: #e7f2fa;
  color: #0d4f8b;
  padding: 0.4rem 0.8rem;
  border-radius: 12px;
  font-size: 0.85rem;
  font-weight: 600;
  border: 1px solid #c9dfef;
}
.card-redes {
  grid-column: span 1;
}
.card-redes .links-grid {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}
.card-redes .links-grid .link-red {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  font-weight: 600;
  color: #0d4f8b;
  text-decoration: none;
  padding: 0.55rem 0.85rem;
  border-radius: 10px;
  background-color: #e7f2fa;
  border: 1px solid #c9dfef;
  transition: all 0.2s ease;
}
.card-redes .links-grid .link-red:hover {
  background-color: #d9ebf7;
  color: #1976a8;
  transform: translateX(3px);
}
.btn-editar,
.btn-primary,
.btn-guardar-main {
  background-color: #16a34a;
  color: #ffffff;
  border: none;
  padding: 0.65rem 1.25rem;
  border-radius: 12px;
  cursor: pointer;
  font-weight: 700;
  transition: all 0.2s ease;
}
.btn-editar:hover:not(:disabled),
.btn-primary:hover:not(:disabled),
.btn-guardar-main:hover:not(:disabled) {
  background-color: #15803d;
  transform: translateY(-1px);
}
.btn-editar:disabled,
.btn-primary:disabled,
.btn-guardar-main:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}
.btn-editar {
  background-color: #0d4f8b;
}
.btn-editar:hover:not(:disabled) {
  background-color: #1976a8;
}
.btn-secundario,
.btn-cancelar {
  background-color: #e7f2fa;
  color: #0d4f8b;
  border: 1px solid #c9dfef;
  padding: 0.65rem 1.25rem;
  border-radius: 12px;
  cursor: pointer;
  font-weight: 600;
  transition: all 0.2s ease;
}
.btn-secundario:hover,
.btn-cancelar:hover {
  background-color: #d9ebf7;
  border-color: #1976a8;
}
.modal-overlay {
  position: fixed;
  inset: 0;
  width: 100vw;
  height: 100vh;
  background: rgba(5, 30, 55, 0.6);
  -webkit-backdrop-filter: blur(4px);
  backdrop-filter: blur(4px);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  padding: 1rem;
  box-sizing: border-box;
}
.modal-overlay .modal-container {
  background: #ffffff;
  border-radius: 20px;
  width: 100%;
  max-width: 580px;
  max-height: 90vh;
  display: flex;
  flex-direction: column;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
  overflow: hidden;
}
.modal-overlay .modal-container .modal-header {
  flex-shrink: 0;
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 1rem;
  border-bottom: 1px solid #c9dfef;
  padding: 1.25rem 1.5rem;
}
.modal-overlay .modal-container .modal-header h2 {
  margin: 0;
  font-size: 1.25rem;
  color: #0d4f8b;
  font-weight: 700;
}
.modal-overlay .modal-container .modal-header p {
  margin: 0.3rem 0 0;
  color: #607080;
  font-size: 0.85rem;
}
.modal-overlay .modal-container .modal-header .btn-cerrar-modal {
  background: transparent;
  border: none;
  font-size: 1.4rem;
  cursor: pointer;
  color: #607080;
  transition: color 0.2s ease;
}
.modal-overlay .modal-container .modal-header .btn-cerrar-modal:hover {
  color: #0d4f8b;
}
.modal-overlay .modal-container .modal-body {
  flex: 1;
  overflow-y: auto;
  padding: 1.5rem;
  box-sizing: border-box;
}
.modal-overlay .modal-container .modal-body .form-group {
  display: flex;
  flex-direction: column;
  gap: 0.4rem;
  margin-bottom: 1.25rem;
}
.modal-overlay .modal-container .modal-body .form-group label {
  font-size: 0.85rem;
  font-weight: 700;
  color: #0d4f8b;
  text-transform: uppercase;
  letter-spacing: 0.4px;
}
.modal-overlay .modal-container .modal-body .form-group input[type=text],
.modal-overlay .modal-container .modal-body .form-group input[type=url],
.modal-overlay .modal-container .modal-body .form-group select,
.modal-overlay .modal-container .modal-body .form-group textarea {
  width: 100%;
  padding: 0.75rem 1rem;
  border: 1.5px solid #c9dfef;
  border-radius: 12px;
  font-size: 0.95rem;
  font-family: inherit;
  color: #1e293b;
  background-color: #f8fafc;
  box-sizing: border-box;
  transition: all 0.2s ease;
}
.modal-overlay .modal-container .modal-body .form-group input[type=text]:focus,
.modal-overlay .modal-container .modal-body .form-group input[type=url]:focus,
.modal-overlay .modal-container .modal-body .form-group select:focus,
.modal-overlay .modal-container .modal-body .form-group textarea:focus {
  outline: none;
  border-color: #1976a8;
  background-color: #ffffff;
  box-shadow: 0 0 0 3.5px rgba(25, 118, 168, 0.15);
}
.modal-overlay .modal-container .modal-body .form-group textarea {
  min-height: 100px;
  resize: vertical;
}
.modal-overlay .modal-container .modal-body .form-group select {
  cursor: pointer;
  appearance: none;
  background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%0d4f8b' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e");
  background-repeat: no-repeat;
  background-position: right 1rem center;
  background-size: 1rem;
  padding-right: 2.5rem;
}
.modal-overlay .modal-container .modal-body .skills-modal-list {
  display: flex;
  flex-direction: column;
  gap: 1.25rem;
  margin-bottom: 1.25rem;
}
.modal-overlay .modal-container .modal-body .skills-modal-list .skill-categoria h4 {
  font-size: 0.9rem;
  color: #0d4f8b;
  margin: 0 0 0.5rem 0;
  border-bottom: 1px solid #e7f2fa;
  padding-bottom: 0.25rem;
}
.modal-overlay .modal-container .modal-body .skills-modal-list .skill-categoria .skills-checkbox-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
  gap: 0.5rem;
}
.modal-overlay .modal-container .modal-body .skills-modal-list .skill-categoria .skills-checkbox-grid .skill-checkbox {
  display: flex;
  align-items: center;
  gap: 0.4rem;
  font-size: 0.85rem;
  color: #334155;
  cursor: pointer;
}
.modal-overlay .modal-container .modal-body .skills-modal-list .skill-categoria .skills-checkbox-grid .skill-checkbox input[type=checkbox] {
  accent-color: #0d4f8b;
  width: 16px;
  height: 16px;
}
.modal-overlay .modal-container .modal-footer {
  flex-shrink: 0;
  display: flex;
  justify-content: flex-end;
  gap: 0.75rem;
  padding: 1rem 1.5rem;
  border-top: 1px solid #c9dfef;
  background: #ffffff;
}
.modal-overlay.cv-preview-overlay .cv-preview-modal {
  max-width: 90vw;
  width: 90vw;
  height: 88vh;
  max-height: 88vh;
}
@media (max-width: 650px) {
  .modal-overlay.cv-preview-overlay .cv-preview-modal {
    max-width: 96vw;
    width: 96vw;
    height: 92vh;
  }
}
.modal-overlay.cv-preview-overlay .cv-preview-modal .cv-preview-container {
  flex: 1;
  width: 100%;
  height: 100%;
  min-height: 0;
  background-color: #525659;
}
.modal-overlay.cv-preview-overlay .cv-preview-modal .cv-preview-container .cv-preview-frame {
  width: 100%;
  height: 100%;
  border: none;
}
@keyframes slideDown {
  from {
    opacity: 0;
    transform: translateY(-8px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
/*# sourceMappingURL=postulante-profile.css.map */
`] }]
  }], null, { idPostulanteInput: [{
    type: Input
  }], esModoAdmin: [{
    type: Input
  }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(PostulanteProfile, { className: "PostulanteProfile", filePath: "app/pagina/perfiles/postulante-profile/postulante-profile.ts", lineNumber: 87 });
})();
(() => {
  const id = "app%2Fpagina%2Fperfiles%2Fpostulante-profile%2Fpostulante-profile.ts%40PostulanteProfile";
  function PostulanteProfile_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i0.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i0.\u0275\u0275replaceMetadata(PostulanteProfile, m.default, [i0, i1, i2], [CommonModule, FormsModule, Component, Input], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && PostulanteProfile_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && PostulanteProfile_HmrLoad(d.timestamp)));
})();

export {
  inicializarPerfilPostulante,
  PostulanteProfile
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnaW5hL3BlcmZpbGVzL3Bvc3R1bGFudGUtcHJvZmlsZS9wb3N0dWxhbnRlLXByb2ZpbGUudHMiLCJzcmMvYXBwL3BhZ2luYS9wZXJmaWxlcy9wb3N0dWxhbnRlLXByb2ZpbGUvcG9zdHVsYW50ZS1wcm9maWxlLmh0bWwiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQsIE9uQ2hhbmdlcywgU2ltcGxlQ2hhbmdlcywgaW5qZWN0LCBQTEFURk9STV9JRCwgSW5wdXQsIENoYW5nZURldGVjdG9yUmVmIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IENvbW1vbk1vZHVsZSwgaXNQbGF0Zm9ybUJyb3dzZXIsIExvY2F0aW9uIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcclxuaW1wb3J0IHsgRm9ybXNNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XHJcbmltcG9ydCB7IFJvdXRlciwgQWN0aXZhdGVkUm91dGUgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xyXG5pbXBvcnQgeyBQb3N0dWxhbnRlU2VydmljZSB9IGZyb20gJy4uLy4uLy4uL3NlcnZpY2VzL3Bvc3R1bGFudGUuc2VydmljZSc7XHJcbmltcG9ydCB7IERvbVNhbml0aXplciwgU2FmZVJlc291cmNlVXJsIH0gZnJvbSAnQGFuZ3VsYXIvcGxhdGZvcm0tYnJvd3Nlcic7XHJcblxyXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuLy8gSU5URVJGQUNFUyBZIERUT3NcclxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIFNraWxsRFRPIHtcclxuICBza2lsbF9pZDogbnVtYmVyO1xyXG4gIGNhdGVnb3JpYV9pZDogbnVtYmVyO1xyXG4gIG5vbWJyZTogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIENhdGVnb3JpYVNraWxsRFRPIHtcclxuICBjYXRlZ29yaWFfaWQ6IG51bWJlcjtcclxuICBub21icmVfY2F0ZWdvcmlhOiBzdHJpbmc7XHJcbiAgc2tpbGxzOiBTa2lsbERUT1tdO1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIFJlZGVzRFRPIHtcclxuICBnaXRodWI6IHN0cmluZztcclxuICBsaW5rZWRpbjogc3RyaW5nO1xyXG4gIHBvcnRmb2xpbzogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIFBvc3R1bGFudGVQZXJmaWxEVE8ge1xyXG4gIG5vbWJyZXM6IHN0cmluZztcclxuICBhcGVsbGlkb3M6IHN0cmluZztcclxuICBlbWFpbDogc3RyaW5nO1xyXG4gIGNhcnJlcmE6IHN0cmluZztcclxuICBmb3RvPzogc3RyaW5nO1xyXG4gIGNpdWRhZDogc3RyaW5nO1xyXG4gIHBhaXM6IHN0cmluZztcclxuICBzb2JyZV9taTogc3RyaW5nO1xyXG4gIGVzcGVjaWFsaWRhZDogc3RyaW5nO1xyXG4gIGVzdGFkb19hY2FkZW1pY286IHN0cmluZztcclxuICBjdl91cmw/OiBzdHJpbmc7XHJcbiAgY3Zfbm9tYnJlPzogc3RyaW5nO1xyXG4gIHNraWxsczogU2tpbGxEVE9bXTtcclxuICBvdHJhc19oYWJpbGlkYWRlcz86IHN0cmluZztcclxuICByZWRlczogUmVkZXNEVE87XHJcbn1cclxuXHJcbi8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4vLyBQRVJGSUwgSU5JQ0lBTFxyXG4vLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBpbmljaWFsaXphclBlcmZpbFBvc3R1bGFudGUoKTogUG9zdHVsYW50ZVBlcmZpbERUTyB7XHJcbiAgcmV0dXJuIHtcclxuICAgIG5vbWJyZXM6ICcnLFxyXG4gICAgYXBlbGxpZG9zOiAnJyxcclxuICAgIGVtYWlsOiAnJyxcclxuICAgIGNhcnJlcmE6ICcnLFxyXG4gICAgZm90bzogJycsXHJcbiAgICBjaXVkYWQ6ICcnLFxyXG4gICAgcGFpczogJycsXHJcbiAgICBzb2JyZV9taTogJycsXHJcbiAgICBlc3BlY2lhbGlkYWQ6ICcnLFxyXG4gICAgZXN0YWRvX2FjYWRlbWljbzogJ0VzdHVkaWFudGUgQXZhbnphZG8nLFxyXG4gICAgY3ZfdXJsOiAnJyxcclxuICAgIGN2X25vbWJyZTogJycsXHJcbiAgICBza2lsbHM6IFtdLFxyXG4gICAgb3RyYXNfaGFiaWxpZGFkZXM6ICcnLFxyXG4gICAgcmVkZXM6IHtcclxuICAgICAgZ2l0aHViOiAnJyxcclxuICAgICAgbGlua2VkaW46ICcnLFxyXG4gICAgICBwb3J0Zm9saW86ICcnXHJcbiAgICB9XHJcbiAgfTtcclxufVxyXG5cclxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbi8vIENPTVBPTkVOVEVcclxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogJ2FwcC1wb3N0dWxhbnRlLXByb2ZpbGUnLFxyXG4gIHN0YW5kYWxvbmU6IHRydWUsXHJcbiAgaW1wb3J0czogW0NvbW1vbk1vZHVsZSwgRm9ybXNNb2R1bGVdLFxyXG4gIHRlbXBsYXRlVXJsOiAnLi9wb3N0dWxhbnRlLXByb2ZpbGUuaHRtbCcsXHJcbiAgc3R5bGVVcmw6ICcuL3Bvc3R1bGFudGUtcHJvZmlsZS5zY3NzJ1xyXG59KVxyXG5leHBvcnQgY2xhc3MgUG9zdHVsYW50ZVByb2ZpbGUgaW1wbGVtZW50cyBPbkluaXQsIE9uQ2hhbmdlcyB7XHJcblxyXG4gIC8vIFNFUlZJQ0lPU1xyXG4gIHByaXZhdGUgcG9zdHVsYW50ZVNlcnZpY2UgPSBpbmplY3QoUG9zdHVsYW50ZVNlcnZpY2UpO1xyXG4gIHByaXZhdGUgcGxhdGZvcm1JZCA9IGluamVjdChQTEFURk9STV9JRCk7XHJcbiAgcHJpdmF0ZSByb3V0ZXIgPSBpbmplY3QoUm91dGVyKTtcclxuICBwcml2YXRlIHJvdXRlID0gaW5qZWN0KEFjdGl2YXRlZFJvdXRlKTtcclxuICBwcml2YXRlIGxvY2F0aW9uID0gaW5qZWN0KExvY2F0aW9uKTtcclxuICBwcml2YXRlIHNhbml0aXplciA9IGluamVjdChEb21TYW5pdGl6ZXIpO1xyXG4gIHByaXZhdGUgY2RyID0gaW5qZWN0KENoYW5nZURldGVjdG9yUmVmKTtcclxuXHJcbiAgLy8gMS4gUkVDRVBUT1IgREUgSUQgREVTREUgUEFORUwtQURNSU4gTyBQQURSRVxyXG4gIEBJbnB1dCgpIGlkUG9zdHVsYW50ZUlucHV0PzogbnVtYmVyO1xyXG4gIEBJbnB1dCgpIGVzTW9kb0FkbWluOiBib29sZWFuID0gZmFsc2U7XHJcblxyXG4gIC8vIEJBTkRFUkFTIERFIE5BVkVHQUNJw5NOIFkgUEVSTUlTT1NcclxuICBlc1Zpc2l0YW50ZTogYm9vbGVhbiA9IGZhbHNlO1xyXG4gIGlkUG9zdHVsYW50ZUFPYnRlbmVyOiBudW1iZXIgPSAwO1xyXG5cclxuICAvLyBEQVRPUyBERUwgVVNVQVJJT1xyXG4gIHBlcmZpbDogUG9zdHVsYW50ZVBlcmZpbERUTyA9IGluaWNpYWxpemFyUGVyZmlsUG9zdHVsYW50ZSgpO1xyXG5cclxuICAvLyBFU1RBRE9TXHJcbiAgZ3VhcmRhbmRvOiBib29sZWFuID0gZmFsc2U7XHJcbiAgbWVuc2FqZUVzdGFkbzogc3RyaW5nIHwgbnVsbCA9IG51bGw7XHJcbiAgbW9zdHJhclZpc3RhUHJldmlhQ1Y6IGJvb2xlYW4gPSBmYWxzZTtcclxuICBjdlByZXZpZXdVcmw6IFNhZmVSZXNvdXJjZVVybCB8IG51bGwgPSBudWxsO1xyXG5cclxuICAvLyBNT0RBTEVTXHJcbiAgbW9kYWxBY3Rpdm86ICdwcmluY2lwYWxlcycgfCAnc29icmVNaScgfCAnc2tpbGxzJyB8ICdyZWRlcycgfCBudWxsID0gbnVsbDtcclxuXHJcbiAgLy8gU0tJTExTXHJcbiAgY2F0ZWdvcmlhc1NraWxsczogQ2F0ZWdvcmlhU2tpbGxEVE9bXSA9IFtdO1xyXG4gIHRlbXBTa2lsbHNJZHM6IG51bWJlcltdID0gW107XHJcbiAgdGVtcE90cmFzSGFiaWxpZGFkZXM6IHN0cmluZyA9ICcnO1xyXG4gIGJ1c3F1ZWRhU2tpbGw6IHN0cmluZyA9ICcnO1xyXG5cclxuICAvLyBGT1RPXHJcbiAgYXJjaGl2b0ZvdG9TZWxlY2Npb25hZG86IEZpbGUgfCBudWxsID0gbnVsbDtcclxuICBmb3RvUHJldmlldzogc3RyaW5nIHwgbnVsbCA9IG51bGw7XHJcblxyXG4gIC8vIEZPUk1VTEFSSU9TIFRFTVBPUkFMRVNcclxuICB0ZW1wVWJpY2FjaW9uID0ge1xyXG4gICAgY2l1ZGFkOiAnJyxcclxuICAgIHBhaXM6ICcnXHJcbiAgfTtcclxuXHJcbiAgdGVtcFNvYnJlTWkgPSB7XHJcbiAgICBzb2JyZV9taTogJycsXHJcbiAgICBlc3BlY2lhbGlkYWQ6ICcnLFxyXG4gICAgZXN0YWRvX2FjYWRlbWljbzogJydcclxuICB9O1xyXG5cclxuICB0ZW1wUmVkZXM6IFJlZGVzRFRPID0ge1xyXG4gICAgZ2l0aHViOiAnJyxcclxuICAgIGxpbmtlZGluOiAnJyxcclxuICAgIHBvcnRmb2xpbzogJydcclxuICB9O1xyXG5cclxuICBuZ09uSW5pdCgpOiB2b2lkIHtcclxuICAgIHRoaXMuZXZhbHVhclljYXJnYXJEYXRvcygpO1xyXG4gIH1cclxuXHJcbiAgLy8gRGV0ZWN0YSBjYW1iaW9zIHNpIGVsIGFkbWluIHNlbGVjY2lvbmEgYSBvdHJvIHBvc3R1bGFudGUgZGUgbGEgbGlzdGFcclxuICBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XHJcbiAgICBpZiAoY2hhbmdlc1snaWRQb3N0dWxhbnRlSW5wdXQnXSAmJiAhY2hhbmdlc1snaWRQb3N0dWxhbnRlSW5wdXQnXS5maXJzdENoYW5nZSkge1xyXG4gICAgICBjb25zdCBudWV2b0lkID0gY2hhbmdlc1snaWRQb3N0dWxhbnRlSW5wdXQnXS5jdXJyZW50VmFsdWU7XHJcbiAgICAgIGlmIChudWV2b0lkKSB7XHJcbiAgICAgICAgdGhpcy5lc1Zpc2l0YW50ZSA9IHRydWU7XHJcbiAgICAgICAgdGhpcy5pZFBvc3R1bGFudGVBT2J0ZW5lciA9IE51bWJlcihudWV2b0lkKTtcclxuICAgICAgICB0aGlzLm9idGVuZXJEYXRvc0RlbFBvc3R1bGFudGUoKTtcclxuICAgICAgICB0aGlzLmNhcmdhckNhdGFsb2dvU2tpbGxzKCk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIHByaXZhdGUgZXZhbHVhclljYXJnYXJEYXRvcygpOiB2b2lkIHtcclxuICAgIGNvbnN0IGlkUGFyYW0gPSB0aGlzLnJvdXRlLnNuYXBzaG90LnBhcmFtTWFwLmdldCgnaWQnKTtcclxuXHJcbiAgICBpZiAodGhpcy5pZFBvc3R1bGFudGVJbnB1dCkge1xyXG4gICAgICAvLyBWaWVuZSBjb21vIGNvbXBvbmVudGUgaGlqbyBlbiBQYW5lbCBBZG1pbiBvIE1vZGFsXHJcbiAgICAgIHRoaXMuZXNWaXNpdGFudGUgPSB0cnVlO1xyXG4gICAgICB0aGlzLmlkUG9zdHVsYW50ZUFPYnRlbmVyID0gTnVtYmVyKHRoaXMuaWRQb3N0dWxhbnRlSW5wdXQpO1xyXG4gICAgfSBlbHNlIGlmIChpZFBhcmFtKSB7XHJcbiAgICAgIC8vIFZpZW5lIHBvciBVUkwgZGlyZWN0YSAoL3Bvc3R1bGFudGUvOmlkKVxyXG4gICAgICB0aGlzLmVzVmlzaXRhbnRlID0gdHJ1ZTtcclxuICAgICAgdGhpcy5pZFBvc3R1bGFudGVBT2J0ZW5lciA9IE51bWJlcihpZFBhcmFtKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIC8vIEVsIHByb3BpbyBhbHVtbm8gaW5ncmVzYW5kbyBhIHN1IHBlcmZpbCAoL3BlcmZpbC9wb3N0dWxhbnRlKVxyXG4gICAgICB0aGlzLmVzVmlzaXRhbnRlID0gZmFsc2U7XHJcbiAgICAgIHRoaXMuaWRQb3N0dWxhbnRlQU9idGVuZXIgPSB0aGlzLm9idGVuZXJJZERlU2VzaW9uKCk7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKHRoaXMuaWRQb3N0dWxhbnRlQU9idGVuZXIpIHtcclxuICAgICAgdGhpcy5vYnRlbmVyRGF0b3NEZWxQb3N0dWxhbnRlKCk7XHJcbiAgICAgIHRoaXMuY2FyZ2FyQ2F0YWxvZ29Ta2lsbHMoKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHByaXZhdGUgb2J0ZW5lcklkRGVTZXNpb24oKTogbnVtYmVyIHtcclxuICAgIGlmIChpc1BsYXRmb3JtQnJvd3Nlcih0aGlzLnBsYXRmb3JtSWQpKSB7XHJcbiAgICAgIGNvbnN0IHVzdWFyaW9TZXNpb24gPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgndXN1YXJpbycpO1xyXG4gICAgICBpZiAodXN1YXJpb1Nlc2lvbikge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBjb25zdCB1c2VyT2JqID0gSlNPTi5wYXJzZSh1c3VhcmlvU2VzaW9uKTtcclxuICAgICAgICAgIHJldHVybiB1c2VyT2JqLmlkX3Bvc3R1bGFudGUgfHwgdXNlck9iai5pZCB8fCAxO1xyXG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBhbCBsZWVyIHVzdWFyaW8gZGUgbG9jYWxTdG9yYWdlOicsIGVycm9yKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHJldHVybiAxO1xyXG4gIH1cclxuXHJcbiAgdm9sdmVyKCk6IHZvaWQge1xyXG4gICAgdGhpcy5sb2NhdGlvbi5iYWNrKCk7XHJcbiAgfVxyXG5cclxuICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAvLyBHRVNUScOTTiBERSBDVVJSSUNVTFVNIFZJVEFFXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gIHByaXZhdGUgb2J0ZW5lclVybENWKCk6IHN0cmluZyB8IG51bGwge1xyXG4gICAgaWYgKCF0aGlzLnBlcmZpbD8uY3ZfdXJsKSByZXR1cm4gbnVsbDtcclxuICAgIGNvbnN0IGJhY2tlbmRVcmwgPSAnaHR0cDovL2xvY2FsaG9zdDozMDAwJztcclxuICAgIHJldHVybiB0aGlzLnBlcmZpbC5jdl91cmwuc3RhcnRzV2l0aCgnaHR0cCcpXHJcbiAgICAgID8gdGhpcy5wZXJmaWwuY3ZfdXJsXHJcbiAgICAgIDogYCR7YmFja2VuZFVybH0ke3RoaXMucGVyZmlsLmN2X3VybH1gO1xyXG4gIH1cclxuXHJcbiAgaXJBQ3VycmljdWx1bSgpOiB2b2lkIHtcclxuICAgIGlmICh0aGlzLmVzVmlzaXRhbnRlKSByZXR1cm47XHJcbiAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbJy9wZXJmaWwvY3VycmljdWx1bSddKTtcclxuICB9XHJcblxyXG4gIHZlckNWKCk6IHZvaWQge1xyXG4gICAgY29uc3QgcmF3VXJsID0gdGhpcy5vYnRlbmVyVXJsQ1YoKTtcclxuXHJcbiAgICBpZiAocmF3VXJsKSB7XHJcbiAgICAgIHRoaXMuY3ZQcmV2aWV3VXJsID0gdGhpcy5zYW5pdGl6ZXIuYnlwYXNzU2VjdXJpdHlUcnVzdFJlc291cmNlVXJsKHJhd1VybCk7XHJcbiAgICAgIHRoaXMubW9zdHJhclZpc3RhUHJldmlhQ1YgPSB0cnVlO1xyXG4gICAgICB0aGlzLmNkci5kZXRlY3RDaGFuZ2VzKCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICB0aGlzLmlyQUN1cnJpY3VsdW0oKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGNlcnJhclZpc3RhUHJldmlhQ1YoKTogdm9pZCB7XHJcbiAgICB0aGlzLm1vc3RyYXJWaXN0YVByZXZpYUNWID0gZmFsc2U7XHJcbiAgICB0aGlzLmN2UHJldmlld1VybCA9IG51bGw7XHJcbiAgfVxyXG5cclxuICBhc3luYyBkZXNjYXJnYXJDVigpOiBQcm9taXNlPHZvaWQ+IHtcclxuICAgIGNvbnN0IHVybCA9IHRoaXMub2J0ZW5lclVybENWKCk7XHJcblxyXG4gICAgaWYgKCF1cmwpIHtcclxuICAgICAgdGhpcy5pckFDdXJyaWN1bHVtKCk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwdWVzdGEgPSBhd2FpdCBmZXRjaCh1cmwpO1xyXG4gICAgICBjb25zdCBibG9iID0gYXdhaXQgcmVzcHVlc3RhLmJsb2IoKTtcclxuXHJcbiAgICAgIGNvbnN0IGJsb2JVcmwgPSB3aW5kb3cuVVJMLmNyZWF0ZU9iamVjdFVSTChibG9iKTtcclxuICAgICAgY29uc3QgbGluayA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKTtcclxuICAgICAgbGluay5ocmVmID0gYmxvYlVybDtcclxuICAgICAgbGluay5kb3dubG9hZCA9IHRoaXMucGVyZmlsLmN2X25vbWJyZSB8fCBgQ1ZfJHt0aGlzLnBlcmZpbC5ub21icmVzfV8ke3RoaXMucGVyZmlsLmFwZWxsaWRvc30ucGRmYDtcclxuXHJcbiAgICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQobGluayk7XHJcbiAgICAgIGxpbmsuY2xpY2soKTtcclxuICAgICAgZG9jdW1lbnQuYm9keS5yZW1vdmVDaGlsZChsaW5rKTtcclxuXHJcbiAgICAgIHdpbmRvdy5VUkwucmV2b2tlT2JqZWN0VVJMKGJsb2JVcmwpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgYWwgZGVzY2FyZ2FyIGVsIFBERjonLCBlcnJvcik7XHJcbiAgICAgIHdpbmRvdy5vcGVuKHVybCwgJ19ibGFuaycpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgLy8gRk9UTyBERSBQRVJGSUxcclxuICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbiAgZ2V0Rm90b1VybCgpOiBzdHJpbmcge1xyXG4gICAgaWYgKHRoaXMuZm90b1ByZXZpZXcpIHtcclxuICAgICAgcmV0dXJuIHRoaXMuZm90b1ByZXZpZXc7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKHRoaXMucGVyZmlsPy5mb3RvKSB7XHJcbiAgICAgIGNvbnN0IGZvdG8gPSB0aGlzLnBlcmZpbC5mb3RvO1xyXG5cclxuICAgICAgaWYgKGZvdG8uc3RhcnRzV2l0aCgnaHR0cCcpIHx8IGZvdG8uc3RhcnRzV2l0aCgnZGF0YTonKSkge1xyXG4gICAgICAgIHJldHVybiBmb3RvO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBjb25zdCBydXRhTGltcGlhID0gZm90by5zdGFydHNXaXRoKCcvJykgPyBmb3RvIDogYC8ke2ZvdG99YDtcclxuICAgICAgcmV0dXJuIGBodHRwOi8vbG9jYWxob3N0OjMwMDAke3J1dGFMaW1waWF9YDtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gJ2Fzc2V0cy9pbWcvZGVmYXVsdC1hdmF0YXIucG5nJztcclxuICB9XHJcblxyXG4gIG9uRm90b0Vycm9yKGV2ZW50OiBFdmVudCk6IHZvaWQge1xyXG4gICAgY29uc3QgaW1nRWxlbWVudCA9IGV2ZW50LnRhcmdldCBhcyBIVE1MSW1hZ2VFbGVtZW50O1xyXG4gICAgaW1nRWxlbWVudC5zcmMgPSAnYXNzZXRzL2ltZy9kZWZhdWx0LWF2YXRhci5wbmcnO1xyXG4gIH1cclxuXHJcbiAgb25Gb3RvU2VsZWNjaW9uYWRhKGV2ZW50OiBFdmVudCk6IHZvaWQge1xyXG4gICAgaWYgKHRoaXMuZXNWaXNpdGFudGUpIHJldHVybjtcclxuXHJcbiAgICBjb25zdCBpbnB1dCA9IGV2ZW50LnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50O1xyXG4gICAgaWYgKCFpbnB1dC5maWxlcyB8fCAhaW5wdXQuZmlsZXNbMF0pIHJldHVybjtcclxuXHJcbiAgICBjb25zdCBmaWxlID0gaW5wdXQuZmlsZXNbMF07XHJcblxyXG4gICAgaWYgKCFmaWxlLnR5cGUuc3RhcnRzV2l0aCgnaW1hZ2UvJykpIHtcclxuICAgICAgYWxlcnQoJ1BvciBmYXZvciBzZWxlY2Npb27DoSB1bmEgaW1hZ2VuIHbDoWxpZGEuJyk7XHJcbiAgICAgIGlucHV0LnZhbHVlID0gJyc7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoZmlsZS5zaXplID4gMiAqIDEwMjQgKiAxMDI0KSB7XHJcbiAgICAgIGFsZXJ0KCdMYSBpbWFnZW4gbm8gZGViZSBzdXBlcmFyIGxvcyAyTUIuJyk7XHJcbiAgICAgIGlucHV0LnZhbHVlID0gJyc7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICB0aGlzLmFyY2hpdm9Gb3RvU2VsZWNjaW9uYWRvID0gZmlsZTtcclxuXHJcbiAgICBjb25zdCByZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpO1xyXG4gICAgcmVhZGVyLm9ubG9hZCA9ICgpID0+IHtcclxuICAgICAgdGhpcy5mb3RvUHJldmlldyA9IHJlYWRlci5yZXN1bHQgYXMgc3RyaW5nO1xyXG4gICAgICB0aGlzLnN1YmlyRm90b1BlcmZpbCgpO1xyXG4gICAgfTtcclxuICAgIHJlYWRlci5yZWFkQXNEYXRhVVJMKGZpbGUpO1xyXG4gIH1cclxuXHJcbiAgc3ViaXJGb3RvUGVyZmlsKCk6IHZvaWQge1xyXG4gICAgaWYgKCF0aGlzLmFyY2hpdm9Gb3RvU2VsZWNjaW9uYWRvIHx8ICF0aGlzLmlkUG9zdHVsYW50ZUFPYnRlbmVyKSByZXR1cm47XHJcblxyXG4gICAgdGhpcy5wb3N0dWxhbnRlU2VydmljZVxyXG4gICAgICAuc3ViaXJGb3RvUGVyZmlsKHRoaXMuaWRQb3N0dWxhbnRlQU9idGVuZXIsIHRoaXMuYXJjaGl2b0ZvdG9TZWxlY2Npb25hZG8pXHJcbiAgICAgIC5zdWJzY3JpYmUoe1xyXG4gICAgICAgIG5leHQ6IChyZXM6IGFueSkgPT4ge1xyXG4gICAgICAgICAgaWYgKHJlcy5zdWNjZXNzKSB7XHJcbiAgICAgICAgICAgIHRoaXMucGVyZmlsLmZvdG8gPSByZXMuZm90b1VybCB8fCByZXMuZGF0YSB8fCAnJztcclxuICAgICAgICAgICAgdGhpcy5hcmNoaXZvRm90b1NlbGVjY2lvbmFkbyA9IG51bGw7XHJcbiAgICAgICAgICAgIHRoaXMuZm90b1ByZXZpZXcgPSBudWxsO1xyXG4gICAgICAgICAgICBhbGVydCgnwqFGb3RvIGRlIHBlcmZpbCBhY3R1YWxpemFkYSEnKTtcclxuICAgICAgICAgICAgdGhpcy5jZHIuZGV0ZWN0Q2hhbmdlcygpO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgYWxlcnQocmVzLm1lc3NhZ2UgfHwgJ05vIHNlIHB1ZG8gc3ViaXIgbGEgZm90by4nKTtcclxuICAgICAgICAgICAgdGhpcy5mb3RvUHJldmlldyA9IG51bGw7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSxcclxuICAgICAgICBlcnJvcjogKGVycjogYW55KSA9PiB7XHJcbiAgICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBhbCBzdWJpciBmb3RvOicsIGVycik7XHJcbiAgICAgICAgICB0aGlzLmZvdG9QcmV2aWV3ID0gbnVsbDtcclxuICAgICAgICAgIGFsZXJ0KGVycj8uZXJyb3I/Lm1lc3NhZ2UgfHwgJ09jdXJyacOzIHVuIGVycm9yIGFsIHN1YmlyIGxhIGZvdG8gZGUgcGVyZmlsLicpO1xyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcbiAgfVxyXG5cclxuICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAvLyBPQlRFTkVSIFkgR1VBUkRBUiBQRVJGSUxcclxuICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcbiAgb2J0ZW5lckRhdG9zRGVsUG9zdHVsYW50ZSgpOiB2b2lkIHtcclxuICAgIGlmICghdGhpcy5pZFBvc3R1bGFudGVBT2J0ZW5lcikgcmV0dXJuO1xyXG5cclxuICAgIHRoaXMucG9zdHVsYW50ZVNlcnZpY2UuZ2V0UGVyZmlsKHRoaXMuaWRQb3N0dWxhbnRlQU9idGVuZXIpLnN1YnNjcmliZSh7XHJcbiAgICAgIG5leHQ6IChyZXMpID0+IHtcclxuICAgICAgICBpZiAocmVzLnN1Y2Nlc3MgJiYgcmVzLmRhdGEpIHtcclxuICAgICAgICAgIHRoaXMucGVyZmlsID0ge1xyXG4gICAgICAgICAgICAuLi5pbmljaWFsaXphclBlcmZpbFBvc3R1bGFudGUoKSxcclxuICAgICAgICAgICAgLi4ucmVzLmRhdGEsXHJcbiAgICAgICAgICAgIHNraWxsczogcmVzLmRhdGEuc2tpbGxzIHx8IFtdLFxyXG4gICAgICAgICAgICByZWRlczogcmVzLmRhdGEucmVkZXMgfHwgeyBnaXRodWI6ICcnLCBsaW5rZWRpbjogJycsIHBvcnRmb2xpbzogJycgfVxyXG4gICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5jZHIuZGV0ZWN0Q2hhbmdlcygpO1xyXG4gICAgICB9LFxyXG4gICAgICBlcnJvcjogKGVycikgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGFsIG9idGVuZXIgcGVyZmlsOicsIGVycik7XHJcbiAgICAgICAgdGhpcy5jZHIuZGV0ZWN0Q2hhbmdlcygpO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIGd1YXJkYXJQZXJmaWxDb21wbGV0bygpOiB2b2lkIHtcclxuICAgIGlmICghdGhpcy5pZFBvc3R1bGFudGVBT2J0ZW5lcikge1xyXG4gICAgICBhbGVydCgnTm8gc2UgaWRlbnRpZmljw7MgbGEgc2VzacOzbiBkZWwgdXN1YXJpby4nKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHRoaXMuZ3VhcmRhbmRvID0gdHJ1ZTtcclxuICAgIHRoaXMubWVuc2FqZUVzdGFkbyA9IG51bGw7XHJcblxyXG4gICAgdGhpcy5wb3N0dWxhbnRlU2VydmljZVxyXG4gICAgICAuYWN0dWFsaXphclBlcmZpbCh0aGlzLmlkUG9zdHVsYW50ZUFPYnRlbmVyLCB0aGlzLnBlcmZpbClcclxuICAgICAgLnN1YnNjcmliZSh7XHJcbiAgICAgICAgbmV4dDogKHJlcykgPT4ge1xyXG4gICAgICAgICAgdGhpcy5ndWFyZGFuZG8gPSBmYWxzZTtcclxuICAgICAgICAgIGlmIChyZXMuc3VjY2Vzcykge1xyXG4gICAgICAgICAgICB0aGlzLm1lbnNhamVFc3RhZG8gPSAnwqFQZXJmaWwgZ3VhcmRhZG8gY29uIMOpeGl0byEnO1xyXG4gICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgICB0aGlzLm1lbnNhamVFc3RhZG8gPSBudWxsO1xyXG4gICAgICAgICAgICAgIHRoaXMuY2RyLmRldGVjdENoYW5nZXMoKTtcclxuICAgICAgICAgICAgfSwgNDAwMCk7XHJcbiAgICAgICAgICAgIHRoaXMub2J0ZW5lckRhdG9zRGVsUG9zdHVsYW50ZSgpO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgYWxlcnQocmVzLm1lc3NhZ2UgfHwgJ05vIHNlIHB1ZGllcm9uIGd1YXJkYXIgbG9zIGNhbWJpb3MuJyk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICB0aGlzLmNkci5kZXRlY3RDaGFuZ2VzKCk7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBlcnJvcjogKGVycikgPT4ge1xyXG4gICAgICAgICAgdGhpcy5ndWFyZGFuZG8gPSBmYWxzZTtcclxuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGFsIGd1YXJkYXIgcGVyZmlsOicsIGVycik7XHJcbiAgICAgICAgICBhbGVydChlcnI/LmVycm9yPy5tZXNzYWdlIHx8ICdPY3VycmnDsyB1biBlcnJvciBhbCBndWFyZGFyIGxvcyBkYXRvcy4nKTtcclxuICAgICAgICAgIHRoaXMuY2RyLmRldGVjdENoYW5nZXMoKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgLy8gQ0FUw4FMT0dPIFkgR0VTVEnDk04gREUgU0tJTExTXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gIGdldCBjYXRlZ29yaWFzRmlsdHJhZGFzKCk6IENhdGVnb3JpYVNraWxsRFRPW10ge1xyXG4gICAgaWYgKCF0aGlzLmJ1c3F1ZWRhU2tpbGwgfHwgIXRoaXMuYnVzcXVlZGFTa2lsbC50cmltKCkpIHtcclxuICAgICAgcmV0dXJuIHRoaXMuY2F0ZWdvcmlhc1NraWxscztcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBidXNxdWVkYSA9IHRoaXMuYnVzcXVlZGFTa2lsbC50b0xvd2VyQ2FzZSgpLnRyaW0oKTtcclxuXHJcbiAgICByZXR1cm4gdGhpcy5jYXRlZ29yaWFzU2tpbGxzXHJcbiAgICAgIC5tYXAoY2F0ID0+ICh7XHJcbiAgICAgICAgLi4uY2F0LFxyXG4gICAgICAgIHNraWxsczogY2F0LnNraWxscy5maWx0ZXIocyA9PiBzLm5vbWJyZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGJ1c3F1ZWRhKSlcclxuICAgICAgfSkpXHJcbiAgICAgIC5maWx0ZXIoY2F0ID0+IGNhdC5za2lsbHMubGVuZ3RoID4gMCk7XHJcbiAgfVxyXG5cclxuICBjYXJnYXJDYXRhbG9nb1NraWxscygpOiB2b2lkIHtcclxuICAgIHRoaXMucG9zdHVsYW50ZVNlcnZpY2UuZ2V0Q2F0YWxvZ29Ta2lsbHMoKS5zdWJzY3JpYmUoe1xyXG4gICAgICBuZXh0OiAocmVzKSA9PiB7XHJcbiAgICAgICAgaWYgKHJlcy5zdWNjZXNzKSB7XHJcbiAgICAgICAgICB0aGlzLmNhdGVnb3JpYXNTa2lsbHMgPSByZXMuZGF0YTtcclxuICAgICAgICAgIHRoaXMuY2RyLmRldGVjdENoYW5nZXMoKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICAgIGVycm9yOiAoZXJyKSA9PiBjb25zb2xlLmVycm9yKCdFcnJvciBhbCBjYXJnYXIgc2tpbGxzOicsIGVycilcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgdG9nZ2xlU2tpbGwoc2tpbGxJZDogbnVtYmVyKTogdm9pZCB7XHJcbiAgICBjb25zdCBpZHggPSB0aGlzLnRlbXBTa2lsbHNJZHMuaW5kZXhPZihza2lsbElkKTtcclxuICAgIGlmIChpZHggPiAtMSkge1xyXG4gICAgICB0aGlzLnRlbXBTa2lsbHNJZHMuc3BsaWNlKGlkeCwgMSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICB0aGlzLnRlbXBTa2lsbHNJZHMucHVzaChza2lsbElkKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGVzU2tpbGxTZWxlY2Npb25hZGEoc2tpbGxJZDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gdGhpcy50ZW1wU2tpbGxzSWRzLmluY2x1ZGVzKHNraWxsSWQpO1xyXG4gIH1cclxuXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgLy8gTMOTR0lDQSBERSBNT0RBTEVTXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gIGFicmlyTW9kYWwodGlwbzogJ3ByaW5jaXBhbGVzJyB8ICdzb2JyZU1pJyB8ICdza2lsbHMnIHwgJ3JlZGVzJyk6IHZvaWQge1xyXG4gICAgaWYgKHRoaXMuZXNWaXNpdGFudGUpIHJldHVybjtcclxuXHJcbiAgICB0aGlzLm1vZGFsQWN0aXZvID0gdGlwbztcclxuXHJcbiAgICBzd2l0Y2ggKHRpcG8pIHtcclxuICAgICAgY2FzZSAncHJpbmNpcGFsZXMnOlxyXG4gICAgICAgIHRoaXMudGVtcFViaWNhY2lvbiA9IHtcclxuICAgICAgICAgIGNpdWRhZDogdGhpcy5wZXJmaWwuY2l1ZGFkLFxyXG4gICAgICAgICAgcGFpczogdGhpcy5wZXJmaWwucGFpc1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICBjYXNlICdzb2JyZU1pJzpcclxuICAgICAgICB0aGlzLnRlbXBTb2JyZU1pID0ge1xyXG4gICAgICAgICAgc29icmVfbWk6IHRoaXMucGVyZmlsLnNvYnJlX21pIHx8ICcnLFxyXG4gICAgICAgICAgZXNwZWNpYWxpZGFkOiB0aGlzLnBlcmZpbC5lc3BlY2lhbGlkYWQgfHwgJycsXHJcbiAgICAgICAgICBlc3RhZG9fYWNhZGVtaWNvOiB0aGlzLnBlcmZpbC5lc3RhZG9fYWNhZGVtaWNvIHx8ICdFc3R1ZGlhbnRlIEF2YW56YWRvJ1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICBjYXNlICdza2lsbHMnOlxyXG4gICAgICAgIHRoaXMuYnVzcXVlZGFTa2lsbCA9ICcnO1xyXG4gICAgICAgIHRoaXMudGVtcFNraWxsc0lkcyA9IHRoaXMucGVyZmlsLnNraWxscy5tYXAocyA9PiBzLnNraWxsX2lkKTtcclxuICAgICAgICB0aGlzLnRlbXBPdHJhc0hhYmlsaWRhZGVzID0gdGhpcy5wZXJmaWwub3RyYXNfaGFiaWxpZGFkZXMgfHwgJyc7XHJcbiAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICBjYXNlICdyZWRlcyc6XHJcbiAgICAgICAgdGhpcy50ZW1wUmVkZXMgPSB7IC4uLnRoaXMucGVyZmlsLnJlZGVzIH07XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBjZXJyYXJNb2RhbCgpOiB2b2lkIHtcclxuICAgIHRoaXMubW9kYWxBY3Rpdm8gPSBudWxsO1xyXG4gIH1cclxuXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgLy8gTcOJVE9ET1MgREUgR1VBUkRBRE8gREVTREUgTU9EQUxFU1xyXG4gIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICBndWFyZGFyVWJpY2FjaW9uKCk6IHZvaWQge1xyXG4gICAgdGhpcy5wZXJmaWwuY2l1ZGFkID0gdGhpcy50ZW1wVWJpY2FjaW9uLmNpdWRhZDtcclxuICAgIHRoaXMucGVyZmlsLnBhaXMgPSB0aGlzLnRlbXBVYmljYWNpb24ucGFpcztcclxuICAgIHRoaXMuZ3VhcmRhclBlcmZpbENvbXBsZXRvKCk7XHJcbiAgICB0aGlzLmNlcnJhck1vZGFsKCk7XHJcbiAgfVxyXG5cclxuICBndWFyZGFyU29icmVNaSgpOiB2b2lkIHtcclxuICAgIHRoaXMucGVyZmlsLnNvYnJlX21pID0gdGhpcy50ZW1wU29icmVNaS5zb2JyZV9taTtcclxuICAgIHRoaXMucGVyZmlsLmVzcGVjaWFsaWRhZCA9IHRoaXMudGVtcFNvYnJlTWkuZXNwZWNpYWxpZGFkO1xyXG4gICAgdGhpcy5wZXJmaWwuZXN0YWRvX2FjYWRlbWljbyA9IHRoaXMudGVtcFNvYnJlTWkuZXN0YWRvX2FjYWRlbWljbztcclxuICAgIHRoaXMuZ3VhcmRhclBlcmZpbENvbXBsZXRvKCk7XHJcbiAgICB0aGlzLmNlcnJhck1vZGFsKCk7XHJcbiAgfVxyXG5cclxuICBndWFyZGFyU2tpbGxzKCk6IHZvaWQge1xyXG4gICAgY29uc3QgdG9kYXNMYXNTa2lsbHM6IFNraWxsRFRPW10gPSBbXTtcclxuICAgIHRoaXMuY2F0ZWdvcmlhc1NraWxscy5mb3JFYWNoKGNhdCA9PiB0b2Rhc0xhc1NraWxscy5wdXNoKC4uLmNhdC5za2lsbHMpKTtcclxuXHJcbiAgICB0aGlzLnBlcmZpbC5za2lsbHMgPSB0b2Rhc0xhc1NraWxscy5maWx0ZXIocyA9PiB0aGlzLnRlbXBTa2lsbHNJZHMuaW5jbHVkZXMocy5za2lsbF9pZCkpO1xyXG4gICAgdGhpcy5wZXJmaWwub3RyYXNfaGFiaWxpZGFkZXMgPSB0aGlzLnRlbXBPdHJhc0hhYmlsaWRhZGVzO1xyXG4gICAgdGhpcy5ndWFyZGFyUGVyZmlsQ29tcGxldG8oKTtcclxuICAgIHRoaXMuY2VycmFyTW9kYWwoKTtcclxuICB9XHJcblxyXG4gIGd1YXJkYXJTa2lsbHNNb2RhbCgpOiB2b2lkIHtcclxuICAgIHRoaXMuZ3VhcmRhclNraWxscygpO1xyXG4gIH1cclxuXHJcbiAgZ3VhcmRhclJlZGVzKCk6IHZvaWQge1xyXG4gICAgdGhpcy5wZXJmaWwucmVkZXMgPSB7IC4uLnRoaXMudGVtcFJlZGVzIH07XHJcbiAgICB0aGlzLmd1YXJkYXJQZXJmaWxDb21wbGV0bygpO1xyXG4gICAgdGhpcy5jZXJyYXJNb2RhbCgpO1xyXG4gIH1cclxufSIsIjxkaXYgY2xhc3M9XCJwZXJmaWwtY29udGFpbmVyXCI+XHJcblxyXG4gIDwhLS0gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAgICAgIDEuIENBUkQgUFJJTkNJUEFMXHJcbiAgICAgICA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAtLT5cclxuICA8ZGl2IGNsYXNzPVwicGVyZmlsLWNhcmQgY2FyZC1tYWluXCI+XHJcblxyXG4gICAgPCEtLSBGT1RPIERFIFBFUkZJTCAtLT5cclxuICAgIDxkaXYgY2xhc3M9XCJmb3RvLWNvbnRhaW5lclwiPlxyXG4gICAgICA8ZGl2IGNsYXNzPVwiYXZhdGFyLXdyYXBwZXJcIj5cclxuICAgICAgICBAaWYgKHBlcmZpbC5mb3RvIHx8IGZvdG9QcmV2aWV3KSB7XHJcbiAgICAgICAgICA8aW1nIFtzcmNdPVwiZ2V0Rm90b1VybCgpXCIgYWx0PVwiRm90byBkZSBQZXJmaWxcIiBjbGFzcz1cImZvdG8tYXZhdGFyXCIgKGVycm9yKT1cInBlcmZpbC5mb3RvID0gJydcIj5cclxuICAgICAgICB9IEBlbHNlIHtcclxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJhdmF0YXItcGxhY2Vob2xkZXJcIj5cclxuICAgICAgICAgICAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJjdXJyZW50Q29sb3JcIiBjbGFzcz1cImljb24tdXNlclwiPlxyXG4gICAgICAgICAgICAgIDxwYXRoIGZpbGwtcnVsZT1cImV2ZW5vZGRcIiBkPVwiTTcuNSA2YTQuNSA0LjUgMCAxIDEgOSAwYTQuNSA0LjUgMCAwIDEtOSAwWk0zLjc1MSAyMC4xMDVhOC4yNSA4LjI1IDAgMCAxIDE2LjQ5OCAwIC43NS43NSAwIDAgMS0uNDM3LjY5NUExOC42ODMgMTguNjgzIDAgMCAxIDEyIDIyLjVjLTIuNzg2IDAtNS40MzMtLjYtNy44MTItMS43YS43NS43NSAwIDAgMS0uNDM3LS42OTVaXCIgY2xpcC1ydWxlPVwiZXZlbm9kZFwiIC8+XHJcbiAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICA8IS0tIPCfk7cgQm90w7NuIGNhbWJpYXIgZm90byAoU29sbyB2aXNpYmxlIHBhcmEgZWwgYWx1bW5vKSAtLT5cclxuICAgICAgICBAaWYgKCFlc1Zpc2l0YW50ZSkge1xyXG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3M9XCJidG4tZm90by1iYWRnZVwiIChjbGljayk9XCJmb3RvSW5wdXQuY2xpY2soKVwiIFtkaXNhYmxlZF09XCJndWFyZGFuZG9cIiB0aXRsZT1cIkNhbWJpYXIgZm90byBkZSBwZXJmaWxcIj5cclxuICAgICAgICAgICAg8J+Tt1xyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8aW5wdXQgdHlwZT1cImZpbGVcIiAjZm90b0lucHV0IChjaGFuZ2UpPVwib25Gb3RvU2VsZWNjaW9uYWRhKCRldmVudClcIiBhY2NlcHQ9XCJpbWFnZS9wbmcsIGltYWdlL2pwZWcsIGltYWdlL2pwZ1wiIHN0eWxlPVwiZGlzcGxheTogbm9uZTtcIj5cclxuICAgICAgICB9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcblxyXG4gICAgPCEtLSBEQVRPUyBERUwgVVNVQVJJTyAtLT5cclxuICAgIDxkaXYgY2xhc3M9XCJ1c2VyLWluZm9cIj5cclxuICAgICAgPGgyPnt7IHBlcmZpbC5ub21icmVzIHx8ICdOb21icmUnIH19IHt7IHBlcmZpbC5hcGVsbGlkb3MgfHwgJ0FwZWxsaWRvJyB9fTwvaDI+XHJcbiAgICAgIDxwIGNsYXNzPVwiY2FycmVyYS10ZXh0XCI+8J+OkyB7eyBwZXJmaWwuY2FycmVyYSB8fCAnQ2FycmVyYSBubyBlc3BlY2lmaWNhZGEnIH19PC9wPlxyXG4gICAgICA8cCBjbGFzcz1cImVtYWlsLXRleHRcIj7inInvuI8ge3sgcGVyZmlsLmVtYWlsIHx8ICdjb3JyZW9AZWplbXBsby5jb20nIH19PC9wPlxyXG4gICAgICA8cCBjbGFzcz1cInViaWNhY2lvblwiPlxyXG4gICAgICAgIPCfk40ge3sgcGVyZmlsLmNpdWRhZCA/IHBlcmZpbC5jaXVkYWQgKyAocGVyZmlsLnBhaXMgPyAnLCAnICsgcGVyZmlsLnBhaXMgOiAnJykgOiAnVWJpY2FjacOzbiBubyBlc3BlY2lmaWNhZGEnIH19XHJcbiAgICAgIDwvcD5cclxuXHJcbiAgICAgIDwhLS0gQk9UT05FUyBQUklOQ0lQQUxFUyAtLT5cclxuICAgICAgPGRpdiBjbGFzcz1cImFjY2lvbmVzLWhlYWRlclwiPlxyXG4gICAgICAgIEBpZiAoZXNWaXNpdGFudGUpIHtcclxuICAgICAgICAgIDwhLS0g8J+Rge+4jyBCb3TDs24gZGUgbmF2ZWdhY2nDs24gcGFyYSBFbXByZXNhcyBvIEFkbWlucyAtLT5cclxuICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzPVwiYnRuLXNlY3VuZGFyaW9cIiAoY2xpY2spPVwidm9sdmVyKClcIj5cclxuICAgICAgICAgICAg4oaQIFZvbHZlclxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgfSBAZWxzZSB7XHJcbiAgICAgICAgICA8IS0tIOKcj++4jyBDb250cm9sZXMgZGUgZWRpY2nDs24gZGVsIHByb3BpbyBhbHVtbm8gLS0+XHJcbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzcz1cImJ0bi1lZGl0YXJcIiAoY2xpY2spPVwiYWJyaXJNb2RhbCgncHJpbmNpcGFsZXMnKVwiPlxyXG4gICAgICAgICAgICDinI/vuI8gRWRpdGFyIFViaWNhY2nDs25cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzPVwiYnRuLWd1YXJkYXItbWFpblwiIFtkaXNhYmxlZF09XCJndWFyZGFuZG9cIiAoY2xpY2spPVwiZ3VhcmRhclBlcmZpbENvbXBsZXRvKClcIj5cclxuICAgICAgICAgICAgQGlmICghZ3VhcmRhbmRvKSB7XHJcbiAgICAgICAgICAgICAgPHNwYW4+8J+SviBHdWFyZGFyIFBlcmZpbCBEZWZpbml0aXZvPC9zcGFuPlxyXG4gICAgICAgICAgICB9IEBlbHNlIHtcclxuICAgICAgICAgICAgICA8c3Bhbj7ij7MgR3VhcmRhbmRvLi4uPC9zcGFuPlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICB9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcblxyXG4gIDwvZGl2PlxyXG5cclxuICA8IS0tIE1FTlNBSkUgREUgR1VBUkRBRE8gLS0+XHJcbiAgQGlmIChtZW5zYWplRXN0YWRvICYmICFlc1Zpc2l0YW50ZSkge1xyXG4gICAgPGRpdiBjbGFzcz1cImFsZXJ0LXN1Y2Nlc3MtY3VzdG9tXCI+XHJcbiAgICAgIHt7IG1lbnNhamVFc3RhZG8gfX1cclxuICAgIDwvZGl2PlxyXG4gIH1cclxuXHJcbiAgPCEtLSA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gICAgICAgMi4gUEVSRklMIFBST0ZFU0lPTkFMXHJcbiAgICAgICA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAtLT5cclxuICA8ZGl2IGNsYXNzPVwicGVyZmlsLWNhcmQgY2FyZC1zb2JyZS1taVwiPlxyXG4gICAgPGRpdiBjbGFzcz1cImNhcmQtaGVhZGVyLWFjdGlvbnNcIj5cclxuICAgICAgPGgzPvCfkrsgUGVyZmlsIFByb2Zlc2lvbmFsPC9oMz5cclxuICAgICAgPCEtLSDinI/vuI8gQm90w7NuIG1vZGFsIChTb2xvIHZpc2libGUgcGFyYSBlbCBhbHVtbm8pIC0tPlxyXG4gICAgICBAaWYgKCFlc1Zpc2l0YW50ZSkge1xyXG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzPVwiYnRuLWxpbmstZWRpdGFyXCIgKGNsaWNrKT1cImFicmlyTW9kYWwoJ3NvYnJlTWknKVwiIHRpdGxlPVwiRWRpdGFyIGRlc2NyaXBjacOzblwiPlxyXG4gICAgICAgICAg4pyP77iPXHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIH1cclxuICAgIDwvZGl2PlxyXG5cclxuICAgIEBpZiAocGVyZmlsLnNvYnJlX21pKSB7XHJcbiAgICAgIDxwIGNsYXNzPVwidGV4dG8tZGVzY3JpcGNpb25cIj57eyBwZXJmaWwuc29icmVfbWkgfX08L3A+XHJcbiAgICB9IEBlbHNlIHtcclxuICAgICAgPHAgY2xhc3M9XCJlbXB0eS10ZXh0XCI+XHJcbiAgICAgICAgQGlmIChlc1Zpc2l0YW50ZSkge1xyXG4gICAgICAgICAgRWwgcG9zdHVsYW50ZSBhw7puIG5vIGhhIGNhcmdhZG8gc3UgcHJlc2VudGFjacOzbiBwcm9mZXNpb25hbC5cclxuICAgICAgICB9IEBlbHNlIHtcclxuICAgICAgICAgIENvbnRhbGUgYSBsYXMgZW1wcmVzYXMgdHUgZW5mb3F1ZSB0w6ljbmljbzogdGVjbm9sb2fDrWFzIHByaW5jaXBhbGVzLCBvcmllbnRhY2nDs24geSBtb3RpdmFjacOzbiBwcm9mZXNpb25hbC5cclxuICAgICAgICB9XHJcbiAgICAgIDwvcD5cclxuICAgIH1cclxuXHJcbiAgICA8ZGl2IGNsYXNzPVwicmVzdW1lbi10ZWNuaWNvLWdyaWRcIj5cclxuICAgICAgPGRpdiBjbGFzcz1cIml0ZW0tcmVzdW1lblwiPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzPVwibGFiZWxcIj5Fc3BlY2lhbGlkYWQgLyBJbnRlcsOpczo8L3NwYW4+XHJcbiAgICAgICAgPHNwYW4gY2xhc3M9XCJ2YWxvclwiPnt7IHBlcmZpbC5lc3BlY2lhbGlkYWQgfHwgJ05vIGRlZmluaWRhJyB9fTwvc3Bhbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJpdGVtLXJlc3VtZW5cIj5cclxuICAgICAgICA8c3BhbiBjbGFzcz1cImxhYmVsXCI+RXN0YWRvIGFjYWTDqW1pY286PC9zcGFuPlxyXG4gICAgICAgIDxzcGFuIGNsYXNzPVwidmFsb3JcIj57eyBwZXJmaWwuZXN0YWRvX2FjYWRlbWljbyB8fCAnRXN0dWRpYW50ZSBBdmFuemFkbycgfX08L3NwYW4+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgPC9kaXY+XHJcblxyXG5cclxuIDwhLS0gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAgICAgIDMuIENVUlJJQ1VMVU0gVklUQUVcclxuICAgICAgID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IC0tPlxyXG4gIDxkaXYgY2xhc3M9XCJwZXJmaWwtY2FyZCBjYXJkLWN2XCI+XHJcbiAgICA8ZGl2IGNsYXNzPVwiY2FyZC1oZWFkZXItYWN0aW9uc1wiPlxyXG4gICAgICA8aDM+8J+ThCBDdXJyaWN1bHVtIFZpdGFlPC9oMz5cclxuICAgICAgPCEtLSDinI/vuI8gU29sbyB2aXNpYmxlIHBhcmEgZWwgYWx1bW5vIC0tPlxyXG4gICAgICBAaWYgKCFlc1Zpc2l0YW50ZSkge1xyXG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzPVwiYnRuLWxpbmstZWRpdGFyXCIgKGNsaWNrKT1cImlyQUN1cnJpY3VsdW0oKVwiIHRpdGxlPVwiSXIgYWwgbcOzZHVsbyBkZSBDdXJyaWN1bHVtXCI+XHJcbiAgICAgICAgICDinI/vuI9cclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgfVxyXG4gICAgPC9kaXY+XHJcblxyXG4gICAgQGlmIChwZXJmaWwuY3ZfdXJsKSB7XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJjdi1jb250ZW50XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cImN2LWFkanVudG9cIj5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzPVwiaWNvbm8tZG9jXCI+8J+ThDwvc3Bhbj5cclxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJjdi1pbmZvXCI+XHJcbiAgICAgICAgICAgIDxzdHJvbmc+e3sgcGVyZmlsLmN2X25vbWJyZSB8fCAnQ3VycmljdWx1bV9WaXRhZS5wZGYnIH19PC9zdHJvbmc+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiY3YtZXN0YWRvXCI+4pyTIENWIGRpc3BvbmlibGU8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzcz1cImN2LWFjY2lvbmVzXCI+XHJcbiAgICAgICAgICA8IS0tIPCfkYHvuI8g4qyH77iPIEFjY2lvbmVzIGRlIGxlY3R1cmEgKEVtcHJlc2EsIEFkbWluIHkgQWx1bW5vKSAtLT5cclxuICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzPVwiYnRuLWN2IGJ0bi12aXN0YS1wcmV2aWFcIiAoY2xpY2spPVwidmVyQ1YoKVwiPlxyXG4gICAgICAgICAgICDwn5GB77iPIFZlciAvIFByZXZpc3VhbGl6YXJcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3M9XCJidG4tY3YgYnRuLWRlc2NhcmdhclwiIChjbGljayk9XCJkZXNjYXJnYXJDVigpXCI+XHJcbiAgICAgICAgICAgIOKsh++4jyBEZXNjYXJnYXJcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgIDwhLS0g8J+TnSBFZGljacOzbiBzb2xvIHBhcmEgZWwgQWx1bW5vIC0tPlxyXG4gICAgICAgICAgQGlmICghZXNWaXNpdGFudGUpIHtcclxuICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3M9XCJidG4tY3YgYnRuLWNhbWJpYXJcIiAoY2xpY2spPVwiaXJBQ3VycmljdWx1bSgpXCI+XHJcbiAgICAgICAgICAgICAg8J+TnSBJciBhIEN1cnJpY3VsdW1cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgfSBAZWxzZSB7XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJjdi1jb250ZW50IGN2LXNpbi1hZGp1bnRhclwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJjdi11cGxvYWQtaWNvblwiPvCfk4Q8L2Rpdj5cclxuICAgICAgICBcclxuICAgICAgICBAaWYgKGVzVmlzaXRhbnRlKSB7XHJcbiAgICAgICAgICA8aDQ+U2luIENWIGFkanVudGFkbzwvaDQ+XHJcbiAgICAgICAgICA8cCBjbGFzcz1cImN2LWRlc2NyaXBjaW9uXCI+RWwgcG9zdHVsYW50ZSBhw7puIG5vIGhhIHN1YmlkbyBzdSBDdXJyaWN1bHVtIFZpdGFlLjwvcD5cclxuICAgICAgICB9IEBlbHNlIHtcclxuICAgICAgICAgIDxoND5ObyB0ZW7DqXMgdW4gQ1YgYWRqdW50YWRvPC9oND5cclxuICAgICAgICAgIDxwIGNsYXNzPVwiY3YtZGVzY3JpcGNpb25cIj5cclxuICAgICAgICAgICAgSW5ncmVzw6EgYWwgZ2VzdG9yIGRlIENWIHBhcmEgY2FyZ2FybG8geSBjb25maWd1cmFybG8uXHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiY3YtYWNjaW9uZXNcIj5cclxuICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3M9XCJidG4tY3YgYnRuLXByaW1hcnlcIiAoY2xpY2spPVwiaXJBQ3VycmljdWx1bSgpXCI+XHJcbiAgICAgICAgICAgICAg8J+agCBDYXJnYXIgLyBJciBhIEN1cnJpY3VsdW1cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICB9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgfVxyXG4gIDwvZGl2PlxyXG5cclxuICA8IS0tID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgICAgICA0LiBTVEFDSyBUw4lDTklDTyBZIEhBQklMSURBREVTXHJcbiAgICAgICA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAtLT5cclxuICA8ZGl2IGNsYXNzPVwicGVyZmlsLWNhcmQgY2FyZC1za2lsbHNcIj5cclxuICAgIDxkaXYgY2xhc3M9XCJjYXJkLWhlYWRlci1hY3Rpb25zXCI+XHJcbiAgICAgIDxoMz7wn5ug77iPIFN0YWNrIFTDqWNuaWNvIHkgSGFiaWxpZGFkZXM8L2gzPlxyXG4gICAgICBAaWYgKCFlc1Zpc2l0YW50ZSkge1xyXG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzPVwiYnRuLWxpbmstZWRpdGFyXCIgKGNsaWNrKT1cImFicmlyTW9kYWwoJ3NraWxscycpXCIgdGl0bGU9XCJTZWxlY2Npb25hciBoYWJpbGlkYWRlc1wiPlxyXG4gICAgICAgICAg4pyP77iPXHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIH1cclxuICAgIDwvZGl2PlxyXG5cclxuICAgIDxkaXYgY2xhc3M9XCJ0YWdzLWNvbnRhaW5lclwiPlxyXG4gICAgICBAZm9yIChza2lsbCBvZiBwZXJmaWwuc2tpbGxzIHx8IFtdOyB0cmFjayBza2lsbC5za2lsbF9pZCkge1xyXG4gICAgICAgIDxzcGFuIGNsYXNzPVwidGFnXCI+e3sgc2tpbGwubm9tYnJlIH19PC9zcGFuPlxyXG4gICAgICB9XHJcbiAgICA8L2Rpdj5cclxuXHJcbiAgICBAaWYgKHBlcmZpbC5vdHJhc19oYWJpbGlkYWRlcykge1xyXG4gICAgICA8ZGl2IGNsYXNzPVwib3RyYXMtaGFiaWxpZGFkZXMtZGlzcGxheVwiPlxyXG4gICAgICAgIDxwIGNsYXNzPVwic3VidGl0dWxvLWhhYmlsaWRhZGVzXCI+T3RyYXMgaGVycmFtaWVudGFzIHkgY29ub2NpbWllbnRvczo8L3A+XHJcbiAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0by1hZGljaW9uYWxcIj57eyBwZXJmaWwub3RyYXNfaGFiaWxpZGFkZXMgfX08L3A+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgfVxyXG5cclxuICAgIEBpZiAoKHBlcmZpbC5za2lsbHMubGVuZ3RoIHx8IDApID09PSAwICYmICFwZXJmaWwub3RyYXNfaGFiaWxpZGFkZXMpIHtcclxuICAgICAgPHAgY2xhc3M9XCJlbXB0eS10ZXh0XCI+XHJcbiAgICAgICAgQGlmIChlc1Zpc2l0YW50ZSkge1xyXG4gICAgICAgICAgRWwgcG9zdHVsYW50ZSBhw7puIG5vIGhhIHJlZ2lzdHJhZG8gc3VzIGhhYmlsaWRhZGVzIHTDqWNuaWNhcy5cclxuICAgICAgICB9IEBlbHNlIHtcclxuICAgICAgICAgIEhhY8OpIGNsaWMgZW4gZWwgbMOhcGl6IHBhcmEgc2VsZWNjaW9uYXIgdHVzIGhhYmlsaWRhZGVzIGRlbCBjYXTDoWxvZ28gbyBhZ3JlZ2FyIG90cmFzLlxyXG4gICAgICAgIH1cclxuICAgICAgPC9wPlxyXG4gICAgfVxyXG4gIDwvZGl2PlxyXG5cclxuICA8IS0tID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgICAgICA1LiBSRURFUyBZIFBPUlRBRk9MSU9cclxuICAgICAgID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IC0tPlxyXG4gIDxkaXYgY2xhc3M9XCJwZXJmaWwtY2FyZCBjYXJkLXJlZGVzXCI+XHJcbiAgICA8ZGl2IGNsYXNzPVwiY2FyZC1oZWFkZXItYWN0aW9uc1wiPlxyXG4gICAgICA8aDM+8J+MkCBSZWRlcyB5IFBvcnRhZm9saW88L2gzPlxyXG4gICAgICBAaWYgKCFlc1Zpc2l0YW50ZSkge1xyXG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzPVwiYnRuLWxpbmstZWRpdGFyXCIgKGNsaWNrKT1cImFicmlyTW9kYWwoJ3JlZGVzJylcIiB0aXRsZT1cIkVkaXRhciBlbmxhY2VzXCI+XHJcbiAgICAgICAgICDinI/vuI9cclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgfVxyXG4gICAgPC9kaXY+XHJcblxyXG4gICAgPGRpdiBjbGFzcz1cImxpbmtzLWdyaWRcIj5cclxuICAgICAgQGlmIChwZXJmaWwucmVkZXMuZ2l0aHViKSB7XHJcbiAgICAgICAgPGEgW2hyZWZdPVwicGVyZmlsLnJlZGVzLmdpdGh1YlwiIHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIiBjbGFzcz1cImxpbmstcmVkIGdpdGh1YlwiPvCfk4EgR2l0SHViPC9hPlxyXG4gICAgICB9XHJcbiAgICAgIEBpZiAocGVyZmlsLnJlZGVzLmxpbmtlZGluKSB7XHJcbiAgICAgICAgPGEgW2hyZWZdPVwicGVyZmlsLnJlZGVzLmxpbmtlZGluXCIgdGFyZ2V0PVwiX2JsYW5rXCIgcmVsPVwibm9vcGVuZXIgbm9yZWZlcnJlclwiIGNsYXNzPVwibGluay1yZWQgbGlua2VkaW5cIj7wn5K8IExpbmtlZEluPC9hPlxyXG4gICAgICB9XHJcbiAgICAgIEBpZiAocGVyZmlsLnJlZGVzLnBvcnRmb2xpbykge1xyXG4gICAgICAgIDxhIFtocmVmXT1cInBlcmZpbC5yZWRlcy5wb3J0Zm9saW9cIiB0YXJnZXQ9XCJfYmxhbmtcIiByZWw9XCJub29wZW5lciBub3JlZmVycmVyXCIgY2xhc3M9XCJsaW5rLXJlZCBwb3J0Zm9saW9cIj7wn4yQIFdlYiAvIFBvcnRhZm9saW88L2E+XHJcbiAgICAgIH1cclxuICAgICAgQGlmICghcGVyZmlsLnJlZGVzLmdpdGh1YiAmJiAhcGVyZmlsLnJlZGVzLmxpbmtlZGluICYmICFwZXJmaWwucmVkZXMucG9ydGZvbGlvKSB7XHJcbiAgICAgICAgPHAgY2xhc3M9XCJlbXB0eS10ZXh0XCI+XHJcbiAgICAgICAgICBAaWYgKGVzVmlzaXRhbnRlKSB7XHJcbiAgICAgICAgICAgIEVsIHBvc3R1bGFudGUgbm8gaGEgdmluY3VsYWRvIHJlZGVzIHByb2Zlc2lvbmFsZXMuXHJcbiAgICAgICAgICB9IEBlbHNlIHtcclxuICAgICAgICAgICAgTm8gdmluY3VsYXN0ZSBuaW5ndW5hIHJlZCBwcm9mZXNpb25hbCBhw7puLlxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIDwvcD5cclxuICAgICAgfVxyXG4gICAgPC9kaXY+XHJcbiAgPC9kaXY+XHJcblxyXG4gIDwhLS0gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAgICAgIE1PREFMOiBFRElUQVIgVUJJQ0FDScOTTlxyXG4gICAgICAgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gLS0+XHJcbiAgQGlmIChtb2RhbEFjdGl2byA9PT0gJ3ByaW5jaXBhbGVzJykge1xyXG4gICAgPGRpdiBjbGFzcz1cIm1vZGFsLW92ZXJsYXlcIiAoY2xpY2spPVwiY2VycmFyTW9kYWwoKVwiPlxyXG4gICAgICA8ZGl2IGNsYXNzPVwibW9kYWwtY29udGFpbmVyXCIgKGNsaWNrKT1cIiRldmVudC5zdG9wUHJvcGFnYXRpb24oKVwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJtb2RhbC1oZWFkZXJcIj5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxoMj7wn5ONIEVkaXRhciBVYmljYWNpw7NuPC9oMj5cclxuICAgICAgICAgICAgPHA+QWN0dWFsaXrDoSBsYSB1YmljYWNpw7NuIHF1ZSB2ZXLDoW4gbGFzIGVtcHJlc2FzLjwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3M9XCJidG4tY2VycmFyLW1vZGFsXCIgKGNsaWNrKT1cImNlcnJhck1vZGFsKClcIj7inJU8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzcz1cIm1vZGFsLWJvZHlcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgIDxsYWJlbCBmb3I9XCJjaXVkYWRcIj5DaXVkYWQ8L2xhYmVsPlxyXG4gICAgICAgICAgICA8aW5wdXQgaWQ9XCJjaXVkYWRcIiB0eXBlPVwidGV4dFwiIFsobmdNb2RlbCldPVwidGVtcFViaWNhY2lvbi5jaXVkYWRcIiBwbGFjZWhvbGRlcj1cIkVqLiBMYW7DunNcIj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgIDxsYWJlbCBmb3I9XCJwYWlzXCI+UGHDrXM8L2xhYmVsPlxyXG4gICAgICAgICAgICA8aW5wdXQgaWQ9XCJwYWlzXCIgdHlwZT1cInRleHRcIiBbKG5nTW9kZWwpXT1cInRlbXBVYmljYWNpb24ucGFpc1wiIHBsYWNlaG9sZGVyPVwiRWouIEFyZ2VudGluYVwiPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJtb2RhbC1mb290ZXJcIj5cclxuICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzPVwiYnRuLWNhbmNlbGFyXCIgKGNsaWNrKT1cImNlcnJhck1vZGFsKClcIj5DYW5jZWxhcjwvYnV0dG9uPlxyXG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3M9XCJidG4tcHJpbWFyeVwiIChjbGljayk9XCJndWFyZGFyVWJpY2FjaW9uKClcIj7wn5K+IEd1YXJkYXIgdWJpY2FjacOzbjwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gIH1cclxuXHJcbiAgPCEtLSA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gICAgICAgTU9EQUw6IEVESVRBUiBQRVJGSUwgUFJPRkVTSU9OQUxcclxuICAgICAgID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IC0tPlxyXG4gIEBpZiAobW9kYWxBY3Rpdm8gPT09ICdzb2JyZU1pJykge1xyXG4gICAgPGRpdiBjbGFzcz1cIm1vZGFsLW92ZXJsYXlcIiAoY2xpY2spPVwiY2VycmFyTW9kYWwoKVwiPlxyXG4gICAgICA8ZGl2IGNsYXNzPVwibW9kYWwtY29udGFpbmVyXCIgKGNsaWNrKT1cIiRldmVudC5zdG9wUHJvcGFnYXRpb24oKVwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJtb2RhbC1oZWFkZXJcIj5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxoMj7wn5K7IFBlcmZpbCBQcm9mZXNpb25hbDwvaDI+XHJcbiAgICAgICAgICAgIDxwPkNvbnRhbGUgYSBsYXMgZW1wcmVzYXMgc29icmUgdHUgcGVyZmlsIHkgb3JpZW50YWNpw7NuIHByb2Zlc2lvbmFsLjwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3M9XCJidG4tY2VycmFyLW1vZGFsXCIgKGNsaWNrKT1cImNlcnJhck1vZGFsKClcIj7inJU8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzcz1cIm1vZGFsLWJvZHlcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgIDxsYWJlbCBmb3I9XCJzb2JyZU1pXCI+U29icmUgbcOtPC9sYWJlbD5cclxuICAgICAgICAgICAgPHRleHRhcmVhIGlkPVwic29icmVNaVwiIHJvd3M9XCI1XCIgWyhuZ01vZGVsKV09XCJ0ZW1wU29icmVNaS5zb2JyZV9taVwiIHBsYWNlaG9sZGVyPVwiQ29udMOhIGJyZXZlbWVudGUgdHUgcGVyZmlsLCBpbnRlcmVzZXMgeSBvYmpldGl2b3MgcHJvZmVzaW9uYWxlcy4uLlwiPjwvdGV4dGFyZWE+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICA8bGFiZWwgZm9yPVwiZXNwZWNpYWxpZGFkXCI+RXNwZWNpYWxpZGFkIC8gSW50ZXLDqXM8L2xhYmVsPlxyXG4gICAgICAgICAgICA8aW5wdXQgaWQ9XCJlc3BlY2lhbGlkYWRcIiB0eXBlPVwidGV4dFwiIFsobmdNb2RlbCldPVwidGVtcFNvYnJlTWkuZXNwZWNpYWxpZGFkXCIgcGxhY2Vob2xkZXI9XCJFai4gRGVzYXJyb2xsbyBGcm9udGVuZCwgQW7DoWxpc2lzIGRlIERhdG9zLi4uXCI+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICA8bGFiZWwgZm9yPVwiZXN0YWRvQWNhZGVtaWNvXCI+RXN0YWRvIGFjYWTDqW1pY288L2xhYmVsPlxyXG4gICAgICAgICAgICA8c2VsZWN0IGlkPVwiZXN0YWRvQWNhZGVtaWNvXCIgWyhuZ01vZGVsKV09XCJ0ZW1wU29icmVNaS5lc3RhZG9fYWNhZGVtaWNvXCI+XHJcbiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkVzdHVkaWFudGUgSW5pY2lhbFwiPkVzdHVkaWFudGUgSW5pY2lhbDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJFc3R1ZGlhbnRlIEF2YW56YWRvXCI+RXN0dWRpYW50ZSBBdmFuemFkbzwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJHcmFkdWFkb1wiPkdyYWR1YWRvPC9vcHRpb24+XHJcbiAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJtb2RhbC1mb290ZXJcIj5cclxuICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzPVwiYnRuLWNhbmNlbGFyXCIgKGNsaWNrKT1cImNlcnJhck1vZGFsKClcIj5DYW5jZWxhcjwvYnV0dG9uPlxyXG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3M9XCJidG4tcHJpbWFyeVwiIChjbGljayk9XCJndWFyZGFyU29icmVNaSgpXCI+8J+SviBHdWFyZGFyIHBlcmZpbDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gIH1cclxuXHJcbiAgPCEtLSA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gICAgICAgTU9EQUw6IEVESVRBUiBTS0lMTFNcclxuICAgICAgID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IC0tPlxyXG4gIEBpZiAobW9kYWxBY3Rpdm8gPT09ICdza2lsbHMnKSB7XHJcbiAgICA8ZGl2IGNsYXNzPVwibW9kYWwtb3ZlcmxheVwiIChjbGljayk9XCJjZXJyYXJNb2RhbCgpXCI+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJtb2RhbC1jb250YWluZXJcIiAoY2xpY2spPVwiJGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cIm1vZGFsLWhlYWRlclwiPlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGgyPvCfm6DvuI8gU3RhY2sgVMOpY25pY28geSBIYWJpbGlkYWRlczwvaDI+XHJcbiAgICAgICAgICAgIDxwPlNlbGVjY2lvbsOhIGxhcyB0ZWNub2xvZ8OtYXMgeSBjb25vY2ltaWVudG9zIHF1ZSBmb3JtYW4gcGFydGUgZGUgdHUgcGVyZmlsLjwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3M9XCJidG4tY2VycmFyLW1vZGFsXCIgKGNsaWNrKT1cImNlcnJhck1vZGFsKClcIj7inJU8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzcz1cIm1vZGFsLWJvZHlcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgIDxsYWJlbCBmb3I9XCJidXNxdWVkYVNraWxsXCI+QnVzY2FyIGhhYmlsaWRhZDwvbGFiZWw+XHJcbiAgICAgICAgICAgIDxpbnB1dCBpZD1cImJ1c3F1ZWRhU2tpbGxcIiB0eXBlPVwidGV4dFwiIFsobmdNb2RlbCldPVwiYnVzcXVlZGFTa2lsbFwiIHBsYWNlaG9sZGVyPVwiRWouIEFuZ3VsYXIsIEV4Y2VsLCBQeXRob24uLi5cIj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJza2lsbHMtbW9kYWwtbGlzdFwiPlxyXG4gICAgICAgICAgICBAZm9yIChjYXRlZ29yaWEgb2YgY2F0ZWdvcmlhc0ZpbHRyYWRhczsgdHJhY2sgY2F0ZWdvcmlhLmNhdGVnb3JpYV9pZCkge1xyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJza2lsbC1jYXRlZ29yaWFcIj5cclxuICAgICAgICAgICAgICAgIDxoND57eyBjYXRlZ29yaWEubm9tYnJlX2NhdGVnb3JpYSB9fTwvaDQ+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwic2tpbGxzLWNoZWNrYm94LWdyaWRcIj5cclxuICAgICAgICAgICAgICAgICAgQGZvciAoc2tpbGwgb2YgY2F0ZWdvcmlhLnNraWxsczsgdHJhY2sgc2tpbGwuc2tpbGxfaWQpIHtcclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3M9XCJza2lsbC1jaGVja2JveFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIFtjaGVja2VkXT1cImVzU2tpbGxTZWxlY2Npb25hZGEoc2tpbGwuc2tpbGxfaWQpXCIgKGNoYW5nZSk9XCJ0b2dnbGVTa2lsbChza2lsbC5za2lsbF9pZClcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt7IHNraWxsLm5vbWJyZSB9fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgQGlmIChjYXRlZ29yaWFzRmlsdHJhZGFzLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICAgICAgICAgIDxwIGNsYXNzPVwiZW1wdHktdGV4dFwiPk5vIHNlIGVuY29udHJhcm9uIGhhYmlsaWRhZGVzIGNvbiBlc2EgYsO6c3F1ZWRhLjwvcD5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgPGxhYmVsIGZvcj1cIm90cmFzSGFiaWxpZGFkZXNcIj5PdHJhcyBoZXJyYW1pZW50YXMgeSBjb25vY2ltaWVudG9zPC9sYWJlbD5cclxuICAgICAgICAgICAgPHRleHRhcmVhIGlkPVwib3RyYXNIYWJpbGlkYWRlc1wiIHJvd3M9XCI0XCIgWyhuZ01vZGVsKV09XCJ0ZW1wT3RyYXNIYWJpbGlkYWRlc1wiIHBsYWNlaG9sZGVyPVwiUG9kw6lzIGFncmVnYXIgb3RyYXMgaGVycmFtaWVudGFzLCBjb25vY2ltaWVudG9zIG8gdGVjbm9sb2fDrWFzLi4uXCI+PC90ZXh0YXJlYT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwibW9kYWwtZm9vdGVyXCI+XHJcbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzcz1cImJ0bi1jYW5jZWxhclwiIChjbGljayk9XCJjZXJyYXJNb2RhbCgpXCI+Q2FuY2VsYXI8L2J1dHRvbj5cclxuICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzPVwiYnRuLXByaW1hcnlcIiAoY2xpY2spPVwiZ3VhcmRhclNraWxscygpXCI+8J+SviBHdWFyZGFyIGhhYmlsaWRhZGVzPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgfVxyXG5cclxuICA8IS0tID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgICAgICBNT0RBTDogRURJVEFSIFJFREVTIFkgUE9SVEFGT0xJT1xyXG4gICAgICAgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gLS0+XHJcbiAgQGlmIChtb2RhbEFjdGl2byA9PT0gJ3JlZGVzJykge1xyXG4gICAgPGRpdiBjbGFzcz1cIm1vZGFsLW92ZXJsYXlcIiAoY2xpY2spPVwiY2VycmFyTW9kYWwoKVwiPlxyXG4gICAgICA8ZGl2IGNsYXNzPVwibW9kYWwtY29udGFpbmVyXCIgKGNsaWNrKT1cIiRldmVudC5zdG9wUHJvcGFnYXRpb24oKVwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJtb2RhbC1oZWFkZXJcIj5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxoMj7wn4yQIFJlZGVzIHkgUG9ydGFmb2xpbzwvaDI+XHJcbiAgICAgICAgICAgIDxwPkFncmVnw6EgbG9zIGVubGFjZXMgZG9uZGUgbGFzIGVtcHJlc2FzIHB1ZWRhbiBjb25vY2VyIHR1IHRyYWJham8uPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzcz1cImJ0bi1jZXJyYXItbW9kYWxcIiAoY2xpY2spPVwiY2VycmFyTW9kYWwoKVwiPuKclTwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwibW9kYWwtYm9keVwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgPGxhYmVsIGZvcj1cImdpdGh1YlwiPvCfk4EgR2l0SHViPC9sYWJlbD5cclxuICAgICAgICAgICAgPGlucHV0IGlkPVwiZ2l0aHViXCIgdHlwZT1cInVybFwiIFsobmdNb2RlbCldPVwidGVtcFJlZGVzLmdpdGh1YlwiIHBsYWNlaG9sZGVyPVwiaHR0cHM6Ly9naXRodWIuY29tL3R1dXN1YXJpb1wiPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgPGxhYmVsIGZvcj1cImxpbmtlZGluXCI+8J+SvCBMaW5rZWRJbjwvbGFiZWw+XHJcbiAgICAgICAgICAgIDxpbnB1dCBpZD1cImxpbmtlZGluXCIgdHlwZT1cInVybFwiIFsobmdNb2RlbCldPVwidGVtcFJlZGVzLmxpbmtlZGluXCIgcGxhY2Vob2xkZXI9XCJodHRwczovL3d3dy5saW5rZWRpbi5jb20vaW4vdHV1c3VhcmlvXCI+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICA8bGFiZWwgZm9yPVwicG9ydGZvbGlvXCI+8J+MkCBXZWIgLyBQb3J0YWZvbGlvPC9sYWJlbD5cclxuICAgICAgICAgICAgPGlucHV0IGlkPVwicG9ydGZvbGlvXCIgdHlwZT1cInVybFwiIFsobmdNb2RlbCldPVwidGVtcFJlZGVzLnBvcnRmb2xpb1wiIHBsYWNlaG9sZGVyPVwiaHR0cHM6Ly90dXBvcnRmb2xpby5jb21cIj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwibW9kYWwtZm9vdGVyXCI+XHJcbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzcz1cImJ0bi1jYW5jZWxhclwiIChjbGljayk9XCJjZXJyYXJNb2RhbCgpXCI+Q2FuY2VsYXI8L2J1dHRvbj5cclxuICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzPVwiYnRuLXByaW1hcnlcIiAoY2xpY2spPVwiZ3VhcmRhclJlZGVzKClcIj7wn5K+IEd1YXJkYXIgZW5sYWNlczwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gIH1cclxuXHJcbiAgPCEtLSA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gICAgICAgTU9EQUw6IFZJU1RBIFBSRVZJQSBERUwgUERGXHJcbiAgICAgICA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAtLT5cclxuICBAaWYgKG1vc3RyYXJWaXN0YVByZXZpYUNWICYmIGN2UHJldmlld1VybCkge1xyXG4gICAgPGRpdiBjbGFzcz1cIm1vZGFsLW92ZXJsYXkgY3YtcHJldmlldy1vdmVybGF5XCIgKGNsaWNrKT1cImNlcnJhclZpc3RhUHJldmlhQ1YoKVwiPlxyXG4gICAgICA8ZGl2IGNsYXNzPVwibW9kYWwtY29udGFpbmVyIGN2LXByZXZpZXctbW9kYWxcIiAoY2xpY2spPVwiJGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cIm1vZGFsLWhlYWRlclwiPlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGgyPvCfkYHvuI8gVmlzdGEgcHJldmlhIGRlbCBDVjwvaDI+XHJcbiAgICAgICAgICAgIDxwPnt7IHBlcmZpbC5jdl9ub21icmUgfHwgJ0N1cnJpY3VsdW0gVml0YWUnIH19PC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzcz1cImJ0bi1jZXJyYXItbW9kYWxcIiAoY2xpY2spPVwiY2VycmFyVmlzdGFQcmV2aWFDVigpXCI+4pyVPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJjdi1wcmV2aWV3LWNvbnRhaW5lclwiPlxyXG4gICAgICAgICAgPGlmcmFtZSBbc3JjXT1cImN2UHJldmlld1VybFwiIGNsYXNzPVwiY3YtcHJldmlldy1mcmFtZVwiIHRpdGxlPVwiVmlzdGEgcHJldmlhIGRlbCBDdXJyaWN1bHVtIFZpdGFlXCI+PC9pZnJhbWU+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJtb2RhbC1mb290ZXJcIj5cclxuICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzPVwiYnRuLWNhbmNlbGFyXCIgKGNsaWNrKT1cImNlcnJhclZpc3RhUHJldmlhQ1YoKVwiPkNlcnJhcjwvYnV0dG9uPlxyXG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3M9XCJidG4tcHJpbWFyeVwiIChjbGljayk9XCJkZXNjYXJnYXJDVigpXCI+4qyH77iPIERlc2NhcmdhciBQREY8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICB9XHJcblxyXG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBLFNBQVMsV0FBNkMsUUFBUSxhQUFhLE9BQU8seUJBQXlCO0FBQzNHLFNBQVMsY0FBYyxtQkFBbUIsZ0JBQWdCO0FBQzFELFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsUUFBUSxzQkFBc0I7QUFFdkMsU0FBUyxvQkFBcUM7Ozs7Ozs7Ozs7QUNNcEMsSUFBQSw0QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUFtRSxJQUFBLHdCQUFBLFNBQUEsU0FBQSxnRUFBQTtBQUFBLE1BQUEsMkJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQUEseUJBQUEsT0FBQSxPQUFBLE9BQXVCLEVBQUU7SUFBQSxDQUFBO0FBQTVGLElBQUEsMEJBQUE7Ozs7QUFBSyxJQUFBLHdCQUFBLE9BQUEsT0FBQSxXQUFBLEdBQUEsMEJBQUE7Ozs7O0FBRUwsSUFBQSw0QkFBQSxHQUFBLE9BQUEsQ0FBQTs7QUFDRSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0UsSUFBQSx1QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNGLElBQUEsMEJBQUEsRUFBTTs7Ozs7O0FBTVIsSUFBQSw0QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUE2QyxJQUFBLHdCQUFBLFNBQUEsU0FBQSxtRUFBQTtBQUFBLE1BQUEsMkJBQUEsR0FBQTtBQUFBLFlBQUEsZUFBQSx5QkFBQSxDQUFBO0FBQUEsYUFBQSx5QkFBUyxhQUFBLE1BQUEsQ0FBaUI7SUFBQSxDQUFBO0FBQ3JFLElBQUEsb0JBQUEsR0FBQSxhQUFBO0FBQ0YsSUFBQSwwQkFBQTtBQUNBLElBQUEsNEJBQUEsR0FBQSxTQUFBLElBQUEsQ0FBQTtBQUE4QixJQUFBLHdCQUFBLFVBQUEsU0FBQSxpRUFBQSxRQUFBO0FBQUEsTUFBQSwyQkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBVSxPQUFBLG1CQUFBLE1BQUEsQ0FBMEI7SUFBQSxDQUFBO0FBQWxFLElBQUEsMEJBQUE7Ozs7QUFIeUUsSUFBQSx3QkFBQSxZQUFBLE9BQUEsU0FBQTs7Ozs7O0FBcUJ6RSxJQUFBLDRCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQTZDLElBQUEsd0JBQUEsU0FBQSxTQUFBLG9FQUFBO0FBQUEsTUFBQSwyQkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLE9BQUEsQ0FBUTtJQUFBLENBQUE7QUFDNUQsSUFBQSxvQkFBQSxHQUFBLGlCQUFBO0FBQ0YsSUFBQSwwQkFBQTs7Ozs7QUFTSSxJQUFBLDRCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEsb0JBQUEsR0FBQSxxQ0FBQTtBQUE0QixJQUFBLDBCQUFBOzs7OztBQUVsQyxJQUFBLDRCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEsb0JBQUEsR0FBQSxxQkFBQTtBQUFjLElBQUEsMEJBQUE7Ozs7OztBQVJ4QixJQUFBLDRCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQXlDLElBQUEsd0JBQUEsU0FBQSxTQUFBLG9FQUFBO0FBQUEsTUFBQSwyQkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLFdBQVcsYUFBYSxDQUFDO0lBQUEsQ0FBQTtBQUN6RSxJQUFBLG9CQUFBLEdBQUEsb0NBQUE7QUFDRixJQUFBLDBCQUFBO0FBRUEsSUFBQSw0QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUFzRSxJQUFBLHdCQUFBLFNBQUEsU0FBQSxvRUFBQTtBQUFBLE1BQUEsMkJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxzQkFBQSxDQUF1QjtJQUFBLENBQUE7QUFDcEcsSUFBQSxpQ0FBQSxHQUFBLHlEQUFBLEdBQUEsR0FBQSxNQUFBLEVBQWtCLEdBQUEseURBQUEsR0FBQSxHQUFBLE1BQUE7QUFLcEIsSUFBQSwwQkFBQTs7OztBQU4rQyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLFlBQUEsT0FBQSxTQUFBO0FBQzdDLElBQUEsdUJBQUE7QUFBQSxJQUFBLDJCQUFBLENBQUEsT0FBQSxZQUFBLElBQUEsQ0FBQTs7Ozs7QUFjUixJQUFBLDRCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0UsSUFBQSxvQkFBQSxDQUFBO0FBQ0YsSUFBQSwwQkFBQTs7OztBQURFLElBQUEsdUJBQUE7QUFBQSxJQUFBLGdDQUFBLEtBQUEsT0FBQSxlQUFBLEdBQUE7Ozs7OztBQVlFLElBQUEsNEJBQUEsR0FBQSxVQUFBLEVBQUE7QUFBOEMsSUFBQSx3QkFBQSxTQUFBLFNBQUEsb0VBQUE7QUFBQSxNQUFBLDJCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsV0FBVyxTQUFTLENBQUM7SUFBQSxDQUFBO0FBQzFFLElBQUEsb0JBQUEsR0FBQSxnQkFBQTtBQUNGLElBQUEsMEJBQUE7Ozs7O0FBS0YsSUFBQSw0QkFBQSxHQUFBLEtBQUEsRUFBQTtBQUE2QixJQUFBLG9CQUFBLENBQUE7QUFBcUIsSUFBQSwwQkFBQTs7OztBQUFyQixJQUFBLHVCQUFBO0FBQUEsSUFBQSwrQkFBQSxPQUFBLE9BQUEsUUFBQTs7Ozs7QUFJekIsSUFBQSxvQkFBQSxHQUFBLHNFQUFBOzs7OztBQUVBLElBQUEsb0JBQUEsR0FBQSx5SEFBQTs7Ozs7QUFKSixJQUFBLDRCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQ0UsSUFBQSxpQ0FBQSxHQUFBLHlEQUFBLEdBQUEsQ0FBQSxFQUFtQixHQUFBLHlEQUFBLEdBQUEsQ0FBQTtBQUtyQixJQUFBLDBCQUFBOzs7O0FBTEUsSUFBQSx1QkFBQTtBQUFBLElBQUEsMkJBQUEsT0FBQSxjQUFBLElBQUEsQ0FBQTs7Ozs7O0FBNkJBLElBQUEsNEJBQUEsR0FBQSxVQUFBLEVBQUE7QUFBOEMsSUFBQSx3QkFBQSxTQUFBLFNBQUEsb0VBQUE7QUFBQSxNQUFBLDJCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsY0FBQSxDQUFlO0lBQUEsQ0FBQTtBQUNwRSxJQUFBLG9CQUFBLEdBQUEsZ0JBQUE7QUFDRixJQUFBLDBCQUFBOzs7Ozs7QUF5QkksSUFBQSw0QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUFpRCxJQUFBLHdCQUFBLFNBQUEsU0FBQSxtRkFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQSxDQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLGNBQUEsQ0FBZTtJQUFBLENBQUE7QUFDdkUsSUFBQSxvQkFBQSxHQUFBLDZCQUFBO0FBQ0YsSUFBQSwwQkFBQTs7Ozs7O0FBdEJOLElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUEsRUFBd0IsR0FBQSxPQUFBLEVBQUEsRUFDRSxHQUFBLFFBQUEsRUFBQTtBQUNFLElBQUEsb0JBQUEsR0FBQSxXQUFBO0FBQUUsSUFBQSwwQkFBQTtBQUMxQixJQUFBLDRCQUFBLEdBQUEsT0FBQSxFQUFBLEVBQXFCLEdBQUEsUUFBQTtBQUNYLElBQUEsb0JBQUEsQ0FBQTtBQUFnRCxJQUFBLDBCQUFBO0FBQ3hELElBQUEsNEJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBd0IsSUFBQSxvQkFBQSxHQUFBLHNCQUFBO0FBQWUsSUFBQSwwQkFBQSxFQUFPLEVBQzFDO0FBR1IsSUFBQSw0QkFBQSxHQUFBLE9BQUEsRUFBQSxFQUF5QixJQUFBLFVBQUEsRUFBQTtBQUUrQixJQUFBLHdCQUFBLFNBQUEsU0FBQSxxRUFBQTtBQUFBLE1BQUEsMkJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxNQUFBLENBQU87SUFBQSxDQUFBO0FBQ3BFLElBQUEsb0JBQUEsSUFBQSx1Q0FBQTtBQUNGLElBQUEsMEJBQUE7QUFDQSxJQUFBLDRCQUFBLElBQUEsVUFBQSxFQUFBO0FBQW1ELElBQUEsd0JBQUEsU0FBQSxTQUFBLHFFQUFBO0FBQUEsTUFBQSwyQkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLFlBQUEsQ0FBYTtJQUFBLENBQUE7QUFDdkUsSUFBQSxvQkFBQSxJQUFBLDBCQUFBO0FBQ0YsSUFBQSwwQkFBQTtBQUdBLElBQUEsaUNBQUEsSUFBQSwwREFBQSxHQUFBLEdBQUEsVUFBQSxFQUFBO0FBS0YsSUFBQSwwQkFBQSxFQUFNOzs7O0FBcEJNLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsK0JBQUEsT0FBQSxPQUFBLGFBQUEsc0JBQUE7QUFlVixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDJCQUFBLENBQUEsT0FBQSxjQUFBLEtBQUEsRUFBQTs7Ozs7QUFZQSxJQUFBLDRCQUFBLEdBQUEsSUFBQTtBQUFJLElBQUEsb0JBQUEsR0FBQSxrQkFBQTtBQUFnQixJQUFBLDBCQUFBO0FBQ3BCLElBQUEsNEJBQUEsR0FBQSxLQUFBLEVBQUE7QUFBMEIsSUFBQSxvQkFBQSxHQUFBLHdEQUFBO0FBQW1ELElBQUEsMEJBQUE7Ozs7OztBQUU3RSxJQUFBLDRCQUFBLEdBQUEsSUFBQTtBQUFJLElBQUEsb0JBQUEsR0FBQSw2QkFBQTtBQUF3QixJQUFBLDBCQUFBO0FBQzVCLElBQUEsNEJBQUEsR0FBQSxLQUFBLEVBQUE7QUFDRSxJQUFBLG9CQUFBLEdBQUEsNERBQUE7QUFDRixJQUFBLDBCQUFBO0FBQ0EsSUFBQSw0QkFBQSxHQUFBLE9BQUEsRUFBQSxFQUF5QixHQUFBLFVBQUEsRUFBQTtBQUMwQixJQUFBLHdCQUFBLFNBQUEsU0FBQSxrRkFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQSxDQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLGNBQUEsQ0FBZTtJQUFBLENBQUE7QUFDdkUsSUFBQSxvQkFBQSxHQUFBLHNDQUFBO0FBQ0YsSUFBQSwwQkFBQSxFQUFTOzs7OztBQWRmLElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUEsRUFBd0MsR0FBQSxPQUFBLEVBQUE7QUFDVixJQUFBLG9CQUFBLEdBQUEsV0FBQTtBQUFFLElBQUEsMEJBQUE7QUFFOUIsSUFBQSxpQ0FBQSxHQUFBLHlEQUFBLEdBQUEsQ0FBQSxFQUFtQixHQUFBLHlEQUFBLEdBQUEsQ0FBQTtBQWNyQixJQUFBLDBCQUFBOzs7O0FBZEUsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxPQUFBLGNBQUEsSUFBQSxDQUFBOzs7Ozs7QUF5QkEsSUFBQSw0QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUE4QyxJQUFBLHdCQUFBLFNBQUEsU0FBQSxvRUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxXQUFXLFFBQVEsQ0FBQztJQUFBLENBQUE7QUFDekUsSUFBQSxvQkFBQSxHQUFBLGdCQUFBO0FBQ0YsSUFBQSwwQkFBQTs7Ozs7QUFNQSxJQUFBLDRCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQWtCLElBQUEsb0JBQUEsQ0FBQTtBQUFrQixJQUFBLDBCQUFBOzs7O0FBQWxCLElBQUEsdUJBQUE7QUFBQSxJQUFBLCtCQUFBLFVBQUEsTUFBQTs7Ozs7QUFLcEIsSUFBQSw0QkFBQSxHQUFBLE9BQUEsRUFBQSxFQUF1QyxHQUFBLEtBQUEsRUFBQTtBQUNKLElBQUEsb0JBQUEsR0FBQSxxQ0FBQTtBQUFtQyxJQUFBLDBCQUFBO0FBQ3BFLElBQUEsNEJBQUEsR0FBQSxLQUFBLEVBQUE7QUFBMkIsSUFBQSxvQkFBQSxDQUFBO0FBQThCLElBQUEsMEJBQUEsRUFBSTs7OztBQUFsQyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLE9BQUEsT0FBQSxpQkFBQTs7Ozs7QUFPekIsSUFBQSxvQkFBQSxHQUFBLHNFQUFBOzs7OztBQUVBLElBQUEsb0JBQUEsR0FBQSxpR0FBQTs7Ozs7QUFKSixJQUFBLDRCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQ0UsSUFBQSxpQ0FBQSxHQUFBLHlEQUFBLEdBQUEsQ0FBQSxFQUFtQixHQUFBLHlEQUFBLEdBQUEsQ0FBQTtBQUtyQixJQUFBLDBCQUFBOzs7O0FBTEUsSUFBQSx1QkFBQTtBQUFBLElBQUEsMkJBQUEsT0FBQSxjQUFBLElBQUEsQ0FBQTs7Ozs7O0FBZ0JBLElBQUEsNEJBQUEsR0FBQSxVQUFBLEVBQUE7QUFBOEMsSUFBQSx3QkFBQSxTQUFBLFNBQUEsb0VBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsV0FBVyxPQUFPLENBQUM7SUFBQSxDQUFBO0FBQ3hFLElBQUEsb0JBQUEsR0FBQSxnQkFBQTtBQUNGLElBQUEsMEJBQUE7Ozs7O0FBTUEsSUFBQSw0QkFBQSxHQUFBLEtBQUEsRUFBQTtBQUFrRyxJQUFBLG9CQUFBLEdBQUEsa0JBQUE7QUFBUyxJQUFBLDBCQUFBOzs7O0FBQXhHLElBQUEsd0JBQUEsUUFBQSxPQUFBLE9BQUEsTUFBQSxRQUFBLDBCQUFBOzs7OztBQUdILElBQUEsNEJBQUEsR0FBQSxLQUFBLEVBQUE7QUFBc0csSUFBQSxvQkFBQSxHQUFBLG9CQUFBO0FBQVcsSUFBQSwwQkFBQTs7OztBQUE5RyxJQUFBLHdCQUFBLFFBQUEsT0FBQSxPQUFBLE1BQUEsVUFBQSwwQkFBQTs7Ozs7QUFHSCxJQUFBLDRCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQXdHLElBQUEsb0JBQUEsR0FBQSw0QkFBQTtBQUFtQixJQUFBLDBCQUFBOzs7O0FBQXhILElBQUEsd0JBQUEsUUFBQSxPQUFBLE9BQUEsTUFBQSxXQUFBLDBCQUFBOzs7OztBQUtDLElBQUEsb0JBQUEsR0FBQSxzREFBQTs7Ozs7QUFFQSxJQUFBLG9CQUFBLEdBQUEsaURBQUE7Ozs7O0FBSkosSUFBQSw0QkFBQSxHQUFBLEtBQUEsRUFBQTtBQUNFLElBQUEsaUNBQUEsR0FBQSx5REFBQSxHQUFBLENBQUEsRUFBbUIsR0FBQSx5REFBQSxHQUFBLENBQUE7QUFLckIsSUFBQSwwQkFBQTs7OztBQUxFLElBQUEsdUJBQUE7QUFBQSxJQUFBLDJCQUFBLE9BQUEsY0FBQSxJQUFBLENBQUE7Ozs7OztBQWNOLElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFBMkIsSUFBQSx3QkFBQSxTQUFBLFNBQUEsaUVBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsWUFBQSxDQUFhO0lBQUEsQ0FBQTtBQUMvQyxJQUFBLDRCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQTZCLElBQUEsd0JBQUEsU0FBQSxTQUFBLCtEQUFBLFFBQUE7QUFBQSxhQUFTLE9BQUEsZ0JBQUE7SUFBd0IsQ0FBQTtBQUM1RCxJQUFBLDRCQUFBLEdBQUEsT0FBQSxFQUFBLEVBQTBCLEdBQUEsS0FBQSxFQUNuQixHQUFBLElBQUE7QUFDQyxJQUFBLG9CQUFBLEdBQUEsK0JBQUE7QUFBbUIsSUFBQSwwQkFBQTtBQUN2QixJQUFBLDRCQUFBLEdBQUEsR0FBQTtBQUFHLElBQUEsb0JBQUEsR0FBQSx5REFBQTtBQUE4QyxJQUFBLDBCQUFBLEVBQUk7QUFFdkQsSUFBQSw0QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUErQyxJQUFBLHdCQUFBLFNBQUEsU0FBQSxvRUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxZQUFBLENBQWE7SUFBQSxDQUFBO0FBQUUsSUFBQSxvQkFBQSxHQUFBLFFBQUE7QUFBQyxJQUFBLDBCQUFBLEVBQVM7QUFHbkYsSUFBQSw0QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUF3QixJQUFBLE9BQUEsRUFBQSxFQUNFLElBQUEsU0FBQSxFQUFBO0FBQ0YsSUFBQSxvQkFBQSxJQUFBLFFBQUE7QUFBTSxJQUFBLDBCQUFBO0FBQzFCLElBQUEsNEJBQUEsSUFBQSxTQUFBLEVBQUE7QUFBK0IsSUFBQSw4QkFBQSxpQkFBQSxTQUFBLDBFQUFBLFFBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxNQUFBLGdDQUFBLE9BQUEsY0FBQSxRQUFBLE1BQUEsTUFBQSxPQUFBLGNBQUEsU0FBQTtBQUFBLGFBQUEseUJBQUEsTUFBQTtJQUFBLENBQUE7QUFBL0IsSUFBQSwwQkFBQSxFQUEwRjtBQUc1RixJQUFBLDRCQUFBLElBQUEsT0FBQSxFQUFBLEVBQXdCLElBQUEsU0FBQSxFQUFBO0FBQ0osSUFBQSxvQkFBQSxJQUFBLFNBQUE7QUFBSSxJQUFBLDBCQUFBO0FBQ3RCLElBQUEsNEJBQUEsSUFBQSxTQUFBLEVBQUE7QUFBNkIsSUFBQSw4QkFBQSxpQkFBQSxTQUFBLDBFQUFBLFFBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxNQUFBLGdDQUFBLE9BQUEsY0FBQSxNQUFBLE1BQUEsTUFBQSxPQUFBLGNBQUEsT0FBQTtBQUFBLGFBQUEseUJBQUEsTUFBQTtJQUFBLENBQUE7QUFBN0IsSUFBQSwwQkFBQSxFQUEwRixFQUN0RjtBQUdSLElBQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBMEIsSUFBQSxVQUFBLEVBQUE7QUFDbUIsSUFBQSx3QkFBQSxTQUFBLFNBQUEscUVBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsWUFBQSxDQUFhO0lBQUEsQ0FBQTtBQUFFLElBQUEsb0JBQUEsSUFBQSxVQUFBO0FBQVEsSUFBQSwwQkFBQTtBQUMzRSxJQUFBLDRCQUFBLElBQUEsVUFBQSxFQUFBO0FBQTBDLElBQUEsd0JBQUEsU0FBQSxTQUFBLHFFQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLGlCQUFBLENBQWtCO0lBQUEsQ0FBQTtBQUFFLElBQUEsb0JBQUEsSUFBQSxnQ0FBQTtBQUFvQixJQUFBLDBCQUFBLEVBQVMsRUFDaEcsRUFDRjs7OztBQWIrQixJQUFBLHVCQUFBLEVBQUE7QUFBQSxJQUFBLDhCQUFBLFdBQUEsT0FBQSxjQUFBLE1BQUE7QUFLRixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDhCQUFBLFdBQUEsT0FBQSxjQUFBLElBQUE7Ozs7OztBQWdCckMsSUFBQSw0QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUEyQixJQUFBLHdCQUFBLFNBQUEsU0FBQSxpRUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxZQUFBLENBQWE7SUFBQSxDQUFBO0FBQy9DLElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFBNkIsSUFBQSx3QkFBQSxTQUFBLFNBQUEsK0RBQUEsUUFBQTtBQUFBLGFBQVMsT0FBQSxnQkFBQTtJQUF3QixDQUFBO0FBQzVELElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUEsRUFBMEIsR0FBQSxLQUFBLEVBQ25CLEdBQUEsSUFBQTtBQUNDLElBQUEsb0JBQUEsR0FBQSw4QkFBQTtBQUFxQixJQUFBLDBCQUFBO0FBQ3pCLElBQUEsNEJBQUEsR0FBQSxHQUFBO0FBQUcsSUFBQSxvQkFBQSxHQUFBLHNFQUFBO0FBQWlFLElBQUEsMEJBQUEsRUFBSTtBQUUxRSxJQUFBLDRCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQStDLElBQUEsd0JBQUEsU0FBQSxTQUFBLG9FQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLFlBQUEsQ0FBYTtJQUFBLENBQUE7QUFBRSxJQUFBLG9CQUFBLEdBQUEsUUFBQTtBQUFDLElBQUEsMEJBQUEsRUFBUztBQUduRixJQUFBLDRCQUFBLElBQUEsT0FBQSxFQUFBLEVBQXdCLElBQUEsT0FBQSxFQUFBLEVBQ0UsSUFBQSxTQUFBLEVBQUE7QUFDRCxJQUFBLG9CQUFBLElBQUEsYUFBQTtBQUFRLElBQUEsMEJBQUE7QUFDN0IsSUFBQSw0QkFBQSxJQUFBLFlBQUEsRUFBQTtBQUFnQyxJQUFBLDhCQUFBLGlCQUFBLFNBQUEsNkVBQUEsUUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLE1BQUEsZ0NBQUEsT0FBQSxZQUFBLFVBQUEsTUFBQSxNQUFBLE9BQUEsWUFBQSxXQUFBO0FBQUEsYUFBQSx5QkFBQSxNQUFBO0lBQUEsQ0FBQTtBQUFvSCxJQUFBLDBCQUFBLEVBQVc7QUFHakssSUFBQSw0QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUF3QixJQUFBLFNBQUEsRUFBQTtBQUNJLElBQUEsb0JBQUEsSUFBQSwyQkFBQTtBQUFzQixJQUFBLDBCQUFBO0FBQ2hELElBQUEsNEJBQUEsSUFBQSxTQUFBLEVBQUE7QUFBcUMsSUFBQSw4QkFBQSxpQkFBQSxTQUFBLDBFQUFBLFFBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxNQUFBLGdDQUFBLE9BQUEsWUFBQSxjQUFBLE1BQUEsTUFBQSxPQUFBLFlBQUEsZUFBQTtBQUFBLGFBQUEseUJBQUEsTUFBQTtJQUFBLENBQUE7QUFBckMsSUFBQSwwQkFBQSxFQUF3STtBQUcxSSxJQUFBLDRCQUFBLElBQUEsT0FBQSxFQUFBLEVBQXdCLElBQUEsU0FBQSxFQUFBO0FBQ08sSUFBQSxvQkFBQSxJQUFBLHFCQUFBO0FBQWdCLElBQUEsMEJBQUE7QUFDN0MsSUFBQSw0QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUE2QixJQUFBLDhCQUFBLGlCQUFBLFNBQUEsMkVBQUEsUUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLE1BQUEsZ0NBQUEsT0FBQSxZQUFBLGtCQUFBLE1BQUEsTUFBQSxPQUFBLFlBQUEsbUJBQUE7QUFBQSxhQUFBLHlCQUFBLE1BQUE7SUFBQSxDQUFBO0FBQzNCLElBQUEsNEJBQUEsSUFBQSxVQUFBLEVBQUE7QUFBbUMsSUFBQSxvQkFBQSxJQUFBLG9CQUFBO0FBQWtCLElBQUEsMEJBQUE7QUFDckQsSUFBQSw0QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUFvQyxJQUFBLG9CQUFBLElBQUEscUJBQUE7QUFBbUIsSUFBQSwwQkFBQTtBQUN2RCxJQUFBLDRCQUFBLElBQUEsVUFBQSxFQUFBO0FBQXlCLElBQUEsb0JBQUEsSUFBQSxVQUFBO0FBQVEsSUFBQSwwQkFBQSxFQUFTLEVBQ25DLEVBQ0w7QUFHUixJQUFBLDRCQUFBLElBQUEsT0FBQSxFQUFBLEVBQTBCLElBQUEsVUFBQSxFQUFBO0FBQ21CLElBQUEsd0JBQUEsU0FBQSxTQUFBLHFFQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLFlBQUEsQ0FBYTtJQUFBLENBQUE7QUFBRSxJQUFBLG9CQUFBLElBQUEsVUFBQTtBQUFRLElBQUEsMEJBQUE7QUFDM0UsSUFBQSw0QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUEwQyxJQUFBLHdCQUFBLFNBQUEsU0FBQSxxRUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxlQUFBLENBQWdCO0lBQUEsQ0FBQTtBQUFFLElBQUEsb0JBQUEsSUFBQSwwQkFBQTtBQUFpQixJQUFBLDBCQUFBLEVBQVMsRUFDM0YsRUFDRjs7OztBQXRCZ0MsSUFBQSx1QkFBQSxFQUFBO0FBQUEsSUFBQSw4QkFBQSxXQUFBLE9BQUEsWUFBQSxRQUFBO0FBS0ssSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSw4QkFBQSxXQUFBLE9BQUEsWUFBQSxZQUFBO0FBS1IsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSw4QkFBQSxXQUFBLE9BQUEsWUFBQSxnQkFBQTs7Ozs7O0FBMENyQixJQUFBLDRCQUFBLEdBQUEsU0FBQSxFQUFBLEVBQThCLEdBQUEsU0FBQSxFQUFBO0FBQzJDLElBQUEsd0JBQUEsVUFBQSxTQUFBLGlGQUFBO0FBQUEsWUFBQSxZQUFBLDJCQUFBLElBQUEsRUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQSxDQUFBO0FBQUEsYUFBQSx5QkFBVSxPQUFBLFlBQUEsVUFBQSxRQUFBLENBQTJCO0lBQUEsQ0FBQTtBQUE1RyxJQUFBLDBCQUFBO0FBQ0EsSUFBQSw0QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLG9CQUFBLENBQUE7QUFBa0IsSUFBQSwwQkFBQSxFQUFPOzs7OztBQURSLElBQUEsdUJBQUE7QUFBQSxJQUFBLHdCQUFBLFdBQUEsT0FBQSxvQkFBQSxVQUFBLFFBQUEsQ0FBQTtBQUNqQixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLFVBQUEsTUFBQTs7Ozs7QUFOZCxJQUFBLDRCQUFBLEdBQUEsT0FBQSxFQUFBLEVBQTZCLEdBQUEsSUFBQTtBQUN2QixJQUFBLG9CQUFBLENBQUE7QUFBZ0MsSUFBQSwwQkFBQTtBQUNwQyxJQUFBLDRCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0UsSUFBQSw4QkFBQSxHQUFBLHdEQUFBLEdBQUEsR0FBQSxTQUFBLElBQUEsVUFBQTtBQU1GLElBQUEsMEJBQUEsRUFBTTs7OztBQVJGLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsK0JBQUEsY0FBQSxnQkFBQTtBQUVGLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsd0JBQUEsY0FBQSxNQUFBOzs7OztBQVdKLElBQUEsNEJBQUEsR0FBQSxLQUFBLEVBQUE7QUFBc0IsSUFBQSxvQkFBQSxHQUFBLG9EQUFBO0FBQStDLElBQUEsMEJBQUE7Ozs7OztBQWhDL0UsSUFBQSw0QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUEyQixJQUFBLHdCQUFBLFNBQUEsU0FBQSxpRUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxZQUFBLENBQWE7SUFBQSxDQUFBO0FBQy9DLElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFBNkIsSUFBQSx3QkFBQSxTQUFBLFNBQUEsK0RBQUEsUUFBQTtBQUFBLGFBQVMsT0FBQSxnQkFBQTtJQUF3QixDQUFBO0FBQzVELElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUEsRUFBMEIsR0FBQSxLQUFBLEVBQ25CLEdBQUEsSUFBQTtBQUNDLElBQUEsb0JBQUEsR0FBQSxnREFBQTtBQUErQixJQUFBLDBCQUFBO0FBQ25DLElBQUEsNEJBQUEsR0FBQSxHQUFBO0FBQUcsSUFBQSxvQkFBQSxHQUFBLGlGQUFBO0FBQXlFLElBQUEsMEJBQUEsRUFBSTtBQUVsRixJQUFBLDRCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQStDLElBQUEsd0JBQUEsU0FBQSxTQUFBLG9FQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLFlBQUEsQ0FBYTtJQUFBLENBQUE7QUFBRSxJQUFBLG9CQUFBLEdBQUEsUUFBQTtBQUFDLElBQUEsMEJBQUEsRUFBUztBQUduRixJQUFBLDRCQUFBLElBQUEsT0FBQSxFQUFBLEVBQXdCLElBQUEsT0FBQSxFQUFBLEVBQ0UsSUFBQSxTQUFBLEVBQUE7QUFDSyxJQUFBLG9CQUFBLElBQUEsa0JBQUE7QUFBZ0IsSUFBQSwwQkFBQTtBQUMzQyxJQUFBLDRCQUFBLElBQUEsU0FBQSxFQUFBO0FBQXNDLElBQUEsOEJBQUEsaUJBQUEsU0FBQSwwRUFBQSxRQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsTUFBQSxnQ0FBQSxPQUFBLGVBQUEsTUFBQSxNQUFBLE9BQUEsZ0JBQUE7QUFBQSxhQUFBLHlCQUFBLE1BQUE7SUFBQSxDQUFBO0FBQXRDLElBQUEsMEJBQUEsRUFBOEc7QUFHaEgsSUFBQSw0QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNFLElBQUEsOEJBQUEsSUFBQSxrREFBQSxHQUFBLEdBQUEsT0FBQSxJQUFBLFVBQUE7QUFjQSxJQUFBLGlDQUFBLElBQUEsMERBQUEsR0FBQSxHQUFBLEtBQUEsRUFBQTtBQUdGLElBQUEsMEJBQUE7QUFFQSxJQUFBLDRCQUFBLElBQUEsT0FBQSxFQUFBLEVBQXdCLElBQUEsU0FBQSxFQUFBO0FBQ1EsSUFBQSxvQkFBQSxJQUFBLG9DQUFBO0FBQWtDLElBQUEsMEJBQUE7QUFDaEUsSUFBQSw0QkFBQSxJQUFBLFlBQUEsRUFBQTtBQUF5QyxJQUFBLDhCQUFBLGlCQUFBLFNBQUEsNkVBQUEsUUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLE1BQUEsZ0NBQUEsT0FBQSxzQkFBQSxNQUFBLE1BQUEsT0FBQSx1QkFBQTtBQUFBLGFBQUEseUJBQUEsTUFBQTtJQUFBLENBQUE7QUFBa0gsSUFBQSwwQkFBQSxFQUFXLEVBQ2xLO0FBR1IsSUFBQSw0QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUEwQixJQUFBLFVBQUEsRUFBQTtBQUNtQixJQUFBLHdCQUFBLFNBQUEsU0FBQSxxRUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxZQUFBLENBQWE7SUFBQSxDQUFBO0FBQUUsSUFBQSxvQkFBQSxJQUFBLFVBQUE7QUFBUSxJQUFBLDBCQUFBO0FBQzNFLElBQUEsNEJBQUEsSUFBQSxVQUFBLEVBQUE7QUFBMEMsSUFBQSx3QkFBQSxTQUFBLFNBQUEscUVBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsY0FBQSxDQUFlO0lBQUEsQ0FBQTtBQUFFLElBQUEsb0JBQUEsSUFBQSwrQkFBQTtBQUFzQixJQUFBLDBCQUFBLEVBQVMsRUFDL0YsRUFDRjs7OztBQWpDc0MsSUFBQSx1QkFBQSxFQUFBO0FBQUEsSUFBQSw4QkFBQSxXQUFBLE9BQUEsYUFBQTtBQUl0QyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLE9BQUEsbUJBQUE7QUFjQSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDJCQUFBLE9BQUEsb0JBQUEsV0FBQSxJQUFBLEtBQUEsRUFBQTtBQU95QyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDhCQUFBLFdBQUEsT0FBQSxvQkFBQTs7Ozs7O0FBZ0JqRCxJQUFBLDRCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQTJCLElBQUEsd0JBQUEsU0FBQSxTQUFBLGlFQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLFlBQUEsQ0FBYTtJQUFBLENBQUE7QUFDL0MsSUFBQSw0QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUE2QixJQUFBLHdCQUFBLFNBQUEsU0FBQSwrREFBQSxRQUFBO0FBQUEsYUFBUyxPQUFBLGdCQUFBO0lBQXdCLENBQUE7QUFDNUQsSUFBQSw0QkFBQSxHQUFBLE9BQUEsRUFBQSxFQUEwQixHQUFBLEtBQUEsRUFDbkIsR0FBQSxJQUFBO0FBQ0MsSUFBQSxvQkFBQSxHQUFBLDhCQUFBO0FBQXFCLElBQUEsMEJBQUE7QUFDekIsSUFBQSw0QkFBQSxHQUFBLEdBQUE7QUFBRyxJQUFBLG9CQUFBLEdBQUEscUVBQUE7QUFBZ0UsSUFBQSwwQkFBQSxFQUFJO0FBRXpFLElBQUEsNEJBQUEsR0FBQSxVQUFBLEVBQUE7QUFBK0MsSUFBQSx3QkFBQSxTQUFBLFNBQUEsb0VBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsWUFBQSxDQUFhO0lBQUEsQ0FBQTtBQUFFLElBQUEsb0JBQUEsR0FBQSxRQUFBO0FBQUMsSUFBQSwwQkFBQSxFQUFTO0FBR25GLElBQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBd0IsSUFBQSxPQUFBLEVBQUEsRUFDRSxJQUFBLFNBQUEsRUFBQTtBQUNGLElBQUEsb0JBQUEsSUFBQSxrQkFBQTtBQUFTLElBQUEsMEJBQUE7QUFDN0IsSUFBQSw0QkFBQSxJQUFBLFNBQUEsRUFBQTtBQUE4QixJQUFBLDhCQUFBLGlCQUFBLFNBQUEsMEVBQUEsUUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLE1BQUEsZ0NBQUEsT0FBQSxVQUFBLFFBQUEsTUFBQSxNQUFBLE9BQUEsVUFBQSxTQUFBO0FBQUEsYUFBQSx5QkFBQSxNQUFBO0lBQUEsQ0FBQTtBQUE5QixJQUFBLDBCQUFBLEVBQXdHO0FBRzFHLElBQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBd0IsSUFBQSxTQUFBLEVBQUE7QUFDQSxJQUFBLG9CQUFBLElBQUEsb0JBQUE7QUFBVyxJQUFBLDBCQUFBO0FBQ2pDLElBQUEsNEJBQUEsSUFBQSxTQUFBLEdBQUE7QUFBZ0MsSUFBQSw4QkFBQSxpQkFBQSxTQUFBLDBFQUFBLFFBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxNQUFBLGdDQUFBLE9BQUEsVUFBQSxVQUFBLE1BQUEsTUFBQSxPQUFBLFVBQUEsV0FBQTtBQUFBLGFBQUEseUJBQUEsTUFBQTtJQUFBLENBQUE7QUFBaEMsSUFBQSwwQkFBQSxFQUFxSDtBQUd2SCxJQUFBLDRCQUFBLElBQUEsT0FBQSxFQUFBLEVBQXdCLElBQUEsU0FBQSxHQUFBO0FBQ0MsSUFBQSxvQkFBQSxJQUFBLDRCQUFBO0FBQW1CLElBQUEsMEJBQUE7QUFDMUMsSUFBQSw0QkFBQSxJQUFBLFNBQUEsR0FBQTtBQUFpQyxJQUFBLDhCQUFBLGlCQUFBLFNBQUEsMEVBQUEsUUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLE1BQUEsZ0NBQUEsT0FBQSxVQUFBLFdBQUEsTUFBQSxNQUFBLE9BQUEsVUFBQSxZQUFBO0FBQUEsYUFBQSx5QkFBQSxNQUFBO0lBQUEsQ0FBQTtBQUFqQyxJQUFBLDBCQUFBLEVBQXlHLEVBQ3JHO0FBR1IsSUFBQSw0QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUEwQixJQUFBLFVBQUEsRUFBQTtBQUNtQixJQUFBLHdCQUFBLFNBQUEsU0FBQSxxRUFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxZQUFBLENBQWE7SUFBQSxDQUFBO0FBQUUsSUFBQSxvQkFBQSxJQUFBLFVBQUE7QUFBUSxJQUFBLDBCQUFBO0FBQzNFLElBQUEsNEJBQUEsSUFBQSxVQUFBLEVBQUE7QUFBMEMsSUFBQSx3QkFBQSxTQUFBLFNBQUEscUVBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsYUFBQSxDQUFjO0lBQUEsQ0FBQTtBQUFFLElBQUEsb0JBQUEsSUFBQSwyQkFBQTtBQUFrQixJQUFBLDBCQUFBLEVBQVMsRUFDMUYsRUFDRjs7OztBQWxCOEIsSUFBQSx1QkFBQSxFQUFBO0FBQUEsSUFBQSw4QkFBQSxXQUFBLE9BQUEsVUFBQSxNQUFBO0FBS0UsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSw4QkFBQSxXQUFBLE9BQUEsVUFBQSxRQUFBO0FBS0MsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSw4QkFBQSxXQUFBLE9BQUEsVUFBQSxTQUFBOzs7Ozs7QUFnQnpDLElBQUEsNEJBQUEsR0FBQSxPQUFBLEdBQUE7QUFBOEMsSUFBQSx3QkFBQSxTQUFBLFNBQUEsaUVBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsb0JBQUEsQ0FBcUI7SUFBQSxDQUFBO0FBQzFFLElBQUEsNEJBQUEsR0FBQSxPQUFBLEdBQUE7QUFBOEMsSUFBQSx3QkFBQSxTQUFBLFNBQUEsK0RBQUEsUUFBQTtBQUFBLGFBQVMsT0FBQSxnQkFBQTtJQUF3QixDQUFBO0FBQzdFLElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUEsRUFBMEIsR0FBQSxLQUFBLEVBQ25CLEdBQUEsSUFBQTtBQUNDLElBQUEsb0JBQUEsR0FBQSxxQ0FBQTtBQUF1QixJQUFBLDBCQUFBO0FBQzNCLElBQUEsNEJBQUEsR0FBQSxHQUFBO0FBQUcsSUFBQSxvQkFBQSxDQUFBO0FBQTRDLElBQUEsMEJBQUEsRUFBSTtBQUVyRCxJQUFBLDRCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQStDLElBQUEsd0JBQUEsU0FBQSxTQUFBLG9FQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLG9CQUFBLENBQXFCO0lBQUEsQ0FBQTtBQUFFLElBQUEsb0JBQUEsR0FBQSxRQUFBO0FBQUMsSUFBQSwwQkFBQSxFQUFTO0FBRzNGLElBQUEsNEJBQUEsSUFBQSxPQUFBLEdBQUE7QUFDRSxJQUFBLHVCQUFBLElBQUEsVUFBQSxHQUFBO0FBQ0YsSUFBQSwwQkFBQTtBQUVBLElBQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBMEIsSUFBQSxVQUFBLEVBQUE7QUFDbUIsSUFBQSx3QkFBQSxTQUFBLFNBQUEscUVBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsb0JBQUEsQ0FBcUI7SUFBQSxDQUFBO0FBQUUsSUFBQSxvQkFBQSxJQUFBLFFBQUE7QUFBTSxJQUFBLDBCQUFBO0FBQ2pGLElBQUEsNEJBQUEsSUFBQSxVQUFBLEVBQUE7QUFBMEMsSUFBQSx3QkFBQSxTQUFBLFNBQUEscUVBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsWUFBQSxDQUFhO0lBQUEsQ0FBQTtBQUFFLElBQUEsb0JBQUEsSUFBQSw0QkFBQTtBQUFnQixJQUFBLDBCQUFBLEVBQVMsRUFDdkYsRUFDRjs7OztBQWJHLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsK0JBQUEsT0FBQSxPQUFBLGFBQUEsa0JBQUE7QUFNRyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLE9BQUEsT0FBQSxjQUFBLGtDQUFBOzs7QUQ1WFosU0FBVSw4QkFBMkI7QUFDekMsU0FBTztJQUNMLFNBQVM7SUFDVCxXQUFXO0lBQ1gsT0FBTztJQUNQLFNBQVM7SUFDVCxNQUFNO0lBQ04sUUFBUTtJQUNSLE1BQU07SUFDTixVQUFVO0lBQ1YsY0FBYztJQUNkLGtCQUFrQjtJQUNsQixRQUFRO0lBQ1IsV0FBVztJQUNYLFFBQVEsQ0FBQTtJQUNSLG1CQUFtQjtJQUNuQixPQUFPO01BQ0wsUUFBUTtNQUNSLFVBQVU7TUFDVixXQUFXOzs7QUFHakI7QUFhTSxJQUFPLG9CQUFQLE1BQU8sbUJBQWlCOztFQUdwQixvQkFBb0IsT0FBTyxpQkFBaUI7RUFDNUMsYUFBYSxPQUFPLFdBQVc7RUFDL0IsU0FBUyxPQUFPLE1BQU07RUFDdEIsUUFBUSxPQUFPLGNBQWM7RUFDN0IsV0FBVyxPQUFPLFFBQVE7RUFDMUIsWUFBWSxPQUFPLFlBQVk7RUFDL0IsTUFBTSxPQUFPLGlCQUFpQjs7RUFHN0I7RUFDQSxjQUF1Qjs7RUFHaEMsY0FBdUI7RUFDdkIsdUJBQStCOztFQUcvQixTQUE4Qiw0QkFBMkI7O0VBR3pELFlBQXFCO0VBQ3JCLGdCQUErQjtFQUMvQix1QkFBZ0M7RUFDaEMsZUFBdUM7O0VBR3ZDLGNBQXFFOztFQUdyRSxtQkFBd0MsQ0FBQTtFQUN4QyxnQkFBMEIsQ0FBQTtFQUMxQix1QkFBK0I7RUFDL0IsZ0JBQXdCOztFQUd4QiwwQkFBdUM7RUFDdkMsY0FBNkI7O0VBRzdCLGdCQUFnQjtJQUNkLFFBQVE7SUFDUixNQUFNOztFQUdSLGNBQWM7SUFDWixVQUFVO0lBQ1YsY0FBYztJQUNkLGtCQUFrQjs7RUFHcEIsWUFBc0I7SUFDcEIsUUFBUTtJQUNSLFVBQVU7SUFDVixXQUFXOztFQUdiLFdBQVE7QUFDTixTQUFLLG9CQUFtQjtFQUMxQjs7RUFHQSxZQUFZLFNBQXNCO0FBQ2hDLFFBQUksUUFBUSxtQkFBbUIsS0FBSyxDQUFDLFFBQVEsbUJBQW1CLEVBQUUsYUFBYTtBQUM3RSxZQUFNLFVBQVUsUUFBUSxtQkFBbUIsRUFBRTtBQUM3QyxVQUFJLFNBQVM7QUFDWCxhQUFLLGNBQWM7QUFDbkIsYUFBSyx1QkFBdUIsT0FBTyxPQUFPO0FBQzFDLGFBQUssMEJBQXlCO0FBQzlCLGFBQUsscUJBQW9CO01BQzNCO0lBQ0Y7RUFDRjtFQUVRLHNCQUFtQjtBQUN6QixVQUFNLFVBQVUsS0FBSyxNQUFNLFNBQVMsU0FBUyxJQUFJLElBQUk7QUFFckQsUUFBSSxLQUFLLG1CQUFtQjtBQUUxQixXQUFLLGNBQWM7QUFDbkIsV0FBSyx1QkFBdUIsT0FBTyxLQUFLLGlCQUFpQjtJQUMzRCxXQUFXLFNBQVM7QUFFbEIsV0FBSyxjQUFjO0FBQ25CLFdBQUssdUJBQXVCLE9BQU8sT0FBTztJQUM1QyxPQUFPO0FBRUwsV0FBSyxjQUFjO0FBQ25CLFdBQUssdUJBQXVCLEtBQUssa0JBQWlCO0lBQ3BEO0FBRUEsUUFBSSxLQUFLLHNCQUFzQjtBQUM3QixXQUFLLDBCQUF5QjtBQUM5QixXQUFLLHFCQUFvQjtJQUMzQjtFQUNGO0VBRVEsb0JBQWlCO0FBQ3ZCLFFBQUksa0JBQWtCLEtBQUssVUFBVSxHQUFHO0FBQ3RDLFlBQU0sZ0JBQWdCLGFBQWEsUUFBUSxTQUFTO0FBQ3BELFVBQUksZUFBZTtBQUNqQixZQUFJO0FBQ0YsZ0JBQU0sVUFBVSxLQUFLLE1BQU0sYUFBYTtBQUN4QyxpQkFBTyxRQUFRLGlCQUFpQixRQUFRLE1BQU07UUFDaEQsU0FBUyxPQUFPO0FBQ2Qsa0JBQVEsTUFBTSwwQ0FBMEMsS0FBSztRQUMvRDtNQUNGO0lBQ0Y7QUFDQSxXQUFPO0VBQ1Q7RUFFQSxTQUFNO0FBQ0osU0FBSyxTQUFTLEtBQUk7RUFDcEI7Ozs7RUFNUSxlQUFZO0FBQ2xCLFFBQUksQ0FBQyxLQUFLLFFBQVE7QUFBUSxhQUFPO0FBQ2pDLFVBQU0sYUFBYTtBQUNuQixXQUFPLEtBQUssT0FBTyxPQUFPLFdBQVcsTUFBTSxJQUN2QyxLQUFLLE9BQU8sU0FDWixHQUFHLFVBQVUsR0FBRyxLQUFLLE9BQU8sTUFBTTtFQUN4QztFQUVBLGdCQUFhO0FBQ1gsUUFBSSxLQUFLO0FBQWE7QUFDdEIsU0FBSyxPQUFPLFNBQVMsQ0FBQyxvQkFBb0IsQ0FBQztFQUM3QztFQUVBLFFBQUs7QUFDSCxVQUFNLFNBQVMsS0FBSyxhQUFZO0FBRWhDLFFBQUksUUFBUTtBQUNWLFdBQUssZUFBZSxLQUFLLFVBQVUsK0JBQStCLE1BQU07QUFDeEUsV0FBSyx1QkFBdUI7QUFDNUIsV0FBSyxJQUFJLGNBQWE7SUFDeEIsT0FBTztBQUNMLFdBQUssY0FBYTtJQUNwQjtFQUNGO0VBRUEsc0JBQW1CO0FBQ2pCLFNBQUssdUJBQXVCO0FBQzVCLFNBQUssZUFBZTtFQUN0QjtFQUVBLE1BQU0sY0FBVztBQUNmLFVBQU0sTUFBTSxLQUFLLGFBQVk7QUFFN0IsUUFBSSxDQUFDLEtBQUs7QUFDUixXQUFLLGNBQWE7QUFDbEI7SUFDRjtBQUVBLFFBQUk7QUFDRixZQUFNLFlBQVksTUFBTSxNQUFNLEdBQUc7QUFDakMsWUFBTSxPQUFPLE1BQU0sVUFBVSxLQUFJO0FBRWpDLFlBQU0sVUFBVSxPQUFPLElBQUksZ0JBQWdCLElBQUk7QUFDL0MsWUFBTSxPQUFPLFNBQVMsY0FBYyxHQUFHO0FBQ3ZDLFdBQUssT0FBTztBQUNaLFdBQUssV0FBVyxLQUFLLE9BQU8sYUFBYSxNQUFNLEtBQUssT0FBTyxPQUFPLElBQUksS0FBSyxPQUFPLFNBQVM7QUFFM0YsZUFBUyxLQUFLLFlBQVksSUFBSTtBQUM5QixXQUFLLE1BQUs7QUFDVixlQUFTLEtBQUssWUFBWSxJQUFJO0FBRTlCLGFBQU8sSUFBSSxnQkFBZ0IsT0FBTztJQUNwQyxTQUFTLE9BQU87QUFDZCxjQUFRLE1BQU0sOEJBQThCLEtBQUs7QUFDakQsYUFBTyxLQUFLLEtBQUssUUFBUTtJQUMzQjtFQUNGOzs7O0VBTUEsYUFBVTtBQUNSLFFBQUksS0FBSyxhQUFhO0FBQ3BCLGFBQU8sS0FBSztJQUNkO0FBRUEsUUFBSSxLQUFLLFFBQVEsTUFBTTtBQUNyQixZQUFNLE9BQU8sS0FBSyxPQUFPO0FBRXpCLFVBQUksS0FBSyxXQUFXLE1BQU0sS0FBSyxLQUFLLFdBQVcsT0FBTyxHQUFHO0FBQ3ZELGVBQU87TUFDVDtBQUVBLFlBQU0sYUFBYSxLQUFLLFdBQVcsR0FBRyxJQUFJLE9BQU8sSUFBSSxJQUFJO0FBQ3pELGFBQU8sd0JBQXdCLFVBQVU7SUFDM0M7QUFFQSxXQUFPO0VBQ1Q7RUFFQSxZQUFZLE9BQVk7QUFDdEIsVUFBTSxhQUFhLE1BQU07QUFDekIsZUFBVyxNQUFNO0VBQ25CO0VBRUEsbUJBQW1CLE9BQVk7QUFDN0IsUUFBSSxLQUFLO0FBQWE7QUFFdEIsVUFBTSxRQUFRLE1BQU07QUFDcEIsUUFBSSxDQUFDLE1BQU0sU0FBUyxDQUFDLE1BQU0sTUFBTSxDQUFDO0FBQUc7QUFFckMsVUFBTSxPQUFPLE1BQU0sTUFBTSxDQUFDO0FBRTFCLFFBQUksQ0FBQyxLQUFLLEtBQUssV0FBVyxRQUFRLEdBQUc7QUFDbkMsWUFBTSwrQ0FBeUM7QUFDL0MsWUFBTSxRQUFRO0FBQ2Q7SUFDRjtBQUVBLFFBQUksS0FBSyxPQUFPLElBQUksT0FBTyxNQUFNO0FBQy9CLFlBQU0sb0NBQW9DO0FBQzFDLFlBQU0sUUFBUTtBQUNkO0lBQ0Y7QUFFQSxTQUFLLDBCQUEwQjtBQUUvQixVQUFNLFNBQVMsSUFBSSxXQUFVO0FBQzdCLFdBQU8sU0FBUyxNQUFLO0FBQ25CLFdBQUssY0FBYyxPQUFPO0FBQzFCLFdBQUssZ0JBQWU7SUFDdEI7QUFDQSxXQUFPLGNBQWMsSUFBSTtFQUMzQjtFQUVBLGtCQUFlO0FBQ2IsUUFBSSxDQUFDLEtBQUssMkJBQTJCLENBQUMsS0FBSztBQUFzQjtBQUVqRSxTQUFLLGtCQUNGLGdCQUFnQixLQUFLLHNCQUFzQixLQUFLLHVCQUF1QixFQUN2RSxVQUFVO01BQ1QsTUFBTSxDQUFDLFFBQVk7QUFDakIsWUFBSSxJQUFJLFNBQVM7QUFDZixlQUFLLE9BQU8sT0FBTyxJQUFJLFdBQVcsSUFBSSxRQUFRO0FBQzlDLGVBQUssMEJBQTBCO0FBQy9CLGVBQUssY0FBYztBQUNuQixnQkFBTSxpQ0FBOEI7QUFDcEMsZUFBSyxJQUFJLGNBQWE7UUFDeEIsT0FBTztBQUNMLGdCQUFNLElBQUksV0FBVywyQkFBMkI7QUFDaEQsZUFBSyxjQUFjO1FBQ3JCO01BQ0Y7TUFDQSxPQUFPLENBQUMsUUFBWTtBQUNsQixnQkFBUSxNQUFNLHdCQUF3QixHQUFHO0FBQ3pDLGFBQUssY0FBYztBQUNuQixjQUFNLEtBQUssT0FBTyxXQUFXLGlEQUE4QztNQUM3RTtLQUNEO0VBQ0w7Ozs7RUFNQSw0QkFBeUI7QUFDdkIsUUFBSSxDQUFDLEtBQUs7QUFBc0I7QUFFaEMsU0FBSyxrQkFBa0IsVUFBVSxLQUFLLG9CQUFvQixFQUFFLFVBQVU7TUFDcEUsTUFBTSxDQUFDLFFBQU87QUFDWixZQUFJLElBQUksV0FBVyxJQUFJLE1BQU07QUFDM0IsZUFBSyxTQUFTLGdEQUNULDRCQUEyQixJQUMzQixJQUFJLE9BRks7WUFHWixRQUFRLElBQUksS0FBSyxVQUFVLENBQUE7WUFDM0IsT0FBTyxJQUFJLEtBQUssU0FBUyxFQUFFLFFBQVEsSUFBSSxVQUFVLElBQUksV0FBVyxHQUFFOztRQUV0RTtBQUNBLGFBQUssSUFBSSxjQUFhO01BQ3hCO01BQ0EsT0FBTyxDQUFDLFFBQU87QUFDYixnQkFBUSxNQUFNLDRCQUE0QixHQUFHO0FBQzdDLGFBQUssSUFBSSxjQUFhO01BQ3hCO0tBQ0Q7RUFDSDtFQUVBLHdCQUFxQjtBQUNuQixRQUFJLENBQUMsS0FBSyxzQkFBc0I7QUFDOUIsWUFBTSwrQ0FBeUM7QUFDL0M7SUFDRjtBQUVBLFNBQUssWUFBWTtBQUNqQixTQUFLLGdCQUFnQjtBQUVyQixTQUFLLGtCQUNGLGlCQUFpQixLQUFLLHNCQUFzQixLQUFLLE1BQU0sRUFDdkQsVUFBVTtNQUNULE1BQU0sQ0FBQyxRQUFPO0FBQ1osYUFBSyxZQUFZO0FBQ2pCLFlBQUksSUFBSSxTQUFTO0FBQ2YsZUFBSyxnQkFBZ0I7QUFDckIscUJBQVcsTUFBSztBQUNkLGlCQUFLLGdCQUFnQjtBQUNyQixpQkFBSyxJQUFJLGNBQWE7VUFDeEIsR0FBRyxHQUFJO0FBQ1AsZUFBSywwQkFBeUI7UUFDaEMsT0FBTztBQUNMLGdCQUFNLElBQUksV0FBVyxxQ0FBcUM7UUFDNUQ7QUFDQSxhQUFLLElBQUksY0FBYTtNQUN4QjtNQUNBLE9BQU8sQ0FBQyxRQUFPO0FBQ2IsYUFBSyxZQUFZO0FBQ2pCLGdCQUFRLE1BQU0sNEJBQTRCLEdBQUc7QUFDN0MsY0FBTSxLQUFLLE9BQU8sV0FBVywyQ0FBd0M7QUFDckUsYUFBSyxJQUFJLGNBQWE7TUFDeEI7S0FDRDtFQUNMOzs7O0VBTUEsSUFBSSxzQkFBbUI7QUFDckIsUUFBSSxDQUFDLEtBQUssaUJBQWlCLENBQUMsS0FBSyxjQUFjLEtBQUksR0FBSTtBQUNyRCxhQUFPLEtBQUs7SUFDZDtBQUVBLFVBQU0sV0FBVyxLQUFLLGNBQWMsWUFBVyxFQUFHLEtBQUk7QUFFdEQsV0FBTyxLQUFLLGlCQUNULElBQUksU0FBUSxpQ0FDUixNQURRO01BRVgsUUFBUSxJQUFJLE9BQU8sT0FBTyxPQUFLLEVBQUUsT0FBTyxZQUFXLEVBQUcsU0FBUyxRQUFRLENBQUM7TUFDeEUsRUFDRCxPQUFPLFNBQU8sSUFBSSxPQUFPLFNBQVMsQ0FBQztFQUN4QztFQUVBLHVCQUFvQjtBQUNsQixTQUFLLGtCQUFrQixrQkFBaUIsRUFBRyxVQUFVO01BQ25ELE1BQU0sQ0FBQyxRQUFPO0FBQ1osWUFBSSxJQUFJLFNBQVM7QUFDZixlQUFLLG1CQUFtQixJQUFJO0FBQzVCLGVBQUssSUFBSSxjQUFhO1FBQ3hCO01BQ0Y7TUFDQSxPQUFPLENBQUMsUUFBUSxRQUFRLE1BQU0sMkJBQTJCLEdBQUc7S0FDN0Q7RUFDSDtFQUVBLFlBQVksU0FBZTtBQUN6QixVQUFNLE1BQU0sS0FBSyxjQUFjLFFBQVEsT0FBTztBQUM5QyxRQUFJLE1BQU0sSUFBSTtBQUNaLFdBQUssY0FBYyxPQUFPLEtBQUssQ0FBQztJQUNsQyxPQUFPO0FBQ0wsV0FBSyxjQUFjLEtBQUssT0FBTztJQUNqQztFQUNGO0VBRUEsb0JBQW9CLFNBQWU7QUFDakMsV0FBTyxLQUFLLGNBQWMsU0FBUyxPQUFPO0VBQzVDOzs7O0VBTUEsV0FBVyxNQUFvRDtBQUM3RCxRQUFJLEtBQUs7QUFBYTtBQUV0QixTQUFLLGNBQWM7QUFFbkIsWUFBUSxNQUFNO01BQ1osS0FBSztBQUNILGFBQUssZ0JBQWdCO1VBQ25CLFFBQVEsS0FBSyxPQUFPO1VBQ3BCLE1BQU0sS0FBSyxPQUFPOztBQUVwQjtNQUVGLEtBQUs7QUFDSCxhQUFLLGNBQWM7VUFDakIsVUFBVSxLQUFLLE9BQU8sWUFBWTtVQUNsQyxjQUFjLEtBQUssT0FBTyxnQkFBZ0I7VUFDMUMsa0JBQWtCLEtBQUssT0FBTyxvQkFBb0I7O0FBRXBEO01BRUYsS0FBSztBQUNILGFBQUssZ0JBQWdCO0FBQ3JCLGFBQUssZ0JBQWdCLEtBQUssT0FBTyxPQUFPLElBQUksT0FBSyxFQUFFLFFBQVE7QUFDM0QsYUFBSyx1QkFBdUIsS0FBSyxPQUFPLHFCQUFxQjtBQUM3RDtNQUVGLEtBQUs7QUFDSCxhQUFLLFlBQVksbUJBQUssS0FBSyxPQUFPO0FBQ2xDO0lBQ0o7RUFDRjtFQUVBLGNBQVc7QUFDVCxTQUFLLGNBQWM7RUFDckI7Ozs7RUFNQSxtQkFBZ0I7QUFDZCxTQUFLLE9BQU8sU0FBUyxLQUFLLGNBQWM7QUFDeEMsU0FBSyxPQUFPLE9BQU8sS0FBSyxjQUFjO0FBQ3RDLFNBQUssc0JBQXFCO0FBQzFCLFNBQUssWUFBVztFQUNsQjtFQUVBLGlCQUFjO0FBQ1osU0FBSyxPQUFPLFdBQVcsS0FBSyxZQUFZO0FBQ3hDLFNBQUssT0FBTyxlQUFlLEtBQUssWUFBWTtBQUM1QyxTQUFLLE9BQU8sbUJBQW1CLEtBQUssWUFBWTtBQUNoRCxTQUFLLHNCQUFxQjtBQUMxQixTQUFLLFlBQVc7RUFDbEI7RUFFQSxnQkFBYTtBQUNYLFVBQU0saUJBQTZCLENBQUE7QUFDbkMsU0FBSyxpQkFBaUIsUUFBUSxTQUFPLGVBQWUsS0FBSyxHQUFHLElBQUksTUFBTSxDQUFDO0FBRXZFLFNBQUssT0FBTyxTQUFTLGVBQWUsT0FBTyxPQUFLLEtBQUssY0FBYyxTQUFTLEVBQUUsUUFBUSxDQUFDO0FBQ3ZGLFNBQUssT0FBTyxvQkFBb0IsS0FBSztBQUNyQyxTQUFLLHNCQUFxQjtBQUMxQixTQUFLLFlBQVc7RUFDbEI7RUFFQSxxQkFBa0I7QUFDaEIsU0FBSyxjQUFhO0VBQ3BCO0VBRUEsZUFBWTtBQUNWLFNBQUssT0FBTyxRQUFRLG1CQUFLLEtBQUs7QUFDOUIsU0FBSyxzQkFBcUI7QUFDMUIsU0FBSyxZQUFXO0VBQ2xCOztxQ0EvYlcsb0JBQWlCO0VBQUE7NEVBQWpCLG9CQUFpQixXQUFBLENBQUEsQ0FBQSx3QkFBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLG1CQUFBLHFCQUFBLGFBQUEsY0FBQSxHQUFBLFVBQUEsQ0FBQSxpQ0FBQSxHQUFBLE9BQUEsSUFBQSxNQUFBLElBQUEsUUFBQSxDQUFBLENBQUEsYUFBQSxFQUFBLEdBQUEsQ0FBQSxHQUFBLGtCQUFBLEdBQUEsQ0FBQSxHQUFBLGVBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxnQkFBQSxHQUFBLENBQUEsR0FBQSxnQkFBQSxHQUFBLENBQUEsT0FBQSxrQkFBQSxHQUFBLGVBQUEsR0FBQSxLQUFBLEdBQUEsQ0FBQSxHQUFBLG9CQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsY0FBQSxHQUFBLENBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsaUJBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxHQUFBLGdCQUFBLEdBQUEsQ0FBQSxHQUFBLHNCQUFBLEdBQUEsQ0FBQSxHQUFBLGVBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSxxQkFBQSxHQUFBLENBQUEsUUFBQSxVQUFBLFNBQUEseUJBQUEsR0FBQSxpQkFBQSxHQUFBLENBQUEsR0FBQSxtQkFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLHNCQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLGVBQUEsU0FBQSxHQUFBLENBQUEsUUFBQSxVQUFBLFNBQUEsaUNBQUEsR0FBQSxpQkFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsaUJBQUEsR0FBQSxDQUFBLEdBQUEsZUFBQSxhQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsU0FBQSwyQkFBQSxHQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLGdCQUFBLEdBQUEsQ0FBQSxHQUFBLEtBQUEsR0FBQSxDQUFBLEdBQUEsMkJBQUEsR0FBQSxDQUFBLEdBQUEsZUFBQSxZQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsU0FBQSxrQkFBQSxHQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLFVBQUEsVUFBQSxPQUFBLHVCQUFBLEdBQUEsWUFBQSxVQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsVUFBQSxVQUFBLE9BQUEsdUJBQUEsR0FBQSxZQUFBLFlBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxVQUFBLFVBQUEsT0FBQSx1QkFBQSxHQUFBLFlBQUEsYUFBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSxpQkFBQSxvQkFBQSxHQUFBLENBQUEsT0FBQSxrQkFBQSxHQUFBLGVBQUEsR0FBQSxTQUFBLEtBQUEsR0FBQSxDQUFBLFNBQUEsOEJBQUEsV0FBQSxhQUFBLFFBQUEsZ0JBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxhQUFBLFdBQUEsS0FBQSwyTEFBQSxhQUFBLFNBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxTQUFBLDBCQUFBLEdBQUEsa0JBQUEsR0FBQSxTQUFBLFVBQUEsR0FBQSxDQUFBLFFBQUEsUUFBQSxVQUFBLG9DQUFBLEdBQUEsV0FBQSxRQUFBLEdBQUEsUUFBQSxHQUFBLENBQUEsUUFBQSxVQUFBLEdBQUEsa0JBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsR0FBQSxjQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsUUFBQSxVQUFBLEdBQUEsb0JBQUEsR0FBQSxTQUFBLFVBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxTQUFBLHlCQUFBLEdBQUEsbUJBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsU0FBQSxpQ0FBQSxHQUFBLG1CQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxHQUFBLFVBQUEsb0JBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsR0FBQSxVQUFBLGlCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsUUFBQSxVQUFBLEdBQUEsVUFBQSxhQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsR0FBQSxVQUFBLGVBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLGdCQUFBLEdBQUEsQ0FBQSxHQUFBLGdCQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsR0FBQSxVQUFBLGVBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsU0FBQSwyQkFBQSxHQUFBLG1CQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSx1QkFBQSxHQUFBLENBQUEsR0FBQSxpQkFBQSxHQUFBLENBQUEsUUFBQSxVQUFBLFNBQUEsa0JBQUEsR0FBQSxtQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsaUJBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLG1CQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxjQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsR0FBQSxvQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxPQUFBLFFBQUEsR0FBQSxDQUFBLE1BQUEsVUFBQSxRQUFBLFFBQUEsZUFBQSxnQkFBQSxHQUFBLGlCQUFBLFNBQUEsR0FBQSxDQUFBLE9BQUEsTUFBQSxHQUFBLENBQUEsTUFBQSxRQUFBLFFBQUEsUUFBQSxlQUFBLGlCQUFBLEdBQUEsaUJBQUEsU0FBQSxHQUFBLENBQUEsR0FBQSxjQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsR0FBQSxnQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxHQUFBLGVBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxPQUFBLFNBQUEsR0FBQSxDQUFBLE1BQUEsV0FBQSxRQUFBLEtBQUEsZUFBQSx5RUFBQSxHQUFBLGlCQUFBLFNBQUEsR0FBQSxDQUFBLE9BQUEsY0FBQSxHQUFBLENBQUEsTUFBQSxnQkFBQSxRQUFBLFFBQUEsZUFBQSxvREFBQSxHQUFBLGlCQUFBLFNBQUEsR0FBQSxDQUFBLE9BQUEsaUJBQUEsR0FBQSxDQUFBLE1BQUEsbUJBQUEsR0FBQSxpQkFBQSxTQUFBLEdBQUEsQ0FBQSxTQUFBLG9CQUFBLEdBQUEsQ0FBQSxTQUFBLHFCQUFBLEdBQUEsQ0FBQSxTQUFBLFVBQUEsR0FBQSxDQUFBLE9BQUEsZUFBQSxHQUFBLENBQUEsTUFBQSxpQkFBQSxRQUFBLFFBQUEsZUFBQSxpQ0FBQSxHQUFBLGlCQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsbUJBQUEsR0FBQSxDQUFBLEdBQUEsaUJBQUEsR0FBQSxDQUFBLE9BQUEsa0JBQUEsR0FBQSxDQUFBLE1BQUEsb0JBQUEsUUFBQSxLQUFBLGVBQUEsMEVBQUEsR0FBQSxpQkFBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLHNCQUFBLEdBQUEsQ0FBQSxHQUFBLGdCQUFBLEdBQUEsQ0FBQSxRQUFBLFlBQUEsR0FBQSxVQUFBLFNBQUEsR0FBQSxDQUFBLE9BQUEsUUFBQSxHQUFBLENBQUEsTUFBQSxVQUFBLFFBQUEsT0FBQSxlQUFBLGdDQUFBLEdBQUEsaUJBQUEsU0FBQSxHQUFBLENBQUEsT0FBQSxVQUFBLEdBQUEsQ0FBQSxNQUFBLFlBQUEsUUFBQSxPQUFBLGVBQUEseUNBQUEsR0FBQSxpQkFBQSxTQUFBLEdBQUEsQ0FBQSxPQUFBLFdBQUEsR0FBQSxDQUFBLE1BQUEsYUFBQSxRQUFBLE9BQUEsZUFBQSwyQkFBQSxHQUFBLGlCQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsaUJBQUEsc0JBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLG1CQUFBLG9CQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxzQkFBQSxHQUFBLENBQUEsU0FBQSxxQ0FBQSxHQUFBLG9CQUFBLEdBQUEsS0FBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLDJCQUFBLElBQUEsS0FBQTtBQUFBLFFBQUEsS0FBQSxHQUFBO0FDdEY5QixNQUFBLDRCQUFBLEdBQUEsT0FBQSxDQUFBLEVBQThCLEdBQUEsT0FBQSxDQUFBLEVBS08sR0FBQSxPQUFBLENBQUEsRUFHTCxHQUFBLE9BQUEsQ0FBQTtBQUV4QixNQUFBLGlDQUFBLEdBQUEsMENBQUEsR0FBQSxHQUFBLE9BQUEsQ0FBQSxFQUFrQyxHQUFBLDBDQUFBLEdBQUEsR0FBQSxPQUFBLENBQUE7QUFXbEMsTUFBQSxpQ0FBQSxHQUFBLDBDQUFBLEdBQUEsQ0FBQTtBQU1GLE1BQUEsMEJBQUEsRUFBTTtBQUlSLE1BQUEsNEJBQUEsR0FBQSxPQUFBLENBQUEsRUFBdUIsR0FBQSxJQUFBO0FBQ2pCLE1BQUEsb0JBQUEsQ0FBQTtBQUFxRSxNQUFBLDBCQUFBO0FBQ3pFLE1BQUEsNEJBQUEsSUFBQSxLQUFBLENBQUE7QUFBd0IsTUFBQSxvQkFBQSxFQUFBO0FBQW9ELE1BQUEsMEJBQUE7QUFDNUUsTUFBQSw0QkFBQSxJQUFBLEtBQUEsQ0FBQTtBQUFzQixNQUFBLG9CQUFBLEVBQUE7QUFBNkMsTUFBQSwwQkFBQTtBQUNuRSxNQUFBLDRCQUFBLElBQUEsS0FBQSxFQUFBO0FBQ0UsTUFBQSxvQkFBQSxFQUFBO0FBQ0YsTUFBQSwwQkFBQTtBQUdBLE1BQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDRSxNQUFBLGlDQUFBLElBQUEsMkNBQUEsR0FBQSxHQUFBLFVBQUEsRUFBQSxFQUFtQixJQUFBLDJDQUFBLEdBQUEsQ0FBQTtBQW1CckIsTUFBQSwwQkFBQSxFQUFNLEVBQ0Y7QUFLUixNQUFBLGlDQUFBLElBQUEsMkNBQUEsR0FBQSxHQUFBLE9BQUEsRUFBQTtBQVNBLE1BQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBdUMsSUFBQSxPQUFBLEVBQUEsRUFDSixJQUFBLElBQUE7QUFDM0IsTUFBQSxvQkFBQSxJQUFBLDhCQUFBO0FBQXFCLE1BQUEsMEJBQUE7QUFFekIsTUFBQSxpQ0FBQSxJQUFBLDJDQUFBLEdBQUEsR0FBQSxVQUFBLEVBQUE7QUFLRixNQUFBLDBCQUFBO0FBRUEsTUFBQSxpQ0FBQSxJQUFBLDJDQUFBLEdBQUEsR0FBQSxLQUFBLEVBQUEsRUFBdUIsSUFBQSwyQ0FBQSxHQUFBLEdBQUEsS0FBQSxFQUFBO0FBWXZCLE1BQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBa0MsSUFBQSxPQUFBLEVBQUEsRUFDTixJQUFBLFFBQUEsRUFBQTtBQUNKLE1BQUEsb0JBQUEsSUFBQSw0QkFBQTtBQUF1QixNQUFBLDBCQUFBO0FBQzNDLE1BQUEsNEJBQUEsSUFBQSxRQUFBLEVBQUE7QUFBb0IsTUFBQSxvQkFBQSxFQUFBO0FBQTBDLE1BQUEsMEJBQUEsRUFBTztBQUV2RSxNQUFBLDRCQUFBLElBQUEsT0FBQSxFQUFBLEVBQTBCLElBQUEsUUFBQSxFQUFBO0FBQ0osTUFBQSxvQkFBQSxJQUFBLHNCQUFBO0FBQWlCLE1BQUEsMEJBQUE7QUFDckMsTUFBQSw0QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUFvQixNQUFBLG9CQUFBLEVBQUE7QUFBc0QsTUFBQSwwQkFBQSxFQUFPLEVBQzdFLEVBQ0Y7QUFPUixNQUFBLDRCQUFBLElBQUEsT0FBQSxFQUFBLEVBQWlDLElBQUEsT0FBQSxFQUFBLEVBQ0UsSUFBQSxJQUFBO0FBQzNCLE1BQUEsb0JBQUEsSUFBQSw0QkFBQTtBQUFtQixNQUFBLDBCQUFBO0FBRXZCLE1BQUEsaUNBQUEsSUFBQSwyQ0FBQSxHQUFBLEdBQUEsVUFBQSxFQUFBO0FBS0YsTUFBQSwwQkFBQTtBQUVBLE1BQUEsaUNBQUEsSUFBQSwyQ0FBQSxJQUFBLEdBQUEsT0FBQSxFQUFBLEVBQXFCLElBQUEsMkNBQUEsR0FBQSxHQUFBLE9BQUEsRUFBQTtBQStDdkIsTUFBQSwwQkFBQTtBQUtBLE1BQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBcUMsSUFBQSxPQUFBLEVBQUEsRUFDRixJQUFBLElBQUE7QUFDM0IsTUFBQSxvQkFBQSxJQUFBLGdEQUFBO0FBQStCLE1BQUEsMEJBQUE7QUFDbkMsTUFBQSxpQ0FBQSxJQUFBLDJDQUFBLEdBQUEsR0FBQSxVQUFBLEVBQUE7QUFLRixNQUFBLDBCQUFBO0FBRUEsTUFBQSw0QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNFLE1BQUEsOEJBQUEsSUFBQSxtQ0FBQSxHQUFBLEdBQUEsUUFBQSxJQUFBLFVBQUE7QUFHRixNQUFBLDBCQUFBO0FBRUEsTUFBQSxpQ0FBQSxJQUFBLDJDQUFBLEdBQUEsR0FBQSxPQUFBLEVBQUE7QUFPQSxNQUFBLGlDQUFBLElBQUEsMkNBQUEsR0FBQSxHQUFBLEtBQUEsRUFBQTtBQVNGLE1BQUEsMEJBQUE7QUFLQSxNQUFBLDRCQUFBLElBQUEsT0FBQSxFQUFBLEVBQW9DLElBQUEsT0FBQSxFQUFBLEVBQ0QsSUFBQSxJQUFBO0FBQzNCLE1BQUEsb0JBQUEsSUFBQSw4QkFBQTtBQUFxQixNQUFBLDBCQUFBO0FBQ3pCLE1BQUEsaUNBQUEsSUFBQSwyQ0FBQSxHQUFBLEdBQUEsVUFBQSxFQUFBO0FBS0YsTUFBQSwwQkFBQTtBQUVBLE1BQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDRSxNQUFBLGlDQUFBLElBQUEsMkNBQUEsR0FBQSxHQUFBLEtBQUEsRUFBQTtBQUdBLE1BQUEsaUNBQUEsSUFBQSwyQ0FBQSxHQUFBLEdBQUEsS0FBQSxFQUFBO0FBR0EsTUFBQSxpQ0FBQSxJQUFBLDJDQUFBLEdBQUEsR0FBQSxLQUFBLEVBQUE7QUFHQSxNQUFBLGlDQUFBLElBQUEsMkNBQUEsR0FBQSxHQUFBLEtBQUEsRUFBQTtBQVNGLE1BQUEsMEJBQUEsRUFBTTtBQU1SLE1BQUEsaUNBQUEsSUFBQSwyQ0FBQSxJQUFBLEdBQUEsT0FBQSxFQUFBO0FBa0NBLE1BQUEsaUNBQUEsSUFBQSwyQ0FBQSxJQUFBLEdBQUEsT0FBQSxFQUFBO0FBMkNBLE1BQUEsaUNBQUEsSUFBQSwyQ0FBQSxJQUFBLEdBQUEsT0FBQSxFQUFBO0FBc0RBLE1BQUEsaUNBQUEsSUFBQSwyQ0FBQSxJQUFBLEdBQUEsT0FBQSxFQUFBO0FBdUNBLE1BQUEsaUNBQUEsSUFBQSwyQ0FBQSxJQUFBLEdBQUEsT0FBQSxFQUFBO0FBbmFGLE1BQUEsMEJBQUE7OztBQVVRLE1BQUEsdUJBQUEsQ0FBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQSxPQUFBLFFBQUEsSUFBQSxjQUFBLElBQUEsQ0FBQTtBQVdBLE1BQUEsdUJBQUEsQ0FBQTtBQUFBLE1BQUEsMkJBQUEsQ0FBQSxJQUFBLGNBQUEsSUFBQSxFQUFBO0FBV0UsTUFBQSx1QkFBQSxDQUFBO0FBQUEsTUFBQSxnQ0FBQSxJQUFBLElBQUEsT0FBQSxXQUFBLFVBQUEsS0FBQSxJQUFBLE9BQUEsYUFBQSxVQUFBO0FBQ29CLE1BQUEsdUJBQUEsQ0FBQTtBQUFBLE1BQUEsZ0NBQUEsY0FBQSxJQUFBLE9BQUEsV0FBQSx5QkFBQTtBQUNGLE1BQUEsdUJBQUEsQ0FBQTtBQUFBLE1BQUEsZ0NBQUEsaUJBQUEsSUFBQSxPQUFBLFNBQUEsb0JBQUE7QUFFcEIsTUFBQSx1QkFBQSxDQUFBO0FBQUEsTUFBQSxnQ0FBQSxlQUFBLElBQUEsT0FBQSxTQUFBLElBQUEsT0FBQSxVQUFBLElBQUEsT0FBQSxPQUFBLE9BQUEsSUFBQSxPQUFBLE9BQUEsTUFBQSxnQ0FBQSxHQUFBO0FBS0EsTUFBQSx1QkFBQSxDQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBLGNBQUEsS0FBQSxFQUFBO0FBeUJOLE1BQUEsdUJBQUEsQ0FBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQSxpQkFBQSxDQUFBLElBQUEsY0FBQSxLQUFBLEVBQUE7QUFhSSxNQUFBLHVCQUFBLENBQUE7QUFBQSxNQUFBLDJCQUFBLENBQUEsSUFBQSxjQUFBLEtBQUEsRUFBQTtBQU9GLE1BQUEsdUJBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUEsT0FBQSxXQUFBLEtBQUEsRUFBQTtBQWV3QixNQUFBLHVCQUFBLENBQUE7QUFBQSxNQUFBLCtCQUFBLElBQUEsT0FBQSxnQkFBQSxhQUFBO0FBSUEsTUFBQSx1QkFBQSxDQUFBO0FBQUEsTUFBQSwrQkFBQSxJQUFBLE9BQUEsb0JBQUEscUJBQUE7QUFhdEIsTUFBQSx1QkFBQSxDQUFBO0FBQUEsTUFBQSwyQkFBQSxDQUFBLElBQUEsY0FBQSxLQUFBLEVBQUE7QUFPRixNQUFBLHVCQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBLE9BQUEsU0FBQSxLQUFBLEVBQUE7QUF1REUsTUFBQSx1QkFBQSxDQUFBO0FBQUEsTUFBQSwyQkFBQSxDQUFBLElBQUEsY0FBQSxLQUFBLEVBQUE7QUFRQSxNQUFBLHVCQUFBLENBQUE7QUFBQSxNQUFBLHdCQUFBLElBQUEsT0FBQSxVQUFBLDZCQUFBLElBQUEsR0FBQSxDQUFBO0FBS0YsTUFBQSx1QkFBQSxDQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBLE9BQUEsb0JBQUEsS0FBQSxFQUFBO0FBT0EsTUFBQSx1QkFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQSxPQUFBLE9BQUEsVUFBQSxPQUFBLEtBQUEsQ0FBQSxJQUFBLE9BQUEsb0JBQUEsS0FBQSxFQUFBO0FBaUJFLE1BQUEsdUJBQUEsQ0FBQTtBQUFBLE1BQUEsMkJBQUEsQ0FBQSxJQUFBLGNBQUEsS0FBQSxFQUFBO0FBUUEsTUFBQSx1QkFBQSxDQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBLE9BQUEsTUFBQSxTQUFBLEtBQUEsRUFBQTtBQUdBLE1BQUEsdUJBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUEsT0FBQSxNQUFBLFdBQUEsS0FBQSxFQUFBO0FBR0EsTUFBQSx1QkFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQSxPQUFBLE1BQUEsWUFBQSxLQUFBLEVBQUE7QUFHQSxNQUFBLHVCQUFBO0FBQUEsTUFBQSwyQkFBQSxDQUFBLElBQUEsT0FBQSxNQUFBLFVBQUEsQ0FBQSxJQUFBLE9BQUEsTUFBQSxZQUFBLENBQUEsSUFBQSxPQUFBLE1BQUEsWUFBQSxLQUFBLEVBQUE7QUFlSixNQUFBLHVCQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBLGdCQUFBLGdCQUFBLEtBQUEsRUFBQTtBQWtDQSxNQUFBLHVCQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBLGdCQUFBLFlBQUEsS0FBQSxFQUFBO0FBMkNBLE1BQUEsdUJBQUE7QUFBQSxNQUFBLDJCQUFBLElBQUEsZ0JBQUEsV0FBQSxLQUFBLEVBQUE7QUFzREEsTUFBQSx1QkFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQSxnQkFBQSxVQUFBLEtBQUEsRUFBQTtBQXVDQSxNQUFBLHVCQUFBO0FBQUEsTUFBQSwyQkFBQSxJQUFBLHdCQUFBLElBQUEsZUFBQSxLQUFBLEVBQUE7O29CRGpWVSxjQUFZLFlBQUEsc0JBQUEsWUFBQSxTQUFBLHFCQUFBLFlBQUEsYUFBQSxpQkFBQSxvQkFBQSxhQUFBLGlCQUFFLGFBQVcsdUJBQUEsbUJBQUEsaUNBQUEseUJBQUEsd0JBQUEsdUJBQUEsaUNBQUEsK0JBQUEsdUNBQUEsOEJBQUEsb0JBQUEseUJBQUEsc0JBQUEsdUJBQUEsdUJBQUEscUJBQUEsOEJBQUEsbUJBQUEsaUJBQUEsaUJBQUEsWUFBQSxpQkFBQSxXQUFBLGNBQUEsa0JBQUEsa0JBQUEsYUFBQSxjQUFBLGdCQUFBLGdCQUFBLGtCQUFBLGlCQUFBLGFBQUEsbUJBQUEsbUJBQUEsZUFBQSxHQUFBLFFBQUEsQ0FBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7bURBQUEsRUFBQSxDQUFBOzs7K0VBSXhCLG1CQUFpQixDQUFBO1VBUDdCO3VCQUNXLDBCQUF3QixZQUN0QixNQUFJLFNBQ1AsQ0FBQyxjQUFjLFdBQVcsR0FBQyxVQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBQUEsUUFBQSxDQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FBQSxFQUFBLENBQUE7O1VBZ0JuQzs7VUFDQTs7OztnRkFiVSxtQkFBaUIsRUFBQSxXQUFBLHFCQUFBLFVBQUEsZ0VBQUEsWUFBQSxHQUFBLENBQUE7QUFBQSxHQUFBOzs7Ozs7OzhEQUFqQixtQkFBaUIsRUFBQSxTQUFBLENBQUEsSUFBQSxJQUFBLEVBQUEsR0FBQSxDQUFBLGNBQUEsYUFBQSxXQUFBLEtBQUEsR0FBQSxhQUFBLEVBQUEsQ0FBQTtFQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxjQUFBLDBCQUFBLEtBQUEsSUFBQSxDQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxlQUFBLFlBQUEsT0FBQSxZQUFBLElBQUEsR0FBQSw0QkFBQSxPQUFBLEVBQUEsT0FBQSxNQUFBLDBCQUFBLEVBQUEsU0FBQSxDQUFBO0FBQUEsR0FBQTsiLCJuYW1lcyI6W119