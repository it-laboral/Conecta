import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/chunk-BHBSFVOT.js");import {
  AuthService
} from "/chunk-YI23ZOHR.js";
import {
  __spreadValues
} from "/chunk-CZJLB7T5.js";

// src/app/pagina/perfiles/empresa-profile/empresa-profile.ts
import { Component, Input, Output, EventEmitter, inject, ChangeDetectorRef } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import { CommonModule, Location } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_common.js?v=3d725e17";
import { FormsModule } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_forms.js?v=3d725e17";
import { HttpClient } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_common_http.js?v=3d725e17";
import { Router, ActivatedRoute } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_router.js?v=3d725e17";
import * as i0 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import * as i1 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_common.js?v=3d725e17";
import * as i2 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_forms.js?v=3d725e17";
function EmpresaProfile_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 1);
    i0.\u0275\u0275text(1, "\u231B Cargando datos...");
    i0.\u0275\u0275elementEnd();
  }
}
function EmpresaProfile_Conditional_2_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "button", 8);
    i0.\u0275\u0275listener("click", function EmpresaProfile_Conditional_2_Conditional_7_Template_button_click_0_listener() {
      i0.\u0275\u0275restoreView(_r1);
      const ctx_r1 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r1.volver());
    });
    i0.\u0275\u0275text(1, "\u2190 Volver");
    i0.\u0275\u0275elementEnd();
  }
}
function EmpresaProfile_Conditional_2_Conditional_8_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "button", 10);
    i0.\u0275\u0275listener("click", function EmpresaProfile_Conditional_2_Conditional_8_Conditional_0_Template_button_click_0_listener() {
      i0.\u0275\u0275restoreView(_r3);
      const ctx_r1 = i0.\u0275\u0275nextContext(3);
      return i0.\u0275\u0275resetView(ctx_r1.activarEdicion());
    });
    i0.\u0275\u0275text(1, "\u270F\uFE0F Editar Perfil");
    i0.\u0275\u0275elementEnd();
  }
}
function EmpresaProfile_Conditional_2_Conditional_8_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "button", 11);
    i0.\u0275\u0275listener("click", function EmpresaProfile_Conditional_2_Conditional_8_Conditional_1_Template_button_click_0_listener() {
      i0.\u0275\u0275restoreView(_r4);
      const ctx_r1 = i0.\u0275\u0275nextContext(3);
      return i0.\u0275\u0275resetView(ctx_r1.cancelarEdicion());
    });
    i0.\u0275\u0275text(1, "\u2715 Cancelar");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(2, "button", 12);
    i0.\u0275\u0275listener("click", function EmpresaProfile_Conditional_2_Conditional_8_Conditional_1_Template_button_click_2_listener() {
      i0.\u0275\u0275restoreView(_r4);
      const ctx_r1 = i0.\u0275\u0275nextContext(3);
      return i0.\u0275\u0275resetView(ctx_r1.guardarCambios());
    });
    i0.\u0275\u0275text(3);
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext(3);
    i0.\u0275\u0275property("disabled", ctx_r1.guardando || ctx_r1.subiendoLogo);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275property("disabled", ctx_r1.guardando || ctx_r1.subiendoLogo);
    i0.\u0275\u0275advance();
    i0.\u0275\u0275textInterpolate1(" ", ctx_r1.guardando ? "\u23F3 Guardando..." : ctx_r1.subiendoLogo ? "\u{1F4E4} Subiendo logo..." : "\u{1F4BE} Guardar Perfil", " ");
  }
}
function EmpresaProfile_Conditional_2_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275conditionalCreate(0, EmpresaProfile_Conditional_2_Conditional_8_Conditional_0_Template, 2, 0, "button", 9)(1, EmpresaProfile_Conditional_2_Conditional_8_Conditional_1_Template, 4, 3);
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275conditional(!ctx_r1.modoEdicion ? 0 : 1);
  }
}
function EmpresaProfile_Conditional_2_Conditional_9_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275element(0, "img", 16);
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext(3);
    i0.\u0275\u0275property("alt", i0.\u0275\u0275interpolate1("Logo ", ctx_r1.perfil.fantasia || ctx_r1.perfil.razonSocial))("src", ctx_r1.perfil.logo, i0.\u0275\u0275sanitizeUrl);
  }
}
function EmpresaProfile_Conditional_2_Conditional_9_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 17);
    i0.\u0275\u0275text(1, "\u{1F3E2}");
    i0.\u0275\u0275elementEnd();
  }
}
function EmpresaProfile_Conditional_2_Conditional_9_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "a", 23);
    i0.\u0275\u0275text(1, "\u{1F310} Web");
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext(3);
    i0.\u0275\u0275property("href", ctx_r1.perfil.sitio_web, i0.\u0275\u0275sanitizeUrl);
  }
}
function EmpresaProfile_Conditional_2_Conditional_9_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "a", 23);
    i0.\u0275\u0275text(1, "\u{1F4BC} LinkedIn");
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext(3);
    i0.\u0275\u0275property("href", ctx_r1.perfil.linkedin, i0.\u0275\u0275sanitizeUrl);
  }
}
function EmpresaProfile_Conditional_2_Conditional_9_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "span", 22);
    i0.\u0275\u0275text(1);
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext(3);
    i0.\u0275\u0275advance();
    i0.\u0275\u0275textInterpolate1("\u{1F4DE} ", ctx_r1.perfil.telefono);
  }
}
function EmpresaProfile_Conditional_2_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "header", 13)(1, "div", 14)(2, "div", 15);
    i0.\u0275\u0275conditionalCreate(3, EmpresaProfile_Conditional_2_Conditional_9_Conditional_3_Template, 1, 3, "img", 16)(4, EmpresaProfile_Conditional_2_Conditional_9_Conditional_4_Template, 2, 0, "div", 17);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(5, "div", 18)(6, "h3");
    i0.\u0275\u0275text(7);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(8, "span", 19);
    i0.\u0275\u0275text(9);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(10, "div", 20)(11, "span", 21);
    i0.\u0275\u0275text(12);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(13, "span", 22);
    i0.\u0275\u0275text(14);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275conditionalCreate(15, EmpresaProfile_Conditional_2_Conditional_9_Conditional_15_Template, 2, 1, "a", 23);
    i0.\u0275\u0275conditionalCreate(16, EmpresaProfile_Conditional_2_Conditional_9_Conditional_16_Template, 2, 1, "a", 23);
    i0.\u0275\u0275conditionalCreate(17, EmpresaProfile_Conditional_2_Conditional_9_Conditional_17_Template, 2, 1, "span", 22);
    i0.\u0275\u0275elementStart(18, "span", 22);
    i0.\u0275\u0275text(19);
    i0.\u0275\u0275elementEnd()()()()();
    i0.\u0275\u0275elementStart(20, "div", 24)(21, "section", 25)(22, "article", 26)(23, "h4");
    i0.\u0275\u0275text(24, "\u{1F4C4} Descripci\xF3n General");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(25, "p");
    i0.\u0275\u0275text(26);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(27, "article", 26)(28, "h4");
    i0.\u0275\u0275text(29, "\u{1F4BB} Stack Tecnol\xF3gico y Herramientas");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(30, "p");
    i0.\u0275\u0275text(31);
    i0.\u0275\u0275elementEnd()()();
    i0.\u0275\u0275elementStart(32, "section", 25)(33, "article", 26)(34, "h4");
    i0.\u0275\u0275text(35, "\u{1F3C6} Trayectoria y Proyectos Destacados");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(36, "p");
    i0.\u0275\u0275text(37);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(38, "article", 26)(39, "h4");
    i0.\u0275\u0275text(40, "\u{1F381} Beneficios para Estudiantes");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(41, "p");
    i0.\u0275\u0275text(42);
    i0.\u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275conditional(ctx_r1.perfil.logo ? 3 : 4);
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275textInterpolate(ctx_r1.perfil.fantasia || ctx_r1.perfil.razonSocial);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate(ctx_r1.perfil.sector || "Sector no especificado");
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate1("\u{1F4BB} ", ctx_r1.perfil.modalidad || "H\xEDbrido");
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1("\u{1F4CD} ", ctx_r1.perfil.zona_trabajo || "Ubicaci\xF3n no especificada");
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(ctx_r1.perfil.sitio_web ? 15 : -1);
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(ctx_r1.perfil.linkedin ? 16 : -1);
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(ctx_r1.perfil.telefono ? 17 : -1);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate1("\u{1F4E7} ", ctx_r1.perfil.email);
    i0.\u0275\u0275advance(7);
    i0.\u0275\u0275textInterpolate(ctx_r1.perfil.descripcion || "Sin descripci\xF3n cargada.");
    i0.\u0275\u0275advance(5);
    i0.\u0275\u0275textInterpolate(ctx_r1.perfil.stack_tecnologico || "Sin tecnolog\xEDas especificadas.");
    i0.\u0275\u0275advance(6);
    i0.\u0275\u0275textInterpolate(ctx_r1.perfil.trayectoria || "Sin informaci\xF3n de trayectoria cargada.");
    i0.\u0275\u0275advance(5);
    i0.\u0275\u0275textInterpolate(ctx_r1.perfil.beneficios || "Sin detalles de beneficios.");
  }
}
function EmpresaProfile_Conditional_2_Conditional_10_Conditional_24_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275element(0, "img", 33);
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext(3);
    i0.\u0275\u0275property("src", ctx_r1.logoPreview, i0.\u0275\u0275sanitizeUrl);
  }
}
function EmpresaProfile_Conditional_2_Conditional_10_Conditional_25_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "span");
    i0.\u0275\u0275text(1, "Sin logo");
    i0.\u0275\u0275elementEnd();
  }
}
function EmpresaProfile_Conditional_2_Conditional_10_Conditional_28_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "small", 36);
    i0.\u0275\u0275text(1, "\u23F3 Subiendo imagen...");
    i0.\u0275\u0275elementEnd();
  }
}
function EmpresaProfile_Conditional_2_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 7)(1, "h3");
    i0.\u0275\u0275text(2, "\u270F\uFE0F Actualizar Perfil Institucional");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(3, "div", 27)(4, "small");
    i0.\u0275\u0275text(5, " \u2139\uFE0F ");
    i0.\u0275\u0275elementStart(6, "strong");
    i0.\u0275\u0275text(7, "Raz\xF3n Social:");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(8);
    i0.\u0275\u0275elementStart(9, "strong");
    i0.\u0275\u0275text(10, "Email:");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(11);
    i0.\u0275\u0275elementStart(12, "strong");
    i0.\u0275\u0275text(13, "Ubicaci\xF3n Fiscal:");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275text(14);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(15, "div", 28)(16, "div", 29)(17, "h4");
    i0.\u0275\u0275text(18, "\u{1F5BC}\uFE0F Logo e Identidad");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(19, "div", 30)(20, "label");
    i0.\u0275\u0275text(21, "Logo de la Empresa");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(22, "div", 31)(23, "div", 32);
    i0.\u0275\u0275conditionalCreate(24, EmpresaProfile_Conditional_2_Conditional_10_Conditional_24_Template, 1, 1, "img", 33)(25, EmpresaProfile_Conditional_2_Conditional_10_Conditional_25_Template, 2, 0, "span");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(26, "div", 34)(27, "input", 35);
    i0.\u0275\u0275listener("change", function EmpresaProfile_Conditional_2_Conditional_10_Template_input_change_27_listener($event) {
      i0.\u0275\u0275restoreView(_r5);
      const ctx_r1 = i0.\u0275\u0275nextContext(2);
      return i0.\u0275\u0275resetView(ctx_r1.onLogoSelected($event));
    });
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275conditionalCreate(28, EmpresaProfile_Conditional_2_Conditional_10_Conditional_28_Template, 2, 0, "small", 36);
    i0.\u0275\u0275elementEnd()()();
    i0.\u0275\u0275elementStart(29, "div", 30)(30, "label");
    i0.\u0275\u0275text(31, "Modalidad de Trabajo");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(32, "select", 37);
    i0.\u0275\u0275twoWayListener("ngModelChange", function EmpresaProfile_Conditional_2_Conditional_10_Template_select_ngModelChange_32_listener($event) {
      i0.\u0275\u0275restoreView(_r5);
      const ctx_r1 = i0.\u0275\u0275nextContext(2);
      i0.\u0275\u0275twoWayBindingSet(ctx_r1.perfilEditado.modalidad, $event) || (ctx_r1.perfilEditado.modalidad = $event);
      return i0.\u0275\u0275resetView($event);
    });
    i0.\u0275\u0275elementStart(33, "option", 38);
    i0.\u0275\u0275text(34, "Presencial");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(35, "option", 39);
    i0.\u0275\u0275text(36, "H\xEDbrido");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(37, "option", 40);
    i0.\u0275\u0275text(38, "Remoto");
    i0.\u0275\u0275elementEnd()()();
    i0.\u0275\u0275elementStart(39, "div", 30)(40, "label");
    i0.\u0275\u0275text(41, "Zona de Trabajo / Lugar Laboral");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(42, "input", 41);
    i0.\u0275\u0275twoWayListener("ngModelChange", function EmpresaProfile_Conditional_2_Conditional_10_Template_input_ngModelChange_42_listener($event) {
      i0.\u0275\u0275restoreView(_r5);
      const ctx_r1 = i0.\u0275\u0275nextContext(2);
      i0.\u0275\u0275twoWayBindingSet(ctx_r1.perfilEditado.zona_trabajo, $event) || (ctx_r1.perfilEditado.zona_trabajo = $event);
      return i0.\u0275\u0275resetView($event);
    });
    i0.\u0275\u0275elementEnd()()();
    i0.\u0275\u0275elementStart(43, "div", 29)(44, "h4");
    i0.\u0275\u0275text(45, "\u{1F310} Contacto y Enlaces");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(46, "div", 30)(47, "label");
    i0.\u0275\u0275text(48, "Sitio Web");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(49, "input", 42);
    i0.\u0275\u0275twoWayListener("ngModelChange", function EmpresaProfile_Conditional_2_Conditional_10_Template_input_ngModelChange_49_listener($event) {
      i0.\u0275\u0275restoreView(_r5);
      const ctx_r1 = i0.\u0275\u0275nextContext(2);
      i0.\u0275\u0275twoWayBindingSet(ctx_r1.perfilEditado.sitio_web, $event) || (ctx_r1.perfilEditado.sitio_web = $event);
      return i0.\u0275\u0275resetView($event);
    });
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(50, "div", 30)(51, "label");
    i0.\u0275\u0275text(52, "Perfil de LinkedIn");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(53, "input", 43);
    i0.\u0275\u0275twoWayListener("ngModelChange", function EmpresaProfile_Conditional_2_Conditional_10_Template_input_ngModelChange_53_listener($event) {
      i0.\u0275\u0275restoreView(_r5);
      const ctx_r1 = i0.\u0275\u0275nextContext(2);
      i0.\u0275\u0275twoWayBindingSet(ctx_r1.perfilEditado.linkedin, $event) || (ctx_r1.perfilEditado.linkedin = $event);
      return i0.\u0275\u0275resetView($event);
    });
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(54, "div", 30)(55, "label");
    i0.\u0275\u0275text(56, "Tel\xE9fono de Contacto");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(57, "input", 44);
    i0.\u0275\u0275twoWayListener("ngModelChange", function EmpresaProfile_Conditional_2_Conditional_10_Template_input_ngModelChange_57_listener($event) {
      i0.\u0275\u0275restoreView(_r5);
      const ctx_r1 = i0.\u0275\u0275nextContext(2);
      i0.\u0275\u0275twoWayBindingSet(ctx_r1.perfilEditado.telefono, $event) || (ctx_r1.perfilEditado.telefono = $event);
      return i0.\u0275\u0275resetView($event);
    });
    i0.\u0275\u0275elementEnd()()()();
    i0.\u0275\u0275elementStart(58, "div", 45)(59, "h4");
    i0.\u0275\u0275text(60, "\u{1F4C4} Informaci\xF3n Detallada");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(61, "div", 30)(62, "label");
    i0.\u0275\u0275text(63, "Descripci\xF3n General");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(64, "textarea", 46);
    i0.\u0275\u0275twoWayListener("ngModelChange", function EmpresaProfile_Conditional_2_Conditional_10_Template_textarea_ngModelChange_64_listener($event) {
      i0.\u0275\u0275restoreView(_r5);
      const ctx_r1 = i0.\u0275\u0275nextContext(2);
      i0.\u0275\u0275twoWayBindingSet(ctx_r1.perfilEditado.descripcion, $event) || (ctx_r1.perfilEditado.descripcion = $event);
      return i0.\u0275\u0275resetView($event);
    });
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(65, "div", 30)(66, "label");
    i0.\u0275\u0275text(67, "Stack Tecnol\xF3gico / Herramientas");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(68, "input", 47);
    i0.\u0275\u0275twoWayListener("ngModelChange", function EmpresaProfile_Conditional_2_Conditional_10_Template_input_ngModelChange_68_listener($event) {
      i0.\u0275\u0275restoreView(_r5);
      const ctx_r1 = i0.\u0275\u0275nextContext(2);
      i0.\u0275\u0275twoWayBindingSet(ctx_r1.perfilEditado.stack_tecnologico, $event) || (ctx_r1.perfilEditado.stack_tecnologico = $event);
      return i0.\u0275\u0275resetView($event);
    });
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(69, "div", 30)(70, "label");
    i0.\u0275\u0275text(71, "Trayectoria y Proyectos");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(72, "textarea", 48);
    i0.\u0275\u0275twoWayListener("ngModelChange", function EmpresaProfile_Conditional_2_Conditional_10_Template_textarea_ngModelChange_72_listener($event) {
      i0.\u0275\u0275restoreView(_r5);
      const ctx_r1 = i0.\u0275\u0275nextContext(2);
      i0.\u0275\u0275twoWayBindingSet(ctx_r1.perfilEditado.trayectoria, $event) || (ctx_r1.perfilEditado.trayectoria = $event);
      return i0.\u0275\u0275resetView($event);
    });
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(73, "div", 30)(74, "label");
    i0.\u0275\u0275text(75, "Beneficios para Estudiantes / Pasant\xEDas");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(76, "textarea", 49);
    i0.\u0275\u0275twoWayListener("ngModelChange", function EmpresaProfile_Conditional_2_Conditional_10_Template_textarea_ngModelChange_76_listener($event) {
      i0.\u0275\u0275restoreView(_r5);
      const ctx_r1 = i0.\u0275\u0275nextContext(2);
      i0.\u0275\u0275twoWayBindingSet(ctx_r1.perfilEditado.beneficios, $event) || (ctx_r1.perfilEditado.beneficios = $event);
      return i0.\u0275\u0275resetView($event);
    });
    i0.\u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext(2);
    i0.\u0275\u0275advance(8);
    i0.\u0275\u0275textInterpolate1(" ", ctx_r1.perfilEditado.razonSocial, " | ");
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate1(" ", ctx_r1.perfilEditado.email, " | ");
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate2(" ", ctx_r1.perfilEditado.ciudad_fiscal || "N/A", "", ctx_r1.perfilEditado.provincia_fiscal ? ", " + ctx_r1.perfilEditado.provincia_fiscal : "", " ");
    i0.\u0275\u0275advance(10);
    i0.\u0275\u0275conditional(ctx_r1.logoPreview ? 24 : 25);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275property("disabled", ctx_r1.subiendoLogo);
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(ctx_r1.subiendoLogo ? 28 : -1);
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275twoWayProperty("ngModel", ctx_r1.perfilEditado.modalidad);
    i0.\u0275\u0275advance(10);
    i0.\u0275\u0275twoWayProperty("ngModel", ctx_r1.perfilEditado.zona_trabajo);
    i0.\u0275\u0275advance(7);
    i0.\u0275\u0275twoWayProperty("ngModel", ctx_r1.perfilEditado.sitio_web);
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275twoWayProperty("ngModel", ctx_r1.perfilEditado.linkedin);
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275twoWayProperty("ngModel", ctx_r1.perfilEditado.telefono);
    i0.\u0275\u0275advance(7);
    i0.\u0275\u0275twoWayProperty("ngModel", ctx_r1.perfilEditado.descripcion);
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275twoWayProperty("ngModel", ctx_r1.perfilEditado.stack_tecnologico);
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275twoWayProperty("ngModel", ctx_r1.perfilEditado.trayectoria);
    i0.\u0275\u0275advance(4);
    i0.\u0275\u0275twoWayProperty("ngModel", ctx_r1.perfilEditado.beneficios);
  }
}
function EmpresaProfile_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 2)(1, "div", 3)(2, "h2");
    i0.\u0275\u0275text(3, "\u{1F3E2} Perfil de la Empresa");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(4, "p", 4);
    i0.\u0275\u0275text(5, "Informaci\xF3n p\xFAblica para postulantes de Sistemas e IA");
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(6, "div", 5);
    i0.\u0275\u0275conditionalCreate(7, EmpresaProfile_Conditional_2_Conditional_7_Template, 2, 0, "button", 6)(8, EmpresaProfile_Conditional_2_Conditional_8_Template, 2, 1);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275conditionalCreate(9, EmpresaProfile_Conditional_2_Conditional_9_Template, 43, 13)(10, EmpresaProfile_Conditional_2_Conditional_10_Template, 77, 16, "div", 7);
  }
  if (rf & 2) {
    const ctx_r1 = i0.\u0275\u0275nextContext();
    i0.\u0275\u0275advance(7);
    i0.\u0275\u0275conditional(ctx_r1.esVisitante ? 7 : 8);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275conditional(!ctx_r1.modoEdicion ? 9 : 10);
  }
}
var EmpresaProfile = class _EmpresaProfile {
  http = inject(HttpClient);
  authService = inject(AuthService);
  router = inject(Router);
  route = inject(ActivatedRoute);
  location = inject(Location);
  cdr = inject(ChangeDetectorRef);
  apiUrl = "http://localhost:3000/api";
  serverUrl = "http://localhost:3000";
  // 👈 Base para resolver rutas relativas de logos
  idEmpresaInput = null;
  esModoAdmin = false;
  cerrarModal = new EventEmitter();
  perfil = this.inicializarPerfil();
  perfilEditado = this.inicializarPerfil();
  esVisitante = false;
  // Indica si quien mira es Postulante/Admin
  modoEdicion = false;
  cargando = true;
  guardando = false;
  subiendoLogo = false;
  logoPreview = null;
  archivoLogoSeleccionado = null;
  ngOnInit() {
    this.obtenerDatosEmpresa();
  }
  ngOnChanges(changes) {
    if (changes["idEmpresaInput"] && !changes["idEmpresaInput"].isFirstChange()) {
      this.modoEdicion = false;
      this.obtenerDatosEmpresa();
    }
  }
  inicializarPerfil() {
    return {
      id_empresa: 0,
      razonSocial: "",
      fantasia: "",
      cuit: "",
      email: "",
      sector: "",
      ciudad_fiscal: "",
      provincia_fiscal: "",
      id_perfil: void 0,
      logo: "",
      descripcion: "",
      trayectoria: "",
      stack_tecnologico: "",
      beneficios: "",
      modalidad: "H\xEDbrido",
      zona_trabajo: "",
      sitio_web: "",
      linkedin: "",
      telefono: ""
    };
  }
  obtenerDatosEmpresa() {
    this.cargando = true;
    const idParam = this.route.snapshot.paramMap.get("id");
    let idEmpresa;
    if (this.idEmpresaInput) {
      this.esVisitante = true;
      idEmpresa = Number(this.idEmpresaInput);
    } else if (idParam) {
      this.esVisitante = true;
      idEmpresa = Number(idParam);
    } else {
      this.esVisitante = false;
      const user = this.authService.getUsuarioActual();
      if (!user || !user.id && !user.id_empresa) {
        console.error("No se encontr\xF3 informaci\xF3n de usuario en sesi\xF3n");
        this.cargando = false;
        this.router.navigate(["/sesion"]);
        return;
      }
      idEmpresa = user.id || user.id_empresa;
    }
    this.http.get(`${this.apiUrl}/empresa/perfil/${idEmpresa}`).subscribe({
      next: (res) => {
        if (res.success && res.perfil) {
          this.perfil = __spreadValues(__spreadValues({}, this.inicializarPerfil()), res.perfil);
          if (this.perfil.logo && !this.perfil.logo.startsWith("http")) {
            this.perfil.logo = `${this.serverUrl}${this.perfil.logo.startsWith("/") ? "" : "/"}${this.perfil.logo}`;
          }
          this.perfilEditado = structuredClone(this.perfil);
          this.modoEdicion = this.esVisitante ? false : !this.perfil.id_perfil;
        }
        this.cargando = false;
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error("Error al obtener perfil:", err);
        this.modoEdicion = !this.esVisitante;
        this.cargando = false;
        this.cdr.detectChanges();
      }
    });
  }
  volver() {
    if (this.idEmpresaInput) {
      this.cerrarModal.emit();
    } else {
      this.location.back();
    }
  }
  activarEdicion() {
    if (this.esVisitante)
      return;
    this.perfilEditado = structuredClone(this.perfil);
    this.logoPreview = this.perfil.logo || null;
    this.modoEdicion = true;
  }
  cancelarEdicion() {
    if (!this.perfil.id_perfil) {
      alert("Debes completar la informaci\xF3n b\xE1sica del perfil para continuar.");
      return;
    }
    this.modoEdicion = false;
    this.logoPreview = this.perfil.logo || null;
    this.archivoLogoSeleccionado = null;
    this.subiendoLogo = false;
  }
  guardarCambios() {
    if (this.esVisitante)
      return;
    if (this.subiendoLogo) {
      alert("Por favor aguarda a que finalice la carga de la imagen del logo.");
      return;
    }
    this.guardando = true;
    const user = this.authService.getUsuarioActual();
    const idEmpresa = user?.id || user?.id_empresa;
    if (!idEmpresa) {
      this.guardando = false;
      return;
    }
    const payload = {
      id_empresa: idEmpresa,
      logo: this.perfilEditado.logo,
      descripcion: this.perfilEditado.descripcion,
      trayectoria: this.perfilEditado.trayectoria,
      stack_tecnologico: this.perfilEditado.stack_tecnologico,
      beneficios: this.perfilEditado.beneficios,
      modalidad: this.perfilEditado.modalidad,
      zona_trabajo: this.perfilEditado.zona_trabajo,
      sitio_web: this.perfilEditado.sitio_web,
      linkedin: this.perfilEditado.linkedin,
      telefono: this.perfilEditado.telefono
    };
    this.http.put(`${this.apiUrl}/empresa/perfil`, payload).subscribe({
      next: (res) => {
        if (res.success) {
          this.perfil = structuredClone(this.perfilEditado);
          if (res.id_perfil) {
            this.perfil.id_perfil = res.id_perfil;
          }
          this.modoEdicion = false;
          alert("Perfil guardado con \xE9xito.");
        }
        this.guardando = false;
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error("Error al guardar perfil:", err);
        alert("Ocurri\xF3 un error al intentar guardar los cambios.");
        this.guardando = false;
        this.cdr.detectChanges();
      }
    });
  }
  onLogoSelected(event) {
    if (this.esVisitante)
      return;
    const input = event.target;
    if (input.files && input.files[0]) {
      const file = input.files[0];
      if (!["image/jpeg", "image/jpg", "image/png"].includes(file.type)) {
        alert("Solo se admiten im\xE1genes en formato JPG o PNG.");
        input.value = "";
        return;
      }
      this.archivoLogoSeleccionado = file;
      const reader = new FileReader();
      reader.onload = () => {
        this.logoPreview = reader.result;
        this.cdr.detectChanges();
      };
      reader.readAsDataURL(file);
      this.subirLogoServidor(file);
    }
  }
  subirLogoServidor(file) {
    if (this.esVisitante)
      return;
    this.subiendoLogo = true;
    const formData = new FormData();
    formData.append("logo", file);
    this.http.post(`${this.apiUrl}/empresa/perfil/logo`, formData).subscribe({
      next: (res) => {
        if (res.success && res.logoUrl) {
          let url = res.logoUrl;
          if (!url.startsWith("http")) {
            url = `${this.serverUrl}${url.startsWith("/") ? "" : "/"}${url}`;
          }
          this.perfilEditado.logo = url;
        }
        this.subiendoLogo = false;
        this.cdr.detectChanges();
      },
      error: (err) => {
        console.error("Error al subir logo:", err);
        alert("No se pudo subir la imagen del logo al servidor.");
        this.subiendoLogo = false;
        this.cdr.detectChanges();
      }
    });
  }
  // 🛠️ Helpers útiles para usar en la plantilla HTML:
  /**
   * Convierte "Angular, Node.js, TypeScript" en un arreglo ["Angular", "Node.js", "TypeScript"]
   * Útil para renderizar badges en el HTML mediante *ngFor
   */
  get stackList() {
    if (!this.perfil.stack_tecnologico)
      return [];
    return this.perfil.stack_tecnologico.split(",").map((item) => item.trim()).filter((item) => item.length > 0);
  }
  /**
   * Garantiza que los enlaces externos (web, linkedin) tengan el protocolo https://
   * evita que el navegador intente abrir la URL como una ruta interna de Angular.
   */
  obtenerUrlValida(url) {
    if (!url)
      return "";
    if (url.startsWith("http://") || url.startsWith("https://")) {
      return url;
    }
    return `https://${url}`;
  }
  static \u0275fac = function EmpresaProfile_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _EmpresaProfile)();
  };
  static \u0275cmp = /* @__PURE__ */ i0.\u0275\u0275defineComponent({ type: _EmpresaProfile, selectors: [["app-empresa-profile"]], inputs: { idEmpresaInput: "idEmpresaInput", esModoAdmin: "esModoAdmin" }, outputs: { cerrarModal: "cerrarModal" }, features: [i0.\u0275\u0275NgOnChangesFeature], decls: 3, vars: 1, consts: [[1, "perfil-container"], [1, "loading"], [1, "perfil-header"], [1, "header-info"], [1, "subtitulo"], [1, "acciones-header"], [1, "btn-secundario"], [1, "tarjeta-perfil", "edicion"], [1, "btn-secundario", 3, "click"], [1, "btn-primario"], [1, "btn-primario", 3, "click"], [1, "btn-secundario", 3, "click", "disabled"], [1, "btn-guardar", 3, "click", "disabled"], [1, "card-hero"], [1, "hero-main"], [1, "logo-box"], [3, "src", "alt"], [1, "logo-placeholder"], [1, "hero-info"], [1, "rubro-tag"], [1, "pills-row"], [1, "pill", "modal-badge"], [1, "pill"], ["target", "_blank", 1, "pill", 3, "href"], [1, "content-grid"], [1, "columna"], [1, "card"], [1, "datos-fijos-banner"], [1, "form-grid-edicion"], [1, "card", "card-form"], [1, "form-group"], [1, "upload-logo-container"], [1, "logo-preview"], ["alt", "Vista previa del logo", 3, "src"], [1, "upload-controls"], ["type", "file", "accept", "image/png, image/jpeg, image/jpg", 3, "change", "disabled"], [1, "upload-status"], [3, "ngModelChange", "ngModel"], ["value", "Presencial"], ["value", "H\xEDbrido"], ["value", "Remoto"], ["type", "text", "placeholder", "Ej: Lan\xFAs / Presencial en Sede Central", 3, "ngModelChange", "ngModel"], ["type", "url", "placeholder", "https://empresa.com", 3, "ngModelChange", "ngModel"], ["type", "url", "placeholder", "https://linkedin.com/company/...", 3, "ngModelChange", "ngModel"], ["type", "text", "placeholder", "Ej: 11 1234-5678", 3, "ngModelChange", "ngModel"], [1, "card", "card-form", "full-width", 2, "margin-top", "1.5rem"], ["rows", "3", "placeholder", "Cuenta brevemente a qu\xE9 se dedica la empresa...", 3, "ngModelChange", "ngModel"], ["type", "text", "placeholder", "Ej: Angular, Node.js, Python, PostgreSQL, PyTorch, Docker", 3, "ngModelChange", "ngModel"], ["rows", "3", "placeholder", "A\xF1os en el mercado, proyectos destacados...", 3, "ngModelChange", "ngModel"], ["rows", "3", "placeholder", "D\xEDas por examen, mentoreo t\xE9cnico, flexibilidad horaria...", 3, "ngModelChange", "ngModel"]], template: function EmpresaProfile_Template(rf, ctx) {
    if (rf & 1) {
      i0.\u0275\u0275elementStart(0, "div", 0);
      i0.\u0275\u0275conditionalCreate(1, EmpresaProfile_Conditional_1_Template, 2, 0, "div", 1)(2, EmpresaProfile_Conditional_2_Template, 11, 2);
      i0.\u0275\u0275elementEnd();
    }
    if (rf & 2) {
      i0.\u0275\u0275advance();
      i0.\u0275\u0275conditional(ctx.cargando ? 1 : 2);
    }
  }, dependencies: [CommonModule, i1.NgClass, i1.NgComponentOutlet, i1.NgForOf, i1.NgIf, i1.NgTemplateOutlet, i1.NgStyle, i1.NgSwitch, i1.NgSwitchCase, i1.NgSwitchDefault, i1.NgPlural, i1.NgPluralCase, FormsModule, i2.\u0275NgNoValidate, i2.NgSelectOption, i2.\u0275NgSelectMultipleOption, i2.DefaultValueAccessor, i2.NumberValueAccessor, i2.RangeValueAccessor, i2.CheckboxControlValueAccessor, i2.SelectControlValueAccessor, i2.SelectMultipleControlValueAccessor, i2.RadioControlValueAccessor, i2.NgControlStatus, i2.NgControlStatusGroup, i2.RequiredValidator, i2.MinLengthValidator, i2.MaxLengthValidator, i2.PatternValidator, i2.CheckboxRequiredValidator, i2.EmailValidator, i2.MinValidator, i2.MaxValidator, i2.NgModel, i2.NgModelGroup, i2.NgForm, i1.AsyncPipe, i1.UpperCasePipe, i1.LowerCasePipe, i1.JsonPipe, i1.SlicePipe, i1.DecimalPipe, i1.PercentPipe, i1.TitleCasePipe, i1.CurrencyPipe, i1.DatePipe, i1.I18nPluralPipe, i1.I18nSelectPipe, i1.KeyValuePipe], styles: ["\n.perfil-container[_ngcontent-%COMP%] {\n  max-width: 1180px;\n  margin: 2rem auto;\n  padding: 0 1rem;\n}\n.perfil-container[_ngcontent-%COMP%]   .loading[_ngcontent-%COMP%] {\n  text-align: center;\n  padding: 3rem;\n  font-size: 1.2rem;\n  color: #321f57;\n}\n.perfil-header[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-bottom: 2rem;\n  flex-wrap: wrap;\n  gap: 1rem;\n}\n.perfil-header[_ngcontent-%COMP%]   .header-info[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  color: #321f57;\n  margin: 0 0 0.25rem 0;\n  font-size: 1.8rem;\n}\n.perfil-header[_ngcontent-%COMP%]   .header-info[_ngcontent-%COMP%]   .subtitulo[_ngcontent-%COMP%] {\n  color: gray;\n  margin: 0;\n  font-size: 0.95rem;\n}\n.perfil-header[_ngcontent-%COMP%]   .acciones-header[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 0.8rem;\n}\n.perfil-header[_ngcontent-%COMP%]   .acciones-header[_ngcontent-%COMP%]   button[_ngcontent-%COMP%] {\n  padding: 0.65rem 1.3rem;\n  border-radius: 12px;\n  font-weight: 600;\n  cursor: pointer;\n  border: none;\n  transition: all 0.2s ease;\n  display: inline-flex;\n  align-items: center;\n  gap: 0.4rem;\n}\n.perfil-header[_ngcontent-%COMP%]   .acciones-header[_ngcontent-%COMP%]   button.btn-primario[_ngcontent-%COMP%] {\n  background-color: #5b44c2;\n  color: #ffffff;\n}\n.perfil-header[_ngcontent-%COMP%]   .acciones-header[_ngcontent-%COMP%]   button.btn-primario[_ngcontent-%COMP%]:hover {\n  background-color: color-mix(in srgb, #5b44c2 85%, black);\n}\n.perfil-header[_ngcontent-%COMP%]   .acciones-header[_ngcontent-%COMP%]   button.btn-secundario[_ngcontent-%COMP%] {\n  background-color: transparent;\n  border: 1px solid #d2c2ff;\n  color: #321f57;\n}\n.perfil-header[_ngcontent-%COMP%]   .acciones-header[_ngcontent-%COMP%]   button.btn-secundario[_ngcontent-%COMP%]:hover:not(:disabled) {\n  background-color: #efe8ff;\n}\n.perfil-header[_ngcontent-%COMP%]   .acciones-header[_ngcontent-%COMP%]   button.btn-guardar[_ngcontent-%COMP%] {\n  background-color: #2e7d32;\n  color: #ffffff;\n}\n.perfil-header[_ngcontent-%COMP%]   .acciones-header[_ngcontent-%COMP%]   button.btn-guardar[_ngcontent-%COMP%]:hover:not(:disabled) {\n  background-color: #1b5e20;\n}\n.perfil-header[_ngcontent-%COMP%]   .acciones-header[_ngcontent-%COMP%]   button.btn-guardar[_ngcontent-%COMP%]:disabled {\n  background-color: #4caf50;\n  opacity: 0.85;\n  cursor: wait;\n}\n.perfil-header[_ngcontent-%COMP%]   .acciones-header[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:disabled {\n  opacity: 0.65;\n  cursor: not-allowed;\n}\n.card-hero[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border: 1px solid #d2c2ff;\n  border-radius: 24px;\n  padding: 1.8rem 2rem;\n  box-shadow: 0 10px 25px rgba(103, 87, 176, 0.05);\n  margin-bottom: 1.5rem;\n}\n.card-hero[_ngcontent-%COMP%]   .hero-main[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 1.8rem;\n}\n.card-hero[_ngcontent-%COMP%]   .hero-main[_ngcontent-%COMP%]   .logo-box[_ngcontent-%COMP%] {\n  width: 95px;\n  height: 95px;\n  border-radius: 20px;\n  overflow: hidden;\n  border: 2px solid #d2c2ff;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  background: #ffffff;\n  flex-shrink: 0;\n}\n.card-hero[_ngcontent-%COMP%]   .hero-main[_ngcontent-%COMP%]   .logo-box[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  object-fit: contain;\n  display: block;\n}\n.card-hero[_ngcontent-%COMP%]   .hero-main[_ngcontent-%COMP%]   .logo-box[_ngcontent-%COMP%]   .logo-placeholder[_ngcontent-%COMP%] {\n  font-size: 2.8rem;\n}\n.card-hero[_ngcontent-%COMP%]   .hero-main[_ngcontent-%COMP%]   .hero-info[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  margin: 0 0 0.3rem 0;\n  color: #321f57;\n  font-size: 1.6rem;\n}\n.card-hero[_ngcontent-%COMP%]   .hero-main[_ngcontent-%COMP%]   .hero-info[_ngcontent-%COMP%]   .rubro-tag[_ngcontent-%COMP%] {\n  display: inline-block;\n  background-color: #e9e1ff;\n  color: #5b44c2;\n  padding: 0.25rem 0.8rem;\n  border-radius: 12px;\n  font-size: 0.85rem;\n  font-weight: 600;\n  margin-bottom: 0.6rem;\n}\n.card-hero[_ngcontent-%COMP%]   .hero-main[_ngcontent-%COMP%]   .hero-info[_ngcontent-%COMP%]   .pills-row[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 0.5rem;\n  margin-top: 0.4rem;\n}\n.card-hero[_ngcontent-%COMP%]   .hero-main[_ngcontent-%COMP%]   .hero-info[_ngcontent-%COMP%]   .pills-row[_ngcontent-%COMP%]   .pill[_ngcontent-%COMP%] {\n  background-color: #efe8ff;\n  border: 1px solid #d2c2ff;\n  color: #321f57;\n  padding: 0.3rem 0.75rem;\n  border-radius: 20px;\n  font-size: 0.85rem;\n  text-decoration: none;\n  display: inline-flex;\n  align-items: center;\n  gap: 0.3rem;\n}\n.card-hero[_ngcontent-%COMP%]   .hero-main[_ngcontent-%COMP%]   .hero-info[_ngcontent-%COMP%]   .pills-row[_ngcontent-%COMP%]   .pill.modal-badge[_ngcontent-%COMP%] {\n  background-color: #dcfce7;\n  color: #15803d;\n  border-color: #bbf7d0;\n  font-weight: 600;\n}\n.card-hero[_ngcontent-%COMP%]   .hero-main[_ngcontent-%COMP%]   .hero-info[_ngcontent-%COMP%]   .pills-row[_ngcontent-%COMP%]   a.pill[_ngcontent-%COMP%]:hover {\n  background-color: #e9e1ff;\n  color: #5b44c2;\n  border-color: #5b44c2;\n}\n.content-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(2, 1fr);\n  gap: 1.5rem;\n}\n.content-grid[_ngcontent-%COMP%]   .columna[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 1.5rem;\n}\n.content-grid[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border: 1px solid #d2c2ff;\n  border-radius: 20px;\n  padding: 1.5rem;\n  box-shadow: 0 10px 25px rgba(103, 87, 176, 0.05);\n}\n.content-grid[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  color: #321f57;\n  margin: 0 0 0.8rem 0;\n  font-size: 1.15rem;\n  display: flex;\n  align-items: center;\n  gap: 0.5rem;\n}\n.content-grid[_ngcontent-%COMP%]   .card[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  color: #321f57;\n  line-height: 1.6;\n  margin: 0;\n  white-space: pre-line;\n  font-size: 0.95rem;\n}\n.tarjeta-perfil.edicion[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border: 1px solid #d2c2ff;\n  border-radius: 24px;\n  padding: 2rem;\n  box-shadow: 0 10px 25px rgba(103, 87, 176, 0.05);\n}\n.tarjeta-perfil.edicion[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  margin-top: 0;\n  margin-bottom: 1.2rem;\n  color: #321f57;\n  font-size: 1.4rem;\n}\n.tarjeta-perfil.edicion[_ngcontent-%COMP%]   .datos-fijos-banner[_ngcontent-%COMP%] {\n  background-color: #e9e1ff;\n  border-left: 4px solid #5b44c2;\n  padding: 0.8rem 1.2rem;\n  border-radius: 12px;\n  margin-bottom: 1.5rem;\n  color: #321f57;\n}\n.tarjeta-perfil.edicion[_ngcontent-%COMP%]   .form-grid-edicion[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(2, 1fr);\n  gap: 1.5rem;\n}\n.tarjeta-perfil.edicion[_ngcontent-%COMP%]   .card-form[_ngcontent-%COMP%] {\n  background: #efe8ff;\n  border: 1px solid #d2c2ff;\n  border-radius: 16px;\n  padding: 1.25rem;\n}\n.tarjeta-perfil.edicion[_ngcontent-%COMP%]   .card-form[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  margin-top: 0;\n  margin-bottom: 1rem;\n  color: #321f57;\n  font-size: 1.05rem;\n}\n.tarjeta-perfil.edicion[_ngcontent-%COMP%]   .card-form.full-width[_ngcontent-%COMP%] {\n  grid-column: span 2;\n}\n.tarjeta-perfil.edicion[_ngcontent-%COMP%]   .upload-logo-container[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 1.2rem;\n}\n.tarjeta-perfil.edicion[_ngcontent-%COMP%]   .upload-logo-container[_ngcontent-%COMP%]   .logo-preview[_ngcontent-%COMP%] {\n  width: 85px;\n  height: 85px;\n  border-radius: 14px;\n  border: 2px dashed #d2c2ff;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  overflow: hidden;\n  background: #ffffff;\n  flex-shrink: 0;\n}\n.tarjeta-perfil.edicion[_ngcontent-%COMP%]   .upload-logo-container[_ngcontent-%COMP%]   .logo-preview[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  object-fit: contain;\n  display: block;\n}\n.tarjeta-perfil.edicion[_ngcontent-%COMP%]   .upload-logo-container[_ngcontent-%COMP%]   .logo-preview[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-size: 0.75rem;\n  color: gray;\n  text-align: center;\n}\n.tarjeta-perfil.edicion[_ngcontent-%COMP%]   .upload-logo-container[_ngcontent-%COMP%]   .upload-controls[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 0.4rem;\n}\n.tarjeta-perfil.edicion[_ngcontent-%COMP%]   .upload-logo-container[_ngcontent-%COMP%]   .upload-controls[_ngcontent-%COMP%]   input[type=file][_ngcontent-%COMP%] {\n  font-size: 0.85rem;\n  color: #321f57;\n}\n.tarjeta-perfil.edicion[_ngcontent-%COMP%]   .upload-logo-container[_ngcontent-%COMP%]   .upload-controls[_ngcontent-%COMP%]   input[type=file][_ngcontent-%COMP%]:disabled {\n  cursor: not-allowed;\n  opacity: 0.6;\n}\n.tarjeta-perfil.edicion[_ngcontent-%COMP%]   .upload-logo-container[_ngcontent-%COMP%]   .upload-controls[_ngcontent-%COMP%]   .upload-status[_ngcontent-%COMP%] {\n  color: #5b44c2;\n  font-weight: 600;\n  font-size: 0.82rem;\n  animation: _ngcontent-%COMP%_pulseStatus 1.5s infinite;\n}\n.tarjeta-perfil.edicion[_ngcontent-%COMP%]   .form-row-2[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(2, 1fr);\n  gap: 1rem;\n}\n.tarjeta-perfil.edicion[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 0.4rem;\n  margin-bottom: 1rem;\n}\n.tarjeta-perfil.edicion[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]:last-child {\n  margin-bottom: 0;\n}\n.tarjeta-perfil.edicion[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  font-weight: 600;\n  font-size: 0.88rem;\n  color: #321f57;\n}\n.tarjeta-perfil.edicion[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   label[_ngcontent-%COMP%]   code[_ngcontent-%COMP%] {\n  background-color: #ffffff;\n  padding: 0.1rem 0.4rem;\n  border-radius: 4px;\n  color: #5b44c2;\n}\n.tarjeta-perfil.edicion[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   input[type=text][_ngcontent-%COMP%], \n.tarjeta-perfil.edicion[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   input[type=email][_ngcontent-%COMP%], \n.tarjeta-perfil.edicion[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   input[type=url][_ngcontent-%COMP%], \n.tarjeta-perfil.edicion[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   textarea[_ngcontent-%COMP%], \n.tarjeta-perfil.edicion[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   select[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 0.65rem 0.9rem;\n  border: 1px solid #d2c2ff;\n  border-radius: 10px;\n  background-color: #ffffff;\n  color: #321f57;\n  font-family: inherit;\n  font-size: 0.92rem;\n  box-sizing: border-box;\n}\n.tarjeta-perfil.edicion[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   input[type=text][_ngcontent-%COMP%]:focus, \n.tarjeta-perfil.edicion[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   input[type=email][_ngcontent-%COMP%]:focus, \n.tarjeta-perfil.edicion[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   input[type=url][_ngcontent-%COMP%]:focus, \n.tarjeta-perfil.edicion[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   textarea[_ngcontent-%COMP%]:focus, \n.tarjeta-perfil.edicion[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   select[_ngcontent-%COMP%]:focus {\n  outline: none;\n  border-color: #5b44c2;\n  box-shadow: 0 0 0 3px #e9e1ff;\n}\n.tarjeta-perfil.edicion[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   textarea[_ngcontent-%COMP%] {\n  resize: vertical;\n}\n@keyframes _ngcontent-%COMP%_pulseStatus {\n  0% {\n    opacity: 0.5;\n  }\n  50% {\n    opacity: 1;\n  }\n  100% {\n    opacity: 0.5;\n  }\n}\n@media (max-width: 820px) {\n  .perfil-header[_ngcontent-%COMP%] {\n    flex-direction: column;\n    align-items: flex-start;\n  }\n  .perfil-header[_ngcontent-%COMP%]   .acciones-header[_ngcontent-%COMP%] {\n    width: 100%;\n  }\n  .perfil-header[_ngcontent-%COMP%]   .acciones-header[_ngcontent-%COMP%]   button[_ngcontent-%COMP%] {\n    flex: 1;\n    justify-content: center;\n  }\n  .card-hero[_ngcontent-%COMP%]   .hero-main[_ngcontent-%COMP%] {\n    flex-direction: column;\n    text-align: center;\n  }\n  .card-hero[_ngcontent-%COMP%]   .hero-main[_ngcontent-%COMP%]   .pills-row[_ngcontent-%COMP%] {\n    justify-content: center;\n  }\n  .content-grid[_ngcontent-%COMP%] {\n    grid-template-columns: 1fr;\n  }\n  .tarjeta-perfil.edicion[_ngcontent-%COMP%] {\n    padding: 1.25rem;\n  }\n  .tarjeta-perfil.edicion[_ngcontent-%COMP%]   .form-grid-edicion[_ngcontent-%COMP%] {\n    grid-template-columns: 1fr;\n  }\n  .tarjeta-perfil.edicion[_ngcontent-%COMP%]   .card-form.full-width[_ngcontent-%COMP%] {\n    grid-column: span 1;\n  }\n  .tarjeta-perfil.edicion[_ngcontent-%COMP%]   .form-row-2[_ngcontent-%COMP%] {\n    grid-template-columns: 1fr;\n  }\n}\n/*# sourceMappingURL=empresa-profile.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassMetadata(EmpresaProfile, [{
    type: Component,
    args: [{ selector: "app-empresa-profile", standalone: true, imports: [CommonModule, FormsModule], template: `<div class="perfil-container">\r
\r
  @if (cargando) {\r
    <div class="loading">\u231B Cargando datos...</div>\r
  } @else {\r
\r
    <!-- HEADER DE ACCIONES GLOBAL -->\r
    <div class="perfil-header">\r
      <div class="header-info">\r
        <h2>\u{1F3E2} Perfil de la Empresa</h2>\r
        <p class="subtitulo">Informaci\xF3n p\xFAblica para postulantes de Sistemas e IA</p>\r
      </div>\r
\r
      <div class="acciones-header">\r
      @if (esVisitante) {\r
      <!-- \u{1F441}\uFE0F Si es visitante (Postulante o Admin), solo ve la opci\xF3n de regresar -->\r
        <button class="btn-secundario" (click)="volver()">\u2190 Volver</button>\r
      } @else {\r
    <!-- \u270F\uFE0F Si es la propia empresa, mantiene sus botones normales -->\r
      @if (!modoEdicion) {\r
      <button class="btn-primario" (click)="activarEdicion()">\u270F\uFE0F Editar Perfil</button>\r
      } @else {\r
        <button class="btn-secundario" (click)="cancelarEdicion()" [disabled]="guardando || subiendoLogo">\u2715 Cancelar</button>\r
        <button class="btn-guardar" (click)="guardarCambios()" [disabled]="guardando || subiendoLogo">\r
        {{ guardando ? '\u23F3 Guardando...' : (subiendoLogo ? '\u{1F4E4} Subiendo logo...' : '\u{1F4BE} Guardar Perfil') }}\r
      </button>\r
      }\r
    }\r
    </div>\r
  </div>\r
\r
    <!-- ========================================== -->\r
    <!-- 1. VISTA DE LECTURA (Header Hero + Cards) -->\r
    <!-- ========================================== -->\r
    @if (!modoEdicion) {\r
      \r
      <!-- HERO BANNER SUPERIOR -->\r
      <header class="card-hero">\r
        <div class="hero-main">\r
          <div class="logo-box">\r
            @if (perfil.logo) {\r
              <img [src]="perfil.logo" alt="Logo {{ perfil.fantasia || perfil.razonSocial }}">\r
            } @else {\r
              <div class="logo-placeholder">\u{1F3E2}</div>\r
            }\r
          </div>\r
          \r
          <div class="hero-info">\r
            <h3>{{ perfil.fantasia || perfil.razonSocial }}</h3>\r
            <span class="rubro-tag">{{ perfil.sector || 'Sector no especificado' }}</span>\r
\r
            <div class="pills-row">\r
              <span class="pill modal-badge">\u{1F4BB} {{ perfil.modalidad || 'H\xEDbrido' }}</span>\r
              <span class="pill">\u{1F4CD} {{ perfil.zona_trabajo || 'Ubicaci\xF3n no especificada' }}</span>\r
              @if (perfil.sitio_web) { <a [href]="perfil.sitio_web" target="_blank" class="pill">\u{1F310} Web</a> }\r
              @if (perfil.linkedin) { <a [href]="perfil.linkedin" target="_blank" class="pill">\u{1F4BC} LinkedIn</a> }\r
              @if (perfil.telefono) { <span class="pill">\u{1F4DE} {{ perfil.telefono }}</span> }\r
              <span class="pill">\u{1F4E7} {{ perfil.email }}</span>\r
            </div>\r
          </div>\r
        </div>\r
      </header>\r
\r
      <!-- GRID DE CARDS INFERIOR -->\r
      <div class="content-grid">\r
        <section class="columna">\r
          <article class="card">\r
            <h4>\u{1F4C4} Descripci\xF3n General</h4>\r
            <p>{{ perfil.descripcion || 'Sin descripci\xF3n cargada.' }}</p>\r
          </article>\r
\r
          <article class="card">\r
            <h4>\u{1F4BB} Stack Tecnol\xF3gico y Herramientas</h4>\r
            <p>{{ perfil.stack_tecnologico || 'Sin tecnolog\xEDas especificadas.' }}</p>\r
          </article>\r
        </section>\r
\r
        <section class="columna">\r
          <article class="card">\r
            <h4>\u{1F3C6} Trayectoria y Proyectos Destacados</h4>\r
            <p>{{ perfil.trayectoria || 'Sin informaci\xF3n de trayectoria cargada.' }}</p>\r
          </article>\r
\r
          <article class="card">\r
            <h4>\u{1F381} Beneficios para Estudiantes</h4>\r
            <p>{{ perfil.beneficios || 'Sin detalles de beneficios.' }}</p>\r
          </article>\r
        </section>\r
      </div>\r
\r
    }\r
\r
    <!-- ========================================== -->\r
    <!-- 2. VISTA DE EDICI\xD3N COMPLETA               -->\r
    <!-- ========================================== -->\r
    @else {\r
      <div class="tarjeta-perfil edicion">\r
        <h3>\u270F\uFE0F Actualizar Perfil Institucional</h3>\r
\r
        <!-- Datos fijos del usuario -->\r
        <div class="datos-fijos-banner">\r
          <small>\r
            \u2139\uFE0F <strong>Raz\xF3n Social:</strong> {{ perfilEditado.razonSocial }} | \r
            <strong>Email:</strong> {{ perfilEditado.email }} | \r
            <strong>Ubicaci\xF3n Fiscal:</strong> {{ perfilEditado.ciudad_fiscal || 'N/A' }}{{ perfilEditado.provincia_fiscal ? ', ' + perfilEditado.provincia_fiscal : '' }}\r
          </small>\r
        </div>\r
\r
        <div class="form-grid-edicion">\r
          \r
          <!-- SECCI\xD3N 1: LOGO Y DATOS R\xC1PIDOS -->\r
          <div class="card card-form">\r
            <h4>\u{1F5BC}\uFE0F Logo e Identidad</h4>\r
            \r
            <div class="form-group">\r
              <label>Logo de la Empresa</label>\r
              <div class="upload-logo-container">\r
                <div class="logo-preview">\r
                  @if (logoPreview) {\r
                    <img [src]="logoPreview" alt="Vista previa del logo">\r
                  } @else {\r
                    <span>Sin logo</span>\r
                  }\r
                </div>\r
                <div class="upload-controls">\r
                  <input type="file" accept="image/png, image/jpeg, image/jpg" (change)="onLogoSelected($event)" [disabled]="subiendoLogo">\r
                  @if (subiendoLogo) {\r
                    <small class="upload-status">\u23F3 Subiendo imagen...</small>\r
                  }\r
                </div>\r
              </div>\r
            </div> <!-- Div de form-group cerrado correctamente -->\r
\r
            <div class="form-group">\r
              <label>Modalidad de Trabajo</label>\r
              <select [(ngModel)]="perfilEditado.modalidad">\r
                <option value="Presencial">Presencial</option>\r
                <option value="H\xEDbrido">H\xEDbrido</option>\r
                <option value="Remoto">Remoto</option>\r
              </select>\r
            </div>\r
\r
            <div class="form-group">\r
              <label>Zona de Trabajo / Lugar Laboral</label>\r
              <input type="text" [(ngModel)]="perfilEditado.zona_trabajo" placeholder="Ej: Lan\xFAs / Presencial en Sede Central">\r
            </div>\r
          </div>\r
\r
          <!-- SECCI\xD3N 2: CONTACTO Y REDES -->\r
          <div class="card card-form">\r
            <h4>\u{1F310} Contacto y Enlaces</h4>\r
            \r
            <div class="form-group">\r
              <label>Sitio Web</label>\r
              <input type="url" [(ngModel)]="perfilEditado.sitio_web" placeholder="https://empresa.com">\r
            </div>\r
\r
            <div class="form-group">\r
              <label>Perfil de LinkedIn</label>\r
              <input type="url" [(ngModel)]="perfilEditado.linkedin" placeholder="https://linkedin.com/company/...">\r
            </div>\r
\r
            <div class="form-group">\r
              <label>Tel\xE9fono de Contacto</label>\r
              <input type="text" [(ngModel)]="perfilEditado.telefono" placeholder="Ej: 11 1234-5678">\r
            </div>\r
          </div>\r
\r
        </div>\r
\r
        <!-- SECCI\xD3N 3: TEXTOS DETALLADOS -->\r
        <div class="card card-form full-width" style="margin-top: 1.5rem;">\r
          <h4>\u{1F4C4} Informaci\xF3n Detallada</h4>\r
\r
          <div class="form-group">\r
            <label>Descripci\xF3n General</label>\r
            <textarea rows="3" [(ngModel)]="perfilEditado.descripcion" placeholder="Cuenta brevemente a qu\xE9 se dedica la empresa..."></textarea>\r
          </div>\r
\r
          <div class="form-group">\r
            <label>Stack Tecnol\xF3gico / Herramientas</label>\r
            <input type="text" [(ngModel)]="perfilEditado.stack_tecnologico" placeholder="Ej: Angular, Node.js, Python, PostgreSQL, PyTorch, Docker">\r
          </div>\r
\r
          <div class="form-group">\r
            <label>Trayectoria y Proyectos</label>\r
            <textarea rows="3" [(ngModel)]="perfilEditado.trayectoria" placeholder="A\xF1os en el mercado, proyectos destacados..."></textarea>\r
          </div>\r
\r
          <div class="form-group">\r
            <label>Beneficios para Estudiantes / Pasant\xEDas</label>\r
            <textarea rows="3" [(ngModel)]="perfilEditado.beneficios" placeholder="D\xEDas por examen, mentoreo t\xE9cnico, flexibilidad horaria..."></textarea>\r
          </div>\r
        </div>\r
\r
      </div>\r
    }\r
\r
  }\r
</div>`, styles: ["/* src/app/pagina/perfiles/empresa-profile/empresa-profile.scss */\n.perfil-container {\n  max-width: 1180px;\n  margin: 2rem auto;\n  padding: 0 1rem;\n}\n.perfil-container .loading {\n  text-align: center;\n  padding: 3rem;\n  font-size: 1.2rem;\n  color: #321f57;\n}\n.perfil-header {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-bottom: 2rem;\n  flex-wrap: wrap;\n  gap: 1rem;\n}\n.perfil-header .header-info h2 {\n  color: #321f57;\n  margin: 0 0 0.25rem 0;\n  font-size: 1.8rem;\n}\n.perfil-header .header-info .subtitulo {\n  color: gray;\n  margin: 0;\n  font-size: 0.95rem;\n}\n.perfil-header .acciones-header {\n  display: flex;\n  gap: 0.8rem;\n}\n.perfil-header .acciones-header button {\n  padding: 0.65rem 1.3rem;\n  border-radius: 12px;\n  font-weight: 600;\n  cursor: pointer;\n  border: none;\n  transition: all 0.2s ease;\n  display: inline-flex;\n  align-items: center;\n  gap: 0.4rem;\n}\n.perfil-header .acciones-header button.btn-primario {\n  background-color: #5b44c2;\n  color: #ffffff;\n}\n.perfil-header .acciones-header button.btn-primario:hover {\n  background-color: color-mix(in srgb, #5b44c2 85%, black);\n}\n.perfil-header .acciones-header button.btn-secundario {\n  background-color: transparent;\n  border: 1px solid #d2c2ff;\n  color: #321f57;\n}\n.perfil-header .acciones-header button.btn-secundario:hover:not(:disabled) {\n  background-color: #efe8ff;\n}\n.perfil-header .acciones-header button.btn-guardar {\n  background-color: #2e7d32;\n  color: #ffffff;\n}\n.perfil-header .acciones-header button.btn-guardar:hover:not(:disabled) {\n  background-color: #1b5e20;\n}\n.perfil-header .acciones-header button.btn-guardar:disabled {\n  background-color: #4caf50;\n  opacity: 0.85;\n  cursor: wait;\n}\n.perfil-header .acciones-header button:disabled {\n  opacity: 0.65;\n  cursor: not-allowed;\n}\n.card-hero {\n  background: #ffffff;\n  border: 1px solid #d2c2ff;\n  border-radius: 24px;\n  padding: 1.8rem 2rem;\n  box-shadow: 0 10px 25px rgba(103, 87, 176, 0.05);\n  margin-bottom: 1.5rem;\n}\n.card-hero .hero-main {\n  display: flex;\n  align-items: center;\n  gap: 1.8rem;\n}\n.card-hero .hero-main .logo-box {\n  width: 95px;\n  height: 95px;\n  border-radius: 20px;\n  overflow: hidden;\n  border: 2px solid #d2c2ff;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  background: #ffffff;\n  flex-shrink: 0;\n}\n.card-hero .hero-main .logo-box img {\n  width: 100%;\n  height: 100%;\n  object-fit: contain;\n  display: block;\n}\n.card-hero .hero-main .logo-box .logo-placeholder {\n  font-size: 2.8rem;\n}\n.card-hero .hero-main .hero-info h3 {\n  margin: 0 0 0.3rem 0;\n  color: #321f57;\n  font-size: 1.6rem;\n}\n.card-hero .hero-main .hero-info .rubro-tag {\n  display: inline-block;\n  background-color: #e9e1ff;\n  color: #5b44c2;\n  padding: 0.25rem 0.8rem;\n  border-radius: 12px;\n  font-size: 0.85rem;\n  font-weight: 600;\n  margin-bottom: 0.6rem;\n}\n.card-hero .hero-main .hero-info .pills-row {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 0.5rem;\n  margin-top: 0.4rem;\n}\n.card-hero .hero-main .hero-info .pills-row .pill {\n  background-color: #efe8ff;\n  border: 1px solid #d2c2ff;\n  color: #321f57;\n  padding: 0.3rem 0.75rem;\n  border-radius: 20px;\n  font-size: 0.85rem;\n  text-decoration: none;\n  display: inline-flex;\n  align-items: center;\n  gap: 0.3rem;\n}\n.card-hero .hero-main .hero-info .pills-row .pill.modal-badge {\n  background-color: #dcfce7;\n  color: #15803d;\n  border-color: #bbf7d0;\n  font-weight: 600;\n}\n.card-hero .hero-main .hero-info .pills-row a.pill:hover {\n  background-color: #e9e1ff;\n  color: #5b44c2;\n  border-color: #5b44c2;\n}\n.content-grid {\n  display: grid;\n  grid-template-columns: repeat(2, 1fr);\n  gap: 1.5rem;\n}\n.content-grid .columna {\n  display: flex;\n  flex-direction: column;\n  gap: 1.5rem;\n}\n.content-grid .card {\n  background: #ffffff;\n  border: 1px solid #d2c2ff;\n  border-radius: 20px;\n  padding: 1.5rem;\n  box-shadow: 0 10px 25px rgba(103, 87, 176, 0.05);\n}\n.content-grid .card h4 {\n  color: #321f57;\n  margin: 0 0 0.8rem 0;\n  font-size: 1.15rem;\n  display: flex;\n  align-items: center;\n  gap: 0.5rem;\n}\n.content-grid .card p {\n  color: #321f57;\n  line-height: 1.6;\n  margin: 0;\n  white-space: pre-line;\n  font-size: 0.95rem;\n}\n.tarjeta-perfil.edicion {\n  background: #ffffff;\n  border: 1px solid #d2c2ff;\n  border-radius: 24px;\n  padding: 2rem;\n  box-shadow: 0 10px 25px rgba(103, 87, 176, 0.05);\n}\n.tarjeta-perfil.edicion h3 {\n  margin-top: 0;\n  margin-bottom: 1.2rem;\n  color: #321f57;\n  font-size: 1.4rem;\n}\n.tarjeta-perfil.edicion .datos-fijos-banner {\n  background-color: #e9e1ff;\n  border-left: 4px solid #5b44c2;\n  padding: 0.8rem 1.2rem;\n  border-radius: 12px;\n  margin-bottom: 1.5rem;\n  color: #321f57;\n}\n.tarjeta-perfil.edicion .form-grid-edicion {\n  display: grid;\n  grid-template-columns: repeat(2, 1fr);\n  gap: 1.5rem;\n}\n.tarjeta-perfil.edicion .card-form {\n  background: #efe8ff;\n  border: 1px solid #d2c2ff;\n  border-radius: 16px;\n  padding: 1.25rem;\n}\n.tarjeta-perfil.edicion .card-form h4 {\n  margin-top: 0;\n  margin-bottom: 1rem;\n  color: #321f57;\n  font-size: 1.05rem;\n}\n.tarjeta-perfil.edicion .card-form.full-width {\n  grid-column: span 2;\n}\n.tarjeta-perfil.edicion .upload-logo-container {\n  display: flex;\n  align-items: center;\n  gap: 1.2rem;\n}\n.tarjeta-perfil.edicion .upload-logo-container .logo-preview {\n  width: 85px;\n  height: 85px;\n  border-radius: 14px;\n  border: 2px dashed #d2c2ff;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  overflow: hidden;\n  background: #ffffff;\n  flex-shrink: 0;\n}\n.tarjeta-perfil.edicion .upload-logo-container .logo-preview img {\n  width: 100%;\n  height: 100%;\n  object-fit: contain;\n  display: block;\n}\n.tarjeta-perfil.edicion .upload-logo-container .logo-preview span {\n  font-size: 0.75rem;\n  color: gray;\n  text-align: center;\n}\n.tarjeta-perfil.edicion .upload-logo-container .upload-controls {\n  display: flex;\n  flex-direction: column;\n  gap: 0.4rem;\n}\n.tarjeta-perfil.edicion .upload-logo-container .upload-controls input[type=file] {\n  font-size: 0.85rem;\n  color: #321f57;\n}\n.tarjeta-perfil.edicion .upload-logo-container .upload-controls input[type=file]:disabled {\n  cursor: not-allowed;\n  opacity: 0.6;\n}\n.tarjeta-perfil.edicion .upload-logo-container .upload-controls .upload-status {\n  color: #5b44c2;\n  font-weight: 600;\n  font-size: 0.82rem;\n  animation: pulseStatus 1.5s infinite;\n}\n.tarjeta-perfil.edicion .form-row-2 {\n  display: grid;\n  grid-template-columns: repeat(2, 1fr);\n  gap: 1rem;\n}\n.tarjeta-perfil.edicion .form-group {\n  display: flex;\n  flex-direction: column;\n  gap: 0.4rem;\n  margin-bottom: 1rem;\n}\n.tarjeta-perfil.edicion .form-group:last-child {\n  margin-bottom: 0;\n}\n.tarjeta-perfil.edicion .form-group label {\n  font-weight: 600;\n  font-size: 0.88rem;\n  color: #321f57;\n}\n.tarjeta-perfil.edicion .form-group label code {\n  background-color: #ffffff;\n  padding: 0.1rem 0.4rem;\n  border-radius: 4px;\n  color: #5b44c2;\n}\n.tarjeta-perfil.edicion .form-group input[type=text],\n.tarjeta-perfil.edicion .form-group input[type=email],\n.tarjeta-perfil.edicion .form-group input[type=url],\n.tarjeta-perfil.edicion .form-group textarea,\n.tarjeta-perfil.edicion .form-group select {\n  width: 100%;\n  padding: 0.65rem 0.9rem;\n  border: 1px solid #d2c2ff;\n  border-radius: 10px;\n  background-color: #ffffff;\n  color: #321f57;\n  font-family: inherit;\n  font-size: 0.92rem;\n  box-sizing: border-box;\n}\n.tarjeta-perfil.edicion .form-group input[type=text]:focus,\n.tarjeta-perfil.edicion .form-group input[type=email]:focus,\n.tarjeta-perfil.edicion .form-group input[type=url]:focus,\n.tarjeta-perfil.edicion .form-group textarea:focus,\n.tarjeta-perfil.edicion .form-group select:focus {\n  outline: none;\n  border-color: #5b44c2;\n  box-shadow: 0 0 0 3px #e9e1ff;\n}\n.tarjeta-perfil.edicion .form-group textarea {\n  resize: vertical;\n}\n@keyframes pulseStatus {\n  0% {\n    opacity: 0.5;\n  }\n  50% {\n    opacity: 1;\n  }\n  100% {\n    opacity: 0.5;\n  }\n}\n@media (max-width: 820px) {\n  .perfil-header {\n    flex-direction: column;\n    align-items: flex-start;\n  }\n  .perfil-header .acciones-header {\n    width: 100%;\n  }\n  .perfil-header .acciones-header button {\n    flex: 1;\n    justify-content: center;\n  }\n  .card-hero .hero-main {\n    flex-direction: column;\n    text-align: center;\n  }\n  .card-hero .hero-main .pills-row {\n    justify-content: center;\n  }\n  .content-grid {\n    grid-template-columns: 1fr;\n  }\n  .tarjeta-perfil.edicion {\n    padding: 1.25rem;\n  }\n  .tarjeta-perfil.edicion .form-grid-edicion {\n    grid-template-columns: 1fr;\n  }\n  .tarjeta-perfil.edicion .card-form.full-width {\n    grid-column: span 1;\n  }\n  .tarjeta-perfil.edicion .form-row-2 {\n    grid-template-columns: 1fr;\n  }\n}\n/*# sourceMappingURL=empresa-profile.css.map */\n"] }]
  }], null, { idEmpresaInput: [{
    type: Input
  }], esModoAdmin: [{
    type: Input
  }], cerrarModal: [{
    type: Output
  }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(EmpresaProfile, { className: "EmpresaProfile", filePath: "app/pagina/perfiles/empresa-profile/empresa-profile.ts", lineNumber: 51 });
})();
(() => {
  const id = "app%2Fpagina%2Fperfiles%2Fempresa-profile%2Fempresa-profile.ts%40EmpresaProfile";
  function EmpresaProfile_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i0.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i0.\u0275\u0275replaceMetadata(EmpresaProfile, m.default, [i0, i1, i2], [CommonModule, FormsModule, Component, Input, Output], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && EmpresaProfile_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && EmpresaProfile_HmrLoad(d.timestamp)));
})();

export {
  EmpresaProfile
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnaW5hL3BlcmZpbGVzL2VtcHJlc2EtcHJvZmlsZS9lbXByZXNhLXByb2ZpbGUudHMiLCJzcmMvYXBwL3BhZ2luYS9wZXJmaWxlcy9lbXByZXNhLXByb2ZpbGUvZW1wcmVzYS1wcm9maWxlLmh0bWwiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgXHJcbiAgQ29tcG9uZW50LCBcclxuICBPbkluaXQsIFxyXG4gIE9uQ2hhbmdlcywgXHJcbiAgU2ltcGxlQ2hhbmdlcywgXHJcbiAgSW5wdXQsIFxyXG4gIE91dHB1dCwgXHJcbiAgRXZlbnRFbWl0dGVyLCBcclxuICBpbmplY3QsIFxyXG4gIENoYW5nZURldGVjdG9yUmVmIFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBBdXRoU2VydmljZSB9IGZyb20gJy4uLy4uLy4uL3NlcnZpY2VzL2F1dGguc2VydmljZSc7XHJcbmltcG9ydCB7IENvbW1vbk1vZHVsZSwgTG9jYXRpb24gfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xyXG5pbXBvcnQgeyBGb3Jtc01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcclxuaW1wb3J0IHsgSHR0cENsaWVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcclxuaW1wb3J0IHsgUm91dGVyLCBBY3RpdmF0ZWRSb3V0ZSB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIFBlcmZpbEVtcHJlc2FEVE8ge1xyXG4gIC8vIERhdG9zIGZpam9zIC8gZmlzY2FsZXMgKFRhYmxhICdlbXByZXNhJylcclxuICBpZF9lbXByZXNhOiBudW1iZXI7XHJcbiAgcmF6b25Tb2NpYWw6IHN0cmluZztcclxuICBmYW50YXNpYT86IHN0cmluZztcclxuICBjdWl0Pzogc3RyaW5nO1xyXG4gIGVtYWlsOiBzdHJpbmc7XHJcbiAgc2VjdG9yPzogc3RyaW5nO1xyXG4gIGNpdWRhZF9maXNjYWw/OiBzdHJpbmc7XHJcbiAgcHJvdmluY2lhX2Zpc2NhbD86IHN0cmluZztcclxuXHJcbiAgLy8gRGF0b3Mgb3BlcmF0aXZvcyBkZSBwZXJmaWwgKFRhYmxhICdwZXJmaWxfZW1wcmVzYScpXHJcbiAgaWRfcGVyZmlsPzogbnVtYmVyO1xyXG4gIGxvZ28/OiBzdHJpbmc7XHJcbiAgZGVzY3JpcGNpb246IHN0cmluZztcclxuICB0cmF5ZWN0b3JpYTogc3RyaW5nO1xyXG4gIHN0YWNrX3RlY25vbG9naWNvPzogc3RyaW5nO1xyXG4gIGJlbmVmaWNpb3M/OiBzdHJpbmc7XHJcbiAgbW9kYWxpZGFkPzogJ1ByZXNlbmNpYWwnIHwgJ0jDrWJyaWRvJyB8ICdSZW1vdG8nO1xyXG4gIHpvbmFfdHJhYmFqbz86IHN0cmluZztcclxuICBzaXRpb193ZWI/OiBzdHJpbmc7XHJcbiAgbGlua2VkaW4/OiBzdHJpbmc7XHJcbiAgdGVsZWZvbm8/OiBzdHJpbmc7XHJcbiAgY3JlYXRlZF9hdD86IHN0cmluZztcclxufVxyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdhcHAtZW1wcmVzYS1wcm9maWxlJyxcclxuICBzdGFuZGFsb25lOiB0cnVlLFxyXG4gIGltcG9ydHM6IFtDb21tb25Nb2R1bGUsIEZvcm1zTW9kdWxlXSxcclxuICB0ZW1wbGF0ZVVybDogJy4vZW1wcmVzYS1wcm9maWxlLmh0bWwnLFxyXG4gIHN0eWxlVXJsOiAnLi9lbXByZXNhLXByb2ZpbGUuc2NzcycsXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBFbXByZXNhUHJvZmlsZSBpbXBsZW1lbnRzIE9uSW5pdCwgT25DaGFuZ2VzIHtcclxuICBwcml2YXRlIGh0dHAgPSBpbmplY3QoSHR0cENsaWVudCk7XHJcbiAgcHJpdmF0ZSBhdXRoU2VydmljZSA9IGluamVjdChBdXRoU2VydmljZSk7XHJcbiAgcHJpdmF0ZSByb3V0ZXIgPSBpbmplY3QoUm91dGVyKTtcclxuICBwcml2YXRlIHJvdXRlID0gaW5qZWN0KEFjdGl2YXRlZFJvdXRlKTtcclxuICBwcml2YXRlIGxvY2F0aW9uID0gaW5qZWN0KExvY2F0aW9uKTtcclxuICBwcml2YXRlIGNkciA9IGluamVjdChDaGFuZ2VEZXRlY3RvclJlZik7XHJcblxyXG4gIHByaXZhdGUgYXBpVXJsID0gJ2h0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9hcGknO1xyXG4gIHJlYWRvbmx5IHNlcnZlclVybCA9ICdodHRwOi8vbG9jYWxob3N0OjMwMDAnOyAvLyDwn5GIIEJhc2UgcGFyYSByZXNvbHZlciBydXRhcyByZWxhdGl2YXMgZGUgbG9nb3NcclxuXHJcbiAgQElucHV0KCkgaWRFbXByZXNhSW5wdXQ/OiBudW1iZXIgfCBudWxsID0gbnVsbDtcclxuICBASW5wdXQoKSBlc01vZG9BZG1pbjogYm9vbGVhbiA9IGZhbHNlO1xyXG4gIEBPdXRwdXQoKSBjZXJyYXJNb2RhbCA9IG5ldyBFdmVudEVtaXR0ZXI8dm9pZD4oKTtcclxuXHJcbiAgcGVyZmlsOiBQZXJmaWxFbXByZXNhRFRPID0gdGhpcy5pbmljaWFsaXphclBlcmZpbCgpO1xyXG4gIHBlcmZpbEVkaXRhZG86IFBlcmZpbEVtcHJlc2FEVE8gPSB0aGlzLmluaWNpYWxpemFyUGVyZmlsKCk7XHJcblxyXG4gIGVzVmlzaXRhbnRlOiBib29sZWFuID0gZmFsc2U7IC8vIEluZGljYSBzaSBxdWllbiBtaXJhIGVzIFBvc3R1bGFudGUvQWRtaW5cclxuICBtb2RvRWRpY2lvbjogYm9vbGVhbiA9IGZhbHNlO1xyXG4gIGNhcmdhbmRvOiBib29sZWFuID0gdHJ1ZTtcclxuICBndWFyZGFuZG86IGJvb2xlYW4gPSBmYWxzZTtcclxuICBzdWJpZW5kb0xvZ286IGJvb2xlYW4gPSBmYWxzZTtcclxuICBsb2dvUHJldmlldzogc3RyaW5nIHwgbnVsbCA9IG51bGw7XHJcbiAgYXJjaGl2b0xvZ29TZWxlY2Npb25hZG86IEZpbGUgfCBudWxsID0gbnVsbDtcclxuXHJcbiAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICB0aGlzLm9idGVuZXJEYXRvc0VtcHJlc2EoKTtcclxuICB9XHJcblxyXG4gIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcclxuICAgIGlmIChjaGFuZ2VzWydpZEVtcHJlc2FJbnB1dCddICYmICFjaGFuZ2VzWydpZEVtcHJlc2FJbnB1dCddLmlzRmlyc3RDaGFuZ2UoKSkge1xyXG4gICAgICB0aGlzLm1vZG9FZGljaW9uID0gZmFsc2U7XHJcbiAgICAgIHRoaXMub2J0ZW5lckRhdG9zRW1wcmVzYSgpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgaW5pY2lhbGl6YXJQZXJmaWwoKTogUGVyZmlsRW1wcmVzYURUTyB7XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBpZF9lbXByZXNhOiAwLFxyXG4gICAgICByYXpvblNvY2lhbDogJycsXHJcbiAgICAgIGZhbnRhc2lhOiAnJyxcclxuICAgICAgY3VpdDogJycsXHJcbiAgICAgIGVtYWlsOiAnJyxcclxuICAgICAgc2VjdG9yOiAnJyxcclxuICAgICAgY2l1ZGFkX2Zpc2NhbDogJycsXHJcbiAgICAgIHByb3ZpbmNpYV9maXNjYWw6ICcnLFxyXG4gICAgICBpZF9wZXJmaWw6IHVuZGVmaW5lZCxcclxuICAgICAgbG9nbzogJycsXHJcbiAgICAgIGRlc2NyaXBjaW9uOiAnJyxcclxuICAgICAgdHJheWVjdG9yaWE6ICcnLFxyXG4gICAgICBzdGFja190ZWNub2xvZ2ljbzogJycsXHJcbiAgICAgIGJlbmVmaWNpb3M6ICcnLFxyXG4gICAgICBtb2RhbGlkYWQ6ICdIw61icmlkbycsXHJcbiAgICAgIHpvbmFfdHJhYmFqbzogJycsXHJcbiAgICAgIHNpdGlvX3dlYjogJycsXHJcbiAgICAgIGxpbmtlZGluOiAnJyxcclxuICAgICAgdGVsZWZvbm86ICcnXHJcbiAgICB9O1xyXG4gIH1cclxuXHJcbiAgb2J0ZW5lckRhdG9zRW1wcmVzYSgpOiB2b2lkIHtcclxuICAgIHRoaXMuY2FyZ2FuZG8gPSB0cnVlO1xyXG5cclxuICAgIGNvbnN0IGlkUGFyYW0gPSB0aGlzLnJvdXRlLnNuYXBzaG90LnBhcmFtTWFwLmdldCgnaWQnKTtcclxuICAgIGxldCBpZEVtcHJlc2E6IG51bWJlcjtcclxuXHJcbiAgICAvLyBQcmlvcmlkYWQgMTogUmVjaWJpZG8gcG9yIEBJbnB1dCgpIGRlc2RlIG1vZGFsIEFkbWluL1Bvc3R1bGFudGVcclxuICAgIGlmICh0aGlzLmlkRW1wcmVzYUlucHV0KSB7XHJcbiAgICAgIHRoaXMuZXNWaXNpdGFudGUgPSB0cnVlO1xyXG4gICAgICBpZEVtcHJlc2EgPSBOdW1iZXIodGhpcy5pZEVtcHJlc2FJbnB1dCk7XHJcbiAgICB9IFxyXG4gICAgLy8gUHJpb3JpZGFkIDI6IFJlY2liaWRvIHBvciBwYXLDoW1ldHJvIGRlIFVSTCAoL2VtcHJlc2EvNSlcclxuICAgIGVsc2UgaWYgKGlkUGFyYW0pIHtcclxuICAgICAgdGhpcy5lc1Zpc2l0YW50ZSA9IHRydWU7XHJcbiAgICAgIGlkRW1wcmVzYSA9IE51bWJlcihpZFBhcmFtKTtcclxuICAgIH0gXHJcbiAgICAvLyBQcmlvcmlkYWQgMzogU2VzacOzbiBhY3RpdmEgZGUgbGEgcHJvcGlhIGVtcHJlc2EgKC9taS1wZXJmaWwtZW1wcmVzYSlcclxuICAgIGVsc2Uge1xyXG4gICAgICB0aGlzLmVzVmlzaXRhbnRlID0gZmFsc2U7XHJcbiAgICAgIGNvbnN0IHVzZXIgPSB0aGlzLmF1dGhTZXJ2aWNlLmdldFVzdWFyaW9BY3R1YWwoKTtcclxuXHJcbiAgICAgIGlmICghdXNlciB8fCAoIXVzZXIuaWQgJiYgIXVzZXIuaWRfZW1wcmVzYSkpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKCdObyBzZSBlbmNvbnRyw7MgaW5mb3JtYWNpw7NuIGRlIHVzdWFyaW8gZW4gc2VzacOzbicpO1xyXG4gICAgICAgIHRoaXMuY2FyZ2FuZG8gPSBmYWxzZTtcclxuICAgICAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbJy9zZXNpb24nXSk7XHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBpZEVtcHJlc2EgPSB1c2VyLmlkIHx8IHVzZXIuaWRfZW1wcmVzYTtcclxuICAgIH1cclxuXHJcbiAgICB0aGlzLmh0dHAuZ2V0PGFueT4oYCR7dGhpcy5hcGlVcmx9L2VtcHJlc2EvcGVyZmlsLyR7aWRFbXByZXNhfWApLnN1YnNjcmliZSh7XHJcbiAgICAgIG5leHQ6IChyZXMpID0+IHtcclxuICAgICAgICBpZiAocmVzLnN1Y2Nlc3MgJiYgcmVzLnBlcmZpbCkge1xyXG4gICAgICAgICAgdGhpcy5wZXJmaWwgPSB7IC4uLnRoaXMuaW5pY2lhbGl6YXJQZXJmaWwoKSwgLi4ucmVzLnBlcmZpbCB9O1xyXG4gICAgICAgICAgXHJcbiAgICAgICAgICAvLyBGb3JtYXRlYXIgbG9nbyBzaSBlbCBiYWNrZW5kIGRldnVlbHZlIHVuYSBydXRhIHJlbGF0aXZhICgvdXBsb2Fkcy8uLi4pXHJcbiAgICAgICAgICBpZiAodGhpcy5wZXJmaWwubG9nbyAmJiAhdGhpcy5wZXJmaWwubG9nby5zdGFydHNXaXRoKCdodHRwJykpIHtcclxuICAgICAgICAgICAgdGhpcy5wZXJmaWwubG9nbyA9IGAke3RoaXMuc2VydmVyVXJsfSR7dGhpcy5wZXJmaWwubG9nby5zdGFydHNXaXRoKCcvJykgPyAnJyA6ICcvJ30ke3RoaXMucGVyZmlsLmxvZ299YDtcclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICB0aGlzLnBlcmZpbEVkaXRhZG8gPSBzdHJ1Y3R1cmVkQ2xvbmUodGhpcy5wZXJmaWwpO1xyXG4gICAgICAgICAgdGhpcy5tb2RvRWRpY2lvbiA9IHRoaXMuZXNWaXNpdGFudGUgPyBmYWxzZSA6ICF0aGlzLnBlcmZpbC5pZF9wZXJmaWw7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuY2FyZ2FuZG8gPSBmYWxzZTtcclxuICAgICAgICB0aGlzLmNkci5kZXRlY3RDaGFuZ2VzKCk7XHJcbiAgICAgIH0sXHJcbiAgICAgIGVycm9yOiAoZXJyKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgYWwgb2J0ZW5lciBwZXJmaWw6JywgZXJyKTtcclxuICAgICAgICB0aGlzLm1vZG9FZGljaW9uID0gIXRoaXMuZXNWaXNpdGFudGU7XHJcbiAgICAgICAgdGhpcy5jYXJnYW5kbyA9IGZhbHNlO1xyXG4gICAgICAgIHRoaXMuY2RyLmRldGVjdENoYW5nZXMoKTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICB2b2x2ZXIoKTogdm9pZCB7XHJcbiAgICBpZiAodGhpcy5pZEVtcHJlc2FJbnB1dCkge1xyXG4gICAgICB0aGlzLmNlcnJhck1vZGFsLmVtaXQoKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHRoaXMubG9jYXRpb24uYmFjaygpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYWN0aXZhckVkaWNpb24oKTogdm9pZCB7XHJcbiAgICBpZiAodGhpcy5lc1Zpc2l0YW50ZSkgcmV0dXJuO1xyXG4gICAgdGhpcy5wZXJmaWxFZGl0YWRvID0gc3RydWN0dXJlZENsb25lKHRoaXMucGVyZmlsKTtcclxuICAgIHRoaXMubG9nb1ByZXZpZXcgPSB0aGlzLnBlcmZpbC5sb2dvIHx8IG51bGw7XHJcbiAgICB0aGlzLm1vZG9FZGljaW9uID0gdHJ1ZTtcclxuICB9XHJcblxyXG4gIGNhbmNlbGFyRWRpY2lvbigpOiB2b2lkIHtcclxuICAgIGlmICghdGhpcy5wZXJmaWwuaWRfcGVyZmlsKSB7XHJcbiAgICAgIGFsZXJ0KCdEZWJlcyBjb21wbGV0YXIgbGEgaW5mb3JtYWNpw7NuIGLDoXNpY2EgZGVsIHBlcmZpbCBwYXJhIGNvbnRpbnVhci4nKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgdGhpcy5tb2RvRWRpY2lvbiA9IGZhbHNlO1xyXG4gICAgdGhpcy5sb2dvUHJldmlldyA9IHRoaXMucGVyZmlsLmxvZ28gfHwgbnVsbDtcclxuICAgIHRoaXMuYXJjaGl2b0xvZ29TZWxlY2Npb25hZG8gPSBudWxsO1xyXG4gICAgdGhpcy5zdWJpZW5kb0xvZ28gPSBmYWxzZTtcclxuICB9XHJcblxyXG4gIGd1YXJkYXJDYW1iaW9zKCk6IHZvaWQge1xyXG4gICAgaWYgKHRoaXMuZXNWaXNpdGFudGUpIHJldHVybjsgLy8gR3VhcmQgZGUgc2VndXJpZGFkXHJcblxyXG4gICAgaWYgKHRoaXMuc3ViaWVuZG9Mb2dvKSB7XHJcbiAgICAgIGFsZXJ0KCdQb3IgZmF2b3IgYWd1YXJkYSBhIHF1ZSBmaW5hbGljZSBsYSBjYXJnYSBkZSBsYSBpbWFnZW4gZGVsIGxvZ28uJyk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIHRoaXMuZ3VhcmRhbmRvID0gdHJ1ZTtcclxuXHJcbiAgICBjb25zdCB1c2VyID0gdGhpcy5hdXRoU2VydmljZS5nZXRVc3VhcmlvQWN0dWFsKCk7XHJcbiAgICBjb25zdCBpZEVtcHJlc2EgPSB1c2VyPy5pZCB8fCB1c2VyPy5pZF9lbXByZXNhO1xyXG5cclxuICAgIGlmICghaWRFbXByZXNhKSB7XHJcbiAgICAgIHRoaXMuZ3VhcmRhbmRvID0gZmFsc2U7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBwYXlsb2FkID0ge1xyXG4gICAgICBpZF9lbXByZXNhOiBpZEVtcHJlc2EsXHJcbiAgICAgIGxvZ286IHRoaXMucGVyZmlsRWRpdGFkby5sb2dvLFxyXG4gICAgICBkZXNjcmlwY2lvbjogdGhpcy5wZXJmaWxFZGl0YWRvLmRlc2NyaXBjaW9uLFxyXG4gICAgICB0cmF5ZWN0b3JpYTogdGhpcy5wZXJmaWxFZGl0YWRvLnRyYXllY3RvcmlhLFxyXG4gICAgICBzdGFja190ZWNub2xvZ2ljbzogdGhpcy5wZXJmaWxFZGl0YWRvLnN0YWNrX3RlY25vbG9naWNvLFxyXG4gICAgICBiZW5lZmljaW9zOiB0aGlzLnBlcmZpbEVkaXRhZG8uYmVuZWZpY2lvcyxcclxuICAgICAgbW9kYWxpZGFkOiB0aGlzLnBlcmZpbEVkaXRhZG8ubW9kYWxpZGFkLFxyXG4gICAgICB6b25hX3RyYWJham86IHRoaXMucGVyZmlsRWRpdGFkby56b25hX3RyYWJham8sXHJcbiAgICAgIHNpdGlvX3dlYjogdGhpcy5wZXJmaWxFZGl0YWRvLnNpdGlvX3dlYixcclxuICAgICAgbGlua2VkaW46IHRoaXMucGVyZmlsRWRpdGFkby5saW5rZWRpbixcclxuICAgICAgdGVsZWZvbm86IHRoaXMucGVyZmlsRWRpdGFkby50ZWxlZm9ub1xyXG4gICAgfTtcclxuXHJcbiAgICB0aGlzLmh0dHAucHV0PGFueT4oYCR7dGhpcy5hcGlVcmx9L2VtcHJlc2EvcGVyZmlsYCwgcGF5bG9hZCkuc3Vic2NyaWJlKHtcclxuICAgICAgbmV4dDogKHJlcykgPT4ge1xyXG4gICAgICAgIGlmIChyZXMuc3VjY2Vzcykge1xyXG4gICAgICAgICAgdGhpcy5wZXJmaWwgPSBzdHJ1Y3R1cmVkQ2xvbmUodGhpcy5wZXJmaWxFZGl0YWRvKTtcclxuICAgICAgICAgIGlmIChyZXMuaWRfcGVyZmlsKSB7XHJcbiAgICAgICAgICAgIHRoaXMucGVyZmlsLmlkX3BlcmZpbCA9IHJlcy5pZF9wZXJmaWw7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICB0aGlzLm1vZG9FZGljaW9uID0gZmFsc2U7XHJcbiAgICAgICAgICBhbGVydCgnUGVyZmlsIGd1YXJkYWRvIGNvbiDDqXhpdG8uJyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuZ3VhcmRhbmRvID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5jZHIuZGV0ZWN0Q2hhbmdlcygpO1xyXG4gICAgICB9LFxyXG4gICAgICBlcnJvcjogKGVycikgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGFsIGd1YXJkYXIgcGVyZmlsOicsIGVycik7XHJcbiAgICAgICAgYWxlcnQoJ09jdXJyacOzIHVuIGVycm9yIGFsIGludGVudGFyIGd1YXJkYXIgbG9zIGNhbWJpb3MuJyk7XHJcbiAgICAgICAgdGhpcy5ndWFyZGFuZG8gPSBmYWxzZTtcclxuICAgICAgICB0aGlzLmNkci5kZXRlY3RDaGFuZ2VzKCk7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgb25Mb2dvU2VsZWN0ZWQoZXZlbnQ6IEV2ZW50KTogdm9pZCB7XHJcbiAgICBpZiAodGhpcy5lc1Zpc2l0YW50ZSkgcmV0dXJuO1xyXG5cclxuICAgIGNvbnN0IGlucHV0ID0gZXZlbnQudGFyZ2V0IGFzIEhUTUxJbnB1dEVsZW1lbnQ7XHJcblxyXG4gICAgaWYgKGlucHV0LmZpbGVzICYmIGlucHV0LmZpbGVzWzBdKSB7XHJcbiAgICAgIGNvbnN0IGZpbGUgPSBpbnB1dC5maWxlc1swXTtcclxuXHJcbiAgICAgIGlmICghWydpbWFnZS9qcGVnJywgJ2ltYWdlL2pwZycsICdpbWFnZS9wbmcnXS5pbmNsdWRlcyhmaWxlLnR5cGUpKSB7XHJcbiAgICAgICAgYWxlcnQoJ1NvbG8gc2UgYWRtaXRlbiBpbcOhZ2VuZXMgZW4gZm9ybWF0byBKUEcgbyBQTkcuJyk7XHJcbiAgICAgICAgaW5wdXQudmFsdWUgPSAnJztcclxuICAgICAgICByZXR1cm47XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHRoaXMuYXJjaGl2b0xvZ29TZWxlY2Npb25hZG8gPSBmaWxlO1xyXG5cclxuICAgICAgY29uc3QgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcclxuICAgICAgcmVhZGVyLm9ubG9hZCA9ICgpID0+IHtcclxuICAgICAgICB0aGlzLmxvZ29QcmV2aWV3ID0gcmVhZGVyLnJlc3VsdCBhcyBzdHJpbmc7XHJcbiAgICAgICAgdGhpcy5jZHIuZGV0ZWN0Q2hhbmdlcygpO1xyXG4gICAgICB9O1xyXG4gICAgICByZWFkZXIucmVhZEFzRGF0YVVSTChmaWxlKTtcclxuXHJcbiAgICAgIHRoaXMuc3ViaXJMb2dvU2Vydmlkb3IoZmlsZSk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBzdWJpckxvZ29TZXJ2aWRvcihmaWxlOiBGaWxlKTogdm9pZCB7XHJcbiAgICBpZiAodGhpcy5lc1Zpc2l0YW50ZSkgcmV0dXJuO1xyXG4gICAgdGhpcy5zdWJpZW5kb0xvZ28gPSB0cnVlO1xyXG5cclxuICAgIGNvbnN0IGZvcm1EYXRhID0gbmV3IEZvcm1EYXRhKCk7XHJcbiAgICBmb3JtRGF0YS5hcHBlbmQoJ2xvZ28nLCBmaWxlKTtcclxuXHJcbiAgICB0aGlzLmh0dHAucG9zdDxhbnk+KGAke3RoaXMuYXBpVXJsfS9lbXByZXNhL3BlcmZpbC9sb2dvYCwgZm9ybURhdGEpLnN1YnNjcmliZSh7XHJcbiAgICAgIG5leHQ6IChyZXMpID0+IHtcclxuICAgICAgICBpZiAocmVzLnN1Y2Nlc3MgJiYgcmVzLmxvZ29VcmwpIHtcclxuICAgICAgICAgIGxldCB1cmwgPSByZXMubG9nb1VybDtcclxuICAgICAgICAgIGlmICghdXJsLnN0YXJ0c1dpdGgoJ2h0dHAnKSkge1xyXG4gICAgICAgICAgICB1cmwgPSBgJHt0aGlzLnNlcnZlclVybH0ke3VybC5zdGFydHNXaXRoKCcvJykgPyAnJyA6ICcvJ30ke3VybH1gO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgdGhpcy5wZXJmaWxFZGl0YWRvLmxvZ28gPSB1cmw7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuc3ViaWVuZG9Mb2dvID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5jZHIuZGV0ZWN0Q2hhbmdlcygpO1xyXG4gICAgICB9LFxyXG4gICAgICBlcnJvcjogKGVycikgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGFsIHN1YmlyIGxvZ286JywgZXJyKTtcclxuICAgICAgICBhbGVydCgnTm8gc2UgcHVkbyBzdWJpciBsYSBpbWFnZW4gZGVsIGxvZ28gYWwgc2Vydmlkb3IuJyk7XHJcbiAgICAgICAgdGhpcy5zdWJpZW5kb0xvZ28gPSBmYWxzZTtcclxuICAgICAgICB0aGlzLmNkci5kZXRlY3RDaGFuZ2VzKCk7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgLy8g8J+boO+4jyBIZWxwZXJzIMO6dGlsZXMgcGFyYSB1c2FyIGVuIGxhIHBsYW50aWxsYSBIVE1MOlxyXG5cclxuICAvKipcclxuICAgKiBDb252aWVydGUgXCJBbmd1bGFyLCBOb2RlLmpzLCBUeXBlU2NyaXB0XCIgZW4gdW4gYXJyZWdsbyBbXCJBbmd1bGFyXCIsIFwiTm9kZS5qc1wiLCBcIlR5cGVTY3JpcHRcIl1cclxuICAgKiDDmnRpbCBwYXJhIHJlbmRlcml6YXIgYmFkZ2VzIGVuIGVsIEhUTUwgbWVkaWFudGUgKm5nRm9yXHJcbiAgICovXHJcbiAgZ2V0IHN0YWNrTGlzdCgpOiBzdHJpbmdbXSB7XHJcbiAgICBpZiAoIXRoaXMucGVyZmlsLnN0YWNrX3RlY25vbG9naWNvKSByZXR1cm4gW107XHJcbiAgICByZXR1cm4gdGhpcy5wZXJmaWwuc3RhY2tfdGVjbm9sb2dpY29cclxuICAgICAgLnNwbGl0KCcsJylcclxuICAgICAgLm1hcChpdGVtID0+IGl0ZW0udHJpbSgpKVxyXG4gICAgICAuZmlsdGVyKGl0ZW0gPT4gaXRlbS5sZW5ndGggPiAwKTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIEdhcmFudGl6YSBxdWUgbG9zIGVubGFjZXMgZXh0ZXJub3MgKHdlYiwgbGlua2VkaW4pIHRlbmdhbiBlbCBwcm90b2NvbG8gaHR0cHM6Ly9cclxuICAgKiBldml0YSBxdWUgZWwgbmF2ZWdhZG9yIGludGVudGUgYWJyaXIgbGEgVVJMIGNvbW8gdW5hIHJ1dGEgaW50ZXJuYSBkZSBBbmd1bGFyLlxyXG4gICAqL1xyXG4gIG9idGVuZXJVcmxWYWxpZGEodXJsPzogc3RyaW5nKTogc3RyaW5nIHtcclxuICAgIGlmICghdXJsKSByZXR1cm4gJyc7XHJcbiAgICBpZiAodXJsLnN0YXJ0c1dpdGgoJ2h0dHA6Ly8nKSB8fCB1cmwuc3RhcnRzV2l0aCgnaHR0cHM6Ly8nKSkge1xyXG4gICAgICByZXR1cm4gdXJsO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIGBodHRwczovLyR7dXJsfWA7XHJcbiAgfVxyXG59IiwiPGRpdiBjbGFzcz1cInBlcmZpbC1jb250YWluZXJcIj5cclxuXHJcbiAgQGlmIChjYXJnYW5kbykge1xyXG4gICAgPGRpdiBjbGFzcz1cImxvYWRpbmdcIj7ijJsgQ2FyZ2FuZG8gZGF0b3MuLi48L2Rpdj5cclxuICB9IEBlbHNlIHtcclxuXHJcbiAgICA8IS0tIEhFQURFUiBERSBBQ0NJT05FUyBHTE9CQUwgLS0+XHJcbiAgICA8ZGl2IGNsYXNzPVwicGVyZmlsLWhlYWRlclwiPlxyXG4gICAgICA8ZGl2IGNsYXNzPVwiaGVhZGVyLWluZm9cIj5cclxuICAgICAgICA8aDI+8J+PoiBQZXJmaWwgZGUgbGEgRW1wcmVzYTwvaDI+XHJcbiAgICAgICAgPHAgY2xhc3M9XCJzdWJ0aXR1bG9cIj5JbmZvcm1hY2nDs24gcMO6YmxpY2EgcGFyYSBwb3N0dWxhbnRlcyBkZSBTaXN0ZW1hcyBlIElBPC9wPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3M9XCJhY2Npb25lcy1oZWFkZXJcIj5cclxuICAgICAgQGlmIChlc1Zpc2l0YW50ZSkge1xyXG4gICAgICA8IS0tIPCfkYHvuI8gU2kgZXMgdmlzaXRhbnRlIChQb3N0dWxhbnRlIG8gQWRtaW4pLCBzb2xvIHZlIGxhIG9wY2nDs24gZGUgcmVncmVzYXIgLS0+XHJcbiAgICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0bi1zZWN1bmRhcmlvXCIgKGNsaWNrKT1cInZvbHZlcigpXCI+4oaQIFZvbHZlcjwvYnV0dG9uPlxyXG4gICAgICB9IEBlbHNlIHtcclxuICAgIDwhLS0g4pyP77iPIFNpIGVzIGxhIHByb3BpYSBlbXByZXNhLCBtYW50aWVuZSBzdXMgYm90b25lcyBub3JtYWxlcyAtLT5cclxuICAgICAgQGlmICghbW9kb0VkaWNpb24pIHtcclxuICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0bi1wcmltYXJpb1wiIChjbGljayk9XCJhY3RpdmFyRWRpY2lvbigpXCI+4pyP77iPIEVkaXRhciBQZXJmaWw8L2J1dHRvbj5cclxuICAgICAgfSBAZWxzZSB7XHJcbiAgICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0bi1zZWN1bmRhcmlvXCIgKGNsaWNrKT1cImNhbmNlbGFyRWRpY2lvbigpXCIgW2Rpc2FibGVkXT1cImd1YXJkYW5kbyB8fCBzdWJpZW5kb0xvZ29cIj7inJUgQ2FuY2VsYXI8L2J1dHRvbj5cclxuICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuLWd1YXJkYXJcIiAoY2xpY2spPVwiZ3VhcmRhckNhbWJpb3MoKVwiIFtkaXNhYmxlZF09XCJndWFyZGFuZG8gfHwgc3ViaWVuZG9Mb2dvXCI+XHJcbiAgICAgICAge3sgZ3VhcmRhbmRvID8gJ+KPsyBHdWFyZGFuZG8uLi4nIDogKHN1YmllbmRvTG9nbyA/ICfwn5OkIFN1YmllbmRvIGxvZ28uLi4nIDogJ/Cfkr4gR3VhcmRhciBQZXJmaWwnKSB9fVxyXG4gICAgICA8L2J1dHRvbj5cclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgPC9kaXY+XHJcbiAgPC9kaXY+XHJcblxyXG4gICAgPCEtLSA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gLS0+XHJcbiAgICA8IS0tIDEuIFZJU1RBIERFIExFQ1RVUkEgKEhlYWRlciBIZXJvICsgQ2FyZHMpIC0tPlxyXG4gICAgPCEtLSA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gLS0+XHJcbiAgICBAaWYgKCFtb2RvRWRpY2lvbikge1xyXG4gICAgICBcclxuICAgICAgPCEtLSBIRVJPIEJBTk5FUiBTVVBFUklPUiAtLT5cclxuICAgICAgPGhlYWRlciBjbGFzcz1cImNhcmQtaGVyb1wiPlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJoZXJvLW1haW5cIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJsb2dvLWJveFwiPlxyXG4gICAgICAgICAgICBAaWYgKHBlcmZpbC5sb2dvKSB7XHJcbiAgICAgICAgICAgICAgPGltZyBbc3JjXT1cInBlcmZpbC5sb2dvXCIgYWx0PVwiTG9nbyB7eyBwZXJmaWwuZmFudGFzaWEgfHwgcGVyZmlsLnJhem9uU29jaWFsIH19XCI+XHJcbiAgICAgICAgICAgIH0gQGVsc2Uge1xyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJsb2dvLXBsYWNlaG9sZGVyXCI+8J+PojwvZGl2PlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImhlcm8taW5mb1wiPlxyXG4gICAgICAgICAgICA8aDM+e3sgcGVyZmlsLmZhbnRhc2lhIHx8IHBlcmZpbC5yYXpvblNvY2lhbCB9fTwvaDM+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwicnVicm8tdGFnXCI+e3sgcGVyZmlsLnNlY3RvciB8fCAnU2VjdG9yIG5vIGVzcGVjaWZpY2FkbycgfX08L3NwYW4+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwicGlsbHMtcm93XCI+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJwaWxsIG1vZGFsLWJhZGdlXCI+8J+SuyB7eyBwZXJmaWwubW9kYWxpZGFkIHx8ICdIw61icmlkbycgfX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJwaWxsXCI+8J+TjSB7eyBwZXJmaWwuem9uYV90cmFiYWpvIHx8ICdVYmljYWNpw7NuIG5vIGVzcGVjaWZpY2FkYScgfX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgQGlmIChwZXJmaWwuc2l0aW9fd2ViKSB7IDxhIFtocmVmXT1cInBlcmZpbC5zaXRpb193ZWJcIiB0YXJnZXQ9XCJfYmxhbmtcIiBjbGFzcz1cInBpbGxcIj7wn4yQIFdlYjwvYT4gfVxyXG4gICAgICAgICAgICAgIEBpZiAocGVyZmlsLmxpbmtlZGluKSB7IDxhIFtocmVmXT1cInBlcmZpbC5saW5rZWRpblwiIHRhcmdldD1cIl9ibGFua1wiIGNsYXNzPVwicGlsbFwiPvCfkrwgTGlua2VkSW48L2E+IH1cclxuICAgICAgICAgICAgICBAaWYgKHBlcmZpbC50ZWxlZm9ubykgeyA8c3BhbiBjbGFzcz1cInBpbGxcIj7wn5OeIHt7IHBlcmZpbC50ZWxlZm9ubyB9fTwvc3Bhbj4gfVxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwicGlsbFwiPvCfk6cge3sgcGVyZmlsLmVtYWlsIH19PC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2hlYWRlcj5cclxuXHJcbiAgICAgIDwhLS0gR1JJRCBERSBDQVJEUyBJTkZFUklPUiAtLT5cclxuICAgICAgPGRpdiBjbGFzcz1cImNvbnRlbnQtZ3JpZFwiPlxyXG4gICAgICAgIDxzZWN0aW9uIGNsYXNzPVwiY29sdW1uYVwiPlxyXG4gICAgICAgICAgPGFydGljbGUgY2xhc3M9XCJjYXJkXCI+XHJcbiAgICAgICAgICAgIDxoND7wn5OEIERlc2NyaXBjacOzbiBHZW5lcmFsPC9oND5cclxuICAgICAgICAgICAgPHA+e3sgcGVyZmlsLmRlc2NyaXBjaW9uIHx8ICdTaW4gZGVzY3JpcGNpw7NuIGNhcmdhZGEuJyB9fTwvcD5cclxuICAgICAgICAgIDwvYXJ0aWNsZT5cclxuXHJcbiAgICAgICAgICA8YXJ0aWNsZSBjbGFzcz1cImNhcmRcIj5cclxuICAgICAgICAgICAgPGg0PvCfkrsgU3RhY2sgVGVjbm9sw7NnaWNvIHkgSGVycmFtaWVudGFzPC9oND5cclxuICAgICAgICAgICAgPHA+e3sgcGVyZmlsLnN0YWNrX3RlY25vbG9naWNvIHx8ICdTaW4gdGVjbm9sb2fDrWFzIGVzcGVjaWZpY2FkYXMuJyB9fTwvcD5cclxuICAgICAgICAgIDwvYXJ0aWNsZT5cclxuICAgICAgICA8L3NlY3Rpb24+XHJcblxyXG4gICAgICAgIDxzZWN0aW9uIGNsYXNzPVwiY29sdW1uYVwiPlxyXG4gICAgICAgICAgPGFydGljbGUgY2xhc3M9XCJjYXJkXCI+XHJcbiAgICAgICAgICAgIDxoND7wn4+GIFRyYXllY3RvcmlhIHkgUHJveWVjdG9zIERlc3RhY2Fkb3M8L2g0PlxyXG4gICAgICAgICAgICA8cD57eyBwZXJmaWwudHJheWVjdG9yaWEgfHwgJ1NpbiBpbmZvcm1hY2nDs24gZGUgdHJheWVjdG9yaWEgY2FyZ2FkYS4nIH19PC9wPlxyXG4gICAgICAgICAgPC9hcnRpY2xlPlxyXG5cclxuICAgICAgICAgIDxhcnRpY2xlIGNsYXNzPVwiY2FyZFwiPlxyXG4gICAgICAgICAgICA8aDQ+8J+OgSBCZW5lZmljaW9zIHBhcmEgRXN0dWRpYW50ZXM8L2g0PlxyXG4gICAgICAgICAgICA8cD57eyBwZXJmaWwuYmVuZWZpY2lvcyB8fCAnU2luIGRldGFsbGVzIGRlIGJlbmVmaWNpb3MuJyB9fTwvcD5cclxuICAgICAgICAgIDwvYXJ0aWNsZT5cclxuICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgIH1cclxuXHJcbiAgICA8IS0tID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAtLT5cclxuICAgIDwhLS0gMi4gVklTVEEgREUgRURJQ0nDk04gQ09NUExFVEEgICAgICAgICAgICAgICAtLT5cclxuICAgIDwhLS0gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IC0tPlxyXG4gICAgQGVsc2Uge1xyXG4gICAgICA8ZGl2IGNsYXNzPVwidGFyamV0YS1wZXJmaWwgZWRpY2lvblwiPlxyXG4gICAgICAgIDxoMz7inI/vuI8gQWN0dWFsaXphciBQZXJmaWwgSW5zdGl0dWNpb25hbDwvaDM+XHJcblxyXG4gICAgICAgIDwhLS0gRGF0b3MgZmlqb3MgZGVsIHVzdWFyaW8gLS0+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cImRhdG9zLWZpam9zLWJhbm5lclwiPlxyXG4gICAgICAgICAgPHNtYWxsPlxyXG4gICAgICAgICAgICDihLnvuI8gPHN0cm9uZz5SYXrDs24gU29jaWFsOjwvc3Ryb25nPiB7eyBwZXJmaWxFZGl0YWRvLnJhem9uU29jaWFsIH19IHwgXHJcbiAgICAgICAgICAgIDxzdHJvbmc+RW1haWw6PC9zdHJvbmc+IHt7IHBlcmZpbEVkaXRhZG8uZW1haWwgfX0gfCBcclxuICAgICAgICAgICAgPHN0cm9uZz5VYmljYWNpw7NuIEZpc2NhbDo8L3N0cm9uZz4ge3sgcGVyZmlsRWRpdGFkby5jaXVkYWRfZmlzY2FsIHx8ICdOL0EnIH19e3sgcGVyZmlsRWRpdGFkby5wcm92aW5jaWFfZmlzY2FsID8gJywgJyArIHBlcmZpbEVkaXRhZG8ucHJvdmluY2lhX2Zpc2NhbCA6ICcnIH19XHJcbiAgICAgICAgICA8L3NtYWxsPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncmlkLWVkaWNpb25cIj5cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgPCEtLSBTRUNDScOTTiAxOiBMT0dPIFkgREFUT1MgUsOBUElET1MgLS0+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZCBjYXJkLWZvcm1cIj5cclxuICAgICAgICAgICAgPGg0PvCflrzvuI8gTG9nbyBlIElkZW50aWRhZDwvaDQ+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbD5Mb2dvIGRlIGxhIEVtcHJlc2E8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJ1cGxvYWQtbG9nby1jb250YWluZXJcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJsb2dvLXByZXZpZXdcIj5cclxuICAgICAgICAgICAgICAgICAgQGlmIChsb2dvUHJldmlldykge1xyXG4gICAgICAgICAgICAgICAgICAgIDxpbWcgW3NyY109XCJsb2dvUHJldmlld1wiIGFsdD1cIlZpc3RhIHByZXZpYSBkZWwgbG9nb1wiPlxyXG4gICAgICAgICAgICAgICAgICB9IEBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5TaW4gbG9nbzwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwidXBsb2FkLWNvbnRyb2xzXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZmlsZVwiIGFjY2VwdD1cImltYWdlL3BuZywgaW1hZ2UvanBlZywgaW1hZ2UvanBnXCIgKGNoYW5nZSk9XCJvbkxvZ29TZWxlY3RlZCgkZXZlbnQpXCIgW2Rpc2FibGVkXT1cInN1YmllbmRvTG9nb1wiPlxyXG4gICAgICAgICAgICAgICAgICBAaWYgKHN1YmllbmRvTG9nbykge1xyXG4gICAgICAgICAgICAgICAgICAgIDxzbWFsbCBjbGFzcz1cInVwbG9hZC1zdGF0dXNcIj7ij7MgU3ViaWVuZG8gaW1hZ2VuLi4uPC9zbWFsbD5cclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PiA8IS0tIERpdiBkZSBmb3JtLWdyb3VwIGNlcnJhZG8gY29ycmVjdGFtZW50ZSAtLT5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsPk1vZGFsaWRhZCBkZSBUcmFiYWpvPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8c2VsZWN0IFsobmdNb2RlbCldPVwicGVyZmlsRWRpdGFkby5tb2RhbGlkYWRcIj5cclxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJQcmVzZW5jaWFsXCI+UHJlc2VuY2lhbDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkjDrWJyaWRvXCI+SMOtYnJpZG88L29wdGlvbj5cclxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJSZW1vdG9cIj5SZW1vdG88L29wdGlvbj5cclxuICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbD5ab25hIGRlIFRyYWJham8gLyBMdWdhciBMYWJvcmFsPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBbKG5nTW9kZWwpXT1cInBlcmZpbEVkaXRhZG8uem9uYV90cmFiYWpvXCIgcGxhY2Vob2xkZXI9XCJFajogTGFuw7pzIC8gUHJlc2VuY2lhbCBlbiBTZWRlIENlbnRyYWxcIj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8IS0tIFNFQ0NJw5NOIDI6IENPTlRBQ1RPIFkgUkVERVMgLS0+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZCBjYXJkLWZvcm1cIj5cclxuICAgICAgICAgICAgPGg0PvCfjJAgQ29udGFjdG8geSBFbmxhY2VzPC9oND5cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsPlNpdGlvIFdlYjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ1cmxcIiBbKG5nTW9kZWwpXT1cInBlcmZpbEVkaXRhZG8uc2l0aW9fd2ViXCIgcGxhY2Vob2xkZXI9XCJodHRwczovL2VtcHJlc2EuY29tXCI+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgICA8bGFiZWw+UGVyZmlsIGRlIExpbmtlZEluPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInVybFwiIFsobmdNb2RlbCldPVwicGVyZmlsRWRpdGFkby5saW5rZWRpblwiIHBsYWNlaG9sZGVyPVwiaHR0cHM6Ly9saW5rZWRpbi5jb20vY29tcGFueS8uLi5cIj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbD5UZWzDqWZvbm8gZGUgQ29udGFjdG88L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIFsobmdNb2RlbCldPVwicGVyZmlsRWRpdGFkby50ZWxlZm9ub1wiIHBsYWNlaG9sZGVyPVwiRWo6IDExIDEyMzQtNTY3OFwiPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPCEtLSBTRUNDScOTTiAzOiBURVhUT1MgREVUQUxMQURPUyAtLT5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZCBjYXJkLWZvcm0gZnVsbC13aWR0aFwiIHN0eWxlPVwibWFyZ2luLXRvcDogMS41cmVtO1wiPlxyXG4gICAgICAgICAgPGg0PvCfk4QgSW5mb3JtYWNpw7NuIERldGFsbGFkYTwvaDQ+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgPGxhYmVsPkRlc2NyaXBjacOzbiBHZW5lcmFsPC9sYWJlbD5cclxuICAgICAgICAgICAgPHRleHRhcmVhIHJvd3M9XCIzXCIgWyhuZ01vZGVsKV09XCJwZXJmaWxFZGl0YWRvLmRlc2NyaXBjaW9uXCIgcGxhY2Vob2xkZXI9XCJDdWVudGEgYnJldmVtZW50ZSBhIHF1w6kgc2UgZGVkaWNhIGxhIGVtcHJlc2EuLi5cIj48L3RleHRhcmVhPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgPGxhYmVsPlN0YWNrIFRlY25vbMOzZ2ljbyAvIEhlcnJhbWllbnRhczwvbGFiZWw+XHJcbiAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIFsobmdNb2RlbCldPVwicGVyZmlsRWRpdGFkby5zdGFja190ZWNub2xvZ2ljb1wiIHBsYWNlaG9sZGVyPVwiRWo6IEFuZ3VsYXIsIE5vZGUuanMsIFB5dGhvbiwgUG9zdGdyZVNRTCwgUHlUb3JjaCwgRG9ja2VyXCI+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICA8bGFiZWw+VHJheWVjdG9yaWEgeSBQcm95ZWN0b3M8L2xhYmVsPlxyXG4gICAgICAgICAgICA8dGV4dGFyZWEgcm93cz1cIjNcIiBbKG5nTW9kZWwpXT1cInBlcmZpbEVkaXRhZG8udHJheWVjdG9yaWFcIiBwbGFjZWhvbGRlcj1cIkHDsW9zIGVuIGVsIG1lcmNhZG8sIHByb3llY3RvcyBkZXN0YWNhZG9zLi4uXCI+PC90ZXh0YXJlYT5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgIDxsYWJlbD5CZW5lZmljaW9zIHBhcmEgRXN0dWRpYW50ZXMgLyBQYXNhbnTDrWFzPC9sYWJlbD5cclxuICAgICAgICAgICAgPHRleHRhcmVhIHJvd3M9XCIzXCIgWyhuZ01vZGVsKV09XCJwZXJmaWxFZGl0YWRvLmJlbmVmaWNpb3NcIiBwbGFjZWhvbGRlcj1cIkTDrWFzIHBvciBleGFtZW4sIG1lbnRvcmVvIHTDqWNuaWNvLCBmbGV4aWJpbGlkYWQgaG9yYXJpYS4uLlwiPjwvdGV4dGFyZWE+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDwvZGl2PlxyXG4gICAgfVxyXG5cclxuICB9XHJcbjwvZGl2PiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSxTQUNFLFdBSUEsT0FDQSxRQUNBLGNBQ0EsUUFDQSx5QkFDSztBQUVQLFNBQVMsY0FBYyxnQkFBZ0I7QUFDdkMsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxRQUFRLHNCQUFzQjs7Ozs7O0FDWm5DLElBQUEsNEJBQUEsR0FBQSxPQUFBLENBQUE7QUFBcUIsSUFBQSxvQkFBQSxHQUFBLDBCQUFBO0FBQW1CLElBQUEsMEJBQUE7Ozs7OztBQWFwQyxJQUFBLDRCQUFBLEdBQUEsVUFBQSxDQUFBO0FBQStCLElBQUEsd0JBQUEsU0FBQSxTQUFBLDhFQUFBO0FBQUEsTUFBQSwyQkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBLENBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsT0FBQSxDQUFRO0lBQUEsQ0FBQTtBQUFFLElBQUEsb0JBQUEsR0FBQSxlQUFBO0FBQVEsSUFBQSwwQkFBQTs7Ozs7O0FBSTVELElBQUEsNEJBQUEsR0FBQSxVQUFBLEVBQUE7QUFBNkIsSUFBQSx3QkFBQSxTQUFBLFNBQUEsNEZBQUE7QUFBQSxNQUFBLDJCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUEsQ0FBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxlQUFBLENBQWdCO0lBQUEsQ0FBQTtBQUFFLElBQUEsb0JBQUEsR0FBQSw0QkFBQTtBQUFnQixJQUFBLDBCQUFBOzs7Ozs7QUFFdEUsSUFBQSw0QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUErQixJQUFBLHdCQUFBLFNBQUEsU0FBQSw0RkFBQTtBQUFBLE1BQUEsMkJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQSxDQUFBO0FBQUEsYUFBQSx5QkFBUyxPQUFBLGdCQUFBLENBQWlCO0lBQUEsQ0FBQTtBQUF5QyxJQUFBLG9CQUFBLEdBQUEsaUJBQUE7QUFBVSxJQUFBLDBCQUFBO0FBQzVHLElBQUEsNEJBQUEsR0FBQSxVQUFBLEVBQUE7QUFBNEIsSUFBQSx3QkFBQSxTQUFBLFNBQUEsNEZBQUE7QUFBQSxNQUFBLDJCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUEsQ0FBQTtBQUFBLGFBQUEseUJBQVMsT0FBQSxlQUFBLENBQWdCO0lBQUEsQ0FBQTtBQUNyRCxJQUFBLG9CQUFBLENBQUE7QUFDRixJQUFBLDBCQUFBOzs7O0FBSDZELElBQUEsd0JBQUEsWUFBQSxPQUFBLGFBQUEsT0FBQSxZQUFBO0FBQ0osSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxZQUFBLE9BQUEsYUFBQSxPQUFBLFlBQUE7QUFDdkQsSUFBQSx1QkFBQTtBQUFBLElBQUEsZ0NBQUEsS0FBQSxPQUFBLFlBQUEsd0JBQUEsT0FBQSxlQUFBLCtCQUFBLDRCQUFBLEdBQUE7Ozs7O0FBTEYsSUFBQSxpQ0FBQSxHQUFBLG1FQUFBLEdBQUEsR0FBQSxVQUFBLENBQUEsRUFBb0IsR0FBQSxtRUFBQSxHQUFBLENBQUE7Ozs7QUFBcEIsSUFBQSwyQkFBQSxDQUFBLE9BQUEsY0FBQSxJQUFBLENBQUE7Ozs7O0FBc0JRLElBQUEsdUJBQUEsR0FBQSxPQUFBLEVBQUE7Ozs7QUFBeUIsSUFBQSx3QkFBQSxPQUFBLDRCQUFBLFNBQUEsT0FBQSxPQUFBLFlBQUEsT0FBQSxPQUFBLFdBQUEsQ0FBc0QsRUFBQSxPQUFBLE9BQUEsT0FBQSxNQUFBLDBCQUFBOzs7OztBQUUvRSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQThCLElBQUEsb0JBQUEsR0FBQSxXQUFBO0FBQUUsSUFBQSwwQkFBQTs7Ozs7QUFXUCxJQUFBLDRCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQTBELElBQUEsb0JBQUEsR0FBQSxlQUFBO0FBQU0sSUFBQSwwQkFBQTs7OztBQUE3RCxJQUFBLHdCQUFBLFFBQUEsT0FBQSxPQUFBLFdBQUEsMEJBQUE7Ozs7O0FBQ0osSUFBQSw0QkFBQSxHQUFBLEtBQUEsRUFBQTtBQUF5RCxJQUFBLG9CQUFBLEdBQUEsb0JBQUE7QUFBVyxJQUFBLDBCQUFBOzs7O0FBQWpFLElBQUEsd0JBQUEsUUFBQSxPQUFBLE9BQUEsVUFBQSwwQkFBQTs7Ozs7QUFDSCxJQUFBLDRCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQW1CLElBQUEsb0JBQUEsQ0FBQTtBQUF3QixJQUFBLDBCQUFBOzs7O0FBQXhCLElBQUEsdUJBQUE7QUFBQSxJQUFBLGdDQUFBLGNBQUEsT0FBQSxPQUFBLFFBQUE7Ozs7O0FBbkJuRCxJQUFBLDRCQUFBLEdBQUEsVUFBQSxFQUFBLEVBQTBCLEdBQUEsT0FBQSxFQUFBLEVBQ0QsR0FBQSxPQUFBLEVBQUE7QUFFbkIsSUFBQSxpQ0FBQSxHQUFBLG1FQUFBLEdBQUEsR0FBQSxPQUFBLEVBQUEsRUFBbUIsR0FBQSxtRUFBQSxHQUFBLEdBQUEsT0FBQSxFQUFBO0FBS3JCLElBQUEsMEJBQUE7QUFFQSxJQUFBLDRCQUFBLEdBQUEsT0FBQSxFQUFBLEVBQXVCLEdBQUEsSUFBQTtBQUNqQixJQUFBLG9CQUFBLENBQUE7QUFBMkMsSUFBQSwwQkFBQTtBQUMvQyxJQUFBLDRCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQXdCLElBQUEsb0JBQUEsQ0FBQTtBQUErQyxJQUFBLDBCQUFBO0FBRXZFLElBQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBdUIsSUFBQSxRQUFBLEVBQUE7QUFDVSxJQUFBLG9CQUFBLEVBQUE7QUFBc0MsSUFBQSwwQkFBQTtBQUNyRSxJQUFBLDRCQUFBLElBQUEsUUFBQSxFQUFBO0FBQW1CLElBQUEsb0JBQUEsRUFBQTtBQUEyRCxJQUFBLDBCQUFBO0FBQzlFLElBQUEsaUNBQUEsSUFBQSxvRUFBQSxHQUFBLEdBQUEsS0FBQSxFQUFBO0FBQ0EsSUFBQSxpQ0FBQSxJQUFBLG9FQUFBLEdBQUEsR0FBQSxLQUFBLEVBQUE7QUFDQSxJQUFBLGlDQUFBLElBQUEsb0VBQUEsR0FBQSxHQUFBLFFBQUEsRUFBQTtBQUNBLElBQUEsNEJBQUEsSUFBQSxRQUFBLEVBQUE7QUFBbUIsSUFBQSxvQkFBQSxFQUFBO0FBQXFCLElBQUEsMEJBQUEsRUFBTyxFQUMzQyxFQUNGLEVBQ0Y7QUFJUixJQUFBLDRCQUFBLElBQUEsT0FBQSxFQUFBLEVBQTBCLElBQUEsV0FBQSxFQUFBLEVBQ0MsSUFBQSxXQUFBLEVBQUEsRUFDRCxJQUFBLElBQUE7QUFDaEIsSUFBQSxvQkFBQSxJQUFBLGtDQUFBO0FBQXNCLElBQUEsMEJBQUE7QUFDMUIsSUFBQSw0QkFBQSxJQUFBLEdBQUE7QUFBRyxJQUFBLG9CQUFBLEVBQUE7QUFBc0QsSUFBQSwwQkFBQSxFQUFJO0FBRy9ELElBQUEsNEJBQUEsSUFBQSxXQUFBLEVBQUEsRUFBc0IsSUFBQSxJQUFBO0FBQ2hCLElBQUEsb0JBQUEsSUFBQSwrQ0FBQTtBQUFtQyxJQUFBLDBCQUFBO0FBQ3ZDLElBQUEsNEJBQUEsSUFBQSxHQUFBO0FBQUcsSUFBQSxvQkFBQSxFQUFBO0FBQWtFLElBQUEsMEJBQUEsRUFBSSxFQUNqRTtBQUdaLElBQUEsNEJBQUEsSUFBQSxXQUFBLEVBQUEsRUFBeUIsSUFBQSxXQUFBLEVBQUEsRUFDRCxJQUFBLElBQUE7QUFDaEIsSUFBQSxvQkFBQSxJQUFBLDhDQUFBO0FBQXFDLElBQUEsMEJBQUE7QUFDekMsSUFBQSw0QkFBQSxJQUFBLEdBQUE7QUFBRyxJQUFBLG9CQUFBLEVBQUE7QUFBcUUsSUFBQSwwQkFBQSxFQUFJO0FBRzlFLElBQUEsNEJBQUEsSUFBQSxXQUFBLEVBQUEsRUFBc0IsSUFBQSxJQUFBO0FBQ2hCLElBQUEsb0JBQUEsSUFBQSx1Q0FBQTtBQUE4QixJQUFBLDBCQUFBO0FBQ2xDLElBQUEsNEJBQUEsSUFBQSxHQUFBO0FBQUcsSUFBQSxvQkFBQSxFQUFBO0FBQXdELElBQUEsMEJBQUEsRUFBSSxFQUN2RCxFQUNGOzs7O0FBL0NOLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsMkJBQUEsT0FBQSxPQUFBLE9BQUEsSUFBQSxDQUFBO0FBUUksSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSxPQUFBLE9BQUEsWUFBQSxPQUFBLE9BQUEsV0FBQTtBQUNvQixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLE9BQUEsT0FBQSxVQUFBLHdCQUFBO0FBR1MsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxjQUFBLE9BQUEsT0FBQSxhQUFBLFlBQUE7QUFDWixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLGNBQUEsT0FBQSxPQUFBLGdCQUFBLDhCQUFBO0FBQ25CLElBQUEsdUJBQUE7QUFBQSxJQUFBLDJCQUFBLE9BQUEsT0FBQSxZQUFBLEtBQUEsRUFBQTtBQUNBLElBQUEsdUJBQUE7QUFBQSxJQUFBLDJCQUFBLE9BQUEsT0FBQSxXQUFBLEtBQUEsRUFBQTtBQUNBLElBQUEsdUJBQUE7QUFBQSxJQUFBLDJCQUFBLE9BQUEsT0FBQSxXQUFBLEtBQUEsRUFBQTtBQUNtQixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLGNBQUEsT0FBQSxPQUFBLEtBQUE7QUFXbEIsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSxPQUFBLE9BQUEsZUFBQSw2QkFBQTtBQUtBLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsK0JBQUEsT0FBQSxPQUFBLHFCQUFBLG1DQUFBO0FBT0EsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSxPQUFBLE9BQUEsZUFBQSw0Q0FBQTtBQUtBLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsK0JBQUEsT0FBQSxPQUFBLGNBQUEsNkJBQUE7Ozs7O0FBa0NLLElBQUEsdUJBQUEsR0FBQSxPQUFBLEVBQUE7Ozs7QUFBSyxJQUFBLHdCQUFBLE9BQUEsT0FBQSxhQUFBLDBCQUFBOzs7OztBQUVMLElBQUEsNEJBQUEsR0FBQSxNQUFBO0FBQU0sSUFBQSxvQkFBQSxHQUFBLFVBQUE7QUFBUSxJQUFBLDBCQUFBOzs7OztBQU1kLElBQUEsNEJBQUEsR0FBQSxTQUFBLEVBQUE7QUFBNkIsSUFBQSxvQkFBQSxHQUFBLDJCQUFBO0FBQW9CLElBQUEsMEJBQUE7Ozs7OztBQS9CL0QsSUFBQSw0QkFBQSxHQUFBLE9BQUEsQ0FBQSxFQUFvQyxHQUFBLElBQUE7QUFDOUIsSUFBQSxvQkFBQSxHQUFBLDhDQUFBO0FBQWtDLElBQUEsMEJBQUE7QUFHdEMsSUFBQSw0QkFBQSxHQUFBLE9BQUEsRUFBQSxFQUFnQyxHQUFBLE9BQUE7QUFFNUIsSUFBQSxvQkFBQSxHQUFBLGdCQUFBO0FBQUcsSUFBQSw0QkFBQSxHQUFBLFFBQUE7QUFBUSxJQUFBLG9CQUFBLEdBQUEsa0JBQUE7QUFBYSxJQUFBLDBCQUFBO0FBQVUsSUFBQSxvQkFBQSxDQUFBO0FBQ2xDLElBQUEsNEJBQUEsR0FBQSxRQUFBO0FBQVEsSUFBQSxvQkFBQSxJQUFBLFFBQUE7QUFBTSxJQUFBLDBCQUFBO0FBQVUsSUFBQSxvQkFBQSxFQUFBO0FBQ3hCLElBQUEsNEJBQUEsSUFBQSxRQUFBO0FBQVEsSUFBQSxvQkFBQSxJQUFBLHNCQUFBO0FBQWlCLElBQUEsMEJBQUE7QUFBVSxJQUFBLG9CQUFBLEVBQUE7QUFDckMsSUFBQSwwQkFBQSxFQUFRO0FBR1YsSUFBQSw0QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUErQixJQUFBLE9BQUEsRUFBQSxFQUdELElBQUEsSUFBQTtBQUN0QixJQUFBLG9CQUFBLElBQUEsa0NBQUE7QUFBb0IsSUFBQSwwQkFBQTtBQUV4QixJQUFBLDRCQUFBLElBQUEsT0FBQSxFQUFBLEVBQXdCLElBQUEsT0FBQTtBQUNmLElBQUEsb0JBQUEsSUFBQSxvQkFBQTtBQUFrQixJQUFBLDBCQUFBO0FBQ3pCLElBQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBbUMsSUFBQSxPQUFBLEVBQUE7QUFFL0IsSUFBQSxpQ0FBQSxJQUFBLHFFQUFBLEdBQUEsR0FBQSxPQUFBLEVBQUEsRUFBbUIsSUFBQSxxRUFBQSxHQUFBLEdBQUEsTUFBQTtBQUtyQixJQUFBLDBCQUFBO0FBQ0EsSUFBQSw0QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUE2QixJQUFBLFNBQUEsRUFBQTtBQUNrQyxJQUFBLHdCQUFBLFVBQUEsU0FBQSw4RUFBQSxRQUFBO0FBQUEsTUFBQSwyQkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBLENBQUE7QUFBQSxhQUFBLHlCQUFVLE9BQUEsZUFBQSxNQUFBLENBQXNCO0lBQUEsQ0FBQTtBQUE3RixJQUFBLDBCQUFBO0FBQ0EsSUFBQSxpQ0FBQSxJQUFBLHFFQUFBLEdBQUEsR0FBQSxTQUFBLEVBQUE7QUFHRixJQUFBLDBCQUFBLEVBQU0sRUFDRjtBQUdSLElBQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBd0IsSUFBQSxPQUFBO0FBQ2YsSUFBQSxvQkFBQSxJQUFBLHNCQUFBO0FBQW9CLElBQUEsMEJBQUE7QUFDM0IsSUFBQSw0QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUFRLElBQUEsOEJBQUEsaUJBQUEsU0FBQSxzRkFBQSxRQUFBO0FBQUEsTUFBQSwyQkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBLENBQUE7QUFBQSxNQUFBLGdDQUFBLE9BQUEsY0FBQSxXQUFBLE1BQUEsTUFBQSxPQUFBLGNBQUEsWUFBQTtBQUFBLGFBQUEseUJBQUEsTUFBQTtJQUFBLENBQUE7QUFDTixJQUFBLDRCQUFBLElBQUEsVUFBQSxFQUFBO0FBQTJCLElBQUEsb0JBQUEsSUFBQSxZQUFBO0FBQVUsSUFBQSwwQkFBQTtBQUNyQyxJQUFBLDRCQUFBLElBQUEsVUFBQSxFQUFBO0FBQXdCLElBQUEsb0JBQUEsSUFBQSxZQUFBO0FBQU8sSUFBQSwwQkFBQTtBQUMvQixJQUFBLDRCQUFBLElBQUEsVUFBQSxFQUFBO0FBQXVCLElBQUEsb0JBQUEsSUFBQSxRQUFBO0FBQU0sSUFBQSwwQkFBQSxFQUFTLEVBQy9CO0FBR1gsSUFBQSw0QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUF3QixJQUFBLE9BQUE7QUFDZixJQUFBLG9CQUFBLElBQUEsaUNBQUE7QUFBK0IsSUFBQSwwQkFBQTtBQUN0QyxJQUFBLDRCQUFBLElBQUEsU0FBQSxFQUFBO0FBQW1CLElBQUEsOEJBQUEsaUJBQUEsU0FBQSxxRkFBQSxRQUFBO0FBQUEsTUFBQSwyQkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBLENBQUE7QUFBQSxNQUFBLGdDQUFBLE9BQUEsY0FBQSxjQUFBLE1BQUEsTUFBQSxPQUFBLGNBQUEsZUFBQTtBQUFBLGFBQUEseUJBQUEsTUFBQTtJQUFBLENBQUE7QUFBbkIsSUFBQSwwQkFBQSxFQUFpSCxFQUM3RztBQUlSLElBQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBNEIsSUFBQSxJQUFBO0FBQ3RCLElBQUEsb0JBQUEsSUFBQSw4QkFBQTtBQUFxQixJQUFBLDBCQUFBO0FBRXpCLElBQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBd0IsSUFBQSxPQUFBO0FBQ2YsSUFBQSxvQkFBQSxJQUFBLFdBQUE7QUFBUyxJQUFBLDBCQUFBO0FBQ2hCLElBQUEsNEJBQUEsSUFBQSxTQUFBLEVBQUE7QUFBa0IsSUFBQSw4QkFBQSxpQkFBQSxTQUFBLHFGQUFBLFFBQUE7QUFBQSxNQUFBLDJCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUEsQ0FBQTtBQUFBLE1BQUEsZ0NBQUEsT0FBQSxjQUFBLFdBQUEsTUFBQSxNQUFBLE9BQUEsY0FBQSxZQUFBO0FBQUEsYUFBQSx5QkFBQSxNQUFBO0lBQUEsQ0FBQTtBQUFsQixJQUFBLDBCQUFBLEVBQTBGO0FBRzVGLElBQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBd0IsSUFBQSxPQUFBO0FBQ2YsSUFBQSxvQkFBQSxJQUFBLG9CQUFBO0FBQWtCLElBQUEsMEJBQUE7QUFDekIsSUFBQSw0QkFBQSxJQUFBLFNBQUEsRUFBQTtBQUFrQixJQUFBLDhCQUFBLGlCQUFBLFNBQUEscUZBQUEsUUFBQTtBQUFBLE1BQUEsMkJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQSxDQUFBO0FBQUEsTUFBQSxnQ0FBQSxPQUFBLGNBQUEsVUFBQSxNQUFBLE1BQUEsT0FBQSxjQUFBLFdBQUE7QUFBQSxhQUFBLHlCQUFBLE1BQUE7SUFBQSxDQUFBO0FBQWxCLElBQUEsMEJBQUEsRUFBc0c7QUFHeEcsSUFBQSw0QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUF3QixJQUFBLE9BQUE7QUFDZixJQUFBLG9CQUFBLElBQUEseUJBQUE7QUFBb0IsSUFBQSwwQkFBQTtBQUMzQixJQUFBLDRCQUFBLElBQUEsU0FBQSxFQUFBO0FBQW1CLElBQUEsOEJBQUEsaUJBQUEsU0FBQSxxRkFBQSxRQUFBO0FBQUEsTUFBQSwyQkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBLENBQUE7QUFBQSxNQUFBLGdDQUFBLE9BQUEsY0FBQSxVQUFBLE1BQUEsTUFBQSxPQUFBLGNBQUEsV0FBQTtBQUFBLGFBQUEseUJBQUEsTUFBQTtJQUFBLENBQUE7QUFBbkIsSUFBQSwwQkFBQSxFQUF1RixFQUNuRixFQUNGO0FBS1IsSUFBQSw0QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUFtRSxJQUFBLElBQUE7QUFDN0QsSUFBQSxvQkFBQSxJQUFBLG9DQUFBO0FBQXdCLElBQUEsMEJBQUE7QUFFNUIsSUFBQSw0QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUF3QixJQUFBLE9BQUE7QUFDZixJQUFBLG9CQUFBLElBQUEsd0JBQUE7QUFBbUIsSUFBQSwwQkFBQTtBQUMxQixJQUFBLDRCQUFBLElBQUEsWUFBQSxFQUFBO0FBQW1CLElBQUEsOEJBQUEsaUJBQUEsU0FBQSx3RkFBQSxRQUFBO0FBQUEsTUFBQSwyQkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBLENBQUE7QUFBQSxNQUFBLGdDQUFBLE9BQUEsY0FBQSxhQUFBLE1BQUEsTUFBQSxPQUFBLGNBQUEsY0FBQTtBQUFBLGFBQUEseUJBQUEsTUFBQTtJQUFBLENBQUE7QUFBc0csSUFBQSwwQkFBQSxFQUFXO0FBR3RJLElBQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBd0IsSUFBQSxPQUFBO0FBQ2YsSUFBQSxvQkFBQSxJQUFBLHFDQUFBO0FBQWdDLElBQUEsMEJBQUE7QUFDdkMsSUFBQSw0QkFBQSxJQUFBLFNBQUEsRUFBQTtBQUFtQixJQUFBLDhCQUFBLGlCQUFBLFNBQUEscUZBQUEsUUFBQTtBQUFBLE1BQUEsMkJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSwyQkFBQSxDQUFBO0FBQUEsTUFBQSxnQ0FBQSxPQUFBLGNBQUEsbUJBQUEsTUFBQSxNQUFBLE9BQUEsY0FBQSxvQkFBQTtBQUFBLGFBQUEseUJBQUEsTUFBQTtJQUFBLENBQUE7QUFBbkIsSUFBQSwwQkFBQSxFQUF5STtBQUczSSxJQUFBLDRCQUFBLElBQUEsT0FBQSxFQUFBLEVBQXdCLElBQUEsT0FBQTtBQUNmLElBQUEsb0JBQUEsSUFBQSx5QkFBQTtBQUF1QixJQUFBLDBCQUFBO0FBQzlCLElBQUEsNEJBQUEsSUFBQSxZQUFBLEVBQUE7QUFBbUIsSUFBQSw4QkFBQSxpQkFBQSxTQUFBLHdGQUFBLFFBQUE7QUFBQSxNQUFBLDJCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUEsQ0FBQTtBQUFBLE1BQUEsZ0NBQUEsT0FBQSxjQUFBLGFBQUEsTUFBQSxNQUFBLE9BQUEsY0FBQSxjQUFBO0FBQUEsYUFBQSx5QkFBQSxNQUFBO0lBQUEsQ0FBQTtBQUFrRyxJQUFBLDBCQUFBLEVBQVc7QUFHbEksSUFBQSw0QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUF3QixJQUFBLE9BQUE7QUFDZixJQUFBLG9CQUFBLElBQUEsNENBQUE7QUFBdUMsSUFBQSwwQkFBQTtBQUM5QyxJQUFBLDRCQUFBLElBQUEsWUFBQSxFQUFBO0FBQW1CLElBQUEsOEJBQUEsaUJBQUEsU0FBQSx3RkFBQSxRQUFBO0FBQUEsTUFBQSwyQkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDJCQUFBLENBQUE7QUFBQSxNQUFBLGdDQUFBLE9BQUEsY0FBQSxZQUFBLE1BQUEsTUFBQSxPQUFBLGNBQUEsYUFBQTtBQUFBLGFBQUEseUJBQUEsTUFBQTtJQUFBLENBQUE7QUFBZ0gsSUFBQSwwQkFBQSxFQUFXLEVBQzFJLEVBQ0Y7Ozs7QUEzRmdDLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsZ0NBQUEsS0FBQSxPQUFBLGNBQUEsYUFBQSxLQUFBO0FBQ1YsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxLQUFBLE9BQUEsY0FBQSxPQUFBLEtBQUE7QUFDVyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLEtBQUEsT0FBQSxjQUFBLGlCQUFBLE9BQUEsSUFBQSxPQUFBLGNBQUEsbUJBQUEsT0FBQSxPQUFBLGNBQUEsbUJBQUEsSUFBQSxHQUFBO0FBYzdCLElBQUEsdUJBQUEsRUFBQTtBQUFBLElBQUEsMkJBQUEsT0FBQSxjQUFBLEtBQUEsRUFBQTtBQU8rRixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLFlBQUEsT0FBQSxZQUFBO0FBQy9GLElBQUEsdUJBQUE7QUFBQSxJQUFBLDJCQUFBLE9BQUEsZUFBQSxLQUFBLEVBQUE7QUFTSSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDhCQUFBLFdBQUEsT0FBQSxjQUFBLFNBQUE7QUFTVyxJQUFBLHVCQUFBLEVBQUE7QUFBQSxJQUFBLDhCQUFBLFdBQUEsT0FBQSxjQUFBLFlBQUE7QUFVRCxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDhCQUFBLFdBQUEsT0FBQSxjQUFBLFNBQUE7QUFLQSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDhCQUFBLFdBQUEsT0FBQSxjQUFBLFFBQUE7QUFLQyxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDhCQUFBLFdBQUEsT0FBQSxjQUFBLFFBQUE7QUFZRixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDhCQUFBLFdBQUEsT0FBQSxjQUFBLFdBQUE7QUFLQSxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDhCQUFBLFdBQUEsT0FBQSxjQUFBLGlCQUFBO0FBS0EsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSw4QkFBQSxXQUFBLE9BQUEsY0FBQSxXQUFBO0FBS0EsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSw4QkFBQSxXQUFBLE9BQUEsY0FBQSxVQUFBOzs7OztBQXhMM0IsSUFBQSw0QkFBQSxHQUFBLE9BQUEsQ0FBQSxFQUEyQixHQUFBLE9BQUEsQ0FBQSxFQUNBLEdBQUEsSUFBQTtBQUNuQixJQUFBLG9CQUFBLEdBQUEsZ0NBQUE7QUFBdUIsSUFBQSwwQkFBQTtBQUMzQixJQUFBLDRCQUFBLEdBQUEsS0FBQSxDQUFBO0FBQXFCLElBQUEsb0JBQUEsR0FBQSw2REFBQTtBQUFxRCxJQUFBLDBCQUFBLEVBQUk7QUFHaEYsSUFBQSw0QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNBLElBQUEsaUNBQUEsR0FBQSxxREFBQSxHQUFBLEdBQUEsVUFBQSxDQUFBLEVBQW1CLEdBQUEscURBQUEsR0FBQSxDQUFBO0FBY3JCLElBQUEsMEJBQUEsRUFBTTtBQU1OLElBQUEsaUNBQUEsR0FBQSxxREFBQSxJQUFBLEVBQUEsRUFBb0IsSUFBQSxzREFBQSxJQUFBLElBQUEsT0FBQSxDQUFBOzs7O0FBcEJsQixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLDJCQUFBLE9BQUEsY0FBQSxJQUFBLENBQUE7QUFvQkYsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxDQUFBLE9BQUEsY0FBQSxJQUFBLEVBQUE7OztBRGdCRSxJQUFPLGlCQUFQLE1BQU8sZ0JBQWM7RUFDakIsT0FBTyxPQUFPLFVBQVU7RUFDeEIsY0FBYyxPQUFPLFdBQVc7RUFDaEMsU0FBUyxPQUFPLE1BQU07RUFDdEIsUUFBUSxPQUFPLGNBQWM7RUFDN0IsV0FBVyxPQUFPLFFBQVE7RUFDMUIsTUFBTSxPQUFPLGlCQUFpQjtFQUU5QixTQUFTO0VBQ1IsWUFBWTs7RUFFWixpQkFBaUM7RUFDakMsY0FBdUI7RUFDdEIsY0FBYyxJQUFJLGFBQVk7RUFFeEMsU0FBMkIsS0FBSyxrQkFBaUI7RUFDakQsZ0JBQWtDLEtBQUssa0JBQWlCO0VBRXhELGNBQXVCOztFQUN2QixjQUF1QjtFQUN2QixXQUFvQjtFQUNwQixZQUFxQjtFQUNyQixlQUF3QjtFQUN4QixjQUE2QjtFQUM3QiwwQkFBdUM7RUFFdkMsV0FBUTtBQUNOLFNBQUssb0JBQW1CO0VBQzFCO0VBRUEsWUFBWSxTQUFzQjtBQUNoQyxRQUFJLFFBQVEsZ0JBQWdCLEtBQUssQ0FBQyxRQUFRLGdCQUFnQixFQUFFLGNBQWEsR0FBSTtBQUMzRSxXQUFLLGNBQWM7QUFDbkIsV0FBSyxvQkFBbUI7SUFDMUI7RUFDRjtFQUVBLG9CQUFpQjtBQUNmLFdBQU87TUFDTCxZQUFZO01BQ1osYUFBYTtNQUNiLFVBQVU7TUFDVixNQUFNO01BQ04sT0FBTztNQUNQLFFBQVE7TUFDUixlQUFlO01BQ2Ysa0JBQWtCO01BQ2xCLFdBQVc7TUFDWCxNQUFNO01BQ04sYUFBYTtNQUNiLGFBQWE7TUFDYixtQkFBbUI7TUFDbkIsWUFBWTtNQUNaLFdBQVc7TUFDWCxjQUFjO01BQ2QsV0FBVztNQUNYLFVBQVU7TUFDVixVQUFVOztFQUVkO0VBRUEsc0JBQW1CO0FBQ2pCLFNBQUssV0FBVztBQUVoQixVQUFNLFVBQVUsS0FBSyxNQUFNLFNBQVMsU0FBUyxJQUFJLElBQUk7QUFDckQsUUFBSTtBQUdKLFFBQUksS0FBSyxnQkFBZ0I7QUFDdkIsV0FBSyxjQUFjO0FBQ25CLGtCQUFZLE9BQU8sS0FBSyxjQUFjO0lBQ3hDLFdBRVMsU0FBUztBQUNoQixXQUFLLGNBQWM7QUFDbkIsa0JBQVksT0FBTyxPQUFPO0lBQzVCLE9BRUs7QUFDSCxXQUFLLGNBQWM7QUFDbkIsWUFBTSxPQUFPLEtBQUssWUFBWSxpQkFBZ0I7QUFFOUMsVUFBSSxDQUFDLFFBQVMsQ0FBQyxLQUFLLE1BQU0sQ0FBQyxLQUFLLFlBQWE7QUFDM0MsZ0JBQVEsTUFBTSwwREFBaUQ7QUFDL0QsYUFBSyxXQUFXO0FBQ2hCLGFBQUssT0FBTyxTQUFTLENBQUMsU0FBUyxDQUFDO0FBQ2hDO01BQ0Y7QUFFQSxrQkFBWSxLQUFLLE1BQU0sS0FBSztJQUM5QjtBQUVBLFNBQUssS0FBSyxJQUFTLEdBQUcsS0FBSyxNQUFNLG1CQUFtQixTQUFTLEVBQUUsRUFBRSxVQUFVO01BQ3pFLE1BQU0sQ0FBQyxRQUFPO0FBQ1osWUFBSSxJQUFJLFdBQVcsSUFBSSxRQUFRO0FBQzdCLGVBQUssU0FBUyxrQ0FBSyxLQUFLLGtCQUFpQixJQUFPLElBQUk7QUFHcEQsY0FBSSxLQUFLLE9BQU8sUUFBUSxDQUFDLEtBQUssT0FBTyxLQUFLLFdBQVcsTUFBTSxHQUFHO0FBQzVELGlCQUFLLE9BQU8sT0FBTyxHQUFHLEtBQUssU0FBUyxHQUFHLEtBQUssT0FBTyxLQUFLLFdBQVcsR0FBRyxJQUFJLEtBQUssR0FBRyxHQUFHLEtBQUssT0FBTyxJQUFJO1VBQ3ZHO0FBRUEsZUFBSyxnQkFBZ0IsZ0JBQWdCLEtBQUssTUFBTTtBQUNoRCxlQUFLLGNBQWMsS0FBSyxjQUFjLFFBQVEsQ0FBQyxLQUFLLE9BQU87UUFDN0Q7QUFDQSxhQUFLLFdBQVc7QUFDaEIsYUFBSyxJQUFJLGNBQWE7TUFDeEI7TUFDQSxPQUFPLENBQUMsUUFBTztBQUNiLGdCQUFRLE1BQU0sNEJBQTRCLEdBQUc7QUFDN0MsYUFBSyxjQUFjLENBQUMsS0FBSztBQUN6QixhQUFLLFdBQVc7QUFDaEIsYUFBSyxJQUFJLGNBQWE7TUFDeEI7S0FDRDtFQUNIO0VBRUEsU0FBTTtBQUNKLFFBQUksS0FBSyxnQkFBZ0I7QUFDdkIsV0FBSyxZQUFZLEtBQUk7SUFDdkIsT0FBTztBQUNMLFdBQUssU0FBUyxLQUFJO0lBQ3BCO0VBQ0Y7RUFFQSxpQkFBYztBQUNaLFFBQUksS0FBSztBQUFhO0FBQ3RCLFNBQUssZ0JBQWdCLGdCQUFnQixLQUFLLE1BQU07QUFDaEQsU0FBSyxjQUFjLEtBQUssT0FBTyxRQUFRO0FBQ3ZDLFNBQUssY0FBYztFQUNyQjtFQUVBLGtCQUFlO0FBQ2IsUUFBSSxDQUFDLEtBQUssT0FBTyxXQUFXO0FBQzFCLFlBQU0sd0VBQWtFO0FBQ3hFO0lBQ0Y7QUFDQSxTQUFLLGNBQWM7QUFDbkIsU0FBSyxjQUFjLEtBQUssT0FBTyxRQUFRO0FBQ3ZDLFNBQUssMEJBQTBCO0FBQy9CLFNBQUssZUFBZTtFQUN0QjtFQUVBLGlCQUFjO0FBQ1osUUFBSSxLQUFLO0FBQWE7QUFFdEIsUUFBSSxLQUFLLGNBQWM7QUFDckIsWUFBTSxrRUFBa0U7QUFDeEU7SUFDRjtBQUNBLFNBQUssWUFBWTtBQUVqQixVQUFNLE9BQU8sS0FBSyxZQUFZLGlCQUFnQjtBQUM5QyxVQUFNLFlBQVksTUFBTSxNQUFNLE1BQU07QUFFcEMsUUFBSSxDQUFDLFdBQVc7QUFDZCxXQUFLLFlBQVk7QUFDakI7SUFDRjtBQUVBLFVBQU0sVUFBVTtNQUNkLFlBQVk7TUFDWixNQUFNLEtBQUssY0FBYztNQUN6QixhQUFhLEtBQUssY0FBYztNQUNoQyxhQUFhLEtBQUssY0FBYztNQUNoQyxtQkFBbUIsS0FBSyxjQUFjO01BQ3RDLFlBQVksS0FBSyxjQUFjO01BQy9CLFdBQVcsS0FBSyxjQUFjO01BQzlCLGNBQWMsS0FBSyxjQUFjO01BQ2pDLFdBQVcsS0FBSyxjQUFjO01BQzlCLFVBQVUsS0FBSyxjQUFjO01BQzdCLFVBQVUsS0FBSyxjQUFjOztBQUcvQixTQUFLLEtBQUssSUFBUyxHQUFHLEtBQUssTUFBTSxtQkFBbUIsT0FBTyxFQUFFLFVBQVU7TUFDckUsTUFBTSxDQUFDLFFBQU87QUFDWixZQUFJLElBQUksU0FBUztBQUNmLGVBQUssU0FBUyxnQkFBZ0IsS0FBSyxhQUFhO0FBQ2hELGNBQUksSUFBSSxXQUFXO0FBQ2pCLGlCQUFLLE9BQU8sWUFBWSxJQUFJO1VBQzlCO0FBQ0EsZUFBSyxjQUFjO0FBQ25CLGdCQUFNLCtCQUE0QjtRQUNwQztBQUNBLGFBQUssWUFBWTtBQUNqQixhQUFLLElBQUksY0FBYTtNQUN4QjtNQUNBLE9BQU8sQ0FBQyxRQUFPO0FBQ2IsZ0JBQVEsTUFBTSw0QkFBNEIsR0FBRztBQUM3QyxjQUFNLHNEQUFtRDtBQUN6RCxhQUFLLFlBQVk7QUFDakIsYUFBSyxJQUFJLGNBQWE7TUFDeEI7S0FDRDtFQUNIO0VBRUEsZUFBZSxPQUFZO0FBQ3pCLFFBQUksS0FBSztBQUFhO0FBRXRCLFVBQU0sUUFBUSxNQUFNO0FBRXBCLFFBQUksTUFBTSxTQUFTLE1BQU0sTUFBTSxDQUFDLEdBQUc7QUFDakMsWUFBTSxPQUFPLE1BQU0sTUFBTSxDQUFDO0FBRTFCLFVBQUksQ0FBQyxDQUFDLGNBQWMsYUFBYSxXQUFXLEVBQUUsU0FBUyxLQUFLLElBQUksR0FBRztBQUNqRSxjQUFNLG1EQUFnRDtBQUN0RCxjQUFNLFFBQVE7QUFDZDtNQUNGO0FBRUEsV0FBSywwQkFBMEI7QUFFL0IsWUFBTSxTQUFTLElBQUksV0FBVTtBQUM3QixhQUFPLFNBQVMsTUFBSztBQUNuQixhQUFLLGNBQWMsT0FBTztBQUMxQixhQUFLLElBQUksY0FBYTtNQUN4QjtBQUNBLGFBQU8sY0FBYyxJQUFJO0FBRXpCLFdBQUssa0JBQWtCLElBQUk7SUFDN0I7RUFDRjtFQUVBLGtCQUFrQixNQUFVO0FBQzFCLFFBQUksS0FBSztBQUFhO0FBQ3RCLFNBQUssZUFBZTtBQUVwQixVQUFNLFdBQVcsSUFBSSxTQUFRO0FBQzdCLGFBQVMsT0FBTyxRQUFRLElBQUk7QUFFNUIsU0FBSyxLQUFLLEtBQVUsR0FBRyxLQUFLLE1BQU0sd0JBQXdCLFFBQVEsRUFBRSxVQUFVO01BQzVFLE1BQU0sQ0FBQyxRQUFPO0FBQ1osWUFBSSxJQUFJLFdBQVcsSUFBSSxTQUFTO0FBQzlCLGNBQUksTUFBTSxJQUFJO0FBQ2QsY0FBSSxDQUFDLElBQUksV0FBVyxNQUFNLEdBQUc7QUFDM0Isa0JBQU0sR0FBRyxLQUFLLFNBQVMsR0FBRyxJQUFJLFdBQVcsR0FBRyxJQUFJLEtBQUssR0FBRyxHQUFHLEdBQUc7VUFDaEU7QUFDQSxlQUFLLGNBQWMsT0FBTztRQUM1QjtBQUNBLGFBQUssZUFBZTtBQUNwQixhQUFLLElBQUksY0FBYTtNQUN4QjtNQUNBLE9BQU8sQ0FBQyxRQUFPO0FBQ2IsZ0JBQVEsTUFBTSx3QkFBd0IsR0FBRztBQUN6QyxjQUFNLGtEQUFrRDtBQUN4RCxhQUFLLGVBQWU7QUFDcEIsYUFBSyxJQUFJLGNBQWE7TUFDeEI7S0FDRDtFQUNIOzs7Ozs7RUFRQSxJQUFJLFlBQVM7QUFDWCxRQUFJLENBQUMsS0FBSyxPQUFPO0FBQW1CLGFBQU8sQ0FBQTtBQUMzQyxXQUFPLEtBQUssT0FBTyxrQkFDaEIsTUFBTSxHQUFHLEVBQ1QsSUFBSSxVQUFRLEtBQUssS0FBSSxDQUFFLEVBQ3ZCLE9BQU8sVUFBUSxLQUFLLFNBQVMsQ0FBQztFQUNuQzs7Ozs7RUFNQSxpQkFBaUIsS0FBWTtBQUMzQixRQUFJLENBQUM7QUFBSyxhQUFPO0FBQ2pCLFFBQUksSUFBSSxXQUFXLFNBQVMsS0FBSyxJQUFJLFdBQVcsVUFBVSxHQUFHO0FBQzNELGFBQU87SUFDVDtBQUNBLFdBQU8sV0FBVyxHQUFHO0VBQ3ZCOztxQ0FuUlcsaUJBQWM7RUFBQTs0RUFBZCxpQkFBYyxXQUFBLENBQUEsQ0FBQSxxQkFBQSxDQUFBLEdBQUEsUUFBQSxFQUFBLGdCQUFBLGtCQUFBLGFBQUEsY0FBQSxHQUFBLFNBQUEsRUFBQSxhQUFBLGNBQUEsR0FBQSxVQUFBLENBQUEsaUNBQUEsR0FBQSxPQUFBLEdBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsa0JBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxHQUFBLENBQUEsR0FBQSxlQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxpQkFBQSxHQUFBLENBQUEsR0FBQSxnQkFBQSxHQUFBLENBQUEsR0FBQSxrQkFBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxjQUFBLEdBQUEsQ0FBQSxHQUFBLGdCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxrQkFBQSxHQUFBLFNBQUEsVUFBQSxHQUFBLENBQUEsR0FBQSxlQUFBLEdBQUEsU0FBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEsS0FBQSxHQUFBLENBQUEsR0FBQSxrQkFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxRQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsVUFBQSxVQUFBLEdBQUEsUUFBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsY0FBQSxHQUFBLENBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsb0JBQUEsR0FBQSxDQUFBLEdBQUEsbUJBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsdUJBQUEsR0FBQSxDQUFBLEdBQUEsY0FBQSxHQUFBLENBQUEsT0FBQSx5QkFBQSxHQUFBLEtBQUEsR0FBQSxDQUFBLEdBQUEsaUJBQUEsR0FBQSxDQUFBLFFBQUEsUUFBQSxVQUFBLG9DQUFBLEdBQUEsVUFBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLGVBQUEsR0FBQSxDQUFBLEdBQUEsaUJBQUEsU0FBQSxHQUFBLENBQUEsU0FBQSxZQUFBLEdBQUEsQ0FBQSxTQUFBLFlBQUEsR0FBQSxDQUFBLFNBQUEsUUFBQSxHQUFBLENBQUEsUUFBQSxRQUFBLGVBQUEsNkNBQUEsR0FBQSxpQkFBQSxTQUFBLEdBQUEsQ0FBQSxRQUFBLE9BQUEsZUFBQSx1QkFBQSxHQUFBLGlCQUFBLFNBQUEsR0FBQSxDQUFBLFFBQUEsT0FBQSxlQUFBLG9DQUFBLEdBQUEsaUJBQUEsU0FBQSxHQUFBLENBQUEsUUFBQSxRQUFBLGVBQUEsb0JBQUEsR0FBQSxpQkFBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLFFBQUEsYUFBQSxjQUFBLEdBQUEsY0FBQSxRQUFBLEdBQUEsQ0FBQSxRQUFBLEtBQUEsZUFBQSxzREFBQSxHQUFBLGlCQUFBLFNBQUEsR0FBQSxDQUFBLFFBQUEsUUFBQSxlQUFBLDZEQUFBLEdBQUEsaUJBQUEsU0FBQSxHQUFBLENBQUEsUUFBQSxLQUFBLGVBQUEsa0RBQUEsR0FBQSxpQkFBQSxTQUFBLEdBQUEsQ0FBQSxRQUFBLEtBQUEsZUFBQSxvRUFBQSxHQUFBLGlCQUFBLFNBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSx3QkFBQSxJQUFBLEtBQUE7QUFBQSxRQUFBLEtBQUEsR0FBQTtBQ2xEM0IsTUFBQSw0QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUVFLE1BQUEsaUNBQUEsR0FBQSx1Q0FBQSxHQUFBLEdBQUEsT0FBQSxDQUFBLEVBQWdCLEdBQUEsdUNBQUEsSUFBQSxDQUFBO0FBcU1sQixNQUFBLDBCQUFBOzs7QUFyTUUsTUFBQSx1QkFBQTtBQUFBLE1BQUEsMkJBQUEsSUFBQSxXQUFBLElBQUEsQ0FBQTs7b0JENENVLGNBQVksWUFBQSxzQkFBQSxZQUFBLFNBQUEscUJBQUEsWUFBQSxhQUFBLGlCQUFBLG9CQUFBLGFBQUEsaUJBQUUsYUFBVyx1QkFBQSxtQkFBQSxpQ0FBQSx5QkFBQSx3QkFBQSx1QkFBQSxpQ0FBQSwrQkFBQSx1Q0FBQSw4QkFBQSxvQkFBQSx5QkFBQSxzQkFBQSx1QkFBQSx1QkFBQSxxQkFBQSw4QkFBQSxtQkFBQSxpQkFBQSxpQkFBQSxZQUFBLGlCQUFBLFdBQUEsY0FBQSxrQkFBQSxrQkFBQSxhQUFBLGNBQUEsZ0JBQUEsZ0JBQUEsa0JBQUEsaUJBQUEsYUFBQSxtQkFBQSxtQkFBQSxlQUFBLEdBQUEsUUFBQSxDQUFBLCt2WkFBQSxFQUFBLENBQUE7OzsrRUFJeEIsZ0JBQWMsQ0FBQTtVQVAxQjt1QkFDVyx1QkFBcUIsWUFDbkIsTUFBSSxTQUNQLENBQUMsY0FBYyxXQUFXLEdBQUMsVUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztTQUFBLFFBQUEsQ0FBQSx5MlJBQUEsRUFBQSxDQUFBOztVQWVuQzs7VUFDQTs7VUFDQTs7OztnRkFiVSxnQkFBYyxFQUFBLFdBQUEsa0JBQUEsVUFBQSwwREFBQSxZQUFBLEdBQUEsQ0FBQTtBQUFBLEdBQUE7Ozs7Ozs7OERBQWQsZ0JBQWMsRUFBQSxTQUFBLENBQUEsSUFBQSxJQUFBLEVBQUEsR0FBQSxDQUFBLGNBQUEsYUFBQSxXQUFBLE9BQUEsTUFBQSxHQUFBLGFBQUEsRUFBQSxDQUFBO0VBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGNBQUEsdUJBQUEsS0FBQSxJQUFBLENBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGVBQUEsWUFBQSxPQUFBLFlBQUEsSUFBQSxHQUFBLDRCQUFBLE9BQUEsRUFBQSxPQUFBLE1BQUEsdUJBQUEsRUFBQSxTQUFBLENBQUE7QUFBQSxHQUFBOyIsIm5hbWVzIjpbXX0=