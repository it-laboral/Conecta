// src/app/services/postulante.service.ts
import { Injectable, inject } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import { HttpClient } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_common_http.js?v=3d725e17";
import * as i0 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
var PostulanteService = class _PostulanteService {
  http = inject(HttpClient);
  apiUrl = "http://localhost:3000/api/postulante";
  getPerfil(idPostulante) {
    return this.http.get(`${this.apiUrl}/perfil/${idPostulante}`);
  }
  actualizarPerfil(idPostulante, perfilData) {
    return this.http.put(`${this.apiUrl}/perfil/${idPostulante}`, perfilData);
  }
  subirFotoPerfil(idPostulante, archivo) {
    const formData = new FormData();
    formData.append("foto", archivo);
    return this.http.post(`${this.apiUrl}/perfil/${idPostulante}/foto`, formData);
  }
  getCatalogoSkills() {
    return this.http.get(`${this.apiUrl}/skills/catalogo`);
  }
  subirCV(idPostulante, archivo) {
    const formData = new FormData();
    formData.append("cv", archivo);
    return this.http.post(`${this.apiUrl}/perfil/${idPostulante}/cv`, formData);
  }
  static \u0275fac = function PostulanteService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _PostulanteService)();
  };
  static \u0275prov = /* @__PURE__ */ i0.\u0275\u0275defineInjectable({ token: _PostulanteService, factory: _PostulanteService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassMetadata(PostulanteService, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], null, null);
})();

export {
  PostulanteService
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2VydmljZXMvcG9zdHVsYW50ZS5zZXJ2aWNlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUsIGluamVjdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBIdHRwQ2xpZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIFJlc3B1ZXN0YUNWIHtcclxuICBzdWNjZXNzOiBib29sZWFuO1xyXG4gIG1lc3NhZ2U6IHN0cmluZztcclxuICBjdl91cmw/OiBzdHJpbmc7XHJcbiAgY3Zfbm9tYnJlPzogc3RyaW5nO1xyXG59XHJcblxyXG5ASW5qZWN0YWJsZSh7XHJcbiAgcHJvdmlkZWRJbjogJ3Jvb3QnXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBQb3N0dWxhbnRlU2VydmljZSB7XHJcblxyXG4gIHByaXZhdGUgaHR0cCA9IGluamVjdChIdHRwQ2xpZW50KTtcclxuXHJcbiAgcHJpdmF0ZSBhcGlVcmwgPSAnaHR0cDovL2xvY2FsaG9zdDozMDAwL2FwaS9wb3N0dWxhbnRlJztcclxuXHJcbiAgZ2V0UGVyZmlsKGlkUG9zdHVsYW50ZTogbnVtYmVyKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0KFxyXG4gICAgICBgJHt0aGlzLmFwaVVybH0vcGVyZmlsLyR7aWRQb3N0dWxhbnRlfWBcclxuICAgICk7XHJcbiAgfVxyXG5cclxuICBhY3R1YWxpemFyUGVyZmlsKFxyXG4gICAgaWRQb3N0dWxhbnRlOiBudW1iZXIsXHJcbiAgICBwZXJmaWxEYXRhOiBhbnlcclxuICApOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgcmV0dXJuIHRoaXMuaHR0cC5wdXQoXHJcbiAgICAgIGAke3RoaXMuYXBpVXJsfS9wZXJmaWwvJHtpZFBvc3R1bGFudGV9YCxcclxuICAgICAgcGVyZmlsRGF0YVxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIHN1YmlyRm90b1BlcmZpbChcclxuICAgIGlkUG9zdHVsYW50ZTogbnVtYmVyLFxyXG4gICAgYXJjaGl2bzogRmlsZVxyXG4gICk6IE9ic2VydmFibGU8YW55PiB7XHJcblxyXG4gICAgY29uc3QgZm9ybURhdGEgPSBuZXcgRm9ybURhdGEoKTtcclxuXHJcbiAgICBmb3JtRGF0YS5hcHBlbmQoJ2ZvdG8nLCBhcmNoaXZvKTtcclxuXHJcbiAgICByZXR1cm4gdGhpcy5odHRwLnBvc3QoXHJcbiAgICAgIGAke3RoaXMuYXBpVXJsfS9wZXJmaWwvJHtpZFBvc3R1bGFudGV9L2ZvdG9gLFxyXG4gICAgICBmb3JtRGF0YVxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIGdldENhdGFsb2dvU2tpbGxzKCk6IE9ic2VydmFibGU8YW55PiB7XHJcbiAgICByZXR1cm4gdGhpcy5odHRwLmdldChcclxuICAgICAgYCR7dGhpcy5hcGlVcmx9L3NraWxscy9jYXRhbG9nb2BcclxuICAgICk7XHJcbiAgfVxyXG5cclxuICBzdWJpckNWKGlkUG9zdHVsYW50ZTogbnVtYmVyLCBhcmNoaXZvOiBGaWxlKTogT2JzZXJ2YWJsZTxSZXNwdWVzdGFDVj4ge1xyXG4gICAgY29uc3QgZm9ybURhdGEgPSBuZXcgRm9ybURhdGEoKTtcclxuICAgIGZvcm1EYXRhLmFwcGVuZCgnY3YnLCBhcmNoaXZvKTtcclxuXHJcbiAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8UmVzcHVlc3RhQ1Y+KFxyXG4gICAgICBgJHt0aGlzLmFwaVVybH0vcGVyZmlsLyR7aWRQb3N0dWxhbnRlfS9jdmAsXHJcbiAgICAgIGZvcm1EYXRhXHJcbiAgICApO1xyXG4gIH1cclxuXHJcbn0iXSwibWFwcGluZ3MiOiI7QUFBQSxTQUFTLFlBQVksY0FBYztBQUNuQyxTQUFTLGtCQUFrQjs7QUFhckIsSUFBTyxvQkFBUCxNQUFPLG1CQUFpQjtFQUVwQixPQUFPLE9BQU8sVUFBVTtFQUV4QixTQUFTO0VBRWpCLFVBQVUsY0FBb0I7QUFDNUIsV0FBTyxLQUFLLEtBQUssSUFDZixHQUFHLEtBQUssTUFBTSxXQUFXLFlBQVksRUFBRTtFQUUzQztFQUVBLGlCQUNFLGNBQ0EsWUFBZTtBQUVmLFdBQU8sS0FBSyxLQUFLLElBQ2YsR0FBRyxLQUFLLE1BQU0sV0FBVyxZQUFZLElBQ3JDLFVBQVU7RUFFZDtFQUVBLGdCQUNFLGNBQ0EsU0FBYTtBQUdiLFVBQU0sV0FBVyxJQUFJLFNBQVE7QUFFN0IsYUFBUyxPQUFPLFFBQVEsT0FBTztBQUUvQixXQUFPLEtBQUssS0FBSyxLQUNmLEdBQUcsS0FBSyxNQUFNLFdBQVcsWUFBWSxTQUNyQyxRQUFRO0VBRVo7RUFFQSxvQkFBaUI7QUFDZixXQUFPLEtBQUssS0FBSyxJQUNmLEdBQUcsS0FBSyxNQUFNLGtCQUFrQjtFQUVwQztFQUVBLFFBQVEsY0FBc0IsU0FBYTtBQUN6QyxVQUFNLFdBQVcsSUFBSSxTQUFRO0FBQzdCLGFBQVMsT0FBTyxNQUFNLE9BQU87QUFFN0IsV0FBTyxLQUFLLEtBQUssS0FDZixHQUFHLEtBQUssTUFBTSxXQUFXLFlBQVksT0FDckMsUUFBUTtFQUVaOztxQ0FuRFcsb0JBQWlCO0VBQUE7K0VBQWpCLG9CQUFpQixTQUFqQixtQkFBaUIsV0FBQSxZQUZoQixPQUFNLENBQUE7OzsrRUFFUCxtQkFBaUIsQ0FBQTtVQUg3QjtXQUFXO01BQ1YsWUFBWTtLQUNiOzs7IiwibmFtZXMiOltdfQ==