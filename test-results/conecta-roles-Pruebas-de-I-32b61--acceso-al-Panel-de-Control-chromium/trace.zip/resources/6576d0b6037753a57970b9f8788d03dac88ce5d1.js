import {
  __export
} from "/chunk-CZJLB7T5.js";

// src/app/services/auth.service.ts
var auth_service_exports = {};
__export(auth_service_exports, {
  AuthService: () => AuthService
});
import { Injectable, inject, signal, PLATFORM_ID } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import { isPlatformBrowser } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_common.js?v=3d725e17";
import { HttpClient } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_common_http.js?v=3d725e17";
import { tap } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/rxjs_operators.js?v=3d725e17";
import * as i0 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
var AuthService = class _AuthService {
  http = inject(HttpClient);
  platformId = inject(PLATFORM_ID);
  API_URL = "http://localhost:3000/api";
  // Signals de estado inicializados de forma segura para SSR
  tipoUsuario = signal(null, ...ngDevMode ? [{ debugName: "tipoUsuario" }] : (
    /* istanbul ignore next */
    []
  ));
  isLoggedIn = signal(false, ...ngDevMode ? [{ debugName: "isLoggedIn" }] : (
    /* istanbul ignore next */
    []
  ));
  usuarioActual = signal(null, ...ngDevMode ? [{ debugName: "usuarioActual" }] : (
    /* istanbul ignore next */
    []
  ));
  constructor() {
    if (isPlatformBrowser(this.platformId)) {
      const token = localStorage.getItem("token");
      const tipo = localStorage.getItem("tipoUsuario");
      const user = localStorage.getItem("usuario");
      if (token) {
        this.isLoggedIn.set(true);
        this.tipoUsuario.set(tipo);
        if (user) {
          try {
            this.usuarioActual.set(JSON.parse(user));
          } catch (e) {
            console.error("Error al parsear usuario de localStorage", e);
          }
        }
      }
    }
  }
  // ==========================================
  // LOGIN
  // ==========================================
  login(credenciales) {
    return this.http.post(`${this.API_URL}/login`, credenciales).pipe(tap((respuesta) => {
      if (respuesta.success && respuesta.token) {
        if (isPlatformBrowser(this.platformId)) {
          localStorage.setItem("token", respuesta.token);
          localStorage.setItem("tipoUsuario", respuesta.tipo);
          localStorage.setItem("usuario", JSON.stringify(respuesta.user));
        }
        this.tipoUsuario.set(respuesta.tipo);
        this.usuarioActual.set(respuesta.user);
        this.isLoggedIn.set(true);
      }
    }));
  }
  // ==========================================
  // REGISTROS
  // ==========================================
  registrarPostulante(datos) {
    return this.http.post(`${this.API_URL}/registrar/postulante`, datos);
  }
  registrarEmpresa(datos) {
    return this.http.post(`${this.API_URL}/registrar/empresa`, datos);
  }
  // ==========================================
  // CONSULTAS Y LOGOUT
  // ==========================================
  getToken() {
    if (isPlatformBrowser(this.platformId)) {
      return localStorage.getItem("token");
    }
    return null;
  }
  getTipoUsuario() {
    return this.tipoUsuario();
  }
  getUsuarioActual() {
    return this.usuarioActual();
  }
  logout() {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.removeItem("token");
      localStorage.removeItem("tipoUsuario");
      localStorage.removeItem("usuario");
    }
    this.tipoUsuario.set(null);
    this.usuarioActual.set(null);
    this.isLoggedIn.set(false);
  }
  static \u0275fac = function AuthService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _AuthService)();
  };
  static \u0275prov = /* @__PURE__ */ i0.\u0275\u0275defineInjectable({ token: _AuthService, factory: _AuthService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassMetadata(AuthService, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], () => [], null);
})();

export {
  AuthService,
  auth_service_exports
};


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2VydmljZXMvYXV0aC5zZXJ2aWNlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUsIGluamVjdCwgc2lnbmFsLCBQTEFURk9STV9JRCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBpc1BsYXRmb3JtQnJvd3NlciB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XHJcbmltcG9ydCB7IEh0dHBDbGllbnQgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XHJcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgdGFwIH0gZnJvbSAncnhqcy9vcGVyYXRvcnMnO1xyXG5cclxuQEluamVjdGFibGUoe1xyXG4gIHByb3ZpZGVkSW46ICdyb290J1xyXG59KVxyXG5leHBvcnQgY2xhc3MgQXV0aFNlcnZpY2Uge1xyXG5cclxuICBwcml2YXRlIGh0dHAgPSBpbmplY3QoSHR0cENsaWVudCk7XHJcbiAgcHJpdmF0ZSBwbGF0Zm9ybUlkID0gaW5qZWN0KFBMQVRGT1JNX0lEKTtcclxuICBwcml2YXRlIEFQSV9VUkwgPSAnaHR0cDovL2xvY2FsaG9zdDozMDAwL2FwaSc7XHJcblxyXG4gIC8vIFNpZ25hbHMgZGUgZXN0YWRvIGluaWNpYWxpemFkb3MgZGUgZm9ybWEgc2VndXJhIHBhcmEgU1NSXHJcbiAgdGlwb1VzdWFyaW8gPSBzaWduYWw8c3RyaW5nIHwgbnVsbD4obnVsbCk7XHJcbiAgaXNMb2dnZWRJbiA9IHNpZ25hbDxib29sZWFuPihmYWxzZSk7XHJcbiAgdXN1YXJpb0FjdHVhbCA9IHNpZ25hbDxhbnk+KG51bGwpO1xyXG5cclxuICBjb25zdHJ1Y3RvcigpIHtcclxuICAgIC8vIExhIGxlY3R1cmEgZGUgbG9jYWxTdG9yYWdlIFNPTE8gb2N1cnJlIHVuYSB2ZXogZW4gZWwgY2xpZW50ZSAobmF2ZWdhZG9yKVxyXG4gICAgaWYgKGlzUGxhdGZvcm1Ccm93c2VyKHRoaXMucGxhdGZvcm1JZCkpIHtcclxuICAgICAgY29uc3QgdG9rZW4gPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgndG9rZW4nKTtcclxuICAgICAgY29uc3QgdGlwbyA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKCd0aXBvVXN1YXJpbycpO1xyXG4gICAgICBjb25zdCB1c2VyID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3VzdWFyaW8nKTtcclxuICAgICAgaWYgKHRva2VuKSB7XHJcbiAgICAgICAgdGhpcy5pc0xvZ2dlZEluLnNldCh0cnVlKTtcclxuICAgICAgICB0aGlzLnRpcG9Vc3VhcmlvLnNldCh0aXBvKTtcclxuICAgICAgICBpZiAodXNlcikge1xyXG4gICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgdGhpcy51c3VhcmlvQWN0dWFsLnNldChKU09OLnBhcnNlKHVzZXIpKTtcclxuICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgYWwgcGFyc2VhciB1c3VhcmlvIGRlIGxvY2FsU3RvcmFnZScsIGUpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuICAgICAgXHJcblxyXG4gIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gIC8vIExPR0lOXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgbG9naW4oY3JlZGVuY2lhbGVzOiBhbnkpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PGFueT4oYCR7dGhpcy5BUElfVVJMfS9sb2dpbmAsIGNyZWRlbmNpYWxlcykucGlwZShcclxuICAgICAgdGFwKHJlc3B1ZXN0YSA9PiB7XHJcbiAgICAgICAgaWYgKHJlc3B1ZXN0YS5zdWNjZXNzICYmIHJlc3B1ZXN0YS50b2tlbikge1xyXG4gICAgICAgICAgaWYgKGlzUGxhdGZvcm1Ccm93c2VyKHRoaXMucGxhdGZvcm1JZCkpIHtcclxuICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3Rva2VuJywgcmVzcHVlc3RhLnRva2VuKTtcclxuICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3RpcG9Vc3VhcmlvJywgcmVzcHVlc3RhLnRpcG8pO1xyXG4gICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgndXN1YXJpbycsIEpTT04uc3RyaW5naWZ5KHJlc3B1ZXN0YS51c2VyKSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICB0aGlzLnRpcG9Vc3VhcmlvLnNldChyZXNwdWVzdGEudGlwbyk7XHJcbiAgICAgICAgICB0aGlzLnVzdWFyaW9BY3R1YWwuc2V0KHJlc3B1ZXN0YS51c2VyKTtcclxuICAgICAgICAgIHRoaXMuaXNMb2dnZWRJbi5zZXQodHJ1ZSk7IC8vIPCfkYggQWN0dWFsaXphIGxhIHNlw7FhbFxyXG4gICAgICAgIH1cclxuICAgICAgfSlcclxuXHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgLy8gUkVHSVNUUk9TXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgcmVnaXN0cmFyUG9zdHVsYW50ZShkYXRvczogYW55KTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgIHJldHVybiB0aGlzLmh0dHAucG9zdChgJHt0aGlzLkFQSV9VUkx9L3JlZ2lzdHJhci9wb3N0dWxhbnRlYCwgZGF0b3MpO1xyXG4gIH1cclxuXHJcbiAgcmVnaXN0cmFyRW1wcmVzYShkYXRvczogYW55KTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgIHJldHVybiB0aGlzLmh0dHAucG9zdChgJHt0aGlzLkFQSV9VUkx9L3JlZ2lzdHJhci9lbXByZXNhYCwgZGF0b3MpO1xyXG4gIH1cclxuXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgLy8gQ09OU1VMVEFTIFkgTE9HT1VUXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgZ2V0VG9rZW4oKTogc3RyaW5nIHwgbnVsbCB7XHJcbiAgICBpZiAoaXNQbGF0Zm9ybUJyb3dzZXIodGhpcy5wbGF0Zm9ybUlkKSkge1xyXG4gICAgICByZXR1cm4gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3Rva2VuJyk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9XHJcblxyXG4gIGdldFRpcG9Vc3VhcmlvKCk6IHN0cmluZyB8IG51bGwge1xyXG4gICAgcmV0dXJuIHRoaXMudGlwb1VzdWFyaW8oKTtcclxuICB9XHJcblxyXG4gIGdldFVzdWFyaW9BY3R1YWwoKTogYW55IHtcclxuICAgIHJldHVybiB0aGlzLnVzdWFyaW9BY3R1YWwoKTsgLy8g8J+RiCBSZXRvcm5hIGRpcmVjdGFtZW50ZSBlbCB2YWxvciBkZSBsYSBTaWduYWxcclxuICB9XHJcblxyXG4gIGxvZ291dCgpOiB2b2lkIHtcclxuICAgIGlmIChpc1BsYXRmb3JtQnJvd3Nlcih0aGlzLnBsYXRmb3JtSWQpKSB7XHJcbiAgICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCd0b2tlbicpO1xyXG4gICAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgndGlwb1VzdWFyaW8nKTtcclxuICAgICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oJ3VzdWFyaW8nKTtcclxuICAgIH1cclxuICAgIHRoaXMudGlwb1VzdWFyaW8uc2V0KG51bGwpO1xyXG4gICAgdGhpcy51c3VhcmlvQWN0dWFsLnNldChudWxsKTtcclxuICAgIHRoaXMuaXNMb2dnZWRJbi5zZXQoZmFsc2UpOyAvLyDwn5GIIExpbXBpYSBsYSBzZcOxYWxcclxuICB9XHJcbn0iXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUE7Ozs7U0FBUyxZQUFZLFFBQVEsUUFBUSxtQkFBbUI7QUFDeEQsU0FBUyx5QkFBeUI7QUFDbEMsU0FBUyxrQkFBa0I7QUFFM0IsU0FBUyxXQUFXOztBQUtkLElBQU8sY0FBUCxNQUFPLGFBQVc7RUFFZCxPQUFPLE9BQU8sVUFBVTtFQUN4QixhQUFhLE9BQU8sV0FBVztFQUMvQixVQUFVOztFQUdsQixjQUFjLE9BQXNCLE1BQUksR0FBQSxZQUFBLENBQUEsRUFBQSxXQUFBLGNBQUEsQ0FBQTs7SUFBQSxDQUFBO0dBQUE7RUFDeEMsYUFBYSxPQUFnQixPQUFLLEdBQUEsWUFBQSxDQUFBLEVBQUEsV0FBQSxhQUFBLENBQUE7O0lBQUEsQ0FBQTtHQUFBO0VBQ2xDLGdCQUFnQixPQUFZLE1BQUksR0FBQSxZQUFBLENBQUEsRUFBQSxXQUFBLGdCQUFBLENBQUE7O0lBQUEsQ0FBQTtHQUFBO0VBRWhDLGNBQUE7QUFFRSxRQUFJLGtCQUFrQixLQUFLLFVBQVUsR0FBRztBQUN0QyxZQUFNLFFBQVEsYUFBYSxRQUFRLE9BQU87QUFDMUMsWUFBTSxPQUFPLGFBQWEsUUFBUSxhQUFhO0FBQy9DLFlBQU0sT0FBTyxhQUFhLFFBQVEsU0FBUztBQUMzQyxVQUFJLE9BQU87QUFDVCxhQUFLLFdBQVcsSUFBSSxJQUFJO0FBQ3hCLGFBQUssWUFBWSxJQUFJLElBQUk7QUFDekIsWUFBSSxNQUFNO0FBQ1IsY0FBSTtBQUNGLGlCQUFLLGNBQWMsSUFBSSxLQUFLLE1BQU0sSUFBSSxDQUFDO1VBQ3pDLFNBQVMsR0FBRztBQUNWLG9CQUFRLE1BQU0sNENBQTRDLENBQUM7VUFDN0Q7UUFDRjtNQUNGO0lBQ0Y7RUFDRjs7OztFQU1BLE1BQU0sY0FBaUI7QUFDckIsV0FBTyxLQUFLLEtBQUssS0FBVSxHQUFHLEtBQUssT0FBTyxVQUFVLFlBQVksRUFBRSxLQUNoRSxJQUFJLGVBQVk7QUFDZCxVQUFJLFVBQVUsV0FBVyxVQUFVLE9BQU87QUFDeEMsWUFBSSxrQkFBa0IsS0FBSyxVQUFVLEdBQUc7QUFDdEMsdUJBQWEsUUFBUSxTQUFTLFVBQVUsS0FBSztBQUM3Qyx1QkFBYSxRQUFRLGVBQWUsVUFBVSxJQUFJO0FBQ2xELHVCQUFhLFFBQVEsV0FBVyxLQUFLLFVBQVUsVUFBVSxJQUFJLENBQUM7UUFDaEU7QUFDQSxhQUFLLFlBQVksSUFBSSxVQUFVLElBQUk7QUFDbkMsYUFBSyxjQUFjLElBQUksVUFBVSxJQUFJO0FBQ3JDLGFBQUssV0FBVyxJQUFJLElBQUk7TUFDMUI7SUFDRixDQUFDLENBQUM7RUFHTjs7OztFQUtBLG9CQUFvQixPQUFVO0FBQzVCLFdBQU8sS0FBSyxLQUFLLEtBQUssR0FBRyxLQUFLLE9BQU8seUJBQXlCLEtBQUs7RUFDckU7RUFFQSxpQkFBaUIsT0FBVTtBQUN6QixXQUFPLEtBQUssS0FBSyxLQUFLLEdBQUcsS0FBSyxPQUFPLHNCQUFzQixLQUFLO0VBQ2xFOzs7O0VBS0EsV0FBUTtBQUNOLFFBQUksa0JBQWtCLEtBQUssVUFBVSxHQUFHO0FBQ3RDLGFBQU8sYUFBYSxRQUFRLE9BQU87SUFDckM7QUFDQSxXQUFPO0VBQ1Q7RUFFQSxpQkFBYztBQUNaLFdBQU8sS0FBSyxZQUFXO0VBQ3pCO0VBRUEsbUJBQWdCO0FBQ2QsV0FBTyxLQUFLLGNBQWE7RUFDM0I7RUFFQSxTQUFNO0FBQ0osUUFBSSxrQkFBa0IsS0FBSyxVQUFVLEdBQUc7QUFDdEMsbUJBQWEsV0FBVyxPQUFPO0FBQy9CLG1CQUFhLFdBQVcsYUFBYTtBQUNyQyxtQkFBYSxXQUFXLFNBQVM7SUFDbkM7QUFDQSxTQUFLLFlBQVksSUFBSSxJQUFJO0FBQ3pCLFNBQUssY0FBYyxJQUFJLElBQUk7QUFDM0IsU0FBSyxXQUFXLElBQUksS0FBSztFQUMzQjs7cUNBM0ZXLGNBQVc7RUFBQTsrRUFBWCxjQUFXLFNBQVgsYUFBVyxXQUFBLFlBRlYsT0FBTSxDQUFBOzs7K0VBRVAsYUFBVyxDQUFBO1VBSHZCO1dBQVc7TUFDVixZQUFZO0tBQ2I7OzsiLCJuYW1lcyI6W119