import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/main.js");import {
  PostulanteProfile
} from "/chunk-UXCBMG7Q.js";
import {
  EmpresaProfile
} from "/chunk-BHBSFVOT.js";
import {
  AuthService,
  auth_service_exports
} from "/chunk-YI23ZOHR.js";
import "/chunk-K5PJFGEX.js";
import {
  __export,
  __spreadProps,
  __spreadValues
} from "/chunk-CZJLB7T5.js";

// src/main.ts
import { bootstrapApplication } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_platform-browser.js?v=3d725e17";

// src/app/app.config.ts
import { provideBrowserGlobalErrorListeners, LOCALE_ID } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import { provideRouter } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_router.js?v=3d725e17";
import { provideHttpClient, withFetch, withInterceptors } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_common_http.js?v=3d725e17";
import { registerLocaleData } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_common.js?v=3d725e17";
import localeEs from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_common_locales_es.js?v=3d725e17";

// src/app/pagina/principal/principal.ts
import { Component } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import { RouterLink } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_router.js?v=3d725e17";
import * as i0 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
var _c0 = () => ["/ofertas"];
var _c1 = (a0) => ({ id: a0 });
var _forTrack0 = ($index, $item) => $item.label;
var _forTrack1 = ($index, $item) => $item.id;
function Principal_For_31_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 14)(1, "div", 41);
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(3, "div", 42);
    i0.\u0275\u0275text(4);
    i0.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const stat_r1 = ctx.$implicit;
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate(stat_r1.valor);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate(stat_r1.label);
  }
}
function Principal_For_40_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 19)(1, "div", 43);
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(3, "div", 29);
    i0.\u0275\u0275element(4, "i");
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(5, "h3");
    i0.\u0275\u0275text(6);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(7, "p");
    i0.\u0275\u0275text(8);
    i0.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const paso_r2 = ctx.$implicit;
    const $index_r3 = ctx.$index;
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate($index_r3 + 1);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275classMap(i0.\u0275\u0275interpolate1("fa-solid ", paso_r2.icono));
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate(paso_r2.titulo);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate(paso_r2.descripcion);
  }
}
function Principal_For_49_For_8_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "span", 47);
    i0.\u0275\u0275text(1);
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const tec_r4 = ctx.$implicit;
    i0.\u0275\u0275advance();
    i0.\u0275\u0275textInterpolate(tec_r4);
  }
}
function Principal_For_49_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 22)(1, "div", 44)(2, "h3");
    i0.\u0275\u0275text(3);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(4, "span", 45);
    i0.\u0275\u0275text(5);
    i0.\u0275\u0275elementEnd()();
    i0.\u0275\u0275elementStart(6, "div", 46);
    i0.\u0275\u0275repeaterCreate(7, Principal_For_49_For_8_Template, 2, 1, "span", 47, i0.\u0275\u0275repeaterTrackByIdentity);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275elementStart(9, "button", 48);
    i0.\u0275\u0275text(10, " Ver detalle ");
    i0.\u0275\u0275element(11, "i", 49);
    i0.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const oferta_r5 = ctx.$implicit;
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate(oferta_r5.titulo);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate(oferta_r5.empresa);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275repeater(oferta_r5.tecnologias);
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275property("routerLink", i0.\u0275\u0275pureFunction0(4, _c0))("queryParams", i0.\u0275\u0275pureFunction1(5, _c1, oferta_r5.id));
  }
}
function Principal_ForEmpty_50_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "p", 23);
    i0.\u0275\u0275text(1, "Todav\xEDa no hay ofertas publicadas \u2014 \xA1s\xE9 la primera empresa!");
    i0.\u0275\u0275elementEnd();
  }
}
function Principal_For_102_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i0.\u0275\u0275elementStart(0, "div", 53)(1, "p");
    i0.\u0275\u0275text(2);
    i0.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const faq_r9 = i0.\u0275\u0275nextContext().$implicit;
    i0.\u0275\u0275advance(2);
    i0.\u0275\u0275textInterpolate(faq_r9.respuesta);
  }
}
function Principal_For_102_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = i0.\u0275\u0275getCurrentView();
    i0.\u0275\u0275elementStart(0, "div", 50)(1, "button", 51);
    i0.\u0275\u0275listener("click", function Principal_For_102_Template_button_click_1_listener() {
      const $index_r7 = i0.\u0275\u0275restoreView(_r6).$index;
      const ctx_r7 = i0.\u0275\u0275nextContext();
      return i0.\u0275\u0275resetView(ctx_r7.toggleFaq($index_r7));
    });
    i0.\u0275\u0275elementStart(2, "span");
    i0.\u0275\u0275text(3);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275element(4, "i", 52);
    i0.\u0275\u0275elementEnd();
    i0.\u0275\u0275conditionalCreate(5, Principal_For_102_Conditional_5_Template, 3, 1, "div", 53);
    i0.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const faq_r9 = ctx.$implicit;
    i0.\u0275\u0275classProp("faq-abierta", faq_r9.abierta);
    i0.\u0275\u0275advance(3);
    i0.\u0275\u0275textInterpolate(faq_r9.pregunta);
    i0.\u0275\u0275advance();
    i0.\u0275\u0275classProp("fa-chevron-down", !faq_r9.abierta)("fa-chevron-up", faq_r9.abierta);
    i0.\u0275\u0275advance();
    i0.\u0275\u0275conditional(faq_r9.abierta ? 5 : -1);
  }
}
var Principal = class _Principal {
  // ============ ESTADÍSTICAS ============
  estadisticas = [
    { valor: "45+", label: "Ofertas Publicadas" },
    { valor: "20+", label: "Empresas Registradas" },
    { valor: "150+", label: "Postulantes Activos" },
    { valor: "30+", label: "Postulaciones Exitosas" }
  ];
  // ============ CÓMO FUNCIONA ============
  pasos = [
    {
      icono: "fa-user-pen",
      titulo: "Cre\xE1 tu perfil",
      descripcion: "Carg\xE1 tus habilidades, estudios y links a tu portfolio en pocos minutos."
    },
    {
      icono: "fa-magnifying-glass",
      titulo: "Postulate a ofertas",
      descripcion: "Explor\xE1 oportunidades filtradas por tecnolog\xEDa, empresa o modalidad."
    },
    {
      icono: "fa-handshake",
      titulo: "Conect\xE1 con empresas",
      descripcion: "Las empresas revisan tu perfil y te contactan directamente."
    }
  ];
  // ============ OFERTAS DESTACADAS ============
  // Dejalas hardcodeadas para la demo si todavía no tenés el service conectado.
  ofertasDestacadas = [
    {
      id: "of-1",
      titulo: "Desarrollador/a Frontend Angular Jr.",
      empresa: "TechMind Solutions",
      tecnologias: ["Angular", "TypeScript", "CSS"]
    },
    {
      id: "of-2",
      titulo: "Analista de Sistemas \u2014 Soporte y Desarrollo",
      empresa: "NovaSoft",
      tecnologias: [".NET", "SQL Server"]
    }
  ];
  // ============ FAQ (tu código original, sin tocar) ============
  faqs = [
    {
      pregunta: "\xBFC\xF3mo me registro en la plataforma?",
      respuesta: "Es s\xFAper f\xE1cil. Hac\xE9s clic en el bot\xF3n de Registrarse, seleccion\xE1s la opci\xF3n de Estudiante/Egresado, complet\xE1s tus datos (Importante: tu n\xFAmero de Legajo del ITB), correo y contrase\xF1a entre otros y listo. Ya pod\xE9s Loguearte armar tu perfil.",
      abierta: false
    },
    {
      pregunta: "\xBFTiene alg\xFAn costo el uso del sistema?",
      respuesta: "No tiene costo. ITB Conecta es una herramienta de intermediaci\xF3n laboral completamente gratuita tanto para estudiantes de tercer a\xF1o de las carreras como para los egresados de la instituci\xF3n.",
      abierta: false
    },
    {
      pregunta: "Soy una empresa, \xBFc\xF3mo puedo publicar ofertas?",
      respuesta: "Al registrarte como Empresa, nuestro equipo validar\xE1 tu perfil institucional. Una vez aprobado, vas a tener un panel exclusivo para subir y gestionar tus vacantes.",
      abierta: false
    }
  ];
  // Función para alternar el desplegable
  toggleFaq(index) {
    this.faqs[index].abierta = !this.faqs[index].abierta;
  }
  static \u0275fac = function Principal_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Principal)();
  };
  static \u0275cmp = /* @__PURE__ */ i0.\u0275\u0275defineComponent({ type: _Principal, selectors: [["app-principal"]], decls: 103, vars: 1, consts: [[1, "portada-container"], [1, "hero-section"], [1, "hero-content"], [1, "badge-tech"], [1, "hero-actions"], ["routerLink", "/ofertas", 1, "btn-principal-hero"], [1, "fa-solid", "fa-compass"], [1, "hero-visual"], [1, "tech-mockup"], ["src", "Logotrans.png", "alt", "ITB Conecta", 1, "logo-itb-futurista"], [1, "floating-badge"], [1, "fa-solid", "fa-circle-check", 2, "color", "#10b981"], [1, "stats-section"], [1, "stats-grid"], [1, "stat-card"], [1, "pasos-section"], [1, "section-title"], [1, "subtitulo"], [1, "pasos-grid"], [1, "paso-card"], [1, "ofertas-destacadas-section"], [1, "ofertas-destacadas-grid"], [1, "oferta-destacada-card"], [1, "sin-ofertas"], [1, "ver-todas-wrapper"], ["routerLink", "/ofertas", 1, "btn-secundario"], [1, "razones-section"], [1, "razones-grid"], [1, "razon-card"], [1, "icon-box"], [1, "fa-solid", "fa-user-astronaut"], [1, "razon-card", "destacado"], [1, "fa-solid", "fa-laptop-code"], [1, "fa-solid", "fa-brain"], [1, "cta-empresas-section"], [1, "cta-empresas-content"], ["routerLink", "/registrar", 1, "btn-principal-hero", "cta-empresas-btn"], [1, "fa-solid", "fa-briefcase"], [1, "faq-section"], [1, "faq-container"], [1, "faq-item", 3, "faq-abierta"], [1, "stat-numero"], [1, "stat-label"], [1, "paso-numero"], [1, "oferta-header"], [1, "oferta-empresa"], [1, "oferta-tags"], [1, "tag-tec"], [1, "btn-ver-oferta", 3, "routerLink", "queryParams"], [1, "fa-solid", "fa-arrow-right"], [1, "faq-item"], [1, "faq-pregunta", 3, "click"], [1, "fa-solid"], [1, "faq-respuesta"]], template: function Principal_Template(rf, ctx) {
    if (rf & 1) {
      i0.\u0275\u0275elementStart(0, "div", 0)(1, "header", 1)(2, "div", 2)(3, "span", 3);
      i0.\u0275\u0275text(4, "Plataforma de Intermediaci\xF3n Laboral");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(5, "h2");
      i0.\u0275\u0275text(6, "\xA1Bienvenidos a ITB Conecta!");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(7, "h2");
      i0.\u0275\u0275text(8, "Uniendo talento y oportunidades en el ITB");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(9, "p");
      i0.\u0275\u0275text(10, " El puente digital exclusivo que conecta a estudiantes y graduados de ");
      i0.\u0275\u0275elementStart(11, "strong");
      i0.\u0275\u0275text(12, "An\xE1lisis de Sistemas");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275text(13, " e ");
      i0.\u0275\u0275elementStart(14, "strong");
      i0.\u0275\u0275text(15, "Inteligencia Artificial");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275text(16, " con los proyectos m\xE1s innovadores de empresas tecnol\xF3gicas y de comunicaci\xF3n. ");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(17, "div", 4)(18, "button", 5);
      i0.\u0275\u0275text(19, " Buscar en las Ofertas Laborales ");
      i0.\u0275\u0275element(20, "i", 6);
      i0.\u0275\u0275elementEnd()()();
      i0.\u0275\u0275elementStart(21, "div", 7)(22, "div", 8);
      i0.\u0275\u0275element(23, "img", 9);
      i0.\u0275\u0275elementStart(24, "div", 10);
      i0.\u0275\u0275element(25, "i", 11);
      i0.\u0275\u0275elementStart(26, "span");
      i0.\u0275\u0275text(27, "Conexi\xF3n Exitosa");
      i0.\u0275\u0275elementEnd()()()()();
      i0.\u0275\u0275elementStart(28, "section", 12)(29, "div", 13);
      i0.\u0275\u0275repeaterCreate(30, Principal_For_31_Template, 5, 2, "div", 14, _forTrack0);
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(32, "section", 15)(33, "div", 16)(34, "h2");
      i0.\u0275\u0275text(35, "\xBFC\xF3mo funciona?");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(36, "p", 17);
      i0.\u0275\u0275text(37, "Empez\xE1 a conectar con oportunidades en 3 simples pasos.");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(38, "div", 18);
      i0.\u0275\u0275repeaterCreate(39, Principal_For_40_Template, 9, 6, "div", 19, i0.\u0275\u0275repeaterTrackByIndex);
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(41, "section", 20)(42, "div", 16)(43, "h2");
      i0.\u0275\u0275text(44, "Oportunidades destacadas");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(45, "p", 17);
      i0.\u0275\u0275text(46, "Algunas de las \xFAltimas ofertas publicadas por empresas del ecosistema.");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(47, "div", 21);
      i0.\u0275\u0275repeaterCreate(48, Principal_For_49_Template, 12, 7, "div", 22, _forTrack1, false, Principal_ForEmpty_50_Template, 2, 0, "p", 23);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(51, "div", 24)(52, "button", 25);
      i0.\u0275\u0275text(53, "Ver todas las ofertas");
      i0.\u0275\u0275elementEnd()()();
      i0.\u0275\u0275elementStart(54, "section", 26)(55, "div", 16)(56, "h2");
      i0.\u0275\u0275text(57, "\xBFPor qu\xE9 registrarte en ITB Conecta?");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(58, "p", 17);
      i0.\u0275\u0275text(59, "Dise\xF1ado espec\xEDficamente para las demandas del ecosistema tech actual.");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(60, "div", 27)(61, "div", 28)(62, "div", 29);
      i0.\u0275\u0275element(63, "i", 30);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(64, "h3");
      i0.\u0275\u0275text(65, "Perfil Especializado");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(66, "p");
      i0.\u0275\u0275text(67, "Mostr\xE1 tus proyectos, tus tecnolog\xEDas preferidas y el estado de tu carrera. Ac\xE1 las empresas buscan talento t\xE9cnico espec\xEDfico, no perfiles gen\xE9ricos.");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(68, "div", 31)(69, "div", 29);
      i0.\u0275\u0275element(70, "i", 32);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(71, "h3");
      i0.\u0275\u0275text(72, "Oportunidades Reales");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(73, "p");
      i0.\u0275\u0275text(74, "Acced\xE9 a pasant\xEDas, modalidades h\xEDbridas o remotas y posiciones pensadas para tu crecimiento profesional en empresas de software y comunicaci\xF3n.");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(75, "div", 28)(76, "div", 29);
      i0.\u0275\u0275element(77, "i", 33);
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(78, "h3");
      i0.\u0275\u0275text(79, "Impulsado por IA");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(80, "p");
      i0.\u0275\u0275text(81, "Un entorno moderno optimizado para que los algoritmos de b\xFAsqueda unan la necesidad de la empresa con tus habilidades de forma inteligente y transparente.");
      i0.\u0275\u0275elementEnd()()()();
      i0.\u0275\u0275elementStart(82, "section", 34)(83, "div", 35)(84, "div")(85, "span", 3);
      i0.\u0275\u0275text(86, "Para empresas");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(87, "h2");
      i0.\u0275\u0275text(88, "\xBFBusc\xE1s talento t\xE9cnico para tu equipo?");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(89, "p");
      i0.\u0275\u0275text(90, "Public\xE1 tus oportunidades y acced\xE9 a estudiantes y graduados de An\xE1lisis de Sistemas e IA del ITB, listos para sumarse a tus proyectos.");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(91, "button", 36);
      i0.\u0275\u0275text(92, " Publicar una oferta ");
      i0.\u0275\u0275element(93, "i", 37);
      i0.\u0275\u0275elementEnd()()();
      i0.\u0275\u0275elementStart(94, "section", 38)(95, "div", 16)(96, "h2");
      i0.\u0275\u0275text(97, "Preguntas Frecuentes");
      i0.\u0275\u0275elementEnd();
      i0.\u0275\u0275elementStart(98, "p", 17);
      i0.\u0275\u0275text(99, "Todo lo que necesit\xE1s saber sobre ITB Conecta");
      i0.\u0275\u0275elementEnd()();
      i0.\u0275\u0275elementStart(100, "div", 39);
      i0.\u0275\u0275repeaterCreate(101, Principal_For_102_Template, 6, 8, "div", 40, i0.\u0275\u0275repeaterTrackByIndex);
      i0.\u0275\u0275elementEnd()()();
    }
    if (rf & 2) {
      i0.\u0275\u0275advance(30);
      i0.\u0275\u0275repeater(ctx.estadisticas);
      i0.\u0275\u0275advance(9);
      i0.\u0275\u0275repeater(ctx.pasos);
      i0.\u0275\u0275advance(9);
      i0.\u0275\u0275repeater(ctx.ofertasDestacadas);
      i0.\u0275\u0275advance(53);
      i0.\u0275\u0275repeater(ctx.faqs);
    }
  }, dependencies: [RouterLink], styles: ["\n.portada-container[_ngcontent-%COMP%] {\n  padding: 40px 20px;\n  max-width: 1200px;\n  margin: 0 auto;\n  min-height: calc(100vh - 140px);\n  display: flex;\n  flex-direction: column;\n  gap: 80px;\n}\n.hero-section[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 40px;\n  position: relative;\n}\n@media (max-width: 960px) {\n  .hero-section[_ngcontent-%COMP%] {\n    flex-direction: column;\n    text-align: center;\n  }\n}\n.hero-content[_ngcontent-%COMP%] {\n  flex: 1;\n  max-width: 600px;\n}\n.hero-content[_ngcontent-%COMP%]   .badge-tech[_ngcontent-%COMP%] {\n  background-color: rgba(146, 228, 203, 0.15);\n  color: #16079e;\n  padding: 6px 14px;\n  border-radius: 20px;\n  font-size: 0.85rem;\n  font-weight: 700;\n  letter-spacing: 0.05em;\n  text-transform: uppercase;\n  display: inline-block;\n  margin-bottom: 20px;\n}\n.hero-content[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  font-size: 1.5rem;\n  line-height: 1.2;\n  color: #0f172a;\n  margin: 0 0 20px 0;\n  font-weight: 800;\n}\n@media (max-width: 480px) {\n  .hero-content[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n    font-size: 1.8rem;\n  }\n}\n.hero-content[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  font-size: 1.15rem;\n  line-height: 1.6;\n  color: #475569;\n  margin-bottom: 30px;\n}\n.hero-content[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  color: #2d4c7e;\n}\n.btn-principal-hero[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #2d4c7e 0%,\n      #1e3a8a 100%);\n  color: #ffffff;\n  border: none;\n  padding: 16px 32px;\n  border-radius: 30px;\n  font-size: 1.1rem;\n  font-weight: 600;\n  cursor: pointer;\n  box-shadow: 0 10px 20px rgba(45, 76, 126, 0.2);\n  display: inline-flex;\n  align-items: center;\n  gap: 12px;\n  transition: all 0.3s ease;\n}\n.btn-principal-hero[_ngcontent-%COMP%]:hover {\n  transform: translateY(-3px);\n  box-shadow: 0 15px 25px rgba(45, 76, 126, 0.3);\n}\n.hero-visual[_ngcontent-%COMP%] {\n  flex: 1;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  position: relative;\n  min-height: 350px;\n}\n.hero-visual[_ngcontent-%COMP%]   .glow-orb[_ngcontent-%COMP%] {\n  position: absolute;\n  width: 280px;\n  height: 280px;\n  background:\n    radial-gradient(\n      circle,\n      rgba(56, 189, 248, 0.15) 0%,\n      rgba(146, 228, 203, 0.05) 70%);\n  filter: blur(40px);\n  z-index: 1;\n}\n.hero-visual[_ngcontent-%COMP%]   .tech-mockup[_ngcontent-%COMP%] {\n  position: relative;\n  z-index: 2;\n  width: 340px;\n  height: 340px;\n  flex-shrink: 0;\n  background:\n    linear-gradient(\n      135deg,\n      #f8fafc 0%,\n      #e2edf0 100%);\n  border: 2px solid rgba(255, 255, 255, 0.8);\n  border-radius: 32px;\n  box-shadow: 0 20px 40px rgba(15, 23, 42, 0.08);\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  -webkit-backdrop-filter: blur(8px);\n  backdrop-filter: blur(8px);\n}\n.hero-visual[_ngcontent-%COMP%]   .tech-mockup[_ngcontent-%COMP%]   .logo-itb-futurista[_ngcontent-%COMP%] {\n  max-width: 70%;\n  max-height: 70%;\n  object-fit: contain;\n  opacity: 0.75;\n  mix-blend-mode: multiply;\n  filter: drop-shadow(0 0 20px rgba(56, 189, 248, 0.4)) drop-shadow(0 0 40px rgba(45, 76, 126, 0.1));\n  transition: all 0.4s ease;\n}\n.hero-visual[_ngcontent-%COMP%]   .tech-mockup[_ngcontent-%COMP%]   .logo-itb-futurista[_ngcontent-%COMP%]:hover {\n  opacity: 0.95;\n  transform: scale(1.03);\n  filter: drop-shadow(0 0 25px rgba(56, 189, 248, 0.6));\n}\n.hero-visual[_ngcontent-%COMP%]   .tech-mockup[_ngcontent-%COMP%]   .floating-badge[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: 20px;\n  right: -20px;\n  background: #ffffff;\n  border-left: 4px solid #92e4cb;\n  padding: 12px 20px;\n  border-radius: 12px;\n  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.05);\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  font-weight: 700;\n  font-size: 0.9rem;\n  color: #0f172a;\n  animation: _ngcontent-%COMP%_float 4s ease-in-out infinite;\n}\n.hero-visual[_ngcontent-%COMP%]   .tech-mockup[_ngcontent-%COMP%]   .floating-badge[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  color: #14b8a6;\n}\n.razones-section[_ngcontent-%COMP%]   .section-title[_ngcontent-%COMP%] {\n  text-align: center;\n  margin-bottom: 50px;\n}\n.razones-section[_ngcontent-%COMP%]   .section-title[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  font-size: 2rem;\n  color: #2d4c7e;\n  font-weight: 700;\n  margin-bottom: 10px;\n}\n.razones-section[_ngcontent-%COMP%]   .section-title[_ngcontent-%COMP%]   .subtitulo[_ngcontent-%COMP%] {\n  color: #475569;\n  font-size: 1rem;\n}\n.razones-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));\n  gap: 30px;\n}\n.razon-card[_ngcontent-%COMP%] {\n  background-color: #ffffff;\n  border: 1px solid #e2e8f0;\n  border-radius: 16px;\n  padding: 30px;\n  transition: all 0.3s ease;\n  box-shadow: 0 4px 6px rgba(15, 23, 42, 0.02);\n}\n.razon-card[_ngcontent-%COMP%]   .icon-box[_ngcontent-%COMP%] {\n  width: 50px;\n  height: 50px;\n  background-color: #f1f5f9;\n  border-radius: 12px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  margin-bottom: 20px;\n  font-size: 1.4rem;\n  color: #2d4c7e;\n  transition: all 0.3s ease;\n}\n.razon-card[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  margin: 0 0 12px 0;\n  font-size: 1.25rem;\n  color: #0f172a;\n  font-weight: 700;\n}\n.razon-card[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 0;\n  color: #475569;\n  font-size: 0.95rem;\n  line-height: 1.6;\n}\n.razon-card[_ngcontent-%COMP%]:hover {\n  transform: translateY(-5px);\n  box-shadow: 0 12px 20px rgba(15, 23, 42, 0.06);\n  border-color: #38bdf8;\n}\n.razon-card[_ngcontent-%COMP%]:hover   .icon-box[_ngcontent-%COMP%] {\n  background-color: rgba(56, 189, 248, 0.1);\n  color: #38bdf8;\n}\n.razon-card.destacado[_ngcontent-%COMP%] {\n  border-top: 4px solid #92e4cb;\n}\n@keyframes _ngcontent-%COMP%_float {\n  0% {\n    transform: translateY(0px);\n  }\n  50% {\n    transform: translateY(-10px);\n  }\n  100% {\n    transform: translateY(0px);\n  }\n}\n.faq-section[_ngcontent-%COMP%] {\n  margin-top: 20px;\n}\n.faq-section[_ngcontent-%COMP%]   .faq-container[_ngcontent-%COMP%] {\n  max-width: 800px;\n  margin: 0 auto;\n  display: flex;\n  flex-direction: column;\n  gap: 15px;\n}\n.faq-section[_ngcontent-%COMP%]   .faq-item[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border: 1px solid #e2e8f0;\n  border-radius: 12px;\n  overflow: hidden;\n  transition: all 0.3s ease;\n}\n.faq-section[_ngcontent-%COMP%]   .faq-item.faq-abierta[_ngcontent-%COMP%] {\n  border-color: #38bdf8;\n  box-shadow: 0 10px 20px rgba(15, 23, 42, 0.04);\n}\n.faq-section[_ngcontent-%COMP%]   .faq-item.faq-abierta[_ngcontent-%COMP%]   .faq-pregunta[_ngcontent-%COMP%] {\n  color: #2d4c7e;\n  background-color: rgba(56, 189, 248, 0.03);\n}\n.faq-section[_ngcontent-%COMP%]   .faq-pregunta[_ngcontent-%COMP%] {\n  width: 100%;\n  background: none;\n  border: none;\n  padding: 20px;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  font-size: 1.05rem;\n  font-weight: 600;\n  color: #0f172a;\n  cursor: pointer;\n  text-align: left;\n  transition: all 0.2s ease;\n}\n.faq-section[_ngcontent-%COMP%]   .faq-pregunta[_ngcontent-%COMP%]:hover {\n  background-color: #f8fafc;\n}\n.faq-section[_ngcontent-%COMP%]   .faq-pregunta[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  font-size: 0.9rem;\n  color: #475569;\n  transition: transform 0.3s ease;\n}\n.faq-section[_ngcontent-%COMP%]   .faq-respuesta[_ngcontent-%COMP%] {\n  padding: 0 20px 20px 20px;\n  background-color: rgba(248, 250, 252, 0.5);\n}\n.faq-section[_ngcontent-%COMP%]   .faq-respuesta[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 0.95rem;\n  line-height: 1.6;\n  color: #475569;\n}\n.section-title[_ngcontent-%COMP%] {\n  text-align: center;\n  margin-bottom: 50px;\n}\n.section-title[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  font-size: 2rem;\n  color: #2d4c7e;\n  font-weight: 700;\n  margin-bottom: 10px;\n}\n.section-title[_ngcontent-%COMP%]   .subtitulo[_ngcontent-%COMP%] {\n  color: #475569;\n  font-size: 1rem;\n}\n.stats-section[_ngcontent-%COMP%]   .stats-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(4, 1fr);\n  gap: 20px;\n}\n@media (max-width: 960px) {\n  .stats-section[_ngcontent-%COMP%]   .stats-grid[_ngcontent-%COMP%] {\n    grid-template-columns: repeat(2, 1fr);\n  }\n}\n.stats-section[_ngcontent-%COMP%]   .stat-card[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      rgba(146, 228, 203, 0.12) 0%,\n      rgba(56, 189, 248, 0.08) 100%);\n  border: 1px solid #e2e8f0;\n  border-radius: 16px;\n  padding: 24px 16px;\n  text-align: center;\n  transition: all 0.3s ease;\n}\n.stats-section[_ngcontent-%COMP%]   .stat-card[_ngcontent-%COMP%]:hover {\n  transform: translateY(-4px);\n  box-shadow: 0 12px 20px rgba(15, 23, 42, 0.06);\n}\n.stats-section[_ngcontent-%COMP%]   .stat-numero[_ngcontent-%COMP%] {\n  font-size: 2rem;\n  font-weight: 800;\n  color: #2d4c7e;\n}\n.stats-section[_ngcontent-%COMP%]   .stat-label[_ngcontent-%COMP%] {\n  font-size: 0.85rem;\n  font-weight: 600;\n  color: #475569;\n  margin-top: 6px;\n}\n.pasos-section[_ngcontent-%COMP%]   .pasos-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(3, 1fr);\n  gap: 30px;\n}\n@media (max-width: 960px) {\n  .pasos-section[_ngcontent-%COMP%]   .pasos-grid[_ngcontent-%COMP%] {\n    grid-template-columns: 1fr;\n  }\n}\n.pasos-section[_ngcontent-%COMP%]   .paso-card[_ngcontent-%COMP%] {\n  position: relative;\n  background-color: #ffffff;\n  border: 1px solid #e2e8f0;\n  border-radius: 16px;\n  padding: 34px 24px 28px;\n  text-align: center;\n  box-shadow: 0 4px 6px rgba(15, 23, 42, 0.02);\n  transition: all 0.3s ease;\n}\n.pasos-section[_ngcontent-%COMP%]   .paso-card[_ngcontent-%COMP%]:hover {\n  transform: translateY(-5px);\n  box-shadow: 0 12px 20px rgba(15, 23, 42, 0.06);\n  border-color: #38bdf8;\n}\n.pasos-section[_ngcontent-%COMP%]   .paso-numero[_ngcontent-%COMP%] {\n  position: absolute;\n  top: -16px;\n  left: 50%;\n  transform: translateX(-50%);\n  width: 32px;\n  height: 32px;\n  border-radius: 50%;\n  background:\n    linear-gradient(\n      135deg,\n      #2d4c7e 0%,\n      #38bdf8 100%);\n  color: #ffffff;\n  font-weight: 800;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 0.9rem;\n  box-shadow: 0 6px 14px rgba(45, 76, 126, 0.25);\n}\n.pasos-section[_ngcontent-%COMP%]   .icon-box[_ngcontent-%COMP%] {\n  width: 50px;\n  height: 50px;\n  background-color: #f1f5f9;\n  border-radius: 12px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  margin: 12px auto 18px;\n  font-size: 1.3rem;\n  color: #2d4c7e;\n}\n.pasos-section[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  margin: 0 0 10px 0;\n  font-size: 1.15rem;\n  color: #0f172a;\n  font-weight: 700;\n}\n.pasos-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 0;\n  color: #475569;\n  font-size: 0.92rem;\n  line-height: 1.6;\n}\n.ofertas-destacadas-section[_ngcontent-%COMP%]   .ofertas-destacadas-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(3, 1fr);\n  gap: 24px;\n  margin-top: 40px;\n}\n@media (max-width: 960px) {\n  .ofertas-destacadas-section[_ngcontent-%COMP%]   .ofertas-destacadas-grid[_ngcontent-%COMP%] {\n    grid-template-columns: 1fr;\n  }\n}\n.ofertas-destacadas-section[_ngcontent-%COMP%]   .oferta-destacada-card[_ngcontent-%COMP%] {\n  background-color: #ffffff;\n  border: 1px solid #e2e8f0;\n  border-radius: 16px;\n  padding: 24px;\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n  box-shadow: 0 4px 6px rgba(15, 23, 42, 0.02);\n  transition: all 0.3s ease;\n}\n.ofertas-destacadas-section[_ngcontent-%COMP%]   .oferta-destacada-card[_ngcontent-%COMP%]:hover {\n  transform: translateY(-5px);\n  box-shadow: 0 12px 20px rgba(15, 23, 42, 0.06);\n  border-color: #38bdf8;\n}\n.ofertas-destacadas-section[_ngcontent-%COMP%]   .oferta-header[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  margin: 0 0 4px 0;\n  font-size: 1.05rem;\n  color: #0f172a;\n  font-weight: 700;\n}\n.ofertas-destacadas-section[_ngcontent-%COMP%]   .oferta-empresa[_ngcontent-%COMP%] {\n  font-size: 0.85rem;\n  color: #475569;\n  font-weight: 600;\n}\n.ofertas-destacadas-section[_ngcontent-%COMP%]   .oferta-tags[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 8px;\n}\n.ofertas-destacadas-section[_ngcontent-%COMP%]   .tag-tec[_ngcontent-%COMP%] {\n  background-color: #f1f5f9;\n  color: #2d4c7e;\n  font-size: 0.78rem;\n  font-weight: 700;\n  padding: 5px 12px;\n  border-radius: 20px;\n}\n.ofertas-destacadas-section[_ngcontent-%COMP%]   .btn-ver-oferta[_ngcontent-%COMP%] {\n  margin-top: auto;\n  align-self: flex-start;\n  background: none;\n  border: none;\n  color: #16079e;\n  font-weight: 700;\n  font-size: 0.92rem;\n  cursor: pointer;\n  padding: 0;\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  transition: gap 0.2s ease;\n}\n.ofertas-destacadas-section[_ngcontent-%COMP%]   .btn-ver-oferta[_ngcontent-%COMP%]:hover {\n  gap: 10px;\n}\n.ofertas-destacadas-section[_ngcontent-%COMP%]   .sin-ofertas[_ngcontent-%COMP%] {\n  grid-column: 1/-1;\n  text-align: center;\n  color: #475569;\n  font-style: italic;\n}\n.ofertas-destacadas-section[_ngcontent-%COMP%]   .ver-todas-wrapper[_ngcontent-%COMP%] {\n  text-align: center;\n  margin-top: 32px;\n}\n.ofertas-destacadas-section[_ngcontent-%COMP%]   .btn-secundario[_ngcontent-%COMP%] {\n  background-color: #ffffff;\n  border: 2px solid #2d4c7e;\n  color: #2d4c7e;\n  font-weight: 700;\n  padding: 12px 28px;\n  border-radius: 30px;\n  cursor: pointer;\n  transition: all 0.3s ease;\n}\n.ofertas-destacadas-section[_ngcontent-%COMP%]   .btn-secundario[_ngcontent-%COMP%]:hover {\n  background-color: #2d4c7e;\n  color: #ffffff;\n  transform: translateY(-2px);\n}\n.cta-empresas-section[_ngcontent-%COMP%]   .cta-empresas-content[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #2d4c7e 0%,\n      #1e3a8a 100%);\n  border-radius: 24px;\n  padding: 44px;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 30px;\n  box-shadow: 0 20px 40px rgba(15, 23, 42, 0.12);\n}\n@media (max-width: 820px) {\n  .cta-empresas-section[_ngcontent-%COMP%]   .cta-empresas-content[_ngcontent-%COMP%] {\n    flex-direction: column;\n    text-align: center;\n  }\n}\n.cta-empresas-section[_ngcontent-%COMP%]   .cta-empresas-content[_ngcontent-%COMP%]   .badge-tech[_ngcontent-%COMP%] {\n  background-color: rgba(255, 255, 255, 0.15);\n  color: #ffffff;\n}\n.cta-empresas-section[_ngcontent-%COMP%]   .cta-empresas-content[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  color: #ffffff;\n  margin: 10px 0 8px 0;\n  font-size: 1.5rem;\n  font-weight: 800;\n}\n.cta-empresas-section[_ngcontent-%COMP%]   .cta-empresas-content[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  color: rgba(255, 255, 255, 0.85);\n  max-width: 480px;\n  margin: 0;\n}\n.cta-empresas-section[_ngcontent-%COMP%]   .cta-empresas-btn[_ngcontent-%COMP%] {\n  white-space: nowrap;\n  background: #ffffff !important;\n  color: #2d4c7e !important;\n  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);\n}\n/*# sourceMappingURL=principal.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassMetadata(Principal, [{
    type: Component,
    args: [{ selector: "app-principal", standalone: true, imports: [RouterLink], template: `<div class="portada-container">\r
\r
  <header class="hero-section">\r
    <div class="hero-content">\r
      <span class="badge-tech">Plataforma de Intermediaci\xF3n Laboral</span>\r
      <h2>\xA1Bienvenidos a ITB Conecta!</h2>\r
\r
      <h2>Uniendo talento y oportunidades en el ITB</h2>\r
\r
      <p>\r
        El puente digital exclusivo que conecta a estudiantes y graduados de\r
        <strong>An\xE1lisis de Sistemas</strong> e <strong>Inteligencia Artificial</strong>\r
        con los proyectos m\xE1s innovadores de empresas tecnol\xF3gicas y de comunicaci\xF3n.\r
      </p>\r
\r
      <div class="hero-actions">\r
        <button class="btn-principal-hero" routerLink="/ofertas">\r
          Buscar en las Ofertas Laborales <i class="fa-solid fa-compass"></i>\r
        </button>\r
      </div>\r
    </div>\r
\r
    <div class="hero-visual"> <div class="tech-mockup">\r
    \r
    <img src="Logotrans.png" alt="ITB Conecta" class="logo-itb-futurista">\r
    \r
    <div class="floating-badge">\r
      <i class="fa-solid fa-circle-check" style="color: #10b981;"></i>\r
      <span>Conexi\xF3n Exitosa</span>\r
    </div>\r
    \r
  </div>\r
</div>\r
  </header>\r
\r
  <!-- ============ NUEVO: ESTAD\xCDSTICAS ============ -->\r
  <section class="stats-section">\r
    <div class="stats-grid">\r
      @for (stat of estadisticas; track stat.label) {\r
        <div class="stat-card">\r
          <div class="stat-numero">{{ stat.valor }}</div>\r
          <div class="stat-label">{{ stat.label }}</div>\r
        </div>\r
      }\r
    </div>\r
  </section>\r
\r
  <!-- ============ NUEVO: C\xD3MO FUNCIONA ============ -->\r
  <section class="pasos-section">\r
    <div class="section-title">\r
      <h2>\xBFC\xF3mo funciona?</h2>\r
      <p class="subtitulo">Empez\xE1 a conectar con oportunidades en 3 simples pasos.</p>\r
    </div>\r
\r
    <div class="pasos-grid">\r
      @for (paso of pasos; track $index) {\r
        <div class="paso-card">\r
          <div class="paso-numero">{{ $index + 1 }}</div>\r
          <div class="icon-box">\r
            <i class="fa-solid {{ paso.icono }}"></i>\r
          </div>\r
          <h3>{{ paso.titulo }}</h3>\r
          <p>{{ paso.descripcion }}</p>\r
        </div>\r
      }\r
    </div>\r
  </section>\r
\r
  <!-- ============ NUEVO: OFERTAS DESTACADAS ============ -->\r
  <section class="ofertas-destacadas-section">\r
    <div class="section-title">\r
      <h2>Oportunidades destacadas</h2>\r
      <p class="subtitulo">Algunas de las \xFAltimas ofertas publicadas por empresas del ecosistema.</p>\r
    </div>\r
\r
    <div class="ofertas-destacadas-grid">\r
      @for (oferta of ofertasDestacadas; track oferta.id) {\r
        <div class="oferta-destacada-card">\r
          <div class="oferta-header">\r
            <h3>{{ oferta.titulo }}</h3>\r
            <span class="oferta-empresa">{{ oferta.empresa }}</span>\r
          </div>\r
          <div class="oferta-tags">\r
            @for (tec of oferta.tecnologias; track tec) {\r
              <span class="tag-tec">{{ tec }}</span>\r
            }\r
          </div>\r
          <button class="btn-ver-oferta" [routerLink]="['/ofertas']" [queryParams]="{ id: oferta.id }">\r
            Ver detalle <i class="fa-solid fa-arrow-right"></i>\r
          </button>\r
        </div>\r
      } @empty {\r
        <p class="sin-ofertas">Todav\xEDa no hay ofertas publicadas \u2014 \xA1s\xE9 la primera empresa!</p>\r
      }\r
    </div>\r
\r
    <div class="ver-todas-wrapper">\r
      <button class="btn-secundario" routerLink="/ofertas">Ver todas las ofertas</button>\r
    </div>\r
  </section>\r
\r
  <section class="razones-section">\r
    <div class="section-title">\r
      <h2>\xBFPor qu\xE9 registrarte en ITB Conecta?</h2>\r
      <p class="subtitulo">Dise\xF1ado espec\xEDficamente para las demandas del ecosistema tech actual.</p>\r
    </div>\r
\r
    <div class="razones-grid">\r
\r
      <div class="razon-card">\r
        <div class="icon-box">\r
          <i class="fa-solid fa-user-astronaut"></i>\r
        </div>\r
        <h3>Perfil Especializado</h3>\r
        <p>Mostr\xE1 tus proyectos, tus tecnolog\xEDas preferidas y el estado de tu carrera. Ac\xE1 las empresas buscan talento t\xE9cnico espec\xEDfico, no perfiles gen\xE9ricos.</p>\r
      </div>\r
\r
      <div class="razon-card destacado">\r
        <div class="icon-box">\r
          <i class="fa-solid fa-laptop-code"></i>\r
        </div>\r
        <h3>Oportunidades Reales</h3>\r
        <p>Acced\xE9 a pasant\xEDas, modalidades h\xEDbridas o remotas y posiciones pensadas para tu crecimiento profesional en empresas de software y comunicaci\xF3n.</p>\r
      </div>\r
\r
      <div class="razon-card">\r
        <div class="icon-box">\r
          <i class="fa-solid fa-brain"></i>\r
        </div>\r
        <h3>Impulsado por IA</h3>\r
        <p>Un entorno moderno optimizado para que los algoritmos de b\xFAsqueda unan la necesidad de la empresa con tus habilidades de forma inteligente y transparente.</p>\r
      </div>\r
\r
    </div>\r
  </section>\r
\r
  <!-- ============ NUEVO: CTA PARA EMPRESAS ============ -->\r
  <section class="cta-empresas-section">\r
    <div class="cta-empresas-content">\r
      <div>\r
        <span class="badge-tech">Para empresas</span>\r
        <h2>\xBFBusc\xE1s talento t\xE9cnico para tu equipo?</h2>\r
        <p>Public\xE1 tus oportunidades y acced\xE9 a estudiantes y graduados de An\xE1lisis de Sistemas e IA del ITB, listos para sumarse a tus proyectos.</p>\r
      </div>\r
      <button class="btn-principal-hero cta-empresas-btn" routerLink="/registrar">\r
        Publicar una oferta <i class="fa-solid fa-briefcase"></i>\r
      </button>\r
    </div>\r
  </section>\r
\r
  <section class="faq-section">\r
    <div class="section-title">\r
      <h2>Preguntas Frecuentes</h2>\r
      <p class="subtitulo">Todo lo que necesit\xE1s saber sobre ITB Conecta</p>\r
    </div>\r
\r
    <div class="faq-container">\r
      @for (faq of faqs; track $index) {\r
        <div class="faq-item" [class.faq-abierta]="faq.abierta">\r
\r
          <button class="faq-pregunta" (click)="toggleFaq($index)">\r
            <span>{{ faq.pregunta }}</span>\r
            <i class="fa-solid" [class.fa-chevron-down]="!faq.abierta" [class.fa-chevron-up]="faq.abierta"></i>\r
          </button>\r
\r
          @if (faq.abierta) {\r
            <div class="faq-respuesta">\r
              <p>{{ faq.respuesta }}</p>\r
            </div>\r
          }\r
\r
        </div>\r
      }\r
    </div>\r
  </section>\r
\r
</div>`, styles: ["/* src/app/pagina/principal/principal.scss */\n.portada-container {\n  padding: 40px 20px;\n  max-width: 1200px;\n  margin: 0 auto;\n  min-height: calc(100vh - 140px);\n  display: flex;\n  flex-direction: column;\n  gap: 80px;\n}\n.hero-section {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 40px;\n  position: relative;\n}\n@media (max-width: 960px) {\n  .hero-section {\n    flex-direction: column;\n    text-align: center;\n  }\n}\n.hero-content {\n  flex: 1;\n  max-width: 600px;\n}\n.hero-content .badge-tech {\n  background-color: rgba(146, 228, 203, 0.15);\n  color: #16079e;\n  padding: 6px 14px;\n  border-radius: 20px;\n  font-size: 0.85rem;\n  font-weight: 700;\n  letter-spacing: 0.05em;\n  text-transform: uppercase;\n  display: inline-block;\n  margin-bottom: 20px;\n}\n.hero-content h2 {\n  font-size: 1.5rem;\n  line-height: 1.2;\n  color: #0f172a;\n  margin: 0 0 20px 0;\n  font-weight: 800;\n}\n@media (max-width: 480px) {\n  .hero-content h2 {\n    font-size: 1.8rem;\n  }\n}\n.hero-content p {\n  font-size: 1.15rem;\n  line-height: 1.6;\n  color: #475569;\n  margin-bottom: 30px;\n}\n.hero-content p strong {\n  color: #2d4c7e;\n}\n.btn-principal-hero {\n  background:\n    linear-gradient(\n      135deg,\n      #2d4c7e 0%,\n      #1e3a8a 100%);\n  color: #ffffff;\n  border: none;\n  padding: 16px 32px;\n  border-radius: 30px;\n  font-size: 1.1rem;\n  font-weight: 600;\n  cursor: pointer;\n  box-shadow: 0 10px 20px rgba(45, 76, 126, 0.2);\n  display: inline-flex;\n  align-items: center;\n  gap: 12px;\n  transition: all 0.3s ease;\n}\n.btn-principal-hero:hover {\n  transform: translateY(-3px);\n  box-shadow: 0 15px 25px rgba(45, 76, 126, 0.3);\n}\n.hero-visual {\n  flex: 1;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  position: relative;\n  min-height: 350px;\n}\n.hero-visual .glow-orb {\n  position: absolute;\n  width: 280px;\n  height: 280px;\n  background:\n    radial-gradient(\n      circle,\n      rgba(56, 189, 248, 0.15) 0%,\n      rgba(146, 228, 203, 0.05) 70%);\n  filter: blur(40px);\n  z-index: 1;\n}\n.hero-visual .tech-mockup {\n  position: relative;\n  z-index: 2;\n  width: 340px;\n  height: 340px;\n  flex-shrink: 0;\n  background:\n    linear-gradient(\n      135deg,\n      #f8fafc 0%,\n      #e2edf0 100%);\n  border: 2px solid rgba(255, 255, 255, 0.8);\n  border-radius: 32px;\n  box-shadow: 0 20px 40px rgba(15, 23, 42, 0.08);\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  -webkit-backdrop-filter: blur(8px);\n  backdrop-filter: blur(8px);\n}\n.hero-visual .tech-mockup .logo-itb-futurista {\n  max-width: 70%;\n  max-height: 70%;\n  object-fit: contain;\n  opacity: 0.75;\n  mix-blend-mode: multiply;\n  filter: drop-shadow(0 0 20px rgba(56, 189, 248, 0.4)) drop-shadow(0 0 40px rgba(45, 76, 126, 0.1));\n  transition: all 0.4s ease;\n}\n.hero-visual .tech-mockup .logo-itb-futurista:hover {\n  opacity: 0.95;\n  transform: scale(1.03);\n  filter: drop-shadow(0 0 25px rgba(56, 189, 248, 0.6));\n}\n.hero-visual .tech-mockup .floating-badge {\n  position: absolute;\n  bottom: 20px;\n  right: -20px;\n  background: #ffffff;\n  border-left: 4px solid #92e4cb;\n  padding: 12px 20px;\n  border-radius: 12px;\n  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.05);\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  font-weight: 700;\n  font-size: 0.9rem;\n  color: #0f172a;\n  animation: float 4s ease-in-out infinite;\n}\n.hero-visual .tech-mockup .floating-badge i {\n  color: #14b8a6;\n}\n.razones-section .section-title {\n  text-align: center;\n  margin-bottom: 50px;\n}\n.razones-section .section-title h2 {\n  font-size: 2rem;\n  color: #2d4c7e;\n  font-weight: 700;\n  margin-bottom: 10px;\n}\n.razones-section .section-title .subtitulo {\n  color: #475569;\n  font-size: 1rem;\n}\n.razones-grid {\n  display: grid;\n  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));\n  gap: 30px;\n}\n.razon-card {\n  background-color: #ffffff;\n  border: 1px solid #e2e8f0;\n  border-radius: 16px;\n  padding: 30px;\n  transition: all 0.3s ease;\n  box-shadow: 0 4px 6px rgba(15, 23, 42, 0.02);\n}\n.razon-card .icon-box {\n  width: 50px;\n  height: 50px;\n  background-color: #f1f5f9;\n  border-radius: 12px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  margin-bottom: 20px;\n  font-size: 1.4rem;\n  color: #2d4c7e;\n  transition: all 0.3s ease;\n}\n.razon-card h3 {\n  margin: 0 0 12px 0;\n  font-size: 1.25rem;\n  color: #0f172a;\n  font-weight: 700;\n}\n.razon-card p {\n  margin: 0;\n  color: #475569;\n  font-size: 0.95rem;\n  line-height: 1.6;\n}\n.razon-card:hover {\n  transform: translateY(-5px);\n  box-shadow: 0 12px 20px rgba(15, 23, 42, 0.06);\n  border-color: #38bdf8;\n}\n.razon-card:hover .icon-box {\n  background-color: rgba(56, 189, 248, 0.1);\n  color: #38bdf8;\n}\n.razon-card.destacado {\n  border-top: 4px solid #92e4cb;\n}\n@keyframes float {\n  0% {\n    transform: translateY(0px);\n  }\n  50% {\n    transform: translateY(-10px);\n  }\n  100% {\n    transform: translateY(0px);\n  }\n}\n.faq-section {\n  margin-top: 20px;\n}\n.faq-section .faq-container {\n  max-width: 800px;\n  margin: 0 auto;\n  display: flex;\n  flex-direction: column;\n  gap: 15px;\n}\n.faq-section .faq-item {\n  background: #ffffff;\n  border: 1px solid #e2e8f0;\n  border-radius: 12px;\n  overflow: hidden;\n  transition: all 0.3s ease;\n}\n.faq-section .faq-item.faq-abierta {\n  border-color: #38bdf8;\n  box-shadow: 0 10px 20px rgba(15, 23, 42, 0.04);\n}\n.faq-section .faq-item.faq-abierta .faq-pregunta {\n  color: #2d4c7e;\n  background-color: rgba(56, 189, 248, 0.03);\n}\n.faq-section .faq-pregunta {\n  width: 100%;\n  background: none;\n  border: none;\n  padding: 20px;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  font-size: 1.05rem;\n  font-weight: 600;\n  color: #0f172a;\n  cursor: pointer;\n  text-align: left;\n  transition: all 0.2s ease;\n}\n.faq-section .faq-pregunta:hover {\n  background-color: #f8fafc;\n}\n.faq-section .faq-pregunta i {\n  font-size: 0.9rem;\n  color: #475569;\n  transition: transform 0.3s ease;\n}\n.faq-section .faq-respuesta {\n  padding: 0 20px 20px 20px;\n  background-color: rgba(248, 250, 252, 0.5);\n}\n.faq-section .faq-respuesta p {\n  margin: 0;\n  font-size: 0.95rem;\n  line-height: 1.6;\n  color: #475569;\n}\n.section-title {\n  text-align: center;\n  margin-bottom: 50px;\n}\n.section-title h2 {\n  font-size: 2rem;\n  color: #2d4c7e;\n  font-weight: 700;\n  margin-bottom: 10px;\n}\n.section-title .subtitulo {\n  color: #475569;\n  font-size: 1rem;\n}\n.stats-section .stats-grid {\n  display: grid;\n  grid-template-columns: repeat(4, 1fr);\n  gap: 20px;\n}\n@media (max-width: 960px) {\n  .stats-section .stats-grid {\n    grid-template-columns: repeat(2, 1fr);\n  }\n}\n.stats-section .stat-card {\n  background:\n    linear-gradient(\n      135deg,\n      rgba(146, 228, 203, 0.12) 0%,\n      rgba(56, 189, 248, 0.08) 100%);\n  border: 1px solid #e2e8f0;\n  border-radius: 16px;\n  padding: 24px 16px;\n  text-align: center;\n  transition: all 0.3s ease;\n}\n.stats-section .stat-card:hover {\n  transform: translateY(-4px);\n  box-shadow: 0 12px 20px rgba(15, 23, 42, 0.06);\n}\n.stats-section .stat-numero {\n  font-size: 2rem;\n  font-weight: 800;\n  color: #2d4c7e;\n}\n.stats-section .stat-label {\n  font-size: 0.85rem;\n  font-weight: 600;\n  color: #475569;\n  margin-top: 6px;\n}\n.pasos-section .pasos-grid {\n  display: grid;\n  grid-template-columns: repeat(3, 1fr);\n  gap: 30px;\n}\n@media (max-width: 960px) {\n  .pasos-section .pasos-grid {\n    grid-template-columns: 1fr;\n  }\n}\n.pasos-section .paso-card {\n  position: relative;\n  background-color: #ffffff;\n  border: 1px solid #e2e8f0;\n  border-radius: 16px;\n  padding: 34px 24px 28px;\n  text-align: center;\n  box-shadow: 0 4px 6px rgba(15, 23, 42, 0.02);\n  transition: all 0.3s ease;\n}\n.pasos-section .paso-card:hover {\n  transform: translateY(-5px);\n  box-shadow: 0 12px 20px rgba(15, 23, 42, 0.06);\n  border-color: #38bdf8;\n}\n.pasos-section .paso-numero {\n  position: absolute;\n  top: -16px;\n  left: 50%;\n  transform: translateX(-50%);\n  width: 32px;\n  height: 32px;\n  border-radius: 50%;\n  background:\n    linear-gradient(\n      135deg,\n      #2d4c7e 0%,\n      #38bdf8 100%);\n  color: #ffffff;\n  font-weight: 800;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 0.9rem;\n  box-shadow: 0 6px 14px rgba(45, 76, 126, 0.25);\n}\n.pasos-section .icon-box {\n  width: 50px;\n  height: 50px;\n  background-color: #f1f5f9;\n  border-radius: 12px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  margin: 12px auto 18px;\n  font-size: 1.3rem;\n  color: #2d4c7e;\n}\n.pasos-section h3 {\n  margin: 0 0 10px 0;\n  font-size: 1.15rem;\n  color: #0f172a;\n  font-weight: 700;\n}\n.pasos-section p {\n  margin: 0;\n  color: #475569;\n  font-size: 0.92rem;\n  line-height: 1.6;\n}\n.ofertas-destacadas-section .ofertas-destacadas-grid {\n  display: grid;\n  grid-template-columns: repeat(3, 1fr);\n  gap: 24px;\n  margin-top: 40px;\n}\n@media (max-width: 960px) {\n  .ofertas-destacadas-section .ofertas-destacadas-grid {\n    grid-template-columns: 1fr;\n  }\n}\n.ofertas-destacadas-section .oferta-destacada-card {\n  background-color: #ffffff;\n  border: 1px solid #e2e8f0;\n  border-radius: 16px;\n  padding: 24px;\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n  box-shadow: 0 4px 6px rgba(15, 23, 42, 0.02);\n  transition: all 0.3s ease;\n}\n.ofertas-destacadas-section .oferta-destacada-card:hover {\n  transform: translateY(-5px);\n  box-shadow: 0 12px 20px rgba(15, 23, 42, 0.06);\n  border-color: #38bdf8;\n}\n.ofertas-destacadas-section .oferta-header h3 {\n  margin: 0 0 4px 0;\n  font-size: 1.05rem;\n  color: #0f172a;\n  font-weight: 700;\n}\n.ofertas-destacadas-section .oferta-empresa {\n  font-size: 0.85rem;\n  color: #475569;\n  font-weight: 600;\n}\n.ofertas-destacadas-section .oferta-tags {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 8px;\n}\n.ofertas-destacadas-section .tag-tec {\n  background-color: #f1f5f9;\n  color: #2d4c7e;\n  font-size: 0.78rem;\n  font-weight: 700;\n  padding: 5px 12px;\n  border-radius: 20px;\n}\n.ofertas-destacadas-section .btn-ver-oferta {\n  margin-top: auto;\n  align-self: flex-start;\n  background: none;\n  border: none;\n  color: #16079e;\n  font-weight: 700;\n  font-size: 0.92rem;\n  cursor: pointer;\n  padding: 0;\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  transition: gap 0.2s ease;\n}\n.ofertas-destacadas-section .btn-ver-oferta:hover {\n  gap: 10px;\n}\n.ofertas-destacadas-section .sin-ofertas {\n  grid-column: 1/-1;\n  text-align: center;\n  color: #475569;\n  font-style: italic;\n}\n.ofertas-destacadas-section .ver-todas-wrapper {\n  text-align: center;\n  margin-top: 32px;\n}\n.ofertas-destacadas-section .btn-secundario {\n  background-color: #ffffff;\n  border: 2px solid #2d4c7e;\n  color: #2d4c7e;\n  font-weight: 700;\n  padding: 12px 28px;\n  border-radius: 30px;\n  cursor: pointer;\n  transition: all 0.3s ease;\n}\n.ofertas-destacadas-section .btn-secundario:hover {\n  background-color: #2d4c7e;\n  color: #ffffff;\n  transform: translateY(-2px);\n}\n.cta-empresas-section .cta-empresas-content {\n  background:\n    linear-gradient(\n      135deg,\n      #2d4c7e 0%,\n      #1e3a8a 100%);\n  border-radius: 24px;\n  padding: 44px;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 30px;\n  box-shadow: 0 20px 40px rgba(15, 23, 42, 0.12);\n}\n@media (max-width: 820px) {\n  .cta-empresas-section .cta-empresas-content {\n    flex-direction: column;\n    text-align: center;\n  }\n}\n.cta-empresas-section .cta-empresas-content .badge-tech {\n  background-color: rgba(255, 255, 255, 0.15);\n  color: #ffffff;\n}\n.cta-empresas-section .cta-empresas-content h2 {\n  color: #ffffff;\n  margin: 10px 0 8px 0;\n  font-size: 1.5rem;\n  font-weight: 800;\n}\n.cta-empresas-section .cta-empresas-content p {\n  color: rgba(255, 255, 255, 0.85);\n  max-width: 480px;\n  margin: 0;\n}\n.cta-empresas-section .cta-empresas-btn {\n  white-space: nowrap;\n  background: #ffffff !important;\n  color: #2d4c7e !important;\n  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);\n}\n/*# sourceMappingURL=principal.css.map */\n"] }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i0.\u0275setClassDebugInfo(Principal, { className: "Principal", filePath: "app/pagina/principal/principal.ts", lineNumber: 30 });
})();
(() => {
  const id = "app%2Fpagina%2Fprincipal%2Fprincipal.ts%40Principal";
  function Principal_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i0.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i0.\u0275\u0275replaceMetadata(Principal, m.default, [i0], [RouterLink, Component], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && Principal_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && Principal_HmrLoad(d.timestamp)));
})();

// src/app/pagina/sesion/sesion.ts
import { Component as Component2, inject } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import { FormGroup, FormControl, Validators, ReactiveFormsModule } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_forms.js?v=3d725e17";
import { RouterLink as RouterLink2, Router } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_router.js?v=3d725e17";
import * as i02 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import * as i1 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_forms.js?v=3d725e17";
function Sesion_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    i02.\u0275\u0275elementStart(0, "div", 12);
    i02.\u0275\u0275text(1, " La contrase\xF1a debe tener: ");
    i02.\u0275\u0275element(2, "br");
    i02.\u0275\u0275text(3, " \u2022 Al menos una may\xFAscula ");
    i02.\u0275\u0275element(4, "br");
    i02.\u0275\u0275text(5, " \u2022 Un n\xFAmero ");
    i02.\u0275\u0275element(6, "br");
    i02.\u0275\u0275text(7, " \u2022 M\xEDnimo 8 caracteres ");
    i02.\u0275\u0275elementEnd();
  }
}
var Sesion = class _Sesion {
  // SERVICIOS
  authService = inject(AuthService);
  router = inject(Router);
  // MOSTRAR / OCULTAR PASSWORD
  mostrarPassword = false;
  togglePassword() {
    this.mostrarPassword = !this.mostrarPassword;
  }
  // FORMULARIO
  loginForm = new FormGroup({
    email: new FormControl("", [
      Validators.required,
      Validators.email
    ]),
    password: new FormControl("", [
      Validators.required,
      Validators.minLength(8),
      Validators.pattern(/^(?=.*[A-Z])(?=.*\d).+$/)
    ])
  });
  // LOGIN
  ingresar() {
    if (this.loginForm.valid) {
      const credenciales = this.loginForm.value;
      console.log("Enviando datos al servidor:", credenciales.email);
      this.authService.login(credenciales).subscribe({
        next: (res) => {
          console.log("\xA1\xC9xito! Respuesta completa del servidor:", res);
          if (res.success) {
            localStorage.setItem("token", res.token);
            localStorage.setItem("tipo", res.tipo);
            localStorage.setItem("user", JSON.stringify(res.user));
            if (res.tipo === "admin") {
              alert("\xA1Bienvenido/a Administrador/a!");
              this.router.navigate(["/panel-admin"]);
            } else if (res.tipo === "empresa") {
              alert("\xA1Bienvenida Empresa!");
              this.router.navigate(["/perfiles/empresa-profile"]);
            } else if (res.tipo === "postulante") {
              alert("\xA1Bienvenido/a Postulante!");
              this.router.navigate(["/ofertas"]);
            } else {
              alert("\xA1Bienvenido/a!");
              this.router.navigate(["/"]);
            }
          }
        },
        error: (err) => {
          console.error("Error en el login:", err);
          alert("Error: " + (err.error?.message || "No se pudo iniciar sesi\xF3n"));
        }
      });
    } else {
      this.loginForm.markAllAsTouched();
      alert("Por favor, completa los campos correctamente.");
    }
  }
  static \u0275fac = function Sesion_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Sesion)();
  };
  static \u0275cmp = /* @__PURE__ */ i02.\u0275\u0275defineComponent({ type: _Sesion, selectors: [["app-sesion"]], decls: 24, vars: 8, consts: [[1, "main-split-container"], [1, "info-column"], [1, "info-content"], ["src", "img/plataforma.png", "alt", "ITB Conecta", 1, "img-fluida"], [1, "form-column"], [1, "login-box"], [3, "ngSubmit", "formGroup"], ["type", "email", "formControlName", "email", "placeholder", "Tu correo"], [1, "password-container"], ["formControlName", "password", "placeholder", "Tu contrase\xF1a", 3, "type"], [1, "ojo", 3, "click"], [1, "fa-solid"], [1, "error"], ["type", "submit", 3, "disabled"], [1, "contenedor-enlace"], ["routerLink", "/registrar", 1, "mi-enlace"]], template: function Sesion_Template(rf, ctx) {
    if (rf & 1) {
      i02.\u0275\u0275elementStart(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "h2");
      i02.\u0275\u0275text(4, "Acceso al Sistema");
      i02.\u0275\u0275elementEnd();
      i02.\u0275\u0275elementStart(5, "p");
      i02.\u0275\u0275text(6, " Ingresa con el correo electr\xF3nico y contrase\xF1a que registraste previamente para acceder al Sistema de Intermediaci\xF3n Laboral. ");
      i02.\u0275\u0275elementEnd();
      i02.\u0275\u0275element(7, "img", 3);
      i02.\u0275\u0275elementEnd()();
      i02.\u0275\u0275elementStart(8, "div", 4)(9, "div", 5)(10, "form", 6);
      i02.\u0275\u0275listener("ngSubmit", function Sesion_Template_form_ngSubmit_10_listener() {
        return ctx.ingresar();
      });
      i02.\u0275\u0275element(11, "input", 7);
      i02.\u0275\u0275elementStart(12, "div", 8);
      i02.\u0275\u0275element(13, "input", 9);
      i02.\u0275\u0275elementStart(14, "span", 10);
      i02.\u0275\u0275listener("click", function Sesion_Template_span_click_14_listener() {
        return ctx.togglePassword();
      });
      i02.\u0275\u0275element(15, "i", 11);
      i02.\u0275\u0275elementEnd()();
      i02.\u0275\u0275conditionalCreate(16, Sesion_Conditional_16_Template, 8, 0, "div", 12);
      i02.\u0275\u0275elementStart(17, "button", 13);
      i02.\u0275\u0275text(18, " Iniciar Sesi\xF3n ");
      i02.\u0275\u0275elementEnd()();
      i02.\u0275\u0275elementStart(19, "div", 14)(20, "p");
      i02.\u0275\u0275text(21, " Si a\xFAn no tienes una cuenta, puedes registrarte haciendo clic en el siguiente enlace. ");
      i02.\u0275\u0275elementEnd();
      i02.\u0275\u0275elementStart(22, "a", 15);
      i02.\u0275\u0275text(23, " Ir a Registrarse ");
      i02.\u0275\u0275elementEnd()()()()();
    }
    if (rf & 2) {
      let tmp_4_0;
      i02.\u0275\u0275advance(10);
      i02.\u0275\u0275property("formGroup", ctx.loginForm);
      i02.\u0275\u0275advance(3);
      i02.\u0275\u0275property("type", ctx.mostrarPassword ? "text" : "password");
      i02.\u0275\u0275advance(2);
      i02.\u0275\u0275classProp("fa-eye", ctx.mostrarPassword)("fa-eye-slash", !ctx.mostrarPassword);
      i02.\u0275\u0275advance();
      i02.\u0275\u0275conditional(((tmp_4_0 = ctx.loginForm.get("password")) == null ? null : tmp_4_0.errors == null ? null : tmp_4_0.errors["pattern"]) && ((tmp_4_0 = ctx.loginForm.get("password")) == null ? null : tmp_4_0.touched) ? 16 : -1);
      i02.\u0275\u0275advance();
      i02.\u0275\u0275property("disabled", ctx.loginForm.invalid);
    }
  }, dependencies: [RouterLink2, ReactiveFormsModule, i1.\u0275NgNoValidate, i1.NgSelectOption, i1.\u0275NgSelectMultipleOption, i1.DefaultValueAccessor, i1.NumberValueAccessor, i1.RangeValueAccessor, i1.CheckboxControlValueAccessor, i1.SelectControlValueAccessor, i1.SelectMultipleControlValueAccessor, i1.RadioControlValueAccessor, i1.NgControlStatus, i1.NgControlStatusGroup, i1.RequiredValidator, i1.MinLengthValidator, i1.MaxLengthValidator, i1.PatternValidator, i1.CheckboxRequiredValidator, i1.EmailValidator, i1.MinValidator, i1.MaxValidator, i1.FormControlDirective, i1.FormGroupDirective, i1.FormArrayDirective, i1.FormControlName, i1.FormGroupName, i1.FormArrayName], styles: ['@charset "UTF-8";\n\n\n.main-split-container[_ngcontent-%COMP%] {\n  display: flex;\n  height: 100vh;\n  width: 100%;\n  overflow: hidden;\n}\n.info-column[_ngcontent-%COMP%] {\n  flex: 1;\n  background:\n    linear-gradient(\n      135deg,\n      #06245c,\n      #0aa7b8);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  padding: 20px;\n}\n.info-content[_ngcontent-%COMP%] {\n  max-width: 360px;\n  text-align: left;\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n  justify-content: center;\n}\n.info-content[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  color: white;\n  font-size: 2.1rem;\n  margin-bottom: 10px;\n  line-height: 1.2;\n}\n.info-content[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  margin-bottom: 20px;\n  color: #dffcff;\n}\n.info-content[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  color: white;\n  line-height: 1.5;\n  font-size: 0, 98rem;\n  margin-bottom: 10px;\n}\n.img-fluida[_ngcontent-%COMP%] {\n  width: 100%;\n  max-width: 240px;\n  height: auto;\n  border-radius: 18px;\n  margin-top: 10px;\n  box-shadow: 0 12px 30px rgba(0, 0, 0, 0.25);\n}\n.form-column[_ngcontent-%COMP%] {\n  flex: 1;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  background-color: #eefafb;\n  padding: 40px;\n}\n.login-box[_ngcontent-%COMP%] {\n  width: 100%;\n  max-width: 500px;\n}\nform[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  padding: 40px;\n  border-radius: 28px;\n  margin-bottom: 20px;\n  background: rgba(227, 229, 238, 0.75);\n  border: 1px solid #b8ece5;\n  -webkit-backdrop-filter: blur(10px);\n  backdrop-filter: blur(10px);\n  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.08);\n  transition: 0.3s;\n}\nform[_ngcontent-%COMP%]:hover {\n  transform: translateY(-3px);\n  box-shadow: 0 25px 50px rgba(0, 0, 0, 0.12);\n}\ninput[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 16px;\n  margin-bottom: 25px;\n  border: 1px solid #cfd9e2;\n  border-radius: 14px;\n  background-color: white;\n  transition: 0.3s;\n  font-size: 15px;\n}\ninput[_ngcontent-%COMP%]:focus {\n  outline: none;\n  border-color: #0aa7b8;\n  box-shadow: 0 0 0 3px rgba(10, 167, 184, 0.2);\n}\n.password-container[_ngcontent-%COMP%] {\n  position: relative;\n  width: 100%;\n  margin-bottom: 25px;\n}\n.password-container[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n  margin-bottom: 0;\n}\n.password-container[_ngcontent-%COMP%]   .ojo[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 15px;\n  top: 50%;\n  transform: translateY(-50%);\n  cursor: pointer;\n  font-size: 20px;\n  -webkit-user-select: none;\n  user-select: none;\n  color: #5d4b7a;\n}\nbutton[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 16px;\n  background:\n    linear-gradient(\n      90deg,\n      #06245c,\n      #0aa7b8);\n  color: white;\n  border: none;\n  border-radius: 14px;\n  cursor: pointer;\n  font-weight: bold;\n  font-size: 16px;\n  transition: 0.3s;\n}\nbutton[_ngcontent-%COMP%]:hover {\n  transform: translateY(-2px);\n  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);\n}\nbutton[_ngcontent-%COMP%]:disabled {\n  opacity: 0.7;\n  cursor: not-allowed;\n}\n.contenedor-enlace[_ngcontent-%COMP%] {\n  text-align: center;\n  margin-top: 20px;\n}\n.mi-enlace[_ngcontent-%COMP%] {\n  color: #06245c;\n  text-decoration: none;\n  font-size: 18px;\n  font-weight: bold;\n  transition: 0.3s;\n}\n.mi-enlace[_ngcontent-%COMP%]:hover {\n  color: #0aa7b8;\n}\n@media (max-width: 768px) {\n  .main-split-container[_ngcontent-%COMP%] {\n    flex-direction: column;\n    min-height: auto;\n  }\n  .info-column[_ngcontent-%COMP%] {\n    padding: 30px 20px;\n    text-align: center;\n  }\n  .info-content[_ngcontent-%COMP%] {\n    align-items: center;\n  }\n  .info-content[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n    font-size: 2.1rem;\n  }\n  .info-content[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n    font-size: 1rem;\n  }\n  .img-fluida[_ngcontent-%COMP%] {\n    max-width: 250px;\n    margin-top: 15px;\n  }\n  .form-column[_ngcontent-%COMP%] {\n    padding: 25px 15px;\n  }\n  form[_ngcontent-%COMP%] {\n    padding: 25px 20px;\n  }\n}\n@media (min-width: 769px) and (max-width: 1100px) {\n  .info-column[_ngcontent-%COMP%], \n   .form-column[_ngcontent-%COMP%] {\n    padding: 25px;\n  }\n  .info-content[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n    font-size: 2.2rem;\n  }\n}\n@media (max-width: 576px) {\n  .info-column[_ngcontent-%COMP%] {\n    padding: 25px 15px;\n  }\n  .info-content[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n    font-size: 1.7rem;\n  }\n  .img-fluida[_ngcontent-%COMP%] {\n    max-width: 200px;\n  }\n  .form-column[_ngcontent-%COMP%] {\n    padding: 20px 12px;\n  }\n  form[_ngcontent-%COMP%] {\n    padding: 20px 15px;\n    border-radius: 20px;\n  }\n  input[_ngcontent-%COMP%], \n   button[_ngcontent-%COMP%] {\n    padding: 14px;\n  }\n  .mi-enlace[_ngcontent-%COMP%] {\n    font-size: 16px;\n  }\n}\n/*# sourceMappingURL=sesion.css.map */'] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassMetadata(Sesion, [{
    type: Component2,
    args: [{ selector: "app-sesion", standalone: true, imports: [RouterLink2, ReactiveFormsModule], template: `<div class="main-split-container">\r
  \r
  <!-- COLUMNA IZQUIERDA -->\r
  <div class="info-column">\r
    <div class="info-content">\r
\r
      <h2>Acceso al Sistema</h2>\r
\r
      <p>\r
        Ingresa con el correo electr\xF3nico y contrase\xF1a que registraste previamente \r
        para acceder al Sistema de Intermediaci\xF3n Laboral.\r
      </p>\r
\r
      <img \r
        src="img/plataforma.png" \r
        alt="ITB Conecta" \r
        class="img-fluida">\r
\r
    </div>\r
  </div>\r
\r
  <!-- COLUMNA DERECHA -->\r
  <div class="form-column">\r
\r
    <div class="login-box">\r
\r
      <form [formGroup]="loginForm" (ngSubmit)="ingresar()">\r
\r
        <!-- EMAIL -->\r
        <input \r
          type="email"\r
          formControlName="email"\r
          placeholder="Tu correo">\r
\r
        <!-- PASSWORD -->\r
        <div class="password-container">\r
\r
          <input\r
            [type]="mostrarPassword ? 'text' : 'password'"\r
            formControlName="password"\r
            placeholder="Tu contrase\xF1a">\r
\r
          <!-- OJITO -->\r
          <span class="ojo" (click)="togglePassword()">\r
\r
            <i\r
              class="fa-solid"\r
              [class.fa-eye]="mostrarPassword"\r
              [class.fa-eye-slash]="!mostrarPassword">\r
            </i>\r
\r
          </span>\r
\r
        </div>\r
\r
        <!-- ERROR PASSWORD -->\r
        @if (loginForm.get('password')?.errors?.['pattern']\r
             && loginForm.get('password')?.touched) {\r
          <div class="error">\r
            La contrase\xF1a debe tener:\r
            <br>\r
            \u2022 Al menos una may\xFAscula\r
            <br>\r
            \u2022 Un n\xFAmero\r
            <br>\r
            \u2022 M\xEDnimo 8 caracteres\r
          </div>\r
        }\r
\r
        <!-- BOTON -->\r
        <button \r
          type="submit"\r
          [disabled]="loginForm.invalid">\r
\r
          Iniciar Sesi\xF3n\r
\r
        </button>\r
\r
      </form>\r
\r
      <!-- ENLACE -->\r
      <div class="contenedor-enlace">\r
\r
        <p>\r
          Si a\xFAn no tienes una cuenta, puedes registrarte haciendo clic en el siguiente enlace.\r
        </p>\r
\r
        <a routerLink="/registrar" class="mi-enlace">\r
          Ir a Registrarse\r
        </a>\r
\r
      </div>\r
\r
    </div>\r
\r
  </div>\r
\r
</div>`, styles: ['@charset "UTF-8";\n\n/* src/app/pagina/sesion/sesion.scss */\n.main-split-container {\n  display: flex;\n  height: 100vh;\n  width: 100%;\n  overflow: hidden;\n}\n.info-column {\n  flex: 1;\n  background:\n    linear-gradient(\n      135deg,\n      #06245c,\n      #0aa7b8);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  padding: 20px;\n}\n.info-content {\n  max-width: 360px;\n  text-align: left;\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n  justify-content: center;\n}\n.info-content h2 {\n  color: white;\n  font-size: 2.1rem;\n  margin-bottom: 10px;\n  line-height: 1.2;\n}\n.info-content h3 {\n  margin-bottom: 20px;\n  color: #dffcff;\n}\n.info-content p {\n  color: white;\n  line-height: 1.5;\n  font-size: 0, 98rem;\n  margin-bottom: 10px;\n}\n.img-fluida {\n  width: 100%;\n  max-width: 240px;\n  height: auto;\n  border-radius: 18px;\n  margin-top: 10px;\n  box-shadow: 0 12px 30px rgba(0, 0, 0, 0.25);\n}\n.form-column {\n  flex: 1;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  background-color: #eefafb;\n  padding: 40px;\n}\n.login-box {\n  width: 100%;\n  max-width: 500px;\n}\nform {\n  display: flex;\n  flex-direction: column;\n  padding: 40px;\n  border-radius: 28px;\n  margin-bottom: 20px;\n  background: rgba(227, 229, 238, 0.75);\n  border: 1px solid #b8ece5;\n  -webkit-backdrop-filter: blur(10px);\n  backdrop-filter: blur(10px);\n  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.08);\n  transition: 0.3s;\n}\nform:hover {\n  transform: translateY(-3px);\n  box-shadow: 0 25px 50px rgba(0, 0, 0, 0.12);\n}\ninput {\n  width: 100%;\n  padding: 16px;\n  margin-bottom: 25px;\n  border: 1px solid #cfd9e2;\n  border-radius: 14px;\n  background-color: white;\n  transition: 0.3s;\n  font-size: 15px;\n}\ninput:focus {\n  outline: none;\n  border-color: #0aa7b8;\n  box-shadow: 0 0 0 3px rgba(10, 167, 184, 0.2);\n}\n.password-container {\n  position: relative;\n  width: 100%;\n  margin-bottom: 25px;\n}\n.password-container input {\n  margin-bottom: 0;\n}\n.password-container .ojo {\n  position: absolute;\n  right: 15px;\n  top: 50%;\n  transform: translateY(-50%);\n  cursor: pointer;\n  font-size: 20px;\n  -webkit-user-select: none;\n  user-select: none;\n  color: #5d4b7a;\n}\nbutton {\n  width: 100%;\n  padding: 16px;\n  background:\n    linear-gradient(\n      90deg,\n      #06245c,\n      #0aa7b8);\n  color: white;\n  border: none;\n  border-radius: 14px;\n  cursor: pointer;\n  font-weight: bold;\n  font-size: 16px;\n  transition: 0.3s;\n}\nbutton:hover {\n  transform: translateY(-2px);\n  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);\n}\nbutton:disabled {\n  opacity: 0.7;\n  cursor: not-allowed;\n}\n.contenedor-enlace {\n  text-align: center;\n  margin-top: 20px;\n}\n.mi-enlace {\n  color: #06245c;\n  text-decoration: none;\n  font-size: 18px;\n  font-weight: bold;\n  transition: 0.3s;\n}\n.mi-enlace:hover {\n  color: #0aa7b8;\n}\n@media (max-width: 768px) {\n  .main-split-container {\n    flex-direction: column;\n    min-height: auto;\n  }\n  .info-column {\n    padding: 30px 20px;\n    text-align: center;\n  }\n  .info-content {\n    align-items: center;\n  }\n  .info-content h2 {\n    font-size: 2.1rem;\n  }\n  .info-content p {\n    font-size: 1rem;\n  }\n  .img-fluida {\n    max-width: 250px;\n    margin-top: 15px;\n  }\n  .form-column {\n    padding: 25px 15px;\n  }\n  form {\n    padding: 25px 20px;\n  }\n}\n@media (min-width: 769px) and (max-width: 1100px) {\n  .info-column,\n  .form-column {\n    padding: 25px;\n  }\n  .info-content h2 {\n    font-size: 2.2rem;\n  }\n}\n@media (max-width: 576px) {\n  .info-column {\n    padding: 25px 15px;\n  }\n  .info-content h2 {\n    font-size: 1.7rem;\n  }\n  .img-fluida {\n    max-width: 200px;\n  }\n  .form-column {\n    padding: 20px 12px;\n  }\n  form {\n    padding: 20px 15px;\n    border-radius: 20px;\n  }\n  input,\n  button {\n    padding: 14px;\n  }\n  .mi-enlace {\n    font-size: 16px;\n  }\n}\n/*# sourceMappingURL=sesion.css.map */\n'] }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i02.\u0275setClassDebugInfo(Sesion, { className: "Sesion", filePath: "app/pagina/sesion/sesion.ts", lineNumber: 13 });
})();
(() => {
  const id = "app%2Fpagina%2Fsesion%2Fsesion.ts%40Sesion";
  function Sesion_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i02.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i02.\u0275\u0275replaceMetadata(Sesion, m.default, [i02, i1], [RouterLink2, ReactiveFormsModule, Component2], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && Sesion_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && Sesion_HmrLoad(d.timestamp)));
})();

// src/app/pagina/registrar/registrar-home/registrar-home.ts
import { Component as Component3, ViewEncapsulation } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import { RouterModule } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_router.js?v=3d725e17";
import * as i03 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import * as i12 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_router.js?v=3d725e17";
var RegistrarHome = class _RegistrarHome {
  static \u0275fac = function RegistrarHome_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _RegistrarHome)();
  };
  static \u0275cmp = /* @__PURE__ */ i03.\u0275\u0275defineComponent({ type: _RegistrarHome, selectors: [["app-registrar-home"]], decls: 28, vars: 0, consts: [[1, "main-split-container"], [1, "info-column"], [1, "info-content"], ["src", "img/crearcuenta.png", "alt", "ITB Conecta", 1, "img-fluida"], [1, "registro-container"], [1, "cards-grid"], ["routerLink", "/registrar-postulante", 1, "card"], [1, "icon"], [1, "btn-select"], ["routerLink", "/registrar-empresa", 1, "card"]], template: function RegistrarHome_Template(rf, ctx) {
    if (rf & 1) {
      i03.\u0275\u0275elementStart(0, "div", 0)(1, "div", 1)(2, "div", 2);
      i03.\u0275\u0275element(3, "img", 3);
      i03.\u0275\u0275elementEnd()();
      i03.\u0275\u0275elementStart(4, "div", 4)(5, "h2");
      i03.\u0275\u0275text(6, "\xA1Te damos la bienvenida a ITB Conecta!");
      i03.\u0275\u0275elementEnd();
      i03.\u0275\u0275elementStart(7, "p");
      i03.\u0275\u0275text(8, "Para comenzar, selecciona tu perfil:");
      i03.\u0275\u0275elementEnd();
      i03.\u0275\u0275elementStart(9, "div", 5)(10, "div", 6)(11, "div", 7);
      i03.\u0275\u0275text(12, "\u{1F393}");
      i03.\u0275\u0275elementEnd();
      i03.\u0275\u0275elementStart(13, "h3");
      i03.\u0275\u0275text(14, "Postulante");
      i03.\u0275\u0275elementEnd();
      i03.\u0275\u0275elementStart(15, "p");
      i03.\u0275\u0275text(16, "Post\xFAlate a ofertas y mejora tu perfil profesional.");
      i03.\u0275\u0275elementEnd();
      i03.\u0275\u0275elementStart(17, "button", 8);
      i03.\u0275\u0275text(18, "Soy Estudiante/Egresado");
      i03.\u0275\u0275elementEnd()();
      i03.\u0275\u0275elementStart(19, "div", 9)(20, "div", 7);
      i03.\u0275\u0275text(21, "\u{1F3E2}");
      i03.\u0275\u0275elementEnd();
      i03.\u0275\u0275elementStart(22, "h3");
      i03.\u0275\u0275text(23, "Empresa");
      i03.\u0275\u0275elementEnd();
      i03.\u0275\u0275elementStart(24, "p");
      i03.\u0275\u0275text(25, "Encuentra el mejor talento t\xE9cnico para tu Instituci\xF3n o Empresa.");
      i03.\u0275\u0275elementEnd();
      i03.\u0275\u0275elementStart(26, "button", 8);
      i03.\u0275\u0275text(27, "Soy Empresa");
      i03.\u0275\u0275elementEnd()()()()();
    }
  }, dependencies: [RouterModule, i12.RouterOutlet, i12.RouterLink, i12.RouterLinkActive, i12.\u0275EmptyOutletComponent], styles: ['@charset "UTF-8";\n\n/* src/app/pagina/registrar/registrar-home/registrar-home.scss */\n.main-split-container {\n  display: flex;\n  min-height: 100vh;\n  width: 100%;\n}\n.info-column {\n  flex: 1;\n  background:\n    linear-gradient(\n      135deg,\n      #06245c,\n      #0aa7b8);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  padding: 50px;\n}\n.info-content {\n  max-width: 500px;\n  text-align: center;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n}\n.info-content h2 {\n  color: white;\n  font-size: 3rem;\n  margin-bottom: 10px;\n}\n.info-content h3 {\n  color: #dffcff;\n  margin-bottom: 25px;\n  font-weight: 400;\n}\n.img-fluida {\n  width: 100%;\n  max-width: 420px;\n  height: auto;\n  border-radius: 24px;\n  margin-top: 20px;\n  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.25);\n}\n.registro-container {\n  flex: 1;\n  background-color: #eefafb;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n  text-align: center;\n  padding: 60px 40px;\n}\n.registro-container h2 {\n  color: #06245c;\n  font-size: 2.5rem;\n  margin-bottom: 10px;\n}\n.registro-container p {\n  color: #4c5b73;\n  font-size: 1.1rem;\n}\n.registro-container {\n}\n.registro-container .cards-grid {\n  display: flex;\n  justify-content: center;\n  gap: 20px;\n  margin-top: 40px;\n  width: 100%;\n  max-width: 600px;\n}\n.registro-container {\n}\n.registro-container .card {\n  flex: 1;\n  background: rgba(255, 255, 255, 0.85);\n  border: 2px solid #b8ece5;\n  border-radius: 24px;\n  padding: 30px 20px;\n  width: 290px;\n  cursor: pointer;\n  transition:\n    transform 0.3s ease,\n    box-shadow 0.3s ease,\n    border-color 0.3s ease;\n  -webkit-backdrop-filter: blur(10px);\n  backdrop-filter: blur(10px);\n  box-shadow: 0 12px 30px rgba(6, 36, 92, 0.08);\n}\n.registro-container .card:hover {\n  transform: translateY(-8px);\n  box-shadow: 0 20px 40px rgba(6, 36, 92, 0.15);\n  border-color: #0aa7b8;\n}\n.registro-container .card .icon {\n  font-size: 60px;\n  margin-bottom: 20px;\n}\n.registro-container .card h3 {\n  color: #06245c;\n  margin-bottom: 15px;\n  font-size: 1.6rem;\n}\n.registro-container .card p {\n  color: #4c5b73;\n  margin-bottom: 20px;\n  line-height: 1.5;\n}\n.registro-container .card .btn-select {\n  background:\n    linear-gradient(\n      90deg,\n      #06245c,\n      #0aa7b8);\n  color: white;\n  border: none;\n  padding: 12px 18px;\n  border-radius: 12px;\n  font-weight: bold;\n  cursor: pointer;\n  transition: transform 0.2s ease;\n  margin-top: 15px;\n}\n.registro-container .card .btn-select:hover {\n  transform: scale(1.05);\n}\n@media (max-width: 950px) {\n  .main-split-container {\n    flex-direction: column;\n  }\n  .info-column,\n  .registro-container {\n    width: 100%;\n    min-height: auto;\n    padding: 40px 20px;\n  }\n  .registro-container {\n  }\n  .registro-container .cards-grid {\n    flex-wrap: wrap;\n  }\n  .registro-container .card {\n    width: 100%;\n    max-width: 340px;\n  }\n}\n/*# sourceMappingURL=registrar-home.css.map */\n'], encapsulation: 2 });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i03.\u0275setClassMetadata(RegistrarHome, [{
    type: Component3,
    args: [{ selector: "app-registrar-home", standalone: true, imports: [RouterModule], encapsulation: ViewEncapsulation.None, template: '<div class="main-split-container">\n  \n  <div class="info-column">\n    <div class="info-content">  \n      <img src="img/crearcuenta.png" alt="ITB Conecta" class="img-fluida">\n    </div>\n  </div>\n\n  <div class="registro-container">\n    <h2>\xA1Te damos la bienvenida a ITB Conecta!</h2>\n    <p>Para comenzar, selecciona tu perfil:</p>\n\n    <div class="cards-grid">\n      <div class="card" routerLink="/registrar-postulante">\n        <div class="icon">\u{1F393}</div>\n        <h3>Postulante</h3>\n        <p>Post\xFAlate a ofertas y mejora tu perfil profesional.</p>\n        <button class="btn-select">Soy Estudiante/Egresado</button>\n      </div>       \n\n      <div class="card" routerLink="/registrar-empresa">\n        <div class="icon">\u{1F3E2}</div>\n        <h3>Empresa</h3>\n        <p>Encuentra el mejor talento t\xE9cnico para tu Instituci\xF3n o Empresa.</p>\n        <button class="btn-select">Soy Empresa</button>\n      </div>\n    </div>\n\n  </div>\n</div>', styles: ['@charset "UTF-8";\n\n/* src/app/pagina/registrar/registrar-home/registrar-home.scss */\n.main-split-container {\n  display: flex;\n  min-height: 100vh;\n  width: 100%;\n}\n.info-column {\n  flex: 1;\n  background:\n    linear-gradient(\n      135deg,\n      #06245c,\n      #0aa7b8);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  padding: 50px;\n}\n.info-content {\n  max-width: 500px;\n  text-align: center;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n}\n.info-content h2 {\n  color: white;\n  font-size: 3rem;\n  margin-bottom: 10px;\n}\n.info-content h3 {\n  color: #dffcff;\n  margin-bottom: 25px;\n  font-weight: 400;\n}\n.img-fluida {\n  width: 100%;\n  max-width: 420px;\n  height: auto;\n  border-radius: 24px;\n  margin-top: 20px;\n  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.25);\n}\n.registro-container {\n  flex: 1;\n  background-color: #eefafb;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n  text-align: center;\n  padding: 60px 40px;\n}\n.registro-container h2 {\n  color: #06245c;\n  font-size: 2.5rem;\n  margin-bottom: 10px;\n}\n.registro-container p {\n  color: #4c5b73;\n  font-size: 1.1rem;\n}\n.registro-container {\n}\n.registro-container .cards-grid {\n  display: flex;\n  justify-content: center;\n  gap: 20px;\n  margin-top: 40px;\n  width: 100%;\n  max-width: 600px;\n}\n.registro-container {\n}\n.registro-container .card {\n  flex: 1;\n  background: rgba(255, 255, 255, 0.85);\n  border: 2px solid #b8ece5;\n  border-radius: 24px;\n  padding: 30px 20px;\n  width: 290px;\n  cursor: pointer;\n  transition:\n    transform 0.3s ease,\n    box-shadow 0.3s ease,\n    border-color 0.3s ease;\n  -webkit-backdrop-filter: blur(10px);\n  backdrop-filter: blur(10px);\n  box-shadow: 0 12px 30px rgba(6, 36, 92, 0.08);\n}\n.registro-container .card:hover {\n  transform: translateY(-8px);\n  box-shadow: 0 20px 40px rgba(6, 36, 92, 0.15);\n  border-color: #0aa7b8;\n}\n.registro-container .card .icon {\n  font-size: 60px;\n  margin-bottom: 20px;\n}\n.registro-container .card h3 {\n  color: #06245c;\n  margin-bottom: 15px;\n  font-size: 1.6rem;\n}\n.registro-container .card p {\n  color: #4c5b73;\n  margin-bottom: 20px;\n  line-height: 1.5;\n}\n.registro-container .card .btn-select {\n  background:\n    linear-gradient(\n      90deg,\n      #06245c,\n      #0aa7b8);\n  color: white;\n  border: none;\n  padding: 12px 18px;\n  border-radius: 12px;\n  font-weight: bold;\n  cursor: pointer;\n  transition: transform 0.2s ease;\n  margin-top: 15px;\n}\n.registro-container .card .btn-select:hover {\n  transform: scale(1.05);\n}\n@media (max-width: 950px) {\n  .main-split-container {\n    flex-direction: column;\n  }\n  .info-column,\n  .registro-container {\n    width: 100%;\n    min-height: auto;\n    padding: 40px 20px;\n  }\n  .registro-container {\n  }\n  .registro-container .cards-grid {\n    flex-wrap: wrap;\n  }\n  .registro-container .card {\n    width: 100%;\n    max-width: 340px;\n  }\n}\n/*# sourceMappingURL=registrar-home.css.map */\n'] }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i03.\u0275setClassDebugInfo(RegistrarHome, { className: "RegistrarHome", filePath: "app/pagina/registrar/registrar-home/registrar-home.ts", lineNumber: 14 });
})();
(() => {
  const id = "app%2Fpagina%2Fregistrar%2Fregistrar-home%2Fregistrar-home.ts%40RegistrarHome";
  function RegistrarHome_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i03.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i03.\u0275\u0275replaceMetadata(RegistrarHome, m.default, [i03, i12], [RouterModule, Component3, ViewEncapsulation], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && RegistrarHome_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && RegistrarHome_HmrLoad(d.timestamp)));
})();

// src/app/pagina/registrar/registrar-postulante/registrar-postulante.ts
import { Component as Component4, inject as inject2 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import { FormControl as FormControl2, FormGroup as FormGroup2, ReactiveFormsModule as ReactiveFormsModule2, Validators as Validators2 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_forms.js?v=3d725e17";
import { CommonModule } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_common.js?v=3d725e17";
import { Router as Router2, RouterLink as RouterLink4 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_router.js?v=3d725e17";
import * as i04 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import * as i13 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_forms.js?v=3d725e17";
import * as i2 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_common.js?v=3d725e17";
function RegistrarPostulante_Conditional_18_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275elementStart(0, "small");
    i04.\u0275\u0275text(1, "El DNI es obligatorio.");
    i04.\u0275\u0275elementEnd();
  }
}
function RegistrarPostulante_Conditional_18_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275elementStart(0, "small");
    i04.\u0275\u0275text(1, "Solo se permiten n\xFAmeros.");
    i04.\u0275\u0275elementEnd();
  }
}
function RegistrarPostulante_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275elementStart(0, "div", 6);
    i04.\u0275\u0275conditionalCreate(1, RegistrarPostulante_Conditional_18_Conditional_1_Template, 2, 0, "small");
    i04.\u0275\u0275conditionalCreate(2, RegistrarPostulante_Conditional_18_Conditional_2_Template, 2, 0, "small");
    i04.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    let tmp_1_0;
    let tmp_2_0;
    const ctx_r0 = i04.\u0275\u0275nextContext();
    i04.\u0275\u0275advance();
    i04.\u0275\u0275conditional(((tmp_1_0 = ctx_r0.formRegistro.get("dni")) == null ? null : tmp_1_0.errors == null ? null : tmp_1_0.errors["required"]) ? 1 : -1);
    i04.\u0275\u0275advance();
    i04.\u0275\u0275conditional(((tmp_2_0 = ctx_r0.formRegistro.get("dni")) == null ? null : tmp_2_0.errors == null ? null : tmp_2_0.errors["pattern"]) ? 2 : -1);
  }
}
function RegistrarPostulante_Conditional_31_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275elementStart(0, "small");
    i04.\u0275\u0275text(1, "El correo es obligatorio.");
    i04.\u0275\u0275elementEnd();
  }
}
function RegistrarPostulante_Conditional_31_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275elementStart(0, "small");
    i04.\u0275\u0275text(1, "Formato de correo no v\xE1lido.");
    i04.\u0275\u0275elementEnd();
  }
}
function RegistrarPostulante_Conditional_31_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275elementStart(0, "div", 6);
    i04.\u0275\u0275conditionalCreate(1, RegistrarPostulante_Conditional_31_Conditional_1_Template, 2, 0, "small");
    i04.\u0275\u0275conditionalCreate(2, RegistrarPostulante_Conditional_31_Conditional_2_Template, 2, 0, "small");
    i04.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    let tmp_1_0;
    let tmp_2_0;
    const ctx_r0 = i04.\u0275\u0275nextContext();
    i04.\u0275\u0275advance();
    i04.\u0275\u0275conditional(((tmp_1_0 = ctx_r0.formRegistro.get("email")) == null ? null : tmp_1_0.errors == null ? null : tmp_1_0.errors["required"]) ? 1 : -1);
    i04.\u0275\u0275advance();
    i04.\u0275\u0275conditional(((tmp_2_0 = ctx_r0.formRegistro.get("email")) == null ? null : tmp_2_0.errors == null ? null : tmp_2_0.errors["email"]) ? 2 : -1);
  }
}
function RegistrarPostulante_Conditional_39_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275elementStart(0, "small");
    i04.\u0275\u0275text(1, "La contrase\xF1a es obligatoria.");
    i04.\u0275\u0275elementEnd();
  }
}
function RegistrarPostulante_Conditional_39_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275elementStart(0, "small");
    i04.\u0275\u0275text(1, "Debe tener al menos 8 caracteres.");
    i04.\u0275\u0275elementEnd();
  }
}
function RegistrarPostulante_Conditional_39_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275elementStart(0, "small");
    i04.\u0275\u0275text(1, " Debe contener al menos una may\xFAscula y un n\xFAmero. ");
    i04.\u0275\u0275elementEnd();
  }
}
function RegistrarPostulante_Conditional_39_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275elementStart(0, "div", 6);
    i04.\u0275\u0275conditionalCreate(1, RegistrarPostulante_Conditional_39_Conditional_1_Template, 2, 0, "small");
    i04.\u0275\u0275conditionalCreate(2, RegistrarPostulante_Conditional_39_Conditional_2_Template, 2, 0, "small");
    i04.\u0275\u0275conditionalCreate(3, RegistrarPostulante_Conditional_39_Conditional_3_Template, 2, 0, "small");
    i04.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    let tmp_1_0;
    let tmp_2_0;
    let tmp_3_0;
    const ctx_r0 = i04.\u0275\u0275nextContext();
    i04.\u0275\u0275advance();
    i04.\u0275\u0275conditional(((tmp_1_0 = ctx_r0.formRegistro.get("password")) == null ? null : tmp_1_0.errors == null ? null : tmp_1_0.errors["required"]) ? 1 : -1);
    i04.\u0275\u0275advance();
    i04.\u0275\u0275conditional(((tmp_2_0 = ctx_r0.formRegistro.get("password")) == null ? null : tmp_2_0.errors == null ? null : tmp_2_0.errors["minlength"]) ? 2 : -1);
    i04.\u0275\u0275advance();
    i04.\u0275\u0275conditional(((tmp_3_0 = ctx_r0.formRegistro.get("password")) == null ? null : tmp_3_0.errors == null ? null : tmp_3_0.errors["pattern"]) ? 3 : -1);
  }
}
function RegistrarPostulante_Conditional_47_Template(rf, ctx) {
  if (rf & 1) {
    i04.\u0275\u0275elementStart(0, "div", 6)(1, "small");
    i04.\u0275\u0275text(2, "Las contrase\xF1as no coinciden.");
    i04.\u0275\u0275elementEnd()();
  }
}
var RegistrarPostulante = class _RegistrarPostulante {
  authService = inject2(AuthService);
  router = inject2(Router2);
  // MOSTRAR / OCULTAR PASSWORD
  mostrarPassword = false;
  togglePassword() {
    this.mostrarPassword = !this.mostrarPassword;
  }
  // FORMULARIO
  formRegistro = new FormGroup2({
    nombres: new FormControl2("", [
      Validators2.required,
      Validators2.minLength(3)
    ]),
    apellidos: new FormControl2("", [
      Validators2.required
    ]),
    dni: new FormControl2("", [
      Validators2.required,
      Validators2.pattern("^[0-9]*$"),
      Validators2.minLength(7),
      Validators2.maxLength(8)
    ]),
    legajo: new FormControl2("", [
      Validators2.required
    ]),
    carrera: new FormControl2("", [
      Validators2.required
    ]),
    email: new FormControl2("", [
      Validators2.required,
      Validators2.email
    ]),
    password: new FormControl2("", [
      Validators2.required,
      Validators2.minLength(8),
      Validators2.pattern(/^(?=.*[A-Z])(?=.*\d).+$/)
    ]),
    confirmPassword: new FormControl2("", [
      Validators2.required
    ])
  });
  // REGISTRAR POSTULANTE
  registrarPostulante() {
    if (this.formRegistro.value.password !== this.formRegistro.value.confirmPassword) {
      alert("Las contrase\xF1as no coinciden");
      return;
    }
    if (this.formRegistro.valid) {
      const datos = this.formRegistro.value;
      this.authService.registrarPostulante(datos).subscribe({
        next: (res) => {
          console.log("\xA1Postulante creado con \xE9xito!", res);
          alert("Registro exitoso.");
          this.router.navigate(["/sesion"]);
        },
        error: (err) => {
          console.error("Error detallado desde el servidor:", err);
          const mensajeError = err.error?.message || "Hubo un error al crear la cuenta";
          alert(mensajeError);
        }
      });
    } else {
      this.formRegistro.markAllAsTouched();
      alert("Por favor, completa todos los campos obligatorios correctamente.");
    }
  }
  static \u0275fac = function RegistrarPostulante_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _RegistrarPostulante)();
  };
  static \u0275cmp = /* @__PURE__ */ i04.\u0275\u0275defineComponent({ type: _RegistrarPostulante, selectors: [["app-registrar-postulante"]], decls: 55, vars: 15, consts: [[1, "registro-container"], [3, "ngSubmit", "formGroup"], [1, "form-group"], ["type", "text", "formControlName", "nombres", "placeholder", "Ej: Juan Pablo"], ["type", "text", "formControlName", "apellidos", "placeholder", "Ej: P\xE9rez Garcia"], ["type", "text", "formControlName", "dni", "placeholder", "Solo n\xFAmeros, sin puntos"], [1, "error-msg"], ["type", "text", "formControlName", "legajo", "placeholder", "N\xFAmero dado por ITB"], ["type", "text", "formControlName", "carrera", "placeholder", "Ej: Analista de Sistemas"], ["type", "email", "formControlName", "email", "placeholder", "Ej: usuario@ibeltran.com.ar"], [1, "password-container"], ["formControlName", "password", "placeholder", "M\xEDnimo 8 caracteres", 3, "type"], [1, "ojo", 3, "click"], [1, "fa-solid"], ["formControlName", "confirmPassword", "placeholder", "Repet\xED tu contrase\xF1a", 3, "type"], ["type", "submit"], [1, "acciones-extra"], ["type", "button", "routerLink", "/registrar", 1, "btn-volver"], ["type", "button", "routerLink", "/sesion", 1, "btn-login"]], template: function RegistrarPostulante_Template(rf, ctx) {
    if (rf & 1) {
      i04.\u0275\u0275elementStart(0, "div", 0)(1, "h2");
      i04.\u0275\u0275text(2, "\xBFQuieres registrarte como postulante?");
      i04.\u0275\u0275elementEnd();
      i04.\u0275\u0275elementStart(3, "p");
      i04.\u0275\u0275text(4, " Completa los datos para acceder al Sistema de intermediaci\xF3n Laboral ");
      i04.\u0275\u0275elementEnd();
      i04.\u0275\u0275elementStart(5, "form", 1);
      i04.\u0275\u0275listener("ngSubmit", function RegistrarPostulante_Template_form_ngSubmit_5_listener($event) {
        ctx.registrarPostulante();
        return $event.preventDefault();
      });
      i04.\u0275\u0275elementStart(6, "div", 2)(7, "label");
      i04.\u0275\u0275text(8, "Nombres:");
      i04.\u0275\u0275elementEnd();
      i04.\u0275\u0275element(9, "input", 3);
      i04.\u0275\u0275elementEnd();
      i04.\u0275\u0275elementStart(10, "div", 2)(11, "label");
      i04.\u0275\u0275text(12, "Apellidos:");
      i04.\u0275\u0275elementEnd();
      i04.\u0275\u0275element(13, "input", 4);
      i04.\u0275\u0275elementEnd();
      i04.\u0275\u0275elementStart(14, "div", 2)(15, "label");
      i04.\u0275\u0275text(16, "DNI:");
      i04.\u0275\u0275elementEnd();
      i04.\u0275\u0275element(17, "input", 5);
      i04.\u0275\u0275conditionalCreate(18, RegistrarPostulante_Conditional_18_Template, 3, 2, "div", 6);
      i04.\u0275\u0275elementEnd();
      i04.\u0275\u0275elementStart(19, "div", 2)(20, "label");
      i04.\u0275\u0275text(21, "Legajo:");
      i04.\u0275\u0275elementEnd();
      i04.\u0275\u0275element(22, "input", 7);
      i04.\u0275\u0275elementEnd();
      i04.\u0275\u0275elementStart(23, "div", 2)(24, "label");
      i04.\u0275\u0275text(25, "Carrera:");
      i04.\u0275\u0275elementEnd();
      i04.\u0275\u0275element(26, "input", 8);
      i04.\u0275\u0275elementEnd();
      i04.\u0275\u0275elementStart(27, "div", 2)(28, "label");
      i04.\u0275\u0275text(29, "Correo Electr\xF3nico:");
      i04.\u0275\u0275elementEnd();
      i04.\u0275\u0275element(30, "input", 9);
      i04.\u0275\u0275conditionalCreate(31, RegistrarPostulante_Conditional_31_Template, 3, 2, "div", 6);
      i04.\u0275\u0275elementEnd();
      i04.\u0275\u0275elementStart(32, "div", 2)(33, "label");
      i04.\u0275\u0275text(34, "Contrase\xF1a");
      i04.\u0275\u0275elementEnd();
      i04.\u0275\u0275elementStart(35, "div", 10);
      i04.\u0275\u0275element(36, "input", 11);
      i04.\u0275\u0275elementStart(37, "span", 12);
      i04.\u0275\u0275listener("click", function RegistrarPostulante_Template_span_click_37_listener() {
        return ctx.togglePassword();
      });
      i04.\u0275\u0275element(38, "i", 13);
      i04.\u0275\u0275elementEnd()();
      i04.\u0275\u0275conditionalCreate(39, RegistrarPostulante_Conditional_39_Template, 4, 3, "div", 6);
      i04.\u0275\u0275elementEnd();
      i04.\u0275\u0275elementStart(40, "div", 2)(41, "label");
      i04.\u0275\u0275text(42, "Confirmar Contrase\xF1a");
      i04.\u0275\u0275elementEnd();
      i04.\u0275\u0275elementStart(43, "div", 10);
      i04.\u0275\u0275element(44, "input", 14);
      i04.\u0275\u0275elementStart(45, "span", 12);
      i04.\u0275\u0275listener("click", function RegistrarPostulante_Template_span_click_45_listener() {
        return ctx.togglePassword();
      });
      i04.\u0275\u0275element(46, "i", 13);
      i04.\u0275\u0275elementEnd()();
      i04.\u0275\u0275conditionalCreate(47, RegistrarPostulante_Conditional_47_Template, 3, 0, "div", 6);
      i04.\u0275\u0275elementEnd();
      i04.\u0275\u0275elementStart(48, "button", 15);
      i04.\u0275\u0275text(49, " Crear Cuenta\n");
      i04.\u0275\u0275elementEnd()();
      i04.\u0275\u0275elementStart(50, "div", 16)(51, "button", 17);
      i04.\u0275\u0275text(52, " \u2190 Volver ");
      i04.\u0275\u0275elementEnd();
      i04.\u0275\u0275elementStart(53, "button", 18);
      i04.\u0275\u0275text(54, " Ya tengo cuenta ");
      i04.\u0275\u0275elementEnd()()();
    }
    if (rf & 2) {
      let tmp_1_0;
      let tmp_2_0;
      let tmp_6_0;
      let tmp_10_0;
      i04.\u0275\u0275advance(5);
      i04.\u0275\u0275property("formGroup", ctx.formRegistro);
      i04.\u0275\u0275advance(13);
      i04.\u0275\u0275conditional(((tmp_1_0 = ctx.formRegistro.get("dni")) == null ? null : tmp_1_0.invalid) && ((tmp_1_0 = ctx.formRegistro.get("dni")) == null ? null : tmp_1_0.touched) ? 18 : -1);
      i04.\u0275\u0275advance(13);
      i04.\u0275\u0275conditional(((tmp_2_0 = ctx.formRegistro.get("email")) == null ? null : tmp_2_0.invalid) && ((tmp_2_0 = ctx.formRegistro.get("email")) == null ? null : tmp_2_0.touched) ? 31 : -1);
      i04.\u0275\u0275advance(5);
      i04.\u0275\u0275property("type", ctx.mostrarPassword ? "text" : "password");
      i04.\u0275\u0275advance(2);
      i04.\u0275\u0275classProp("fa-eye", ctx.mostrarPassword)("fa-eye-slash", !ctx.mostrarPassword);
      i04.\u0275\u0275advance();
      i04.\u0275\u0275conditional(((tmp_6_0 = ctx.formRegistro.get("password")) == null ? null : tmp_6_0.invalid) && ((tmp_6_0 = ctx.formRegistro.get("password")) == null ? null : tmp_6_0.touched) ? 39 : -1);
      i04.\u0275\u0275advance(5);
      i04.\u0275\u0275property("type", ctx.mostrarPassword ? "text" : "password");
      i04.\u0275\u0275advance(2);
      i04.\u0275\u0275classProp("fa-eye", ctx.mostrarPassword)("fa-eye-slash", !ctx.mostrarPassword);
      i04.\u0275\u0275advance();
      i04.\u0275\u0275conditional(((tmp_10_0 = ctx.formRegistro.get("confirmPassword")) == null ? null : tmp_10_0.touched) && ((tmp_10_0 = ctx.formRegistro.get("password")) == null ? null : tmp_10_0.value) !== ((tmp_10_0 = ctx.formRegistro.get("confirmPassword")) == null ? null : tmp_10_0.value) ? 47 : -1);
    }
  }, dependencies: [ReactiveFormsModule2, i13.\u0275NgNoValidate, i13.NgSelectOption, i13.\u0275NgSelectMultipleOption, i13.DefaultValueAccessor, i13.NumberValueAccessor, i13.RangeValueAccessor, i13.CheckboxControlValueAccessor, i13.SelectControlValueAccessor, i13.SelectMultipleControlValueAccessor, i13.RadioControlValueAccessor, i13.NgControlStatus, i13.NgControlStatusGroup, i13.RequiredValidator, i13.MinLengthValidator, i13.MaxLengthValidator, i13.PatternValidator, i13.CheckboxRequiredValidator, i13.EmailValidator, i13.MinValidator, i13.MaxValidator, i13.FormControlDirective, i13.FormGroupDirective, i13.FormArrayDirective, i13.FormControlName, i13.FormGroupName, i13.FormArrayName, CommonModule, i2.NgClass, i2.NgComponentOutlet, i2.NgForOf, i2.NgIf, i2.NgTemplateOutlet, i2.NgStyle, i2.NgSwitch, i2.NgSwitchCase, i2.NgSwitchDefault, i2.NgPlural, i2.NgPluralCase, RouterLink4, i2.AsyncPipe, i2.UpperCasePipe, i2.LowerCasePipe, i2.JsonPipe, i2.SlicePipe, i2.DecimalPipe, i2.PercentPipe, i2.TitleCasePipe, i2.CurrencyPipe, i2.DatePipe, i2.I18nPluralPipe, i2.I18nSelectPipe, i2.KeyValuePipe], styles: ['@charset "UTF-8";\n\n\n.registro-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  width: 100%;\n  padding: 30px 20px 60px;\n  background:\n    linear-gradient(\n      180deg,\n      #eefafb 0%,\n      #d7f3f4 100%);\n}\nform[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: 1fr 1fr;\n  gap: 16px;\n  width: 100%;\n  max-width: 700px;\n  padding: 30px;\n  border-radius: 28px;\n  background: rgba(255, 255, 255, 0.75);\n  border: 1px solid #b8ece5;\n  -webkit-backdrop-filter: blur(10px);\n  backdrop-filter: blur(10px);\n  box-shadow: 0 15px 35px rgba(6, 36, 92, 0.12);\n  transition: 0.3s ease;\n  box-sizing: border-box;\n}\n*[_ngcontent-%COMP%] {\n  box-sizing: border-box;\n}\nform[_ngcontent-%COMP%]:hover {\n  transform: translateY(-2px);\n  box-shadow: 0 20px 45px rgba(6, 36, 92, 0.18);\n}\n.form-group[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n}\n.form-group[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  margin-bottom: 8px;\n  font-weight: 700;\n  color: #06245c;\n  font-size: 15px;\n}\n.form-group[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n  padding: 14px;\n  border-radius: 14px;\n  border: 1px solid #cfd9e2;\n  background-color: white;\n  font-size: 15px;\n  transition: 0.3s ease;\n}\n.form-group[_ngcontent-%COMP%]   input[_ngcontent-%COMP%]:focus {\n  outline: none;\n  border-color: #0aa7b8;\n  box-shadow: 0 0 0 4px rgba(10, 167, 184, 0.15);\n}\nbutton[_ngcontent-%COMP%] {\n  grid-column: span 2;\n  padding: 16px;\n  border: none;\n  border-radius: 14px;\n  font-size: 16px;\n  font-weight: bold;\n  color: white;\n  cursor: pointer;\n  background:\n    linear-gradient(\n      90deg,\n      #06245c,\n      #0aa7b8);\n  transition: 0.3s ease;\n  margin-top: 10px;\n}\nbutton[_ngcontent-%COMP%]:hover {\n  transform: translateY(-2px);\n  box-shadow: 0 10px 25px rgba(6, 36, 92, 0.25);\n}\n@media (max-width: 768px) {\n  form[_ngcontent-%COMP%] {\n    grid-template-columns: 1fr;\n    padding: 30px 20px;\n  }\n  button[_ngcontent-%COMP%] {\n    grid-column: span 1;\n  }\n  h2[_ngcontent-%COMP%] {\n    text-align: center;\n    font-size: 32px;\n    color: #06245c;\n    margin-bottom: 10px;\n  }\n  p[_ngcontent-%COMP%] {\n    text-align: center;\n    color: #355070;\n    margin-bottom: 30px;\n    max-width: 500px;\n  }\n  .password-container[_ngcontent-%COMP%] {\n    position: relative;\n    display: flex;\n    align-items: center;\n  }\n  .password-container[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n    width: 100%;\n  }\n  .ojo[_ngcontent-%COMP%] {\n    position: absolute;\n    right: 15px;\n    cursor: pointer;\n    color: #06245c;\n  }\n}\n@media (max-width: 768px) and (max-width: 768px) {\n  .registro-container[_ngcontent-%COMP%] {\n    padding: 20px 12px;\n  }\n  form[_ngcontent-%COMP%] {\n    grid-template-columns: 1fr;\n    width: 100%;\n    padding: 25px 18px;\n    border-radius: 22px;\n  }\n  .form-group[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n    width: 100%;\n    font-size: 14px;\n  }\n  button[_ngcontent-%COMP%] {\n    grid-column: span 1;\n    width: 100%;\n  }\n  h2[_ngcontent-%COMP%] {\n    font-size: 24px;\n  }\n  p[_ngcontent-%COMP%] {\n    font-size: 14px;\n    padding: 0 10px;\n  }\n}\n@media (max-width: 768px) {\n  .acciones-extra[_ngcontent-%COMP%] {\n    grid-column: span 2;\n    display: flex;\n    justify-content: space-between;\n    align-items: center;\n    margin-top: 10px;\n  }\n  .btn-volver[_ngcontent-%COMP%] {\n    background: transparent;\n    border: 2px solid #0aa7b8;\n    color: #06245c;\n    padding: 12px 18px;\n    border-radius: 12px;\n    font-weight: 600;\n    cursor: pointer;\n    transition: 0.3s ease;\n  }\n  .btn-volver[_ngcontent-%COMP%]:hover {\n    background: #0aa7b8;\n    color: white;\n  }\n  .link-login[_ngcontent-%COMP%] {\n    text-decoration: none;\n    color: #06245c;\n    font-weight: 600;\n    transition: 0.3s ease;\n  }\n  .link-login[_ngcontent-%COMP%]:hover {\n    color: #0aa7b8;\n  }\n}\n@media (max-width: 768px) {\n}\n@media (max-width: 768px) and (max-width: 768px) {\n  .acciones-extra[_ngcontent-%COMP%] {\n    grid-column: span 1;\n    flex-direction: column;\n    gap: 15px;\n  }\n  .btn-volver[_ngcontent-%COMP%] {\n    width: 100%;\n  }\n}\n@media (max-width: 768px) {\n  .btn-login[_ngcontent-%COMP%] {\n    background: transparent;\n    border: 2px solid #06245c;\n    color: #06245c;\n    padding: 12px 18px;\n    border-radius: 12px;\n    font-weight: 600;\n    cursor: pointer;\n    transition: 0.3s ease;\n  }\n  .btn-login[_ngcontent-%COMP%]:hover {\n    background: #06245c;\n    color: white;\n  }\n}\n/*# sourceMappingURL=registrar-postulante.css.map */'] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i04.\u0275setClassMetadata(RegistrarPostulante, [{
    type: Component4,
    args: [{ selector: "app-registrar-postulante", standalone: true, imports: [
      ReactiveFormsModule2,
      CommonModule,
      RouterLink4
    ], template: `<div class="registro-container">\r
  \r
  <h2>\xBFQuieres registrarte como postulante?</h2>\r
\r
  <p>\r
    Completa los datos para acceder al Sistema de intermediaci\xF3n Laboral\r
  </p>\r
\r
  <form\r
    [formGroup]="formRegistro"\r
    (ngSubmit)="registrarPostulante(); $event.preventDefault()">\r
\r
    <!-- NOMBRES -->\r
    <div class="form-group">\r
\r
      <label>Nombres:</label>\r
\r
      <input\r
        type="text"\r
        formControlName="nombres"\r
        placeholder="Ej: Juan Pablo">\r
\r
    </div>\r
\r
    <!-- APELLIDOS -->\r
    <div class="form-group">\r
\r
      <label>Apellidos:</label>\r
\r
      <input\r
        type="text"\r
        formControlName="apellidos"\r
        placeholder="Ej: P\xE9rez Garcia">\r
\r
    </div>\r
\r
    <!-- DNI -->\r
    <div class="form-group">\r
\r
      <label>DNI:</label>\r
\r
      <input\r
        type="text"\r
        formControlName="dni"\r
        placeholder="Solo n\xFAmeros, sin puntos">\r
\r
      @if (formRegistro.get('dni')?.invalid &&\r
           formRegistro.get('dni')?.touched) {\r
\r
        <div class="error-msg">\r
\r
          @if (formRegistro.get('dni')?.errors?.['required']) {\r
            <small>El DNI es obligatorio.</small>\r
          }\r
\r
          @if (formRegistro.get('dni')?.errors?.['pattern']) {\r
            <small>Solo se permiten n\xFAmeros.</small>\r
          }\r
\r
        </div>\r
\r
      }\r
\r
    </div>\r
\r
    <!-- LEGAJO -->\r
    <div class="form-group">\r
\r
      <label>Legajo:</label>\r
\r
      <input\r
        type="text"\r
        formControlName="legajo"\r
        placeholder="N\xFAmero dado por ITB">\r
\r
    </div>\r
\r
    <!-- CARRERA -->\r
    <div class="form-group">\r
\r
      <label>Carrera:</label>\r
\r
      <input\r
        type="text"\r
        formControlName="carrera"\r
        placeholder="Ej: Analista de Sistemas">\r
\r
    </div>\r
\r
    <!-- EMAIL -->\r
    <div class="form-group">\r
\r
      <label>Correo Electr\xF3nico:</label>\r
\r
      <input\r
        type="email"\r
        formControlName="email"\r
        placeholder="Ej: usuario@ibeltran.com.ar">\r
\r
      @if (formRegistro.get('email')?.invalid &&\r
           formRegistro.get('email')?.touched) {\r
\r
        <div class="error-msg">\r
\r
          @if (formRegistro.get('email')?.errors?.['required']) {\r
            <small>El correo es obligatorio.</small>\r
          }\r
\r
          @if (formRegistro.get('email')?.errors?.['email']) {\r
            <small>Formato de correo no v\xE1lido.</small>\r
          }\r
\r
        </div>\r
\r
      }\r
\r
    </div>\r
\r
    <!-- PASSWORD -->\r
    <div class="form-group">\r
\r
      <label>Contrase\xF1a</label>\r
\r
      <div class="password-container">\r
\r
        <input\r
          [type]="mostrarPassword ? 'text' : 'password'"\r
          formControlName="password"\r
          placeholder="M\xEDnimo 8 caracteres">\r
\r
        <!-- OJITO -->\r
        <span class="ojo" (click)="togglePassword()">\r
\r
          <i\r
            class="fa-solid"\r
            [class.fa-eye]="mostrarPassword"\r
            [class.fa-eye-slash]="!mostrarPassword">\r
          </i>\r
\r
        </span>\r
\r
      </div>\r
\r
      @if (formRegistro.get('password')?.invalid &&\r
           formRegistro.get('password')?.touched) {\r
\r
        <div class="error-msg">\r
\r
          @if (formRegistro.get('password')?.errors?.['required']) {\r
            <small>La contrase\xF1a es obligatoria.</small>\r
          }\r
\r
          @if (formRegistro.get('password')?.errors?.['minlength']) {\r
            <small>Debe tener al menos 8 caracteres.</small>\r
          }\r
\r
          @if (formRegistro.get('password')?.errors?.['pattern']) {\r
            <small>\r
              Debe contener al menos una may\xFAscula y un n\xFAmero.\r
            </small>\r
          }\r
\r
        </div>\r
\r
      }\r
\r
    </div>\r
    <!-- CONFIRMAR PASSWORD -->\r
<div class="form-group">\r
\r
  <label>Confirmar Contrase\xF1a</label>\r
\r
  <div class="password-container">\r
\r
    <input\r
      [type]="mostrarPassword ? 'text' : 'password'"\r
      formControlName="confirmPassword"\r
      placeholder="Repet\xED tu contrase\xF1a">\r
\r
    <!-- OJITO -->\r
    <span class="ojo" (click)="togglePassword()">\r
\r
      <i\r
        class="fa-solid"\r
        [class.fa-eye]="mostrarPassword"\r
        [class.fa-eye-slash]="!mostrarPassword">\r
      </i>\r
\r
    </span>\r
\r
  </div>\r
\r
  @if (\r
    formRegistro.get('confirmPassword')?.touched &&\r
    formRegistro.get('password')?.value !==\r
    formRegistro.get('confirmPassword')?.value\r
  ) {\r
\r
    <div class="error-msg">\r
      <small>Las contrase\xF1as no coinciden.</small>\r
    </div>\r
\r
  }\r
\r
</div>\r
\r
    <!-- BOTON crear cuenta -->\r
    <button type="submit">\r
  Crear Cuenta\r
</button>\r
\r
  </form>\r
  <div class="acciones-extra">\r
\r
  <!-- VOLVER -->\r
  <button\r
    type="button"\r
    class="btn-volver"\r
    routerLink="/registrar">\r
\r
    \u2190 Volver\r
\r
  </button>\r
\r
  <!-- YA TENGO CUENTA -->\r
  <button\r
    type="button"\r
    class="btn-login"\r
    routerLink="/sesion">\r
\r
    Ya tengo cuenta\r
\r
  </button>\r
\r
\r
</div>`, styles: ['@charset "UTF-8";\n\n/* src/app/pagina/registrar/registrar-postulante/registrar-postulante.scss */\n.registro-container {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  width: 100%;\n  padding: 30px 20px 60px;\n  background:\n    linear-gradient(\n      180deg,\n      #eefafb 0%,\n      #d7f3f4 100%);\n}\nform {\n  display: grid;\n  grid-template-columns: 1fr 1fr;\n  gap: 16px;\n  width: 100%;\n  max-width: 700px;\n  padding: 30px;\n  border-radius: 28px;\n  background: rgba(255, 255, 255, 0.75);\n  border: 1px solid #b8ece5;\n  -webkit-backdrop-filter: blur(10px);\n  backdrop-filter: blur(10px);\n  box-shadow: 0 15px 35px rgba(6, 36, 92, 0.12);\n  transition: 0.3s ease;\n  box-sizing: border-box;\n}\n* {\n  box-sizing: border-box;\n}\nform:hover {\n  transform: translateY(-2px);\n  box-shadow: 0 20px 45px rgba(6, 36, 92, 0.18);\n}\n.form-group {\n  display: flex;\n  flex-direction: column;\n}\n.form-group label {\n  margin-bottom: 8px;\n  font-weight: 700;\n  color: #06245c;\n  font-size: 15px;\n}\n.form-group input {\n  padding: 14px;\n  border-radius: 14px;\n  border: 1px solid #cfd9e2;\n  background-color: white;\n  font-size: 15px;\n  transition: 0.3s ease;\n}\n.form-group input:focus {\n  outline: none;\n  border-color: #0aa7b8;\n  box-shadow: 0 0 0 4px rgba(10, 167, 184, 0.15);\n}\nbutton {\n  grid-column: span 2;\n  padding: 16px;\n  border: none;\n  border-radius: 14px;\n  font-size: 16px;\n  font-weight: bold;\n  color: white;\n  cursor: pointer;\n  background:\n    linear-gradient(\n      90deg,\n      #06245c,\n      #0aa7b8);\n  transition: 0.3s ease;\n  margin-top: 10px;\n}\nbutton:hover {\n  transform: translateY(-2px);\n  box-shadow: 0 10px 25px rgba(6, 36, 92, 0.25);\n}\n@media (max-width: 768px) {\n  form {\n    grid-template-columns: 1fr;\n    padding: 30px 20px;\n  }\n  button {\n    grid-column: span 1;\n  }\n  h2 {\n    text-align: center;\n    font-size: 32px;\n    color: #06245c;\n    margin-bottom: 10px;\n  }\n  p {\n    text-align: center;\n    color: #355070;\n    margin-bottom: 30px;\n    max-width: 500px;\n  }\n  .password-container {\n    position: relative;\n    display: flex;\n    align-items: center;\n  }\n  .password-container input {\n    width: 100%;\n  }\n  .ojo {\n    position: absolute;\n    right: 15px;\n    cursor: pointer;\n    color: #06245c;\n  }\n}\n@media (max-width: 768px) and (max-width: 768px) {\n  .registro-container {\n    padding: 20px 12px;\n  }\n  form {\n    grid-template-columns: 1fr;\n    width: 100%;\n    padding: 25px 18px;\n    border-radius: 22px;\n  }\n  .form-group input {\n    width: 100%;\n    font-size: 14px;\n  }\n  button {\n    grid-column: span 1;\n    width: 100%;\n  }\n  h2 {\n    font-size: 24px;\n  }\n  p {\n    font-size: 14px;\n    padding: 0 10px;\n  }\n}\n@media (max-width: 768px) {\n  .acciones-extra {\n    grid-column: span 2;\n    display: flex;\n    justify-content: space-between;\n    align-items: center;\n    margin-top: 10px;\n  }\n  .btn-volver {\n    background: transparent;\n    border: 2px solid #0aa7b8;\n    color: #06245c;\n    padding: 12px 18px;\n    border-radius: 12px;\n    font-weight: 600;\n    cursor: pointer;\n    transition: 0.3s ease;\n  }\n  .btn-volver:hover {\n    background: #0aa7b8;\n    color: white;\n  }\n  .link-login {\n    text-decoration: none;\n    color: #06245c;\n    font-weight: 600;\n    transition: 0.3s ease;\n  }\n  .link-login:hover {\n    color: #0aa7b8;\n  }\n}\n@media (max-width: 768px) {\n}\n@media (max-width: 768px) and (max-width: 768px) {\n  .acciones-extra {\n    grid-column: span 1;\n    flex-direction: column;\n    gap: 15px;\n  }\n  .btn-volver {\n    width: 100%;\n  }\n}\n@media (max-width: 768px) {\n  .btn-login {\n    background: transparent;\n    border: 2px solid #06245c;\n    color: #06245c;\n    padding: 12px 18px;\n    border-radius: 12px;\n    font-weight: 600;\n    cursor: pointer;\n    transition: 0.3s ease;\n  }\n  .btn-login:hover {\n    background: #06245c;\n    color: white;\n  }\n}\n/*# sourceMappingURL=registrar-postulante.css.map */\n'] }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i04.\u0275setClassDebugInfo(RegistrarPostulante, { className: "RegistrarPostulante", filePath: "app/pagina/registrar/registrar-postulante/registrar-postulante.ts", lineNumber: 26 });
})();
(() => {
  const id = "app%2Fpagina%2Fregistrar%2Fregistrar-postulante%2Fregistrar-postulante.ts%40RegistrarPostulante";
  function RegistrarPostulante_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i04.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i04.\u0275\u0275replaceMetadata(RegistrarPostulante, m.default, [i04, i13, i2], [ReactiveFormsModule2, CommonModule, RouterLink4, Component4], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && RegistrarPostulante_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && RegistrarPostulante_HmrLoad(d.timestamp)));
})();

// src/app/pagina/registrar/registrar-empresa/registrar-empresa.ts
import { Component as Component5, inject as inject3 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import { FormControl as FormControl3, FormGroup as FormGroup3, ReactiveFormsModule as ReactiveFormsModule3, Validators as Validators3 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_forms.js?v=3d725e17";
import { CommonModule as CommonModule2 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_common.js?v=3d725e17";
import { Router as Router3, RouterLink as RouterLink5 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_router.js?v=3d725e17";
import * as i05 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import * as i14 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_forms.js?v=3d725e17";
import * as i22 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_common.js?v=3d725e17";
function RegistrarEmpresa_Conditional_22_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275elementStart(0, "small");
    i05.\u0275\u0275text(1, "El CUIT es obligatorio.");
    i05.\u0275\u0275elementEnd();
  }
}
function RegistrarEmpresa_Conditional_22_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275elementStart(0, "small");
    i05.\u0275\u0275text(1, "Formato inv\xE1lido. Ej: 30-12345678-9");
    i05.\u0275\u0275elementEnd();
  }
}
function RegistrarEmpresa_Conditional_22_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275elementStart(0, "div", 7);
    i05.\u0275\u0275conditionalCreate(1, RegistrarEmpresa_Conditional_22_Conditional_1_Template, 2, 0, "small");
    i05.\u0275\u0275conditionalCreate(2, RegistrarEmpresa_Conditional_22_Conditional_2_Template, 2, 0, "small");
    i05.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    let tmp_1_0;
    let tmp_2_0;
    const ctx_r0 = i05.\u0275\u0275nextContext();
    i05.\u0275\u0275advance();
    i05.\u0275\u0275conditional(((tmp_1_0 = ctx_r0.formRegistro.get("cuit")) == null ? null : tmp_1_0.errors == null ? null : tmp_1_0.errors["required"]) ? 1 : -1);
    i05.\u0275\u0275advance();
    i05.\u0275\u0275conditional(((tmp_2_0 = ctx_r0.formRegistro.get("cuit")) == null ? null : tmp_2_0.errors == null ? null : tmp_2_0.errors["pattern"]) ? 2 : -1);
  }
}
function RegistrarEmpresa_Conditional_63_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275elementStart(0, "small");
    i05.\u0275\u0275text(1, "El correo es obligatorio.");
    i05.\u0275\u0275elementEnd();
  }
}
function RegistrarEmpresa_Conditional_63_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275elementStart(0, "small");
    i05.\u0275\u0275text(1, "Formato de correo no v\xE1lido.");
    i05.\u0275\u0275elementEnd();
  }
}
function RegistrarEmpresa_Conditional_63_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275elementStart(0, "div", 7);
    i05.\u0275\u0275conditionalCreate(1, RegistrarEmpresa_Conditional_63_Conditional_1_Template, 2, 0, "small");
    i05.\u0275\u0275conditionalCreate(2, RegistrarEmpresa_Conditional_63_Conditional_2_Template, 2, 0, "small");
    i05.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    let tmp_1_0;
    let tmp_2_0;
    const ctx_r0 = i05.\u0275\u0275nextContext();
    i05.\u0275\u0275advance();
    i05.\u0275\u0275conditional(((tmp_1_0 = ctx_r0.formRegistro.get("email")) == null ? null : tmp_1_0.errors == null ? null : tmp_1_0.errors["required"]) ? 1 : -1);
    i05.\u0275\u0275advance();
    i05.\u0275\u0275conditional(((tmp_2_0 = ctx_r0.formRegistro.get("email")) == null ? null : tmp_2_0.errors == null ? null : tmp_2_0.errors["email"]) ? 2 : -1);
  }
}
function RegistrarEmpresa_Conditional_83_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275elementStart(0, "small");
    i05.\u0275\u0275text(1, "La contrase\xF1a es obligatoria.");
    i05.\u0275\u0275elementEnd();
  }
}
function RegistrarEmpresa_Conditional_83_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275elementStart(0, "small");
    i05.\u0275\u0275text(1, "Debe tener al menos 8 caracteres.");
    i05.\u0275\u0275elementEnd();
  }
}
function RegistrarEmpresa_Conditional_83_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275elementStart(0, "small");
    i05.\u0275\u0275text(1, " Debe contener al menos una may\xFAscula y un n\xFAmero. ");
    i05.\u0275\u0275elementEnd();
  }
}
function RegistrarEmpresa_Conditional_83_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275elementStart(0, "div", 7);
    i05.\u0275\u0275conditionalCreate(1, RegistrarEmpresa_Conditional_83_Conditional_1_Template, 2, 0, "small");
    i05.\u0275\u0275conditionalCreate(2, RegistrarEmpresa_Conditional_83_Conditional_2_Template, 2, 0, "small");
    i05.\u0275\u0275conditionalCreate(3, RegistrarEmpresa_Conditional_83_Conditional_3_Template, 2, 0, "small");
    i05.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    let tmp_1_0;
    let tmp_2_0;
    let tmp_3_0;
    const ctx_r0 = i05.\u0275\u0275nextContext();
    i05.\u0275\u0275advance();
    i05.\u0275\u0275conditional(((tmp_1_0 = ctx_r0.formRegistro.get("password")) == null ? null : tmp_1_0.errors == null ? null : tmp_1_0.errors["required"]) ? 1 : -1);
    i05.\u0275\u0275advance();
    i05.\u0275\u0275conditional(((tmp_2_0 = ctx_r0.formRegistro.get("password")) == null ? null : tmp_2_0.errors == null ? null : tmp_2_0.errors["minlength"]) ? 2 : -1);
    i05.\u0275\u0275advance();
    i05.\u0275\u0275conditional(((tmp_3_0 = ctx_r0.formRegistro.get("password")) == null ? null : tmp_3_0.errors == null ? null : tmp_3_0.errors["pattern"]) ? 3 : -1);
  }
}
function RegistrarEmpresa_Conditional_91_Template(rf, ctx) {
  if (rf & 1) {
    i05.\u0275\u0275elementStart(0, "div", 7)(1, "small");
    i05.\u0275\u0275text(2, "Las contrase\xF1as no coinciden.");
    i05.\u0275\u0275elementEnd()();
  }
}
var RegistrarEmpresa = class _RegistrarEmpresa {
  authService = inject3(AuthService);
  router = inject3(Router3);
  // MOSTRAR / OCULTAR PASSWORD
  mostrarPassword = false;
  togglePassword() {
    this.mostrarPassword = !this.mostrarPassword;
  }
  // FORMULARIO
  formRegistro = new FormGroup3({
    razonSocial: new FormControl3("", [
      Validators3.required
    ]),
    fantasia: new FormControl3(""),
    organizacion: new FormControl3("", [
      Validators3.required
    ]),
    cuit: new FormControl3("", [
      Validators3.required,
      Validators3.pattern("^[0-9]{2}-[0-9]{8}-[0-9]{1}$")
    ]),
    sector: new FormControl3("", [
      Validators3.required
    ]),
    pais: new FormControl3("", [
      Validators3.required
    ]),
    provincia: new FormControl3("", [
      Validators3.required
    ]),
    ciudad: new FormControl3("", [
      Validators3.required
    ]),
    cp: new FormControl3(""),
    calle: new FormControl3("", [
      Validators3.required
    ]),
    numero: new FormControl3(""),
    piso: new FormControl3(""),
    dpto: new FormControl3(""),
    email: new FormControl3("", [
      Validators3.required,
      Validators3.email
    ]),
    web: new FormControl3(""),
    telefono: new FormControl3("", [
      Validators3.required
    ]),
    responsable: new FormControl3("", [
      Validators3.required
    ]),
    password: new FormControl3("", [
      Validators3.required,
      Validators3.minLength(8),
      // AL MENOS 1 MAYUSCULA Y 1 NUMERO
      Validators3.pattern(/^(?=.*[A-Z])(?=.*\d).+$/)
    ]),
    // CONFIRMAR PASSWORD
    confirmPassword: new FormControl3("", [
      Validators3.required
    ])
  });
  // REGISTRAR EMPRESA
  registrarEmpresa() {
    if (this.formRegistro.value.password !== this.formRegistro.value.confirmPassword) {
      alert("Las contrase\xF1as no coinciden");
      return;
    }
    if (this.formRegistro.valid) {
      const datos = this.formRegistro.value;
      this.authService.registrarEmpresa(datos).subscribe({
        next: (res) => {
          console.log("\xA1Empresa registrada con \xE9xito!", res);
          alert("\xA1Empresa registrada con \xE9xito! Ya pod\xE9s iniciar sesi\xF3n.");
          this.router.navigate(["/sesion"]);
        },
        error: (err) => {
          console.error("Error al registrar:", err);
          alert("Hubo un error al crear la cuenta");
        }
      });
    } else {
      this.formRegistro.markAllAsTouched();
      alert("Por favor, complet\xE1 todos los campos correctamente.");
    }
  }
  static \u0275fac = function RegistrarEmpresa_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _RegistrarEmpresa)();
  };
  static \u0275cmp = /* @__PURE__ */ i05.\u0275\u0275defineComponent({ type: _RegistrarEmpresa, selectors: [["app-registrar-empresa"]], decls: 99, vars: 16, consts: [[1, "registro-container"], [3, "ngSubmit", "formGroup"], [1, "form-group"], ["type", "text", "formControlName", "razonSocial", "placeholder", "Ej: Empresa S.A."], ["type", "text", "formControlName", "fantasia", "placeholder", "Ej: MiEmpresa"], ["type", "text", "formControlName", "organizacion", "placeholder", "Ej: S.R.L., S.A., ONG"], ["type", "text", "formControlName", "cuit", "placeholder", "Ej: 30-12345678-9"], [1, "error-msg"], ["type", "text", "formControlName", "sector", "placeholder", "Ej: Tecnolog\xEDa, Salud"], ["type", "text", "formControlName", "pais", "placeholder", "Ej: Argentina"], ["type", "text", "formControlName", "provincia", "placeholder", "Ej: Buenos Aires"], ["type", "text", "formControlName", "ciudad", "placeholder", "Ej: San Mart\xEDn"], ["type", "text", "formControlName", "cp", "placeholder", "Ej: 1650"], ["type", "text", "formControlName", "calle", "placeholder", "Ej: Av. Libertador"], ["type", "text", "formControlName", "numero", "placeholder", "Ej: 1234"], ["type", "text", "formControlName", "piso", "placeholder", "Ej: 3"], ["type", "text", "formControlName", "dpto", "placeholder", "Ej: B"], ["type", "email", "formControlName", "email", "placeholder", "Ej: contacto@empresa.com"], ["type", "text", "formControlName", "web", "placeholder", "Ej: www.miempresa.com"], ["type", "text", "formControlName", "telefono", "placeholder", "Ej: 011-4567-8900"], [1, "form-group", "full-width"], ["type", "text", "formControlName", "responsable", "placeholder", "Ej: Mar\xEDa Gonz\xE1lez"], [1, "password-container"], ["formControlName", "password", "placeholder", "M\xEDnimo 8 caracteres", 3, "type"], [1, "ojo", 3, "click"], [1, "fa-solid"], ["formControlName", "confirmPassword", "placeholder", "Repet\xED tu contrase\xF1a", 3, "type"], ["type", "submit", 3, "disabled"], [1, "acciones-extra"], ["type", "button", "routerLink", "/registrar", 1, "btn-volver"], ["type", "button", "routerLink", "/sesion", 1, "btn-login"]], template: function RegistrarEmpresa_Template(rf, ctx) {
    if (rf & 1) {
      i05.\u0275\u0275elementStart(0, "div", 0)(1, "h2");
      i05.\u0275\u0275text(2, "Registre su Empresa aqu\xED");
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275elementStart(3, "p");
      i05.\u0275\u0275text(4, " Complete los datos para acceder al Sistema de Intermediaci\xF3n Laboral ");
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275elementStart(5, "form", 1);
      i05.\u0275\u0275listener("ngSubmit", function RegistrarEmpresa_Template_form_ngSubmit_5_listener($event) {
        ctx.registrarEmpresa();
        return $event.preventDefault();
      });
      i05.\u0275\u0275elementStart(6, "div", 2)(7, "label");
      i05.\u0275\u0275text(8, "Raz\xF3n Social:");
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275element(9, "input", 3);
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275elementStart(10, "div", 2)(11, "label");
      i05.\u0275\u0275text(12, "Nombre de Fantas\xEDa:");
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275element(13, "input", 4);
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275elementStart(14, "div", 2)(15, "label");
      i05.\u0275\u0275text(16, "Organizaci\xF3n:");
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275element(17, "input", 5);
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275elementStart(18, "div", 2)(19, "label");
      i05.\u0275\u0275text(20, "CUIT:");
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275element(21, "input", 6);
      i05.\u0275\u0275conditionalCreate(22, RegistrarEmpresa_Conditional_22_Template, 3, 2, "div", 7);
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275elementStart(23, "div", 2)(24, "label");
      i05.\u0275\u0275text(25, "Sector:");
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275element(26, "input", 8);
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275elementStart(27, "div", 2)(28, "label");
      i05.\u0275\u0275text(29, "Pa\xEDs:");
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275element(30, "input", 9);
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275elementStart(31, "div", 2)(32, "label");
      i05.\u0275\u0275text(33, "Provincia:");
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275element(34, "input", 10);
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275elementStart(35, "div", 2)(36, "label");
      i05.\u0275\u0275text(37, "Ciudad:");
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275element(38, "input", 11);
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275elementStart(39, "div", 2)(40, "label");
      i05.\u0275\u0275text(41, "C\xF3digo Postal:");
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275element(42, "input", 12);
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275elementStart(43, "div", 2)(44, "label");
      i05.\u0275\u0275text(45, "Calle:");
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275element(46, "input", 13);
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275elementStart(47, "div", 2)(48, "label");
      i05.\u0275\u0275text(49, "N\xB0:");
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275element(50, "input", 14);
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275elementStart(51, "div", 2)(52, "label");
      i05.\u0275\u0275text(53, "Piso:");
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275element(54, "input", 15);
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275elementStart(55, "div", 2)(56, "label");
      i05.\u0275\u0275text(57, "Departamento:");
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275element(58, "input", 16);
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275elementStart(59, "div", 2)(60, "label");
      i05.\u0275\u0275text(61, "Email:");
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275element(62, "input", 17);
      i05.\u0275\u0275conditionalCreate(63, RegistrarEmpresa_Conditional_63_Template, 3, 2, "div", 7);
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275elementStart(64, "div", 2)(65, "label");
      i05.\u0275\u0275text(66, "Sitio Web:");
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275element(67, "input", 18);
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275elementStart(68, "div", 2)(69, "label");
      i05.\u0275\u0275text(70, "Tel\xE9fono de Contacto:");
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275element(71, "input", 19);
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275elementStart(72, "div", 20)(73, "label");
      i05.\u0275\u0275text(74, "Nombre del Responsable del \xC1rea:");
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275element(75, "input", 21);
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275elementStart(76, "div", 20)(77, "label");
      i05.\u0275\u0275text(78, "Contrase\xF1a:");
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275elementStart(79, "div", 22);
      i05.\u0275\u0275element(80, "input", 23);
      i05.\u0275\u0275elementStart(81, "span", 24);
      i05.\u0275\u0275listener("click", function RegistrarEmpresa_Template_span_click_81_listener() {
        return ctx.togglePassword();
      });
      i05.\u0275\u0275element(82, "i", 25);
      i05.\u0275\u0275elementEnd()();
      i05.\u0275\u0275conditionalCreate(83, RegistrarEmpresa_Conditional_83_Template, 4, 3, "div", 7);
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275elementStart(84, "div", 20)(85, "label");
      i05.\u0275\u0275text(86, "Confirmar Contrase\xF1a:");
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275elementStart(87, "div", 22);
      i05.\u0275\u0275element(88, "input", 26);
      i05.\u0275\u0275elementStart(89, "span", 24);
      i05.\u0275\u0275listener("click", function RegistrarEmpresa_Template_span_click_89_listener() {
        return ctx.togglePassword();
      });
      i05.\u0275\u0275element(90, "i", 25);
      i05.\u0275\u0275elementEnd()();
      i05.\u0275\u0275conditionalCreate(91, RegistrarEmpresa_Conditional_91_Template, 3, 0, "div", 7);
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275elementStart(92, "button", 27);
      i05.\u0275\u0275text(93, " Crear Cuenta ");
      i05.\u0275\u0275elementEnd()();
      i05.\u0275\u0275elementStart(94, "div", 28)(95, "button", 29);
      i05.\u0275\u0275text(96, " \u2190 Volver ");
      i05.\u0275\u0275elementEnd();
      i05.\u0275\u0275elementStart(97, "button", 30);
      i05.\u0275\u0275text(98, " Ya tengo cuenta ");
      i05.\u0275\u0275elementEnd()()();
    }
    if (rf & 2) {
      let tmp_1_0;
      let tmp_2_0;
      let tmp_6_0;
      let tmp_10_0;
      i05.\u0275\u0275advance(5);
      i05.\u0275\u0275property("formGroup", ctx.formRegistro);
      i05.\u0275\u0275advance(17);
      i05.\u0275\u0275conditional(((tmp_1_0 = ctx.formRegistro.get("cuit")) == null ? null : tmp_1_0.invalid) && ((tmp_1_0 = ctx.formRegistro.get("cuit")) == null ? null : tmp_1_0.touched) ? 22 : -1);
      i05.\u0275\u0275advance(41);
      i05.\u0275\u0275conditional(((tmp_2_0 = ctx.formRegistro.get("email")) == null ? null : tmp_2_0.invalid) && ((tmp_2_0 = ctx.formRegistro.get("email")) == null ? null : tmp_2_0.touched) ? 63 : -1);
      i05.\u0275\u0275advance(17);
      i05.\u0275\u0275property("type", ctx.mostrarPassword ? "text" : "password");
      i05.\u0275\u0275advance(2);
      i05.\u0275\u0275classProp("fa-eye", ctx.mostrarPassword)("fa-eye-slash", !ctx.mostrarPassword);
      i05.\u0275\u0275advance();
      i05.\u0275\u0275conditional(((tmp_6_0 = ctx.formRegistro.get("password")) == null ? null : tmp_6_0.invalid) && ((tmp_6_0 = ctx.formRegistro.get("password")) == null ? null : tmp_6_0.touched) ? 83 : -1);
      i05.\u0275\u0275advance(5);
      i05.\u0275\u0275property("type", ctx.mostrarPassword ? "text" : "password");
      i05.\u0275\u0275advance(2);
      i05.\u0275\u0275classProp("fa-eye", ctx.mostrarPassword)("fa-eye-slash", !ctx.mostrarPassword);
      i05.\u0275\u0275advance();
      i05.\u0275\u0275conditional(((tmp_10_0 = ctx.formRegistro.get("confirmPassword")) == null ? null : tmp_10_0.touched) && ((tmp_10_0 = ctx.formRegistro.get("password")) == null ? null : tmp_10_0.value) !== ((tmp_10_0 = ctx.formRegistro.get("confirmPassword")) == null ? null : tmp_10_0.value) ? 91 : -1);
      i05.\u0275\u0275advance();
      i05.\u0275\u0275property("disabled", ctx.formRegistro.invalid);
    }
  }, dependencies: [ReactiveFormsModule3, i14.\u0275NgNoValidate, i14.NgSelectOption, i14.\u0275NgSelectMultipleOption, i14.DefaultValueAccessor, i14.NumberValueAccessor, i14.RangeValueAccessor, i14.CheckboxControlValueAccessor, i14.SelectControlValueAccessor, i14.SelectMultipleControlValueAccessor, i14.RadioControlValueAccessor, i14.NgControlStatus, i14.NgControlStatusGroup, i14.RequiredValidator, i14.MinLengthValidator, i14.MaxLengthValidator, i14.PatternValidator, i14.CheckboxRequiredValidator, i14.EmailValidator, i14.MinValidator, i14.MaxValidator, i14.FormControlDirective, i14.FormGroupDirective, i14.FormArrayDirective, i14.FormControlName, i14.FormGroupName, i14.FormArrayName, CommonModule2, i22.NgClass, i22.NgComponentOutlet, i22.NgForOf, i22.NgIf, i22.NgTemplateOutlet, i22.NgStyle, i22.NgSwitch, i22.NgSwitchCase, i22.NgSwitchDefault, i22.NgPlural, i22.NgPluralCase, RouterLink5, i22.AsyncPipe, i22.UpperCasePipe, i22.LowerCasePipe, i22.JsonPipe, i22.SlicePipe, i22.DecimalPipe, i22.PercentPipe, i22.TitleCasePipe, i22.CurrencyPipe, i22.DatePipe, i22.I18nPluralPipe, i22.I18nSelectPipe, i22.KeyValuePipe], styles: ['@charset "UTF-8";\n\n\n.registro-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  min-height: 70vh;\n  margin: 40px 0;\n}\nform[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: 1fr 1fr;\n  gap: 20px;\n  width: 100%;\n  max-width: 700px;\n  padding: 40px;\n  border-radius: 32px;\n  background: rgba(255, 255, 255, 0.65);\n  border: 1px solid #b8ece5;\n  box-shadow: 0 18px 40px rgba(6, 36, 92, 0.1);\n  -webkit-backdrop-filter: blur(10px);\n  backdrop-filter: blur(10px);\n  transition: 0.3s ease;\n}\nform[_ngcontent-%COMP%]:hover {\n  box-shadow: 0 22px 50px rgba(6, 36, 92, 0.15);\n}\n.form-group[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  margin-bottom: 0;\n}\n.form-group[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  margin-bottom: 8px;\n  font-weight: bold;\n  color: #06245c;\n}\n.form-group[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n  padding: 14px;\n  border-radius: 12px;\n  border: 1px solid #cfd9e2;\n  background-color: #f8fdff;\n  font-size: 15px;\n  transition: 0.3s;\n}\n.form-group[_ngcontent-%COMP%]   input[_ngcontent-%COMP%]:focus {\n  outline: none;\n  border-color: #0aa7b8;\n  box-shadow: 0 0 0 3px rgba(10, 167, 184, 0.2);\n}\nbutton[_ngcontent-%COMP%] {\n  grid-column: span 2;\n  padding: 16px;\n  background:\n    linear-gradient(\n      90deg,\n      #06245c,\n      #0aa7b8);\n  color: white;\n  border: none;\n  border-radius: 14px;\n  font-size: 16px;\n  font-weight: bold;\n  cursor: pointer;\n  margin-top: 10px;\n  transition: 0.3s;\n}\nbutton[_ngcontent-%COMP%]:hover {\n  transform: translateY(-2px);\n  background:\n    linear-gradient(\n      90deg,\n      #0b4f8a,\n      #0aa7b8);\n  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);\n}\n@media (max-width: 768px) {\n  form[_ngcontent-%COMP%] {\n    grid-template-columns: 1fr;\n  }\n  button[_ngcontent-%COMP%] {\n    grid-column: span 1;\n  }\n}\n/*# sourceMappingURL=registrar-empresa.css.map */'] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i05.\u0275setClassMetadata(RegistrarEmpresa, [{
    type: Component5,
    args: [{ selector: "app-registrar-empresa", standalone: true, imports: [
      ReactiveFormsModule3,
      CommonModule2,
      RouterLink5
    ], template: `<div class="registro-container">\r
\r
  <h2>Registre su Empresa aqu\xED</h2>\r
\r
  <p>\r
    Complete los datos para acceder al Sistema de Intermediaci\xF3n Laboral\r
  </p>\r
\r
  <form\r
    [formGroup]="formRegistro"\r
    (ngSubmit)="registrarEmpresa(); $event.preventDefault()">\r
\r
    <!-- RAZON SOCIAL -->\r
    <div class="form-group">\r
      <label>Raz\xF3n Social:</label>\r
\r
      <input\r
        type="text"\r
        formControlName="razonSocial"\r
        placeholder="Ej: Empresa S.A.">\r
    </div>\r
\r
    <!-- FANTASIA -->\r
    <div class="form-group">\r
      <label>Nombre de Fantas\xEDa:</label>\r
\r
      <input\r
        type="text"\r
        formControlName="fantasia"\r
        placeholder="Ej: MiEmpresa">\r
    </div>\r
\r
    <!-- ORGANIZACION -->\r
    <div class="form-group">\r
      <label>Organizaci\xF3n:</label>\r
\r
      <input\r
        type="text"\r
        formControlName="organizacion"\r
        placeholder="Ej: S.R.L., S.A., ONG">\r
    </div>\r
\r
    <!-- CUIT -->\r
    <div class="form-group">\r
\r
      <label>CUIT:</label>\r
\r
      <input\r
        type="text"\r
        formControlName="cuit"\r
        placeholder="Ej: 30-12345678-9">\r
\r
      @if (formRegistro.get('cuit')?.invalid &&\r
           formRegistro.get('cuit')?.touched) {\r
\r
        <div class="error-msg">\r
\r
          @if (formRegistro.get('cuit')?.errors?.['required']) {\r
            <small>El CUIT es obligatorio.</small>\r
          }\r
\r
          @if (formRegistro.get('cuit')?.errors?.['pattern']) {\r
            <small>Formato inv\xE1lido. Ej: 30-12345678-9</small>\r
          }\r
\r
        </div>\r
\r
      }\r
\r
    </div>\r
\r
    <!-- SECTOR -->\r
    <div class="form-group">\r
      <label>Sector:</label>\r
\r
      <input\r
        type="text"\r
        formControlName="sector"\r
        placeholder="Ej: Tecnolog\xEDa, Salud">\r
    </div>\r
\r
    <!-- PAIS -->\r
    <div class="form-group">\r
      <label>Pa\xEDs:</label>\r
\r
      <input\r
        type="text"\r
        formControlName="pais"\r
        placeholder="Ej: Argentina">\r
    </div>\r
\r
    <!-- PROVINCIA -->\r
    <div class="form-group">\r
      <label>Provincia:</label>\r
\r
      <input\r
        type="text"\r
        formControlName="provincia"\r
        placeholder="Ej: Buenos Aires">\r
    </div>\r
\r
    <!-- CIUDAD -->\r
    <div class="form-group">\r
      <label>Ciudad:</label>\r
\r
      <input\r
        type="text"\r
        formControlName="ciudad"\r
        placeholder="Ej: San Mart\xEDn">\r
    </div>\r
\r
    <!-- CODIGO POSTAL -->\r
    <div class="form-group">\r
      <label>C\xF3digo Postal:</label>\r
\r
      <input\r
        type="text"\r
        formControlName="cp"\r
        placeholder="Ej: 1650">\r
    </div>\r
\r
    <!-- CALLE -->\r
    <div class="form-group">\r
      <label>Calle:</label>\r
\r
      <input\r
        type="text"\r
        formControlName="calle"\r
        placeholder="Ej: Av. Libertador">\r
    </div>\r
\r
    <!-- NUMERO -->\r
    <div class="form-group">\r
      <label>N\xB0:</label>\r
\r
      <input\r
        type="text"\r
        formControlName="numero"\r
        placeholder="Ej: 1234">\r
    </div>\r
\r
    <!-- PISO -->\r
    <div class="form-group">\r
      <label>Piso:</label>\r
\r
      <input\r
        type="text"\r
        formControlName="piso"\r
        placeholder="Ej: 3">\r
    </div>\r
\r
    <!-- DPTO -->\r
    <div class="form-group">\r
      <label>Departamento:</label>\r
\r
      <input\r
        type="text"\r
        formControlName="dpto"\r
        placeholder="Ej: B">\r
    </div>\r
\r
    <!-- EMAIL -->\r
    <div class="form-group">\r
\r
      <label>Email:</label>\r
\r
      <input\r
        type="email"\r
        formControlName="email"\r
        placeholder="Ej: contacto@empresa.com">\r
\r
      @if (formRegistro.get('email')?.invalid &&\r
           formRegistro.get('email')?.touched) {\r
\r
        <div class="error-msg">\r
\r
          @if (formRegistro.get('email')?.errors?.['required']) {\r
            <small>El correo es obligatorio.</small>\r
          }\r
\r
          @if (formRegistro.get('email')?.errors?.['email']) {\r
            <small>Formato de correo no v\xE1lido.</small>\r
          }\r
\r
        </div>\r
\r
      }\r
\r
    </div>\r
\r
    <!-- WEB -->\r
    <div class="form-group">\r
      <label>Sitio Web:</label>\r
\r
      <input\r
        type="text"\r
        formControlName="web"\r
        placeholder="Ej: www.miempresa.com">\r
    </div>\r
\r
    <!-- TELEFONO -->\r
    <div class="form-group">\r
      <label>Tel\xE9fono de Contacto:</label>\r
\r
      <input\r
        type="text"\r
        formControlName="telefono"\r
        placeholder="Ej: 011-4567-8900">\r
    </div>\r
\r
    <!-- RESPONSABLE -->\r
    <div class="form-group full-width">\r
\r
      <label>Nombre del Responsable del \xC1rea:</label>\r
\r
      <input\r
        type="text"\r
        formControlName="responsable"\r
        placeholder="Ej: Mar\xEDa Gonz\xE1lez">\r
\r
    </div>\r
\r
    <!-- PASSWORD -->\r
    <div class="form-group full-width">\r
\r
      <label>Contrase\xF1a:</label>\r
\r
      <div class="password-container">\r
\r
        <input\r
          [type]="mostrarPassword ? 'text' : 'password'"\r
          formControlName="password"\r
          placeholder="M\xEDnimo 8 caracteres">\r
\r
        <!-- OJITO -->\r
        <span class="ojo" (click)="togglePassword()">\r
\r
          <i\r
            class="fa-solid"\r
            [class.fa-eye]="mostrarPassword"\r
            [class.fa-eye-slash]="!mostrarPassword">\r
          </i>\r
\r
        </span>\r
\r
      </div>\r
\r
      @if (formRegistro.get('password')?.invalid &&\r
           formRegistro.get('password')?.touched) {\r
\r
        <div class="error-msg">\r
\r
          @if (formRegistro.get('password')?.errors?.['required']) {\r
            <small>La contrase\xF1a es obligatoria.</small>\r
          }\r
\r
          @if (formRegistro.get('password')?.errors?.['minlength']) {\r
            <small>Debe tener al menos 8 caracteres.</small>\r
          }\r
\r
          @if (formRegistro.get('password')?.errors?.['pattern']) {\r
            <small>\r
              Debe contener al menos una may\xFAscula y un n\xFAmero.\r
            </small>\r
          }\r
\r
        </div>\r
\r
      }\r
\r
    </div>\r
    <!-- CONFIRMAR PASSWORD -->\r
<div class="form-group full-width">\r
\r
  <label>Confirmar Contrase\xF1a:</label>\r
\r
  <div class="password-container">\r
\r
    <input\r
      [type]="mostrarPassword ? 'text' : 'password'"\r
      formControlName="confirmPassword"\r
      placeholder="Repet\xED tu contrase\xF1a">\r
\r
    <!-- OJITO -->\r
    <span class="ojo" (click)="togglePassword()">\r
\r
      <i\r
        class="fa-solid"\r
        [class.fa-eye]="mostrarPassword"\r
        [class.fa-eye-slash]="!mostrarPassword">\r
      </i>\r
\r
    </span>\r
\r
  </div>\r
\r
  @if (\r
    formRegistro.get('confirmPassword')?.touched &&\r
    formRegistro.get('password')?.value !==\r
    formRegistro.get('confirmPassword')?.value\r
  ) {\r
\r
    <div class="error-msg">\r
      <small>Las contrase\xF1as no coinciden.</small>\r
    </div>\r
\r
  }\r
\r
</div>\r
\r
    <!-- BOTON -->\r
    <button\r
      type="submit"\r
      [disabled]="formRegistro.invalid">\r
\r
      Crear Cuenta\r
\r
    </button>\r
\r
  </form>\r
<div class="acciones-extra">\r
\r
  <!-- VOLVER -->\r
  <button\r
    type="button"\r
    class="btn-volver"\r
    routerLink="/registrar">\r
\r
    \u2190 Volver\r
\r
  </button>\r
\r
  <!-- YA TENGO CUENTA -->\r
  <button\r
    type="button"\r
    class="btn-login"\r
    routerLink="/sesion">\r
\r
    Ya tengo cuenta\r
\r
  </button>\r
\r
\r
</div>`, styles: ['@charset "UTF-8";\n\n/* src/app/pagina/registrar/registrar-empresa/registrar-empresa.scss */\n.registro-container {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  min-height: 70vh;\n  margin: 40px 0;\n}\nform {\n  display: grid;\n  grid-template-columns: 1fr 1fr;\n  gap: 20px;\n  width: 100%;\n  max-width: 700px;\n  padding: 40px;\n  border-radius: 32px;\n  background: rgba(255, 255, 255, 0.65);\n  border: 1px solid #b8ece5;\n  box-shadow: 0 18px 40px rgba(6, 36, 92, 0.1);\n  -webkit-backdrop-filter: blur(10px);\n  backdrop-filter: blur(10px);\n  transition: 0.3s ease;\n}\nform:hover {\n  box-shadow: 0 22px 50px rgba(6, 36, 92, 0.15);\n}\n.form-group {\n  display: flex;\n  flex-direction: column;\n  margin-bottom: 0;\n}\n.form-group label {\n  margin-bottom: 8px;\n  font-weight: bold;\n  color: #06245c;\n}\n.form-group input {\n  padding: 14px;\n  border-radius: 12px;\n  border: 1px solid #cfd9e2;\n  background-color: #f8fdff;\n  font-size: 15px;\n  transition: 0.3s;\n}\n.form-group input:focus {\n  outline: none;\n  border-color: #0aa7b8;\n  box-shadow: 0 0 0 3px rgba(10, 167, 184, 0.2);\n}\nbutton {\n  grid-column: span 2;\n  padding: 16px;\n  background:\n    linear-gradient(\n      90deg,\n      #06245c,\n      #0aa7b8);\n  color: white;\n  border: none;\n  border-radius: 14px;\n  font-size: 16px;\n  font-weight: bold;\n  cursor: pointer;\n  margin-top: 10px;\n  transition: 0.3s;\n}\nbutton:hover {\n  transform: translateY(-2px);\n  background:\n    linear-gradient(\n      90deg,\n      #0b4f8a,\n      #0aa7b8);\n  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);\n}\n@media (max-width: 768px) {\n  form {\n    grid-template-columns: 1fr;\n  }\n  button {\n    grid-column: span 1;\n  }\n}\n/*# sourceMappingURL=registrar-empresa.css.map */\n'] }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i05.\u0275setClassDebugInfo(RegistrarEmpresa, { className: "RegistrarEmpresa", filePath: "app/pagina/registrar/registrar-empresa/registrar-empresa.ts", lineNumber: 26 });
})();
(() => {
  const id = "app%2Fpagina%2Fregistrar%2Fregistrar-empresa%2Fregistrar-empresa.ts%40RegistrarEmpresa";
  function RegistrarEmpresa_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i05.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i05.\u0275\u0275replaceMetadata(RegistrarEmpresa, m.default, [i05, i14, i22], [ReactiveFormsModule3, CommonModule2, RouterLink5, Component5], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && RegistrarEmpresa_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && RegistrarEmpresa_HmrLoad(d.timestamp)));
})();

// src/app/pagina/ofertas/ofertas.ts
import { Component as Component6 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import { Validators as Validators4, FormsModule, ReactiveFormsModule as ReactiveFormsModule4 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_forms.js?v=3d725e17";
import { CommonModule as CommonModule3 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_common.js?v=3d725e17";
import * as i08 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import * as i15 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_forms.js?v=3d725e17";

// src/app/services/oferta_service.ts
var oferta_service_exports = {};
__export(oferta_service_exports, {
  OfertaService: () => OfertaService
});
import { Injectable, inject as inject4 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import { HttpClient } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_common_http.js?v=3d725e17";
import * as i06 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
var OfertaService = class _OfertaService {
  http = inject4(HttpClient);
  apiUrl = "http://localhost:3000/api/ofertas";
  /** Obtener el listado de categorías con sus respectivas habilidades */
  getCategoriasConSkills() {
    return this.http.get(`${this.apiUrl}/categorias-skills`);
  }
  /** Obtener todas las ofertas laborales vigentes (para postulantes) */
  getOfertasVigentes() {
    return this.http.get(`${this.apiUrl}/vigentes`);
  }
  /** Obtener ofertas creadas por una empresa específica */
  getOfertasPorEmpresa(empresaId) {
    return this.http.get(`${this.apiUrl}/empresa/${empresaId}`);
  }
  /** Publicar una nueva oferta laboral (Empresa / Admin) */
  publicarOferta(oferta) {
    return this.http.post(`${this.apiUrl}/crear`, oferta);
  }
  /** Actualizar los datos de una oferta existente */
  actualizarOferta(idOferta, oferta) {
    return this.http.put(`${this.apiUrl}/${idOferta}`, oferta);
  }
  /** Cambiar el estado (Abierta / Cerrada) */
  cambiarEstado(idOferta, estado) {
    return this.http.patch(`${this.apiUrl}/${idOferta}/estado`, { estado });
  }
  /** Ampliar el plazo de vigencia en días */
  ampliarPlazo(idOferta, dias) {
    return this.http.patch(`${this.apiUrl}/${idOferta}/ampliar`, { dias });
  }
  /** Eliminar una oferta de la base de datos */
  eliminarOferta(idOferta) {
    return this.http.delete(`${this.apiUrl}/${idOferta}`);
  }
  static \u0275fac = function OfertaService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _OfertaService)();
  };
  static \u0275prov = /* @__PURE__ */ i06.\u0275\u0275defineInjectable({ token: _OfertaService, factory: _OfertaService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i06.\u0275setClassMetadata(OfertaService, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], null, null);
})();

// src/app/services/postulaciones.service.ts
var postulaciones_service_exports = {};
__export(postulaciones_service_exports, {
  PostulacionesService: () => PostulacionesService
});
import { Injectable as Injectable2, inject as inject5 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import { HttpClient as HttpClient2 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_common_http.js?v=3d725e17";
import * as i07 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
var PostulacionesService = class _PostulacionesService {
  http = inject5(HttpClient2);
  apiUrl = "http://localhost:3000/api/postulaciones";
  // ===================================================
  // 1. ACCIONES DEL POSTULANTE (Estudiante)
  // ===================================================
  /** Postularse a una oferta */
  crearPostulacion(id_oferta, id_postulante) {
    const body = id_postulante ? { id_oferta, id_postulante } : { id_oferta };
    return this.http.post(this.apiUrl, body);
  }
  /** Obtener postulaciones del estudiante logueado */
  getByPostulante(idPostulante) {
    return this.http.get(`${this.apiUrl}/postulante/${idPostulante}`);
  }
  /** Cancelar postulación activa */
  cancelarPostulacion(idPostulacion) {
    return this.http.delete(`${this.apiUrl}/${idPostulacion}`);
  }
  // ===================================================
  // 2. ACCIONES DE LA EMPRESA
  // ===================================================
  /** Candidatos de todas las búsquedas de la empresa */
  getByEmpresa(idEmpresa) {
    return this.http.get(`${this.apiUrl}/empresa/${idEmpresa}`);
  }
  /** Candidatos de una oferta en particular */
  getByOferta(idOferta) {
    return this.http.get(`${this.apiUrl}/oferta/${idOferta}`);
  }
  /** Actualizar estado ('Pendiente' | 'En Revision' | 'Aceptado' | 'Rechazado') */
  actualizarEstado(idPostulacion, estado) {
    return this.http.put(`${this.apiUrl}/${idPostulacion}/estado`, { estado });
  }
  // ===================================================
  // 3. ACCIONES DEL ADMINISTRADOR (Auditoría ITB)
  // ===================================================
  /** Obtener todas las postulaciones del sistema */
  getTodas() {
    return this.http.get(`${this.apiUrl}/todas`);
  }
  /** Eliminar postulación por moderación de Admin */
  eliminarPorModeracion(idPostulacion) {
    return this.http.delete(`${this.apiUrl}/admin/${idPostulacion}`);
  }
  static \u0275fac = function PostulacionesService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _PostulacionesService)();
  };
  static \u0275prov = /* @__PURE__ */ i07.\u0275\u0275defineInjectable({ token: _PostulacionesService, factory: _PostulacionesService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i07.\u0275setClassMetadata(PostulacionesService, [{
    type: Injectable2,
    args: [{
      providedIn: "root"
    }]
  }], null, null);
})();

// src/app/pagina/ofertas/ofertas.ts
import * as i5 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_router.js?v=3d725e17";
import * as i6 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_common.js?v=3d725e17";
var _forTrack02 = ($index, $item) => $item.categoria_id;
var _forTrack12 = ($index, $item) => $item.skill_id;
var _forTrack2 = ($index, $item) => $item.id_oferta;
function Ofertas_Conditional_1_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementStart(0, "small", 9);
    i08.\u0275\u0275text(1, "El t\xEDtulo debe tener al menos 5 caracteres.");
    i08.\u0275\u0275elementEnd();
  }
}
function Ofertas_Conditional_1_Conditional_46_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementStart(0, "div", 6)(1, "label", 34);
    i08.\u0275\u0275text(2, "D\xEDas personalizados (1 a 90):");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275element(3, "input", 35);
    i08.\u0275\u0275elementEnd();
  }
}
function Ofertas_Conditional_1_Conditional_51_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementStart(0, "small", 9);
    i08.\u0275\u0275text(1, "La descripci\xF3n debe tener al menos 20 caracteres.");
    i08.\u0275\u0275elementEnd();
  }
}
function Ofertas_Conditional_1_For_57_For_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = i08.\u0275\u0275getCurrentView();
    i08.\u0275\u0275elementStart(0, "button", 38);
    i08.\u0275\u0275listener("click", function Ofertas_Conditional_1_For_57_For_5_Template_button_click_0_listener() {
      const skill_r4 = i08.\u0275\u0275restoreView(_r3).$implicit;
      const ctx_r1 = i08.\u0275\u0275nextContext(3);
      return i08.\u0275\u0275resetView(ctx_r1.alternarHabilidad(skill_r4.skill_id));
    });
    i08.\u0275\u0275text(1);
    i08.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const skill_r4 = ctx.$implicit;
    const ctx_r1 = i08.\u0275\u0275nextContext(3);
    i08.\u0275\u0275classProp("seleccionada", ctx_r1.skillsSeleccionadasIds.includes(skill_r4.skill_id));
    i08.\u0275\u0275advance();
    i08.\u0275\u0275textInterpolate1(" ", skill_r4.nombre, " ");
  }
}
function Ofertas_Conditional_1_For_57_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementStart(0, "div", 30)(1, "h4");
    i08.\u0275\u0275text(2);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(3, "div", 36);
    i08.\u0275\u0275repeaterCreate(4, Ofertas_Conditional_1_For_57_For_5_Template, 2, 3, "button", 37, _forTrack12);
    i08.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const cat_r5 = ctx.$implicit;
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275textInterpolate(cat_r5.nombre);
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275repeater(cat_r5.skills);
  }
}
function Ofertas_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = i08.\u0275\u0275getCurrentView();
    i08.\u0275\u0275elementStart(0, "div", 1)(1, "div", 2)(2, "h2");
    i08.\u0275\u0275text(3);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(4, "button", 3);
    i08.\u0275\u0275listener("click", function Ofertas_Conditional_1_Template_button_click_4_listener() {
      i08.\u0275\u0275restoreView(_r1);
      const ctx_r1 = i08.\u0275\u0275nextContext();
      return i08.\u0275\u0275resetView(ctx_r1.toggleVista(false));
    });
    i08.\u0275\u0275element(5, "i", 4);
    i08.\u0275\u0275text(6, " Cancelar ");
    i08.\u0275\u0275elementEnd()();
    i08.\u0275\u0275elementStart(7, "form", 5);
    i08.\u0275\u0275listener("ngSubmit", function Ofertas_Conditional_1_Template_form_ngSubmit_7_listener() {
      i08.\u0275\u0275restoreView(_r1);
      const ctx_r1 = i08.\u0275\u0275nextContext();
      return i08.\u0275\u0275resetView(ctx_r1.guardarOferta());
    });
    i08.\u0275\u0275elementStart(8, "div", 6)(9, "label", 7);
    i08.\u0275\u0275text(10, "T\xEDtulo de la Oferta *");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275element(11, "input", 8);
    i08.\u0275\u0275conditionalCreate(12, Ofertas_Conditional_1_Conditional_12_Template, 2, 0, "small", 9);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(13, "div", 10)(14, "div", 6)(15, "label", 11);
    i08.\u0275\u0275text(16, "Modalidad *");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(17, "select", 12)(18, "option", 13);
    i08.\u0275\u0275text(19, "Presencial");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(20, "option", 14);
    i08.\u0275\u0275text(21, "H\xEDbrido");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(22, "option", 15);
    i08.\u0275\u0275text(23, "Remoto");
    i08.\u0275\u0275elementEnd()()();
    i08.\u0275\u0275elementStart(24, "div", 6)(25, "label", 16);
    i08.\u0275\u0275text(26, "Experiencia *");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(27, "select", 17)(28, "option", 18);
    i08.\u0275\u0275text(29, "Trainee");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(30, "option", 19);
    i08.\u0275\u0275text(31, "Junior");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(32, "option", 20);
    i08.\u0275\u0275text(33, "Semi-Senior");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(34, "option", 21);
    i08.\u0275\u0275text(35, "Senior");
    i08.\u0275\u0275elementEnd()()();
    i08.\u0275\u0275elementStart(36, "div", 6)(37, "label", 22);
    i08.\u0275\u0275text(38, "Duraci\xF3n de la Convocatoria *");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(39, "select", 23);
    i08.\u0275\u0275listener("change", function Ofertas_Conditional_1_Template_select_change_39_listener() {
      i08.\u0275\u0275restoreView(_r1);
      const ctx_r1 = i08.\u0275\u0275nextContext();
      return i08.\u0275\u0275resetView(ctx_r1.onTipoDuracionChange());
    });
    i08.\u0275\u0275elementStart(40, "option", 24);
    i08.\u0275\u0275text(41, "10 D\xEDas (Est\xE1ndar)");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(42, "option", 25);
    i08.\u0275\u0275text(43, "30 D\xEDas");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(44, "option", 26);
    i08.\u0275\u0275text(45, "Personalizado");
    i08.\u0275\u0275elementEnd()()()();
    i08.\u0275\u0275conditionalCreate(46, Ofertas_Conditional_1_Conditional_46_Template, 4, 0, "div", 6);
    i08.\u0275\u0275elementStart(47, "div", 6)(48, "label", 27);
    i08.\u0275\u0275text(49, "Descripci\xF3n de la B\xFAsqueda *");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275element(50, "textarea", 28);
    i08.\u0275\u0275conditionalCreate(51, Ofertas_Conditional_1_Conditional_51_Template, 2, 0, "small", 9);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(52, "div", 6)(53, "label");
    i08.\u0275\u0275text(54, "Habilidades / Requisitos (Seleccionar)");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(55, "div", 29);
    i08.\u0275\u0275repeaterCreate(56, Ofertas_Conditional_1_For_57_Template, 6, 1, "div", 30, _forTrack02);
    i08.\u0275\u0275elementEnd()();
    i08.\u0275\u0275elementStart(58, "div", 31)(59, "button", 32);
    i08.\u0275\u0275listener("click", function Ofertas_Conditional_1_Template_button_click_59_listener() {
      i08.\u0275\u0275restoreView(_r1);
      const ctx_r1 = i08.\u0275\u0275nextContext();
      return i08.\u0275\u0275resetView(ctx_r1.toggleVista(false));
    });
    i08.\u0275\u0275text(60, "Cancelar");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(61, "button", 33);
    i08.\u0275\u0275text(62);
    i08.\u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    let tmp_4_0;
    const ctx_r1 = i08.\u0275\u0275nextContext();
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275textInterpolate(ctx_r1.modoEdicion ? "Editar Oferta Laboral" : "Publicar Nueva Oferta Laboral");
    i08.\u0275\u0275advance(4);
    i08.\u0275\u0275property("formGroup", ctx_r1.ofertaForm);
    i08.\u0275\u0275advance(5);
    i08.\u0275\u0275conditional(ctx_r1.esCampoInvalido("titulo") ? 12 : -1);
    i08.\u0275\u0275advance(34);
    i08.\u0275\u0275conditional(((tmp_4_0 = ctx_r1.ofertaForm.get("tipoDuracion")) == null ? null : tmp_4_0.value) === "personalizado" ? 46 : -1);
    i08.\u0275\u0275advance(5);
    i08.\u0275\u0275conditional(ctx_r1.esCampoInvalido("descripcion") ? 51 : -1);
    i08.\u0275\u0275advance(5);
    i08.\u0275\u0275repeater(ctx_r1.categoriasConSkills);
    i08.\u0275\u0275advance(5);
    i08.\u0275\u0275property("disabled", ctx_r1.ofertaForm.invalid || ctx_r1.skillsSeleccionadasIds.length === 0);
    i08.\u0275\u0275advance();
    i08.\u0275\u0275textInterpolate1(" ", ctx_r1.modoEdicion ? "Guardar Cambios" : "Publicar Oferta", " ");
  }
}
function Ofertas_Conditional_2_Conditional_24_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = i08.\u0275\u0275getCurrentView();
    i08.\u0275\u0275elementStart(0, "button", 56);
    i08.\u0275\u0275listener("click", function Ofertas_Conditional_2_Conditional_24_Template_button_click_0_listener() {
      i08.\u0275\u0275restoreView(_r7);
      const ctx_r1 = i08.\u0275\u0275nextContext(2);
      return i08.\u0275\u0275resetView(ctx_r1.toggleVista(true));
    });
    i08.\u0275\u0275element(1, "i", 57);
    i08.\u0275\u0275text(2, " Nueva Oferta ");
    i08.\u0275\u0275elementEnd();
  }
}
function Ofertas_Conditional_2_For_28_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = i08.\u0275\u0275getCurrentView();
    i08.\u0275\u0275elementStart(0, "div", 58);
    i08.\u0275\u0275listener("click", function Ofertas_Conditional_2_For_28_Template_div_click_0_listener() {
      const oferta_r9 = i08.\u0275\u0275restoreView(_r8).$implicit;
      const ctx_r1 = i08.\u0275\u0275nextContext(2);
      return i08.\u0275\u0275resetView(ctx_r1.seleccionarOferta(oferta_r9));
    });
    i08.\u0275\u0275elementStart(1, "div", 59)(2, "h3");
    i08.\u0275\u0275text(3);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(4, "span", 60);
    i08.\u0275\u0275text(5);
    i08.\u0275\u0275elementEnd()();
    i08.\u0275\u0275elementStart(6, "p", 61);
    i08.\u0275\u0275element(7, "i", 62);
    i08.\u0275\u0275text(8);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(9, "div", 63)(10, "span");
    i08.\u0275\u0275element(11, "i", 64);
    i08.\u0275\u0275text(12);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(13, "span");
    i08.\u0275\u0275element(14, "i", 65);
    i08.\u0275\u0275text(15);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(16, "span");
    i08.\u0275\u0275element(17, "i", 66);
    i08.\u0275\u0275text(18);
    i08.\u0275\u0275pipe(19, "date");
    i08.\u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const oferta_r9 = ctx.$implicit;
    const ctx_r1 = i08.\u0275\u0275nextContext(2);
    i08.\u0275\u0275classProp("seleccionada", (ctx_r1.ofertaSeleccionada == null ? null : ctx_r1.ofertaSeleccionada.id_oferta) === oferta_r9.id_oferta);
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275textInterpolate(oferta_r9.titulo);
    i08.\u0275\u0275advance();
    i08.\u0275\u0275classProp("abierta", ctx_r1.esOfertaAbierta(oferta_r9));
    i08.\u0275\u0275advance();
    i08.\u0275\u0275textInterpolate1(" ", ctx_r1.esOfertaAbierta(oferta_r9) ? "Abierta" : "Cerrada", " ");
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275textInterpolate1(" ", oferta_r9.razonSocial || oferta_r9.nombre_empresa || "Empresa");
    i08.\u0275\u0275advance(4);
    i08.\u0275\u0275textInterpolate1(" ", oferta_r9.modalidad);
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275textInterpolate1(" ", oferta_r9.experiencia);
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275textInterpolate1(" ", i08.\u0275\u0275pipeBind2(19, 10, oferta_r9.fecha_publicacion, "dd/MM/yyyy"));
  }
}
function Ofertas_Conditional_2_ForEmpty_29_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementStart(0, "div", 52)(1, "p");
    i08.\u0275\u0275text(2, "No se encontraron ofertas laborales con los filtros seleccionados.");
    i08.\u0275\u0275elementEnd()();
  }
}
function Ofertas_Conditional_2_Conditional_31_Conditional_21_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementStart(0, "div", 71)(1, "strong");
    i08.\u0275\u0275text(2, "Vence el:");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(3);
    i08.\u0275\u0275pipe(4, "date");
    i08.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i08.\u0275\u0275nextContext(3);
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275textInterpolate2(" ", i08.\u0275\u0275pipeBind2(4, 2, ctx_r1.obtenerFechaVencimiento(ctx_r1.ofertaSeleccionada), "dd/MM/yyyy"), " (", ctx_r1.ofertaSeleccionada.dias_duracion, " d\xEDas) ");
  }
}
function Ofertas_Conditional_2_Conditional_31_Conditional_26_For_4_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementStart(0, "span", 74);
    i08.\u0275\u0275text(1);
    i08.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const skill_r10 = ctx.$implicit;
    i08.\u0275\u0275advance();
    i08.\u0275\u0275textInterpolate(skill_r10);
  }
}
function Ofertas_Conditional_2_Conditional_31_Conditional_26_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementStart(0, "h4");
    i08.\u0275\u0275text(1, "Habilidades Requeridas");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(2, "div", 36);
    i08.\u0275\u0275repeaterCreate(3, Ofertas_Conditional_2_Conditional_31_Conditional_26_For_4_Template, 2, 1, "span", 74, i08.\u0275\u0275repeaterTrackByIdentity);
    i08.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i08.\u0275\u0275nextContext(3);
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275repeater(ctx_r1.ofertaSeleccionada.skills_nombres);
  }
}
function Ofertas_Conditional_2_Conditional_31_Conditional_28_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementStart(0, "button", 75);
    i08.\u0275\u0275element(1, "i", 78);
    i08.\u0275\u0275text(2, " Convocatoria Cerrada ");
    i08.\u0275\u0275elementEnd();
  }
}
function Ofertas_Conditional_2_Conditional_31_Conditional_28_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementStart(0, "button", 76);
    i08.\u0275\u0275element(1, "i", 79);
    i08.\u0275\u0275text(2, " Ya te has postulado ");
    i08.\u0275\u0275elementEnd();
  }
}
function Ofertas_Conditional_2_Conditional_31_Conditional_28_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = i08.\u0275\u0275getCurrentView();
    i08.\u0275\u0275elementStart(0, "button", 80);
    i08.\u0275\u0275listener("click", function Ofertas_Conditional_2_Conditional_31_Conditional_28_Conditional_2_Template_button_click_0_listener() {
      i08.\u0275\u0275restoreView(_r11);
      const ctx_r1 = i08.\u0275\u0275nextContext(4);
      return i08.\u0275\u0275resetView(ctx_r1.guardarPostulacion(ctx_r1.ofertaSeleccionada.id_oferta));
    });
    i08.\u0275\u0275element(1, "i", 81);
    i08.\u0275\u0275text(2, " Postularme ahora ");
    i08.\u0275\u0275elementEnd();
  }
}
function Ofertas_Conditional_2_Conditional_31_Conditional_28_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275conditionalCreate(0, Ofertas_Conditional_2_Conditional_31_Conditional_28_Conditional_0_Template, 3, 0, "button", 75)(1, Ofertas_Conditional_2_Conditional_31_Conditional_28_Conditional_1_Template, 3, 0, "button", 76)(2, Ofertas_Conditional_2_Conditional_31_Conditional_28_Conditional_2_Template, 3, 0, "button", 77);
  }
  if (rf & 2) {
    const ctx_r1 = i08.\u0275\u0275nextContext(3);
    i08.\u0275\u0275conditional(!ctx_r1.esOfertaAbierta(ctx_r1.ofertaSeleccionada) ? 0 : ctx_r1.estaPostulado(ctx_r1.ofertaSeleccionada.id_oferta) ? 1 : 2);
  }
}
function Ofertas_Conditional_2_Conditional_31_Conditional_29_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = i08.\u0275\u0275getCurrentView();
    i08.\u0275\u0275elementStart(0, "button", 90);
    i08.\u0275\u0275listener("click", function Ofertas_Conditional_2_Conditional_31_Conditional_29_Conditional_9_Template_button_click_0_listener() {
      i08.\u0275\u0275restoreView(_r13);
      const ctx_r1 = i08.\u0275\u0275nextContext(4);
      return i08.\u0275\u0275resetView(ctx_r1.cambiarEstadoOferta(ctx_r1.ofertaSeleccionada.id_oferta, "Cerrada"));
    });
    i08.\u0275\u0275element(1, "i", 91);
    i08.\u0275\u0275text(2, " Cerrar Convocatoria ");
    i08.\u0275\u0275elementEnd();
  }
}
function Ofertas_Conditional_2_Conditional_31_Conditional_29_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = i08.\u0275\u0275getCurrentView();
    i08.\u0275\u0275elementStart(0, "button", 92);
    i08.\u0275\u0275listener("click", function Ofertas_Conditional_2_Conditional_31_Conditional_29_Conditional_10_Template_button_click_0_listener() {
      i08.\u0275\u0275restoreView(_r14);
      const ctx_r1 = i08.\u0275\u0275nextContext(4);
      return i08.\u0275\u0275resetView(ctx_r1.cambiarEstadoOferta(ctx_r1.ofertaSeleccionada.id_oferta, "Abierta"));
    });
    i08.\u0275\u0275element(1, "i", 93);
    i08.\u0275\u0275text(2, " Reabrir Convocatoria ");
    i08.\u0275\u0275elementEnd();
  }
}
function Ofertas_Conditional_2_Conditional_31_Conditional_29_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = i08.\u0275\u0275getCurrentView();
    i08.\u0275\u0275elementStart(0, "button", 82);
    i08.\u0275\u0275listener("click", function Ofertas_Conditional_2_Conditional_31_Conditional_29_Template_button_click_0_listener() {
      i08.\u0275\u0275restoreView(_r12);
      const ctx_r1 = i08.\u0275\u0275nextContext(3);
      return i08.\u0275\u0275resetView(ctx_r1.verPostulados(ctx_r1.ofertaSeleccionada.id_oferta));
    });
    i08.\u0275\u0275element(1, "i", 83);
    i08.\u0275\u0275text(2, " Ver Candidatos ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(3, "button", 84);
    i08.\u0275\u0275listener("click", function Ofertas_Conditional_2_Conditional_31_Conditional_29_Template_button_click_3_listener() {
      i08.\u0275\u0275restoreView(_r12);
      const ctx_r1 = i08.\u0275\u0275nextContext(3);
      return i08.\u0275\u0275resetView(ctx_r1.toggleVista(true, ctx_r1.ofertaSeleccionada));
    });
    i08.\u0275\u0275element(4, "i", 85);
    i08.\u0275\u0275text(5, " Editar Publicaci\xF3n ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(6, "button", 86);
    i08.\u0275\u0275listener("click", function Ofertas_Conditional_2_Conditional_31_Conditional_29_Template_button_click_6_listener() {
      i08.\u0275\u0275restoreView(_r12);
      const ctx_r1 = i08.\u0275\u0275nextContext(3);
      return i08.\u0275\u0275resetView(ctx_r1.ampliarDuracion(ctx_r1.ofertaSeleccionada.id_oferta));
    });
    i08.\u0275\u0275element(7, "i", 87);
    i08.\u0275\u0275text(8, " Ampliar D\xEDas ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275conditionalCreate(9, Ofertas_Conditional_2_Conditional_31_Conditional_29_Conditional_9_Template, 3, 0, "button", 88)(10, Ofertas_Conditional_2_Conditional_31_Conditional_29_Conditional_10_Template, 3, 0, "button", 89);
  }
  if (rf & 2) {
    const ctx_r1 = i08.\u0275\u0275nextContext(3);
    i08.\u0275\u0275advance(9);
    i08.\u0275\u0275conditional(ctx_r1.esOfertaAbierta(ctx_r1.ofertaSeleccionada) ? 9 : 10);
  }
}
function Ofertas_Conditional_2_Conditional_31_Conditional_30_Template(rf, ctx) {
  if (rf & 1) {
    const _r15 = i08.\u0275\u0275getCurrentView();
    i08.\u0275\u0275elementStart(0, "button", 82);
    i08.\u0275\u0275listener("click", function Ofertas_Conditional_2_Conditional_31_Conditional_30_Template_button_click_0_listener() {
      i08.\u0275\u0275restoreView(_r15);
      const ctx_r1 = i08.\u0275\u0275nextContext(3);
      return i08.\u0275\u0275resetView(ctx_r1.verPostulados(ctx_r1.ofertaSeleccionada.id_oferta));
    });
    i08.\u0275\u0275element(1, "i", 83);
    i08.\u0275\u0275text(2, " Ver Candidatos ");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(3, "button", 94);
    i08.\u0275\u0275listener("click", function Ofertas_Conditional_2_Conditional_31_Conditional_30_Template_button_click_3_listener() {
      i08.\u0275\u0275restoreView(_r15);
      const ctx_r1 = i08.\u0275\u0275nextContext(3);
      return i08.\u0275\u0275resetView(ctx_r1.bajaOfertaAdmin(ctx_r1.ofertaSeleccionada.id_oferta));
    });
    i08.\u0275\u0275element(4, "i", 95);
    i08.\u0275\u0275text(5, " Eliminar (Moderaci\xF3n Admin) ");
    i08.\u0275\u0275elementEnd();
  }
}
function Ofertas_Conditional_2_Conditional_31_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementStart(0, "div", 54)(1, "div", 67)(2, "div")(3, "h2");
    i08.\u0275\u0275text(4);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(5, "p", 68);
    i08.\u0275\u0275element(6, "i", 62);
    i08.\u0275\u0275text(7);
    i08.\u0275\u0275elementEnd()();
    i08.\u0275\u0275elementStart(8, "span", 69);
    i08.\u0275\u0275text(9);
    i08.\u0275\u0275elementEnd()();
    i08.\u0275\u0275element(10, "hr");
    i08.\u0275\u0275elementStart(11, "div", 70)(12, "div", 71)(13, "strong");
    i08.\u0275\u0275text(14, "Nivel de experiencia:");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(15);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(16, "div", 71)(17, "strong");
    i08.\u0275\u0275text(18, "Publicado el:");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275text(19);
    i08.\u0275\u0275pipe(20, "date");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275conditionalCreate(21, Ofertas_Conditional_2_Conditional_31_Conditional_21_Template, 5, 5, "div", 71);
    i08.\u0275\u0275elementStart(22, "h4");
    i08.\u0275\u0275text(23, "Descripci\xF3n del Puesto");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(24, "p", 72);
    i08.\u0275\u0275text(25);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275conditionalCreate(26, Ofertas_Conditional_2_Conditional_31_Conditional_26_Template, 5, 0);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(27, "div", 73);
    i08.\u0275\u0275conditionalCreate(28, Ofertas_Conditional_2_Conditional_31_Conditional_28_Template, 3, 1);
    i08.\u0275\u0275conditionalCreate(29, Ofertas_Conditional_2_Conditional_31_Conditional_29_Template, 11, 1);
    i08.\u0275\u0275conditionalCreate(30, Ofertas_Conditional_2_Conditional_31_Conditional_30_Template, 6, 0);
    i08.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = i08.\u0275\u0275nextContext(2);
    i08.\u0275\u0275advance(4);
    i08.\u0275\u0275textInterpolate(ctx_r1.ofertaSeleccionada.titulo);
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275textInterpolate1(" ", ctx_r1.ofertaSeleccionada.razonSocial || ctx_r1.ofertaSeleccionada.nombre_empresa || "Empresa ITB");
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275textInterpolate(ctx_r1.ofertaSeleccionada.modalidad);
    i08.\u0275\u0275advance(6);
    i08.\u0275\u0275textInterpolate1(" ", ctx_r1.ofertaSeleccionada.experiencia, " ");
    i08.\u0275\u0275advance(4);
    i08.\u0275\u0275textInterpolate1(" ", i08.\u0275\u0275pipeBind2(20, 11, ctx_r1.ofertaSeleccionada.fecha_publicacion, "dd/MM/yyyy"), " ");
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275conditional(ctx_r1.obtenerFechaVencimiento(ctx_r1.ofertaSeleccionada) ? 21 : -1);
    i08.\u0275\u0275advance(4);
    i08.\u0275\u0275textInterpolate(ctx_r1.ofertaSeleccionada.descripcion);
    i08.\u0275\u0275advance();
    i08.\u0275\u0275conditional(ctx_r1.ofertaSeleccionada.skills_nombres && ctx_r1.ofertaSeleccionada.skills_nombres.length > 0 ? 26 : -1);
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275conditional(ctx_r1.rolUsuario === "postulante" || ctx_r1.rolUsuario === "visitante" || !ctx_r1.rolUsuario ? 28 : -1);
    i08.\u0275\u0275advance();
    i08.\u0275\u0275conditional(ctx_r1.rolUsuario === "empresa" && ctx_r1.idUsuario === ((ctx_r1.ofertaSeleccionada.id_empresa || ctx_r1.ofertaSeleccionada.empresa_id) == null ? null : (ctx_r1.ofertaSeleccionada.id_empresa || ctx_r1.ofertaSeleccionada.empresa_id).toString()) ? 29 : -1);
    i08.\u0275\u0275advance();
    i08.\u0275\u0275conditional(ctx_r1.rolUsuario === "admin" ? 30 : -1);
  }
}
function Ofertas_Conditional_2_Conditional_32_Template(rf, ctx) {
  if (rf & 1) {
    i08.\u0275\u0275elementStart(0, "div", 55)(1, "p");
    i08.\u0275\u0275text(2, "Selecciona una oferta de la lista para ver sus detalles.");
    i08.\u0275\u0275elementEnd()();
  }
}
function Ofertas_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = i08.\u0275\u0275getCurrentView();
    i08.\u0275\u0275elementStart(0, "header", 39)(1, "div", 40)(2, "h2");
    i08.\u0275\u0275text(3, "Bolsa de Trabajos ITB Conecta");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(4, "p", 41);
    i08.\u0275\u0275text(5, "Explora oportunidades laborales o gestiona tus b\xFAsquedas publicadas.");
    i08.\u0275\u0275elementEnd()();
    i08.\u0275\u0275elementStart(6, "div", 42)(7, "input", 43);
    i08.\u0275\u0275twoWayListener("ngModelChange", function Ofertas_Conditional_2_Template_input_ngModelChange_7_listener($event) {
      i08.\u0275\u0275restoreView(_r6);
      const ctx_r1 = i08.\u0275\u0275nextContext();
      i08.\u0275\u0275twoWayBindingSet(ctx_r1.searchQuery, $event) || (ctx_r1.searchQuery = $event);
      return i08.\u0275\u0275resetView($event);
    });
    i08.\u0275\u0275listener("input", function Ofertas_Conditional_2_Template_input_input_7_listener() {
      i08.\u0275\u0275restoreView(_r6);
      const ctx_r1 = i08.\u0275\u0275nextContext();
      return i08.\u0275\u0275resetView(ctx_r1.filtrarOfertasLocal());
    });
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(8, "select", 44);
    i08.\u0275\u0275twoWayListener("ngModelChange", function Ofertas_Conditional_2_Template_select_ngModelChange_8_listener($event) {
      i08.\u0275\u0275restoreView(_r6);
      const ctx_r1 = i08.\u0275\u0275nextContext();
      i08.\u0275\u0275twoWayBindingSet(ctx_r1.filtroModalidad, $event) || (ctx_r1.filtroModalidad = $event);
      return i08.\u0275\u0275resetView($event);
    });
    i08.\u0275\u0275listener("change", function Ofertas_Conditional_2_Template_select_change_8_listener() {
      i08.\u0275\u0275restoreView(_r6);
      const ctx_r1 = i08.\u0275\u0275nextContext();
      return i08.\u0275\u0275resetView(ctx_r1.filtrarOfertasLocal());
    });
    i08.\u0275\u0275elementStart(9, "option", 45);
    i08.\u0275\u0275text(10, "Todas las modalidades");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(11, "option", 13);
    i08.\u0275\u0275text(12, "Presencial");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(13, "option", 14);
    i08.\u0275\u0275text(14, "H\xEDbrido");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(15, "option", 15);
    i08.\u0275\u0275text(16, "Remoto");
    i08.\u0275\u0275elementEnd()();
    i08.\u0275\u0275elementStart(17, "div", 46)(18, "button", 47);
    i08.\u0275\u0275listener("click", function Ofertas_Conditional_2_Template_button_click_18_listener() {
      i08.\u0275\u0275restoreView(_r6);
      const ctx_r1 = i08.\u0275\u0275nextContext();
      return i08.\u0275\u0275resetView(ctx_r1.cambiarFiltroEstado("abiertas"));
    });
    i08.\u0275\u0275text(19, "Abiertas");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(20, "button", 47);
    i08.\u0275\u0275listener("click", function Ofertas_Conditional_2_Template_button_click_20_listener() {
      i08.\u0275\u0275restoreView(_r6);
      const ctx_r1 = i08.\u0275\u0275nextContext();
      return i08.\u0275\u0275resetView(ctx_r1.cambiarFiltroEstado("cerradas"));
    });
    i08.\u0275\u0275text(21, "Cerradas");
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(22, "button", 47);
    i08.\u0275\u0275listener("click", function Ofertas_Conditional_2_Template_button_click_22_listener() {
      i08.\u0275\u0275restoreView(_r6);
      const ctx_r1 = i08.\u0275\u0275nextContext();
      return i08.\u0275\u0275resetView(ctx_r1.cambiarFiltroEstado("todas"));
    });
    i08.\u0275\u0275text(23, "Todas");
    i08.\u0275\u0275elementEnd()();
    i08.\u0275\u0275conditionalCreate(24, Ofertas_Conditional_2_Conditional_24_Template, 3, 0, "button", 48);
    i08.\u0275\u0275elementEnd()();
    i08.\u0275\u0275elementStart(25, "div", 49)(26, "aside", 50);
    i08.\u0275\u0275repeaterCreate(27, Ofertas_Conditional_2_For_28_Template, 20, 13, "div", 51, _forTrack2, false, Ofertas_Conditional_2_ForEmpty_29_Template, 3, 0, "div", 52);
    i08.\u0275\u0275elementEnd();
    i08.\u0275\u0275elementStart(30, "main", 53);
    i08.\u0275\u0275conditionalCreate(31, Ofertas_Conditional_2_Conditional_31_Template, 31, 14, "div", 54)(32, Ofertas_Conditional_2_Conditional_32_Template, 3, 0, "div", 55);
    i08.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = i08.\u0275\u0275nextContext();
    i08.\u0275\u0275advance(7);
    i08.\u0275\u0275twoWayProperty("ngModel", ctx_r1.searchQuery);
    i08.\u0275\u0275advance();
    i08.\u0275\u0275twoWayProperty("ngModel", ctx_r1.filtroModalidad);
    i08.\u0275\u0275advance(10);
    i08.\u0275\u0275classProp("activo", ctx_r1.filtroEstado === "abiertas");
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275classProp("activo", ctx_r1.filtroEstado === "cerradas");
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275classProp("activo", ctx_r1.filtroEstado === "todas");
    i08.\u0275\u0275advance(2);
    i08.\u0275\u0275conditional(ctx_r1.rolUsuario === "empresa" || ctx_r1.rolUsuario === "admin" ? 24 : -1);
    i08.\u0275\u0275advance(3);
    i08.\u0275\u0275repeater(ctx_r1.ofertasFiltradas);
    i08.\u0275\u0275advance(4);
    i08.\u0275\u0275conditional(ctx_r1.ofertaSeleccionada ? 31 : 32);
  }
}
var Ofertas = class _Ofertas {
  fb;
  ofertaService;
  postulacionesService;
  authService;
  cdr;
  router;
  rolUsuario = "";
  idUsuario = "";
  nombreUsuario = "";
  mostrarFormulario = false;
  modoEdicion = false;
  idOfertaEnEdicion = null;
  ofertaForm;
  categoriasConSkills = [];
  skillsSeleccionadasIds = [];
  ofertasDeBaseDeDatos = [];
  ofertasFiltradas = [];
  ofertaSeleccionada = null;
  postulacionesRealizadas = /* @__PURE__ */ new Set();
  searchQuery = "";
  filtroModalidad = "todos";
  filtroEstado = "abiertas";
  constructor(fb, ofertaService, postulacionesService, authService, cdr, router) {
    this.fb = fb;
    this.ofertaService = ofertaService;
    this.postulacionesService = postulacionesService;
    this.authService = authService;
    this.cdr = cdr;
    this.router = router;
  }
  ngOnInit() {
    const usuarioLogueado = this.authService.getUsuarioActual();
    const rolRaw = this.authService.getTipoUsuario() || usuarioLogueado?.rol || "visitante";
    this.rolUsuario = String(rolRaw).toLowerCase();
    this.idUsuario = usuarioLogueado ? String(usuarioLogueado.id_postulante || usuarioLogueado.id_empresa || usuarioLogueado.id) : null;
    this.nombreUsuario = usuarioLogueado ? usuarioLogueado.nombre : "Usuario";
    this.inicializarFormulario();
    this.cargarOfertasDesdeBackend();
    if (usuarioLogueado) {
      this.cargarHabilidadesYCategorias();
      if (this.rolUsuario === "postulante") {
        this.cargarMisPostulaciones();
      }
    }
  }
  inicializarFormulario() {
    this.ofertaForm = this.fb.group({
      titulo: ["", [Validators4.required, Validators4.minLength(5)]],
      modalidad: ["H\xEDbrido", Validators4.required],
      experiencia: ["Junior", Validators4.required],
      descripcion: ["", [Validators4.required, Validators4.minLength(20)]],
      tipoDuracion: ["10", Validators4.required],
      diasPersonalizados: [null]
    });
  }
  resetearFormulario() {
    this.modoEdicion = false;
    this.idOfertaEnEdicion = null;
    this.skillsSeleccionadasIds = [];
    this.ofertaForm.reset({
      modalidad: "H\xEDbrido",
      experiencia: "Junior",
      tipoDuracion: "10"
    });
  }
  get skillsSeleccionadasObjetos() {
    const seleccionadas = [];
    for (const cat of this.categoriasConSkills) {
      for (const skill of cat.skills) {
        if (this.skillsSeleccionadasIds.includes(skill.skill_id)) {
          seleccionadas.push(skill);
        }
      }
    }
    return seleccionadas;
  }
  cargarMisPostulaciones() {
    if (!this.idUsuario)
      return;
    this.postulacionesService.getByPostulante(Number(this.idUsuario)).subscribe({
      next: (postulaciones) => {
        this.postulacionesRealizadas = new Set(postulaciones.map((p) => Number(p.id_oferta)));
        this.cdr.detectChanges();
      },
      error: (err) => console.error("Error al obtener postulaciones:", err)
    });
  }
  cargarOfertasDesdeBackend() {
    this.ofertaService.getOfertasVigentes().subscribe({
      next: (data) => {
        this.ofertasDeBaseDeDatos = (data || []).map((o) => {
          const fechaDetectada = o.fecha_publicacion || o.fechaPublicacion || o.created_at || o.createdAt || o.fecha_creacion || o.fecha;
          return __spreadProps(__spreadValues({}, o), {
            dias_duracion: o.dias_duracion || o.diasDuracion || 10,
            fecha_publicacion: fechaDetectada
          });
        });
        this.filtrarOfertasLocal();
        this.cdr.detectChanges();
      },
      error: (err) => console.error("Error al cargar ofertas:", err)
    });
  }
  cargarHabilidadesYCategorias() {
    this.ofertaService.getCategoriasConSkills().subscribe({
      next: (data) => {
        this.categoriasConSkills = data;
        this.cdr.detectChanges();
      },
      error: (err) => console.error("Error al cargar habilidades:", err)
    });
  }
  onTipoDuracionChange() {
    const tipo = this.ofertaForm.get("tipoDuracion")?.value;
    const controlDias = this.ofertaForm.get("diasPersonalizados");
    if (tipo === "personalizado") {
      controlDias?.setValidators([Validators4.required, Validators4.min(1), Validators4.max(90)]);
    } else {
      controlDias?.clearValidators();
      controlDias?.setValue(null);
    }
    controlDias?.updateValueAndValidity();
  }
  alternarHabilidad(skill_Id) {
    const index = this.skillsSeleccionadasIds.indexOf(skill_Id);
    if (index > -1) {
      this.skillsSeleccionadasIds.splice(index, 1);
    } else {
      this.skillsSeleccionadasIds.push(skill_Id);
    }
  }
  seleccionarOferta(oferta) {
    if (!oferta)
      return;
    this.ofertaSeleccionada = __spreadProps(__spreadValues({}, oferta), {
      id_oferta: oferta.id_oferta || oferta.id,
      dias_duracion: oferta.dias_duracion || oferta.diasDuracion || 10,
      skills_nombres: oferta.skills_nombres || []
    });
  }
  seleccionarPrimeraDisponible(lista) {
    if (lista.length > 0) {
      this.seleccionarOferta(lista[0]);
    } else {
      this.ofertaSeleccionada = null;
    }
  }
  esCampoInvalido(campo) {
    const control = this.ofertaForm.get(campo);
    return !!(control && control.invalid && (control.dirty || control.touched));
  }
  toggleVista(verForm, editarOferta = null) {
    this.mostrarFormulario = verForm;
    if (verForm) {
      if (this.categoriasConSkills.length === 0) {
        this.cargarHabilidadesYCategorias();
      }
      if (editarOferta) {
        this.modoEdicion = true;
        this.idOfertaEnEdicion = editarOferta.id_oferta;
        this.ofertaForm.patchValue({
          titulo: editarOferta.titulo,
          modalidad: editarOferta.modalidad,
          experiencia: editarOferta.experiencia,
          descripcion: editarOferta.descripcion,
          tipoDuracion: String(editarOferta.dias_duracion || "10")
        });
        this.skillsSeleccionadasIds = [...editarOferta.skills_ids || []];
      } else {
        this.resetearFormulario();
      }
    } else {
      this.resetearFormulario();
    }
  }
  verPostulados(idOferta) {
    if (!idOferta)
      return;
    this.router.navigate(["/postulaciones"], { queryParams: { oferta: idOferta } });
  }
  esOfertaAbierta(oferta) {
    if (!oferta)
      return false;
    if (oferta.estado === "Cerrada" || oferta.estado === "Finalizada")
      return false;
    if (oferta.estado === "Abierta")
      return true;
    if (!oferta.fecha_publicacion || !oferta.dias_duracion)
      return false;
    const fechaLimpia = String(oferta.fecha_publicacion).trim().split("T")[0].replace(/\//g, "-");
    const partes = fechaLimpia.split("-");
    if (partes.length < 3)
      return false;
    const anio = Number(partes[0]);
    const mes = Number(partes[1]) - 1;
    const dia = Number(partes[2]);
    const fechaInicio = new Date(anio, mes, dia);
    if (isNaN(fechaInicio.getTime()))
      return false;
    const fechaVencimiento = new Date(fechaInicio);
    fechaVencimiento.setDate(fechaVencimiento.getDate() + Number(oferta.dias_duracion));
    fechaVencimiento.setHours(23, 59, 59, 999);
    return /* @__PURE__ */ new Date() <= fechaVencimiento;
  }
  obtenerFechaVencimiento(oferta) {
    if (!oferta || !oferta.fecha_publicacion || !oferta.dias_duracion)
      return null;
    const fechaLimpia = String(oferta.fecha_publicacion).trim().split("T")[0].replace(/\//g, "-");
    const partes = fechaLimpia.split("-");
    if (partes.length < 3)
      return null;
    const anio = Number(partes[0]);
    const mes = Number(partes[1]) - 1;
    const dia = Number(partes[2]);
    const fechaInicio = new Date(anio, mes, dia);
    if (isNaN(fechaInicio.getTime()))
      return null;
    const fechaVencimiento = new Date(fechaInicio);
    fechaVencimiento.setDate(fechaVencimiento.getDate() + Number(oferta.dias_duracion));
    return fechaVencimiento;
  }
  filtrarOfertasLocal() {
    this.ofertasFiltradas = this.ofertasDeBaseDeDatos.filter((o) => {
      const coincideBusqueda = o.titulo.toLowerCase().includes(this.searchQuery.toLowerCase()) || o.razonSocial && o.razonSocial.toLowerCase().includes(this.searchQuery.toLowerCase()) || o.skills_nombres && o.skills_nombres.some((s) => s.toLowerCase().includes(this.searchQuery.toLowerCase()));
      const coincideModalidad = this.filtroModalidad === "todos" || o.modalidad === this.filtroModalidad;
      const abierta = this.esOfertaAbierta(o);
      let coincideEstado = true;
      if (this.filtroEstado === "abiertas")
        coincideEstado = abierta;
      if (this.filtroEstado === "cerradas")
        coincideEstado = !abierta;
      return coincideBusqueda && coincideModalidad && coincideEstado;
    });
    this.sincronizarSeleccionDerecha();
  }
  cambiarFiltroEstado(estado) {
    this.filtroEstado = estado;
    this.filtrarOfertasLocal();
  }
  cambiarFiltroModalidad(modalidad) {
    this.filtroModalidad = modalidad;
    this.filtrarOfertasLocal();
  }
  sincronizarSeleccionDerecha() {
    if (!this.ofertaSeleccionada || !this.ofertasFiltradas.some((o) => o.id_oferta === this.ofertaSeleccionada.id_oferta)) {
      this.seleccionarPrimeraDisponible(this.ofertasFiltradas);
    }
  }
  guardarOferta() {
    if (this.ofertaForm.invalid || this.skillsSeleccionadasIds.length === 0) {
      this.ofertaForm.markAllAsTouched();
      alert("Por favor completa los campos obligatorios y selecciona al menos una habilidad.");
      return;
    }
    const fValue = this.ofertaForm.value;
    const diasFinales = fValue.tipoDuracion === "personalizado" ? Number(fValue.diasPersonalizados) : Number(fValue.tipoDuracion);
    const payload = {
      id_empresa: Number(this.idUsuario || 0),
      titulo: fValue.titulo,
      descripcion: fValue.descripcion,
      modalidad: fValue.modalidad,
      experiencia: fValue.experiencia,
      dias_duracion: diasFinales,
      skill: [...this.skillsSeleccionadasIds]
    };
    const peticion$ = this.modoEdicion && this.idOfertaEnEdicion ? this.ofertaService.actualizarOferta(this.idOfertaEnEdicion, payload) : this.ofertaService.publicarOferta(payload);
    peticion$.subscribe({
      next: () => {
        alert(this.modoEdicion ? "Oferta actualizada con \xE9xito." : "Oferta publicada con \xE9xito.");
        this.resetearFormulario();
        this.toggleVista(false);
        this.cargarOfertasDesdeBackend();
      },
      error: (err) => {
        console.error("Error al guardar la oferta:", err);
        if (err.status === 403) {
          alert('Acceso denegado (403): Tu usuario no cuenta con el rol "Empresa" o la sesi\xF3n expir\xF3.');
        } else {
          alert(err.error?.error || err.error?.mensaje || "Error al procesar la solicitud en el servidor.");
        }
      }
    });
  }
  cambiarEstadoOferta(ofertaId, nuevoEstado) {
    if (confirm(`\xBFConfirma que desea marcar esta oferta como ${nuevoEstado}?`)) {
      this.ofertaService.cambiarEstado(ofertaId, nuevoEstado).subscribe({
        next: () => {
          if (this.ofertaSeleccionada && this.ofertaSeleccionada.id_oferta === ofertaId) {
            this.ofertaSeleccionada.estado = nuevoEstado;
          }
          const item = this.ofertasDeBaseDeDatos.find((o) => o.id_oferta === ofertaId);
          if (item)
            item.estado = nuevoEstado;
          this.filtrarOfertasLocal();
          alert(`La oferta ahora est\xE1 ${nuevoEstado}.`);
        },
        error: (err) => console.error("Error al cambiar estado:", err)
      });
    }
  }
  ampliarDuracion(ofertaId) {
    const diasStr = prompt("\xBFCu\xE1ntos d\xEDas desea agregar al plazo de vigencia?", "10");
    const dias = Number(diasStr);
    if (dias && dias > 0) {
      this.ofertaService.ampliarPlazo(ofertaId, dias).subscribe({
        next: () => {
          if (this.ofertaSeleccionada && this.ofertaSeleccionada.id_oferta === ofertaId) {
            this.ofertaSeleccionada.dias_duracion = Number(this.ofertaSeleccionada.dias_duracion) + dias;
          }
          this.cargarOfertasDesdeBackend();
          alert(`Plazo ampliado exitosamente en ${dias} d\xEDas.`);
        },
        error: (err) => console.error("Error al ampliar plazo:", err)
      });
    }
  }
  guardarPostulacion(ofertaId) {
    if (!this.idUsuario) {
      alert("Debes iniciar sesi\xF3n para postularte a una oferta laboral.");
      this.router.navigate(["/sesion"]);
      return;
    }
    if (this.postulacionesRealizadas.has(ofertaId)) {
      alert("Ya te has postulado a esta oferta laboral.");
      return;
    }
    this.postulacionesService.crearPostulacion(ofertaId).subscribe({
      next: () => {
        alert("\xA1Postulaci\xF3n enviada con \xE9xito!");
        this.postulacionesRealizadas.add(ofertaId);
        this.postulacionesRealizadas = new Set(this.postulacionesRealizadas);
        this.cdr.detectChanges();
      },
      error: (err) => alert(err.error?.mensaje || "Error al procesar la postulaci\xF3n.")
    });
  }
  estaPostulado(ofertaId) {
    return this.postulacionesRealizadas.has(ofertaId);
  }
  bajaOfertaAdmin(ofertaId) {
    if (confirm("\xBFEst\xE1 seguro de que desea eliminar esta oferta de manera permanente?")) {
      this.ofertaService.eliminarOferta(ofertaId).subscribe({
        next: () => {
          this.ofertasDeBaseDeDatos = this.ofertasDeBaseDeDatos.filter((o) => o.id_oferta !== ofertaId);
          this.filtrarOfertasLocal();
          alert(`Oferta N\xB0 ${ofertaId} eliminada.`);
        },
        error: (err) => console.error("Error al eliminar oferta:", err)
      });
    }
  }
  static \u0275fac = function Ofertas_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Ofertas)(i08.\u0275\u0275directiveInject(i15.FormBuilder), i08.\u0275\u0275directiveInject(OfertaService), i08.\u0275\u0275directiveInject(PostulacionesService), i08.\u0275\u0275directiveInject(AuthService), i08.\u0275\u0275directiveInject(i08.ChangeDetectorRef), i08.\u0275\u0275directiveInject(i5.Router));
  };
  static \u0275cmp = /* @__PURE__ */ i08.\u0275\u0275defineComponent({ type: _Ofertas, selectors: [["app-ofertas"]], decls: 3, vars: 1, consts: [[1, "ofertas-container"], [1, "formulario-card"], [1, "form-header"], ["type", "button", 1, "btn-cancelar", 3, "click"], [1, "fa-solid", "fa-xmark"], [3, "ngSubmit", "formGroup"], [1, "form-group"], ["for", "titulo"], ["id", "titulo", "name", "titulo", "type", "text", "formControlName", "titulo", "placeholder", "Ej: Desarrollador Frontend Angular"], [1, "error-text"], [1, "form-row"], ["for", "modalidad"], ["id", "modalidad", "name", "modalidad", "formControlName", "modalidad"], ["value", "Presencial"], ["value", "H\xEDbrido"], ["value", "Remoto"], ["for", "experiencia"], ["id", "experiencia", "name", "experiencia", "formControlName", "experiencia"], ["value", "Trainee"], ["value", "Junior"], ["value", "Semi-Senior"], ["value", "Senior"], ["for", "tipoDuracion"], ["id", "tipoDuracion", "name", "tipoDuracion", "formControlName", "tipoDuracion", 3, "change"], ["value", "10"], ["value", "30"], ["value", "personalizado"], ["for", "descripcion"], ["id", "descripcion", "name", "descripcion", "formControlName", "descripcion", "rows", "5", "placeholder", "Detalla los requisitos, tareas y beneficios..."], [1, "categorias-container"], [1, "categoria-group"], [1, "form-actions"], ["type", "button", 1, "btn-secundario", 3, "click"], ["type", "submit", 1, "btn-primario", 3, "disabled"], ["for", "diasPersonalizados"], ["id", "diasPersonalizados", "name", "diasPersonalizados", "type", "number", "formControlName", "diasPersonalizados", "min", "1", "max", "90"], [1, "chips-container"], ["type", "button", 1, "chip-skill", 3, "seleccionada"], ["type", "button", 1, "chip-skill", 3, "click"], [1, "header-ofertas"], [1, "titulo-seccion"], [1, "subtitulo"], [1, "bar-acciones"], ["id", "searchQuery", "name", "searchQuery", "type", "text", "placeholder", "\u{1F50D} Buscar por t\xEDtulo, empresa o tecnolog\xEDa...", 1, "input-busqueda", 3, "ngModelChange", "input", "ngModel"], ["id", "filtroModalidad", "name", "filtroModalidad", 1, "select-filtro", 3, "ngModelChange", "change", "ngModel"], ["value", "todos"], [1, "btn-group-estados"], ["type", "button", 3, "click"], ["type", "button", 1, "btn-crear"], [1, "layout-ofertas"], [1, "columna-lista"], [1, "card-oferta", 3, "seleccionada"], [1, "sin-resultados"], [1, "columna-detalle"], [1, "card-detalle-completo"], [1, "sin-seleccion"], ["type", "button", 1, "btn-crear", 3, "click"], [1, "fa-solid", "fa-plus"], [1, "card-oferta", 3, "click"], [1, "card-header"], [1, "badge-estado"], [1, "empresa-nombre"], [1, "fa-regular", "fa-building"], [1, "tags-info"], [1, "fa-solid", "fa-laptop"], [1, "fa-solid", "fa-briefcase"], [1, "fa-regular", "fa-calendar-days"], [1, "detalle-header-top"], [1, "empresa-detalle"], [1, "badge-modalidad"], [1, "detalle-body"], [1, "meta-item"], [1, "descripcion-texto"], [1, "detalle-footer"], [1, "chip-skill-view"], ["type", "button", "disabled", "", 1, "btn-deshabilitado"], ["type", "button", "disabled", "", 1, "btn-postulado"], ["type", "button", 1, "btn-postularse"], [1, "fa-solid", "fa-lock"], [1, "fa-solid", "fa-check-double"], ["type", "button", 1, "btn-postularse", 3, "click"], [1, "fa-solid", "fa-paper-plane"], ["type", "button", 1, "btn-candidatos", 3, "click"], [1, "fa-solid", "fa-users"], ["type", "button", 1, "btn-editar", 3, "click"], [1, "fa-solid", "fa-pen-to-square"], ["type", "button", 1, "btn-duracion", 3, "click"], [1, "fa-solid", "fa-hourglass-half"], ["type", "button", 1, "btn-cerrar-oferta"], ["type", "button", 1, "btn-reabrir-oferta"], ["type", "button", 1, "btn-cerrar-oferta", 3, "click"], [1, "fa-solid", "fa-folder-closed"], ["type", "button", 1, "btn-reabrir-oferta", 3, "click"], [1, "fa-solid", "fa-folder-open"], ["type", "button", 1, "btn-eliminar-admin", 3, "click"], [1, "fa-solid", "fa-trash-can"]], template: function Ofertas_Template(rf, ctx) {
    if (rf & 1) {
      i08.\u0275\u0275elementStart(0, "div", 0);
      i08.\u0275\u0275conditionalCreate(1, Ofertas_Conditional_1_Template, 63, 7, "div", 1)(2, Ofertas_Conditional_2_Template, 33, 11);
      i08.\u0275\u0275elementEnd();
    }
    if (rf & 2) {
      i08.\u0275\u0275advance();
      i08.\u0275\u0275conditional(ctx.mostrarFormulario ? 1 : 2);
    }
  }, dependencies: [ReactiveFormsModule4, i15.\u0275NgNoValidate, i15.NgSelectOption, i15.\u0275NgSelectMultipleOption, i15.DefaultValueAccessor, i15.NumberValueAccessor, i15.RangeValueAccessor, i15.CheckboxControlValueAccessor, i15.SelectControlValueAccessor, i15.SelectMultipleControlValueAccessor, i15.RadioControlValueAccessor, i15.NgControlStatus, i15.NgControlStatusGroup, i15.RequiredValidator, i15.MinLengthValidator, i15.MaxLengthValidator, i15.PatternValidator, i15.CheckboxRequiredValidator, i15.EmailValidator, i15.MinValidator, i15.MaxValidator, i15.FormControlDirective, i15.FormGroupDirective, i15.FormArrayDirective, i15.FormControlName, i15.FormGroupName, i15.FormArrayName, FormsModule, i15.NgModel, i15.NgModelGroup, i15.NgForm, CommonModule3, i6.NgClass, i6.NgComponentOutlet, i6.NgForOf, i6.NgIf, i6.NgTemplateOutlet, i6.NgStyle, i6.NgSwitch, i6.NgSwitchCase, i6.NgSwitchDefault, i6.NgPlural, i6.NgPluralCase, i6.AsyncPipe, i6.UpperCasePipe, i6.LowerCasePipe, i6.JsonPipe, i6.SlicePipe, i6.DecimalPipe, i6.PercentPipe, i6.TitleCasePipe, i6.CurrencyPipe, i6.DatePipe, i6.I18nPluralPipe, i6.I18nSelectPipe, i6.KeyValuePipe], styles: ['\n[_nghost-%COMP%] {\n  display: block;\n  font-family:\n    "Segoe UI",\n    Roboto,\n    Helvetica,\n    Arial,\n    sans-serif;\n  color: #0f172a;\n}\n.ofertas-container[_ngcontent-%COMP%] {\n  padding: 20px;\n  max-width: 1400px;\n  margin: 0 auto;\n}\n.formulario-card[_ngcontent-%COMP%] {\n  padding: 35px;\n  max-width: 850px;\n  margin: 0 auto;\n  background-color: #ffffff;\n  border-radius: 16px;\n  box-shadow: 0 10px 30px rgba(15, 23, 42, 0.08);\n  border: 1px solid #cbd5e1;\n}\n@media (max-width: 640px) {\n  .formulario-card[_ngcontent-%COMP%] {\n    padding: 20px;\n  }\n}\n.formulario-card[_ngcontent-%COMP%]   .form-header[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-bottom: 25px;\n  border-bottom: 2px solid #92e4cb;\n  padding-bottom: 15px;\n}\n.formulario-card[_ngcontent-%COMP%]   .form-header[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  margin: 0;\n  color: #2d4c7e;\n  font-size: 1.5rem;\n  font-weight: 700;\n}\n.form-group[_ngcontent-%COMP%] {\n  margin-bottom: 20px;\n}\n.form-group[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  display: block;\n  margin-bottom: 8px;\n  font-weight: 600;\n  font-size: 0.9rem;\n  color: #0f172a;\n}\n.form-group[_ngcontent-%COMP%]   input[type=text][_ngcontent-%COMP%], \n.form-group[_ngcontent-%COMP%]   input[type=number][_ngcontent-%COMP%], \n.form-group[_ngcontent-%COMP%]   select[_ngcontent-%COMP%], \n.form-group[_ngcontent-%COMP%]   textarea[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 12px 14px;\n  border: 1px solid #cbd5e1;\n  border-radius: 8px;\n  font-size: 0.95rem;\n  color: #0f172a;\n  background-color: #ffffff;\n  box-sizing: border-box;\n  transition: all 0.2s ease-in-out;\n}\n.form-group[_ngcontent-%COMP%]   input[type=text][_ngcontent-%COMP%]:focus, \n.form-group[_ngcontent-%COMP%]   input[type=number][_ngcontent-%COMP%]:focus, \n.form-group[_ngcontent-%COMP%]   select[_ngcontent-%COMP%]:focus, \n.form-group[_ngcontent-%COMP%]   textarea[_ngcontent-%COMP%]:focus {\n  outline: none;\n  border-color: #2d4c7e;\n  box-shadow: 0 0 0 4px rgba(45, 76, 126, 0.12);\n}\n.form-group[_ngcontent-%COMP%]   input[type=text][_ngcontent-%COMP%]::placeholder, \n.form-group[_ngcontent-%COMP%]   input[type=number][_ngcontent-%COMP%]::placeholder, \n.form-group[_ngcontent-%COMP%]   select[_ngcontent-%COMP%]::placeholder, \n.form-group[_ngcontent-%COMP%]   textarea[_ngcontent-%COMP%]::placeholder {\n  color: #94a3b8;\n}\n.form-group[_ngcontent-%COMP%]   .error-text[_ngcontent-%COMP%] {\n  color: #ef4444;\n  font-size: 0.8rem;\n  margin-top: 6px;\n  display: block;\n}\n.form-row[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 20px;\n}\n.form-row[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%] {\n  flex: 1;\n}\n@media (max-width: 600px) {\n  .form-row[_ngcontent-%COMP%] {\n    flex-direction: column;\n    gap: 0;\n  }\n}\n.categorias-container[_ngcontent-%COMP%] {\n  background-color: #f8fafc;\n  border: 1px solid #cbd5e1;\n  border-radius: 12px;\n  padding: 20px;\n}\n.categorias-container[_ngcontent-%COMP%]   .categoria-group[_ngcontent-%COMP%] {\n  margin-bottom: 18px;\n}\n.categorias-container[_ngcontent-%COMP%]   .categoria-group[_ngcontent-%COMP%]:last-child {\n  margin-bottom: 0;\n}\n.categorias-container[_ngcontent-%COMP%]   .categoria-group[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  margin: 0 0 10px 0;\n  color: #2d4c7e;\n  font-size: 0.85rem;\n  text-transform: uppercase;\n  letter-spacing: 0.05em;\n  font-weight: 700;\n}\n.chips-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 8px;\n}\n.chip-skill[_ngcontent-%COMP%] {\n  background-color: #ffffff;\n  border: 1px solid #cbd5e1;\n  color: #475569;\n  padding: 8px 16px;\n  border-radius: 20px;\n  cursor: pointer;\n  font-size: 0.88rem;\n  font-weight: 500;\n  transition: all 0.2s ease-in-out;\n}\n.chip-skill[_ngcontent-%COMP%]:hover {\n  border-color: #38bdf8;\n  background-color: #f0f9ff;\n  color: #2d4c7e;\n}\n.chip-skill.seleccionada[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #2d4c7e 0%,\n      #1e3a8a 100%);\n  border-color: #2d4c7e;\n  color: #ffffff;\n  box-shadow: 0 4px 8px rgba(45, 76, 126, 0.15);\n}\n.form-actions[_ngcontent-%COMP%] {\n  margin-top: 30px;\n  display: flex;\n  justify-content: flex-end;\n  gap: 15px;\n}\n@media (max-width: 480px) {\n  .form-actions[_ngcontent-%COMP%] {\n    flex-direction: column-reverse;\n  }\n  .form-actions[_ngcontent-%COMP%]   button[_ngcontent-%COMP%] {\n    width: 100%;\n    justify-content: center;\n  }\n}\n.header-ofertas[_ngcontent-%COMP%] {\n  margin-bottom: 25px;\n  border-bottom: 2px solid #92e4cb;\n  padding-bottom: 20px;\n}\n.header-ofertas[_ngcontent-%COMP%]   .titulo-seccion[_ngcontent-%COMP%] {\n  margin-bottom: 15px;\n}\n.header-ofertas[_ngcontent-%COMP%]   .titulo-seccion[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  margin: 0;\n  color: #2d4c7e;\n  font-size: 1.6rem;\n  font-weight: 700;\n}\n.header-ofertas[_ngcontent-%COMP%]   .titulo-seccion[_ngcontent-%COMP%]   .subtitulo[_ngcontent-%COMP%] {\n  margin: 5px 0 0 0;\n  color: #475569;\n  font-size: 0.95rem;\n}\n.header-ofertas[_ngcontent-%COMP%]   .bar-acciones[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 15px;\n  flex-wrap: wrap;\n}\n.header-ofertas[_ngcontent-%COMP%]   .bar-acciones[_ngcontent-%COMP%]   .input-busqueda[_ngcontent-%COMP%] {\n  flex: 1;\n  min-width: 260px;\n  padding: 10px 16px;\n  font-size: 0.95rem;\n  border: 2px solid #cbd5e1;\n  border-radius: 10px;\n}\n.header-ofertas[_ngcontent-%COMP%]   .bar-acciones[_ngcontent-%COMP%]   .input-busqueda[_ngcontent-%COMP%]:focus {\n  outline: none;\n  border-color: #38bdf8;\n  box-shadow: 0 0 0 4px rgba(56, 189, 248, 0.15);\n}\n.header-ofertas[_ngcontent-%COMP%]   .bar-acciones[_ngcontent-%COMP%]   .select-filtro[_ngcontent-%COMP%] {\n  padding: 10px 14px;\n  border: 1px solid #cbd5e1;\n  border-radius: 10px;\n  background-color: #ffffff;\n  font-size: 0.9rem;\n  color: #0f172a;\n}\n.header-ofertas[_ngcontent-%COMP%]   .bar-acciones[_ngcontent-%COMP%]   .select-filtro[_ngcontent-%COMP%]:focus {\n  outline: none;\n  border-color: #2d4c7e;\n}\n.header-ofertas[_ngcontent-%COMP%]   .bar-acciones[_ngcontent-%COMP%]   .btn-group-estados[_ngcontent-%COMP%] {\n  display: inline-flex;\n  background-color: #f1f5f9;\n  padding: 4px;\n  border-radius: 10px;\n  border: 1px solid #cbd5e1;\n  gap: 4px;\n}\n.header-ofertas[_ngcontent-%COMP%]   .bar-acciones[_ngcontent-%COMP%]   .btn-group-estados[_ngcontent-%COMP%]   button[_ngcontent-%COMP%] {\n  background: transparent;\n  border: none;\n  padding: 8px 16px;\n  border-radius: 8px;\n  font-size: 0.85rem;\n  font-weight: 600;\n  color: #475569;\n  cursor: pointer;\n  transition: all 0.2s ease;\n}\n.header-ofertas[_ngcontent-%COMP%]   .bar-acciones[_ngcontent-%COMP%]   .btn-group-estados[_ngcontent-%COMP%]   button[_ngcontent-%COMP%]:hover {\n  color: #0f172a;\n}\n.header-ofertas[_ngcontent-%COMP%]   .bar-acciones[_ngcontent-%COMP%]   .btn-group-estados[_ngcontent-%COMP%]   button.activo[_ngcontent-%COMP%] {\n  background-color: #ffffff;\n  color: #2d4c7e;\n  box-shadow: 0 2px 6px rgba(15, 23, 42, 0.1);\n}\n.header-ofertas[_ngcontent-%COMP%]   .bar-acciones[_ngcontent-%COMP%]   .btn-nueva-oferta[_ngcontent-%COMP%], \n.header-ofertas[_ngcontent-%COMP%]   .bar-acciones[_ngcontent-%COMP%]   .btn-crear-oferta[_ngcontent-%COMP%], \n.header-ofertas[_ngcontent-%COMP%]   .bar-acciones[_ngcontent-%COMP%]   .btn-crear[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #2d4c7e 0%,\n      #1e3a8a 100%);\n  color: #ffffff;\n  padding: 10px 20px;\n  border-radius: 10px;\n  font-size: 0.9rem;\n  font-weight: 700;\n  border: none;\n  cursor: pointer;\n  display: inline-flex;\n  align-items: center;\n  gap: 8px;\n  box-shadow: 0 4px 12px rgba(45, 76, 126, 0.25);\n  transition: all 0.2s ease-in-out;\n}\n.header-ofertas[_ngcontent-%COMP%]   .bar-acciones[_ngcontent-%COMP%]   .btn-nueva-oferta[_ngcontent-%COMP%]:hover, \n.header-ofertas[_ngcontent-%COMP%]   .bar-acciones[_ngcontent-%COMP%]   .btn-crear-oferta[_ngcontent-%COMP%]:hover, \n.header-ofertas[_ngcontent-%COMP%]   .bar-acciones[_ngcontent-%COMP%]   .btn-crear[_ngcontent-%COMP%]:hover {\n  background:\n    linear-gradient(\n      135deg,\n      #1e3a63 0%,\n      #2d4c7e 100%);\n  transform: translateY(-2px);\n  box-shadow: 0 6px 16px rgba(45, 76, 126, 0.35);\n}\n.layout-ofertas[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 20px;\n  height: calc(100vh - 240px);\n  min-height: 520px;\n}\n@media (max-width: 868px) {\n  .layout-ofertas[_ngcontent-%COMP%] {\n    flex-direction: column;\n    height: auto;\n  }\n}\n.columna-lista[_ngcontent-%COMP%] {\n  flex: 0 0 380px;\n  overflow-y: auto;\n  padding-right: 8px;\n}\n.columna-lista[_ngcontent-%COMP%]::-webkit-scrollbar {\n  width: 6px;\n}\n.columna-lista[_ngcontent-%COMP%]::-webkit-scrollbar-thumb {\n  background-color: #cbd5e1;\n  border-radius: 3px;\n}\n.columna-lista[_ngcontent-%COMP%]   .sin-resultados[_ngcontent-%COMP%] {\n  color: #475569;\n  font-style: italic;\n  text-align: center;\n  padding: 30px 10px;\n}\n@media (max-width: 868px) {\n  .columna-lista[_ngcontent-%COMP%] {\n    flex: 1 1 auto;\n    max-height: 360px;\n    padding-right: 0;\n  }\n}\n.card-oferta[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #2d4c7e 0%,\n      #1e3a8a 50%,\n      #38bdf8 100%);\n  border: 1px solid rgba(255, 255, 255, 0.2);\n  border-radius: 12px;\n  padding: 16px;\n  margin-bottom: 14px;\n  cursor: pointer;\n  transition: all 0.2s ease-in-out;\n  box-shadow: 0 4px 12px rgba(45, 76, 126, 0.2);\n}\n.card-oferta[_ngcontent-%COMP%]   .card-header[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: flex-start;\n  gap: 10px;\n  margin-bottom: 8px;\n}\n.card-oferta[_ngcontent-%COMP%]   .card-header[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 1.05rem;\n  color: #ffffff;\n  font-weight: 700;\n  line-height: 1.3;\n}\n.card-oferta[_ngcontent-%COMP%]   .empresa-nombre[_ngcontent-%COMP%] {\n  margin: 0 0 12px 0;\n  color: #e2edf0;\n  font-size: 0.88rem;\n  font-weight: 600;\n}\n.card-oferta[_ngcontent-%COMP%]   .tags-info[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 14px;\n  font-size: 0.82rem;\n  color: #f1f5f9;\n}\n.card-oferta[_ngcontent-%COMP%]   .tags-info[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 5px;\n}\n.card-oferta[_ngcontent-%COMP%]   .tags-info[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  color: #92e4cb;\n}\n.card-oferta[_ngcontent-%COMP%]:hover {\n  transform: translateY(-2px);\n  box-shadow: 0 6px 16px rgba(56, 189, 248, 0.35);\n}\n.card-oferta.seleccionada[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border: 2px solid #2d4c7e;\n  border-left: 6px solid #2d4c7e;\n  box-shadow: 0 8px 20px rgba(15, 23, 42, 0.15);\n  transform: translateX(4px);\n}\n@media (max-width: 868px) {\n  .card-oferta.seleccionada[_ngcontent-%COMP%] {\n    transform: none;\n  }\n}\n.card-oferta.seleccionada[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  color: #2d4c7e;\n}\n.card-oferta.seleccionada[_ngcontent-%COMP%]   .empresa-nombre[_ngcontent-%COMP%] {\n  color: #0f172a;\n}\n.card-oferta.seleccionada[_ngcontent-%COMP%]   .tags-info[_ngcontent-%COMP%] {\n  color: #475569;\n}\n.card-oferta.seleccionada[_ngcontent-%COMP%]   .tags-info[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  color: #2d4c7e;\n}\n.badge-estado[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  padding: 3px 10px;\n  border-radius: 12px;\n  font-size: 0.72rem;\n  font-weight: 700;\n  text-transform: uppercase;\n  background-color: #fee2e2;\n  color: #991b1b;\n  border: 1px solid #fca5a5;\n  white-space: nowrap;\n}\n.badge-estado.abierta[_ngcontent-%COMP%] {\n  background-color: #dcfce7;\n  color: #166534;\n  border-color: #bbf7d0;\n}\n.columna-detalle[_ngcontent-%COMP%] {\n  flex: 1;\n  background-color: #ffffff;\n  border: 1px solid #cbd5e1;\n  border-radius: 12px;\n  padding: 30px;\n  overflow-y: auto;\n  box-shadow: 0 10px 25px rgba(15, 23, 42, 0.04);\n}\n.columna-detalle[_ngcontent-%COMP%]::-webkit-scrollbar {\n  width: 6px;\n}\n.columna-detalle[_ngcontent-%COMP%]::-webkit-scrollbar-thumb {\n  background-color: #cbd5e1;\n  border-radius: 3px;\n}\n.columna-detalle[_ngcontent-%COMP%]   .sin-seleccion[_ngcontent-%COMP%] {\n  color: #94a3b8;\n  font-style: italic;\n  text-align: center;\n  margin-top: 100px;\n  font-size: 1.05rem;\n}\n.card-detalle-completo[_ngcontent-%COMP%]   .detalle-header-top[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: flex-start;\n  gap: 15px;\n}\n.card-detalle-completo[_ngcontent-%COMP%]   .detalle-header-top[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 1.6rem;\n  color: #2d4c7e;\n  font-weight: 700;\n}\n.card-detalle-completo[_ngcontent-%COMP%]   .detalle-header-top[_ngcontent-%COMP%]   .empresa-detalle[_ngcontent-%COMP%] {\n  margin: 6px 0 0 0;\n  color: #475569;\n  font-weight: 600;\n}\n.card-detalle-completo[_ngcontent-%COMP%]   .detalle-header-top[_ngcontent-%COMP%]   .badge-modalidad[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #e0f2fe 0%,\n      #bae6fd 100%);\n  color: #2d4c7e;\n  border: 1px solid #38bdf8;\n  padding: 8px 16px;\n  border-radius: 20px;\n  font-size: 0.88rem;\n  font-weight: 700;\n  letter-spacing: 0.02em;\n  box-shadow: 0 2px 6px rgba(56, 189, 248, 0.2);\n}\n.card-detalle-completo[_ngcontent-%COMP%]   hr[_ngcontent-%COMP%] {\n  border: 0;\n  border-top: 2px solid #0461bd;\n  margin: 20px 0;\n}\n.detalle-body[_ngcontent-%COMP%]   .meta-item[_ngcontent-%COMP%] {\n  margin-bottom: 8px;\n  font-size: 0.95rem;\n  color: #475569;\n}\n.detalle-body[_ngcontent-%COMP%]   .meta-item[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  color: #0f172a;\n}\n.detalle-body[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  margin: 22px 0 12px 0;\n  color: #0f172a;\n  font-size: 1.1rem;\n  font-weight: 700;\n  border-left: 4px solid #92e4cb;\n  padding-left: 10px;\n}\n.detalle-body[_ngcontent-%COMP%]   .descripcion-texto[_ngcontent-%COMP%] {\n  line-height: 1.7;\n  color: #475569;\n  font-size: 0.98rem;\n  white-space: pre-line;\n}\n.detalle-body[_ngcontent-%COMP%]   .habilidades-container-view[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 8px;\n  margin-top: 10px;\n}\n.detalle-body[_ngcontent-%COMP%]   .chip-skill-view[_ngcontent-%COMP%] {\n  background-color: #6be7ca;\n  border: 1px solid #92e4cb;\n  color: #0f172a;\n  font-weight: 700;\n  font-size: 0.85rem;\n  padding: 8px 16px;\n  border-radius: 20px;\n  box-shadow: 0 2px 4px rgba(146, 228, 203, 0.15);\n  transition: all 0.2s ease;\n}\n.detalle-body[_ngcontent-%COMP%]   .chip-skill-view[_ngcontent-%COMP%]:hover {\n  background-color: #92e4cb;\n  color: #0f172a;\n}\n.detalle-footer[_ngcontent-%COMP%] {\n  margin-top: 35px;\n  border-top: 2px solid #f1f5f9;\n  padding-top: 25px;\n  display: flex;\n  justify-content: flex-end;\n  gap: 12px;\n  flex-wrap: wrap;\n}\n.detalle-footer[_ngcontent-%COMP%]   button[_ngcontent-%COMP%] {\n  padding: 10px 20px;\n  border-radius: 8px;\n  font-size: 0.9rem;\n  font-weight: 600;\n  cursor: pointer;\n  display: inline-flex;\n  align-items: center;\n  gap: 8px;\n  border: none;\n  transition: all 0.2s ease;\n}\n.detalle-footer[_ngcontent-%COMP%]   .btn-postularse[_ngcontent-%COMP%], \n.detalle-footer[_ngcontent-%COMP%]   .btn-primario[_ngcontent-%COMP%], \n.detalle-footer[_ngcontent-%COMP%]   .btn-crear[_ngcontent-%COMP%] {\n  background-color: #2d4c7e;\n  color: #b0e2b0;\n}\n.detalle-footer[_ngcontent-%COMP%]   .btn-postularse[_ngcontent-%COMP%]:hover, \n.detalle-footer[_ngcontent-%COMP%]   .btn-primario[_ngcontent-%COMP%]:hover, \n.detalle-footer[_ngcontent-%COMP%]   .btn-crear[_ngcontent-%COMP%]:hover {\n  background-color: #1e3a63;\n  transform: translateY(-1px);\n}\n.detalle-footer[_ngcontent-%COMP%]   .btn-secundario[_ngcontent-%COMP%], \n.detalle-footer[_ngcontent-%COMP%]   .btn-cancelar[_ngcontent-%COMP%] {\n  background-color: #f1f5f9;\n  color: #475569;\n  border: 1px solid #cbd5e1;\n}\n.detalle-footer[_ngcontent-%COMP%]   .btn-secundario[_ngcontent-%COMP%]:hover, \n.detalle-footer[_ngcontent-%COMP%]   .btn-cancelar[_ngcontent-%COMP%]:hover {\n  background-color: #e2e8f0;\n  color: #0f172a;\n}\n.detalle-footer[_ngcontent-%COMP%]   .btn-candidatos[_ngcontent-%COMP%] {\n  background-color: #2563eb;\n  color: #ffffff;\n  border: 1px solid #1d4ed8;\n}\n.detalle-footer[_ngcontent-%COMP%]   .btn-candidatos[_ngcontent-%COMP%]:hover {\n  background-color: #1d4ed8;\n  transform: translateY(-1px);\n}\n.detalle-footer[_ngcontent-%COMP%]   .btn-editar[_ngcontent-%COMP%] {\n  background-color: #f1f5f9;\n  color: #0f172a;\n  border: 1px solid #cbd5e1;\n}\n.detalle-footer[_ngcontent-%COMP%]   .btn-editar[_ngcontent-%COMP%]:hover {\n  background-color: #e2e8f0;\n}\n.detalle-footer[_ngcontent-%COMP%]   .btn-duracion[_ngcontent-%COMP%] {\n  background-color: #fef3c7;\n  color: #92400e;\n  border: 1px solid #fde68a;\n}\n.detalle-footer[_ngcontent-%COMP%]   .btn-duracion[_ngcontent-%COMP%]:hover {\n  background-color: #fde68a;\n}\n.detalle-footer[_ngcontent-%COMP%]   .btn-cerrar-oferta[_ngcontent-%COMP%] {\n  background-color: #fee2e2;\n  color: #991b1b;\n  border: 1px solid #fca5a5;\n}\n.detalle-footer[_ngcontent-%COMP%]   .btn-cerrar-oferta[_ngcontent-%COMP%]:hover {\n  background-color: #fca5a5;\n}\n.detalle-footer[_ngcontent-%COMP%]   .btn-reabrir-oferta[_ngcontent-%COMP%] {\n  background-color: #dcfce7;\n  color: #166534;\n  border: 1px solid #bbf7d0;\n}\n.detalle-footer[_ngcontent-%COMP%]   .btn-reabrir-oferta[_ngcontent-%COMP%]:hover {\n  background-color: #bbf7d0;\n}\n.detalle-footer[_ngcontent-%COMP%]   .btn-postulado[_ngcontent-%COMP%] {\n  background-color: #e2e8f0;\n  color: #475569;\n  cursor: default;\n}\n.detalle-footer[_ngcontent-%COMP%]   .btn-deshabilitado[_ngcontent-%COMP%] {\n  background-color: #f1f5f9;\n  color: #94a3b8;\n  cursor: not-allowed;\n}\n.detalle-footer[_ngcontent-%COMP%]   .btn-eliminar-admin[_ngcontent-%COMP%] {\n  background-color: #ef4444;\n  color: #ffffff;\n}\n.detalle-footer[_ngcontent-%COMP%]   .btn-eliminar-admin[_ngcontent-%COMP%]:hover {\n  background-color: #dc2626;\n}\n/*# sourceMappingURL=ofertas.css.map */'] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i08.\u0275setClassMetadata(Ofertas, [{
    type: Component6,
    args: [{ selector: "app-ofertas", standalone: true, imports: [ReactiveFormsModule4, FormsModule, CommonModule3], template: `<div class="ofertas-container">\r
\r
  <!-- ========================================== -->\r
  <!-- VISTA 1: FORMULARIO CREAR / EDITAR OFERTA  -->\r
  <!-- ========================================== -->\r
  @if (mostrarFormulario) {\r
    <div class="formulario-card">\r
      <div class="form-header">\r
        <h2>{{ modoEdicion ? 'Editar Oferta Laboral' : 'Publicar Nueva Oferta Laboral' }}</h2>\r
        <button type="button" class="btn-cancelar" (click)="toggleVista(false)">\r
          <i class="fa-solid fa-xmark"></i> Cancelar\r
        </button>\r
      </div>\r
\r
      <form [formGroup]="ofertaForm" (ngSubmit)="guardarOferta()">\r
        <div class="form-group">\r
          <label for="titulo">T\xEDtulo de la Oferta *</label>\r
          <input id="titulo" name="titulo" type="text" formControlName="titulo" placeholder="Ej: Desarrollador Frontend Angular" />\r
          @if (esCampoInvalido('titulo')) {\r
            <small class="error-text">El t\xEDtulo debe tener al menos 5 caracteres.</small>\r
          }\r
        </div>\r
\r
        <div class="form-row">\r
          <div class="form-group">\r
            <label for="modalidad">Modalidad *</label>\r
            <select id="modalidad" name="modalidad" formControlName="modalidad">\r
              <option value="Presencial">Presencial</option>\r
              <option value="H\xEDbrido">H\xEDbrido</option>\r
              <option value="Remoto">Remoto</option>\r
            </select>\r
          </div>\r
\r
          <div class="form-group">\r
            <label for="experiencia">Experiencia *</label>\r
            <select id="experiencia" name="experiencia" formControlName="experiencia">\r
              <option value="Trainee">Trainee</option>\r
              <option value="Junior">Junior</option>\r
              <option value="Semi-Senior">Semi-Senior</option>\r
              <option value="Senior">Senior</option>\r
            </select>\r
          </div>\r
\r
          <div class="form-group">\r
            <label for="tipoDuracion">Duraci\xF3n de la Convocatoria *</label>\r
            <select id="tipoDuracion" name="tipoDuracion" formControlName="tipoDuracion" (change)="onTipoDuracionChange()">\r
              <option value="10">10 D\xEDas (Est\xE1ndar)</option>\r
              <option value="30">30 D\xEDas</option>\r
              <option value="personalizado">Personalizado</option>\r
            </select>\r
          </div>\r
        </div>\r
\r
        @if (ofertaForm.get('tipoDuracion')?.value === 'personalizado') {\r
          <div class="form-group">\r
            <label for="diasPersonalizados">D\xEDas personalizados (1 a 90):</label>\r
            <input id="diasPersonalizados" name="diasPersonalizados" type="number" formControlName="diasPersonalizados" min="1" max="90" />\r
          </div>\r
        }\r
\r
        <div class="form-group">\r
          <label for="descripcion">Descripci\xF3n de la B\xFAsqueda *</label>\r
          <textarea id="descripcion" name="descripcion" formControlName="descripcion" rows="5" placeholder="Detalla los requisitos, tareas y beneficios..."></textarea>\r
          @if (esCampoInvalido('descripcion')) {\r
            <small class="error-text">La descripci\xF3n debe tener al menos 20 caracteres.</small>\r
          }\r
        </div>\r
\r
        <!-- Habilidades Requeridas -->\r
        <div class="form-group">\r
          <label>Habilidades / Requisitos (Seleccionar)</label>\r
          <div class="categorias-container">\r
            @for (cat of categoriasConSkills; track cat.categoria_id) {\r
              <div class="categoria-group">\r
                <h4>{{ cat.nombre }}</h4>\r
                <div class="chips-container">\r
                  @for (skill of cat.skills; track skill.skill_id) {\r
                    <button type="button" \r
                            class="chip-skill" \r
                            [class.seleccionada]="skillsSeleccionadasIds.includes(skill.skill_id)"\r
                            (click)="alternarHabilidad(skill.skill_id)">\r
                      {{ skill.nombre }}\r
                    </button>\r
                  }\r
                </div>\r
              </div>\r
            }\r
          </div>\r
        </div>\r
\r
        <div class="form-actions">\r
          <button type="button" class="btn-secundario" (click)="toggleVista(false)">Cancelar</button>\r
          <button type="submit" class="btn-primario" [disabled]="ofertaForm.invalid || skillsSeleccionadasIds.length === 0">\r
            {{ modoEdicion ? 'Guardar Cambios' : 'Publicar Oferta' }}\r
          </button>\r
        </div>\r
      </form>\r
    </div>\r
  }\r
\r
  <!-- ========================================== -->\r
  <!-- VISTA 2: LISTADO Y DETALLE PRINCIPAL        -->\r
  <!-- ========================================== -->\r
  @else {\r
    <!-- Header de Filtros y B\xFAsqueda -->\r
    <header class="header-ofertas">\r
      <div class="titulo-seccion">\r
        <h2>Bolsa de Trabajos ITB Conecta</h2>\r
        <p class="subtitulo">Explora oportunidades laborales o gestiona tus b\xFAsquedas publicadas.</p>\r
      </div>\r
\r
      <div class="bar-acciones">\r
        <input id="searchQuery" name="searchQuery" type="text" [(ngModel)]="searchQuery" (input)="filtrarOfertasLocal()" placeholder="\u{1F50D} Buscar por t\xEDtulo, empresa o tecnolog\xEDa..." class="input-busqueda" />\r
\r
        <select id="filtroModalidad" name="filtroModalidad" [(ngModel)]="filtroModalidad" (change)="filtrarOfertasLocal()" class="select-filtro">\r
          <option value="todos">Todas las modalidades</option>\r
          <option value="Presencial">Presencial</option>\r
          <option value="H\xEDbrido">H\xEDbrido</option>\r
          <option value="Remoto">Remoto</option>\r
        </select>\r
\r
        <div class="btn-group-estados">\r
          <button type="button" [class.activo]="filtroEstado === 'abiertas'" (click)="cambiarFiltroEstado('abiertas')">Abiertas</button>\r
          <button type="button" [class.activo]="filtroEstado === 'cerradas'" (click)="cambiarFiltroEstado('cerradas')">Cerradas</button>\r
          <button type="button" [class.activo]="filtroEstado === 'todas'" (click)="cambiarFiltroEstado('todas')">Todas</button>\r
        </div>\r
\r
        @if (rolUsuario === 'empresa' || rolUsuario === 'admin') {\r
          <button type="button" class="btn-crear" (click)="toggleVista(true)">\r
            <i class="fa-solid fa-plus"></i> Nueva Oferta\r
          </button>\r
        }\r
      </div>\r
    </header>\r
\r
    <!-- Panel Dos Columnas (Lista / Detalle) -->\r
    <div class="layout-ofertas">\r
\r
      <!-- COLUMNA IZQUIERDA: LISTA -->\r
      <aside class="columna-lista">\r
        @for (oferta of ofertasFiltradas; track oferta.id_oferta) {\r
          <div class="card-oferta" \r
               [class.seleccionada]="ofertaSeleccionada?.id_oferta === oferta.id_oferta"\r
               (click)="seleccionarOferta(oferta)">\r
            \r
            <div class="card-header">\r
              <h3>{{ oferta.titulo }}</h3>\r
              <span class="badge-estado" [class.abierta]="esOfertaAbierta(oferta)">\r
                {{ esOfertaAbierta(oferta) ? 'Abierta' : 'Cerrada' }}\r
              </span>\r
            </div>\r
\r
            <p class="empresa-nombre"><i class="fa-regular fa-building"></i> {{ oferta.razonSocial || oferta.nombre_empresa || 'Empresa' }}</p>\r
\r
            <div class="tags-info">\r
              <span><i class="fa-solid fa-laptop"></i> {{ oferta.modalidad }}</span>\r
              <span><i class="fa-solid fa-briefcase"></i> {{ oferta.experiencia }}</span>\r
              <span><i class="fa-regular fa-calendar-days"></i> {{ oferta.fecha_publicacion | date:'dd/MM/yyyy' }}</span>\r
            </div>\r
          </div>\r
        } @empty {\r
          <div class="sin-resultados">\r
            <p>No se encontraron ofertas laborales con los filtros seleccionados.</p>\r
          </div>\r
        }\r
      </aside>\r
\r
      <!-- COLUMNA DERECHA: DETALLE SELECCIONADO -->\r
      <main class="columna-detalle">\r
        @if (ofertaSeleccionada) {\r
          <div class="card-detalle-completo">\r
            \r
            <div class="detalle-header-top">\r
              <div>\r
                <h2>{{ ofertaSeleccionada.titulo }}</h2>\r
                <p class="empresa-detalle"><i class="fa-regular fa-building"></i> {{ ofertaSeleccionada.razonSocial || ofertaSeleccionada.nombre_empresa || 'Empresa ITB' }}</p>\r
              </div>\r
              \r
              <span class="badge-modalidad">{{ ofertaSeleccionada.modalidad }}</span>\r
            </div>\r
\r
            <hr />\r
\r
            <div class="detalle-body">\r
              <div class="meta-item">\r
                <strong>Nivel de experiencia:</strong> {{ ofertaSeleccionada.experiencia }}\r
              </div>\r
\r
              <div class="meta-item">\r
              <strong>Publicado el:</strong> {{ ofertaSeleccionada.fecha_publicacion | date:'dd/MM/yyyy' }}\r
              </div>\r
\r
              <!-- \u231B Fecha de Vencimiento calculada -->\r
              @if (obtenerFechaVencimiento(ofertaSeleccionada)) {\r
              <div class="meta-item">\r
              <strong>Vence el:</strong> {{ obtenerFechaVencimiento(ofertaSeleccionada) | date:'dd/MM/yyyy' }} ({{ ofertaSeleccionada.dias_duracion }} d\xEDas)\r
              </div>\r
              }\r
              \r
              <h4>Descripci\xF3n del Puesto</h4>\r
              <p class="descripcion-texto">{{ ofertaSeleccionada.descripcion }}</p>\r
\r
              @if (ofertaSeleccionada.skills_nombres && ofertaSeleccionada.skills_nombres.length > 0) {\r
                <h4>Habilidades Requeridas</h4>\r
                <div class="chips-container">\r
                  @for (skill of ofertaSeleccionada.skills_nombres; track skill) {\r
                    <span class="chip-skill-view">{{ skill }}</span>\r
                  }\r
                </div>\r
              }\r
            </div>\r
\r
            <!-- BLOQUE DE ACCIONES SEG\xDAN EL ROL -->\r
            <div class="detalle-footer">\r
              \r
              <!-- Rol POSTULANTE O VISITANTE -->\r
              @if (rolUsuario === 'postulante' || rolUsuario === 'visitante' || !rolUsuario) {\r
                @if (!esOfertaAbierta(ofertaSeleccionada)) {\r
                  <button type="button" class="btn-deshabilitado" disabled>\r
                    <i class="fa-solid fa-lock"></i> Convocatoria Cerrada\r
                  </button>\r
                } @else if (estaPostulado(ofertaSeleccionada.id_oferta)) {\r
                  <button type="button" class="btn-postulado" disabled>\r
                    <i class="fa-solid fa-check-double"></i> Ya te has postulado\r
                  </button>\r
                } @else {\r
                  <button type="button" class="btn-postularse" (click)="guardarPostulacion(ofertaSeleccionada.id_oferta)">\r
                    <i class="fa-solid fa-paper-plane"></i> Postularme ahora\r
                  </button>\r
                }\r
              }\r
\r
              <!-- Rol EMPRESA (Propietaria de la oferta) -->\r
              @if (rolUsuario === 'empresa' && idUsuario === (ofertaSeleccionada.id_empresa || ofertaSeleccionada.empresa_id)?.toString()) {\r
                <button type="button" class="btn-candidatos" (click)="verPostulados(ofertaSeleccionada.id_oferta)">\r
                  <i class="fa-solid fa-users"></i> Ver Candidatos\r
                </button>\r
\r
                <button type="button" class="btn-editar" (click)="toggleVista(true, ofertaSeleccionada)">\r
                  <i class="fa-solid fa-pen-to-square"></i> Editar Publicaci\xF3n\r
                </button>\r
\r
                <button type="button" class="btn-duracion" (click)="ampliarDuracion(ofertaSeleccionada.id_oferta)">\r
                  <i class="fa-solid fa-hourglass-half"></i> Ampliar D\xEDas\r
                </button>\r
\r
                @if (esOfertaAbierta(ofertaSeleccionada)) {\r
                  <button type="button" class="btn-cerrar-oferta" (click)="cambiarEstadoOferta(ofertaSeleccionada.id_oferta, 'Cerrada')">\r
                    <i class="fa-solid fa-folder-closed"></i> Cerrar Convocatoria\r
                  </button>\r
                } @else {\r
                  <button type="button" class="btn-reabrir-oferta" (click)="cambiarEstadoOferta(ofertaSeleccionada.id_oferta, 'Abierta')">\r
                    <i class="fa-solid fa-folder-open"></i> Reabrir Convocatoria\r
                  </button>\r
                }\r
              }\r
\r
              <!-- Rol ADMIN -->\r
              @if (rolUsuario === 'admin') {\r
                <button type="button" class="btn-candidatos" (click)="verPostulados(ofertaSeleccionada.id_oferta)">\r
                  <i class="fa-solid fa-users"></i> Ver Candidatos\r
                </button>\r
\r
                <button type="button" class="btn-eliminar-admin" (click)="bajaOfertaAdmin(ofertaSeleccionada.id_oferta)">\r
                  <i class="fa-solid fa-trash-can"></i> Eliminar (Moderaci\xF3n Admin)\r
                </button>\r
              }\r
            </div>\r
\r
          </div>\r
        } @else {\r
          <div class="sin-seleccion">\r
            <p>Selecciona una oferta de la lista para ver sus detalles.</p>\r
          </div>\r
        }\r
      </main>\r
\r
    </div>\r
  }\r
\r
</div>`, styles: ['/* src/app/pagina/ofertas/ofertas.scss */\n:host {\n  display: block;\n  font-family:\n    "Segoe UI",\n    Roboto,\n    Helvetica,\n    Arial,\n    sans-serif;\n  color: #0f172a;\n}\n.ofertas-container {\n  padding: 20px;\n  max-width: 1400px;\n  margin: 0 auto;\n}\n.formulario-card {\n  padding: 35px;\n  max-width: 850px;\n  margin: 0 auto;\n  background-color: #ffffff;\n  border-radius: 16px;\n  box-shadow: 0 10px 30px rgba(15, 23, 42, 0.08);\n  border: 1px solid #cbd5e1;\n}\n@media (max-width: 640px) {\n  .formulario-card {\n    padding: 20px;\n  }\n}\n.formulario-card .form-header {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-bottom: 25px;\n  border-bottom: 2px solid #92e4cb;\n  padding-bottom: 15px;\n}\n.formulario-card .form-header h2 {\n  margin: 0;\n  color: #2d4c7e;\n  font-size: 1.5rem;\n  font-weight: 700;\n}\n.form-group {\n  margin-bottom: 20px;\n}\n.form-group label {\n  display: block;\n  margin-bottom: 8px;\n  font-weight: 600;\n  font-size: 0.9rem;\n  color: #0f172a;\n}\n.form-group input[type=text],\n.form-group input[type=number],\n.form-group select,\n.form-group textarea {\n  width: 100%;\n  padding: 12px 14px;\n  border: 1px solid #cbd5e1;\n  border-radius: 8px;\n  font-size: 0.95rem;\n  color: #0f172a;\n  background-color: #ffffff;\n  box-sizing: border-box;\n  transition: all 0.2s ease-in-out;\n}\n.form-group input[type=text]:focus,\n.form-group input[type=number]:focus,\n.form-group select:focus,\n.form-group textarea:focus {\n  outline: none;\n  border-color: #2d4c7e;\n  box-shadow: 0 0 0 4px rgba(45, 76, 126, 0.12);\n}\n.form-group input[type=text]::placeholder,\n.form-group input[type=number]::placeholder,\n.form-group select::placeholder,\n.form-group textarea::placeholder {\n  color: #94a3b8;\n}\n.form-group .error-text {\n  color: #ef4444;\n  font-size: 0.8rem;\n  margin-top: 6px;\n  display: block;\n}\n.form-row {\n  display: flex;\n  gap: 20px;\n}\n.form-row .form-group {\n  flex: 1;\n}\n@media (max-width: 600px) {\n  .form-row {\n    flex-direction: column;\n    gap: 0;\n  }\n}\n.categorias-container {\n  background-color: #f8fafc;\n  border: 1px solid #cbd5e1;\n  border-radius: 12px;\n  padding: 20px;\n}\n.categorias-container .categoria-group {\n  margin-bottom: 18px;\n}\n.categorias-container .categoria-group:last-child {\n  margin-bottom: 0;\n}\n.categorias-container .categoria-group h4 {\n  margin: 0 0 10px 0;\n  color: #2d4c7e;\n  font-size: 0.85rem;\n  text-transform: uppercase;\n  letter-spacing: 0.05em;\n  font-weight: 700;\n}\n.chips-container {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 8px;\n}\n.chip-skill {\n  background-color: #ffffff;\n  border: 1px solid #cbd5e1;\n  color: #475569;\n  padding: 8px 16px;\n  border-radius: 20px;\n  cursor: pointer;\n  font-size: 0.88rem;\n  font-weight: 500;\n  transition: all 0.2s ease-in-out;\n}\n.chip-skill:hover {\n  border-color: #38bdf8;\n  background-color: #f0f9ff;\n  color: #2d4c7e;\n}\n.chip-skill.seleccionada {\n  background:\n    linear-gradient(\n      135deg,\n      #2d4c7e 0%,\n      #1e3a8a 100%);\n  border-color: #2d4c7e;\n  color: #ffffff;\n  box-shadow: 0 4px 8px rgba(45, 76, 126, 0.15);\n}\n.form-actions {\n  margin-top: 30px;\n  display: flex;\n  justify-content: flex-end;\n  gap: 15px;\n}\n@media (max-width: 480px) {\n  .form-actions {\n    flex-direction: column-reverse;\n  }\n  .form-actions button {\n    width: 100%;\n    justify-content: center;\n  }\n}\n.header-ofertas {\n  margin-bottom: 25px;\n  border-bottom: 2px solid #92e4cb;\n  padding-bottom: 20px;\n}\n.header-ofertas .titulo-seccion {\n  margin-bottom: 15px;\n}\n.header-ofertas .titulo-seccion h2 {\n  margin: 0;\n  color: #2d4c7e;\n  font-size: 1.6rem;\n  font-weight: 700;\n}\n.header-ofertas .titulo-seccion .subtitulo {\n  margin: 5px 0 0 0;\n  color: #475569;\n  font-size: 0.95rem;\n}\n.header-ofertas .bar-acciones {\n  display: flex;\n  align-items: center;\n  gap: 15px;\n  flex-wrap: wrap;\n}\n.header-ofertas .bar-acciones .input-busqueda {\n  flex: 1;\n  min-width: 260px;\n  padding: 10px 16px;\n  font-size: 0.95rem;\n  border: 2px solid #cbd5e1;\n  border-radius: 10px;\n}\n.header-ofertas .bar-acciones .input-busqueda:focus {\n  outline: none;\n  border-color: #38bdf8;\n  box-shadow: 0 0 0 4px rgba(56, 189, 248, 0.15);\n}\n.header-ofertas .bar-acciones .select-filtro {\n  padding: 10px 14px;\n  border: 1px solid #cbd5e1;\n  border-radius: 10px;\n  background-color: #ffffff;\n  font-size: 0.9rem;\n  color: #0f172a;\n}\n.header-ofertas .bar-acciones .select-filtro:focus {\n  outline: none;\n  border-color: #2d4c7e;\n}\n.header-ofertas .bar-acciones .btn-group-estados {\n  display: inline-flex;\n  background-color: #f1f5f9;\n  padding: 4px;\n  border-radius: 10px;\n  border: 1px solid #cbd5e1;\n  gap: 4px;\n}\n.header-ofertas .bar-acciones .btn-group-estados button {\n  background: transparent;\n  border: none;\n  padding: 8px 16px;\n  border-radius: 8px;\n  font-size: 0.85rem;\n  font-weight: 600;\n  color: #475569;\n  cursor: pointer;\n  transition: all 0.2s ease;\n}\n.header-ofertas .bar-acciones .btn-group-estados button:hover {\n  color: #0f172a;\n}\n.header-ofertas .bar-acciones .btn-group-estados button.activo {\n  background-color: #ffffff;\n  color: #2d4c7e;\n  box-shadow: 0 2px 6px rgba(15, 23, 42, 0.1);\n}\n.header-ofertas .bar-acciones .btn-nueva-oferta,\n.header-ofertas .bar-acciones .btn-crear-oferta,\n.header-ofertas .bar-acciones .btn-crear {\n  background:\n    linear-gradient(\n      135deg,\n      #2d4c7e 0%,\n      #1e3a8a 100%);\n  color: #ffffff;\n  padding: 10px 20px;\n  border-radius: 10px;\n  font-size: 0.9rem;\n  font-weight: 700;\n  border: none;\n  cursor: pointer;\n  display: inline-flex;\n  align-items: center;\n  gap: 8px;\n  box-shadow: 0 4px 12px rgba(45, 76, 126, 0.25);\n  transition: all 0.2s ease-in-out;\n}\n.header-ofertas .bar-acciones .btn-nueva-oferta:hover,\n.header-ofertas .bar-acciones .btn-crear-oferta:hover,\n.header-ofertas .bar-acciones .btn-crear:hover {\n  background:\n    linear-gradient(\n      135deg,\n      #1e3a63 0%,\n      #2d4c7e 100%);\n  transform: translateY(-2px);\n  box-shadow: 0 6px 16px rgba(45, 76, 126, 0.35);\n}\n.layout-ofertas {\n  display: flex;\n  gap: 20px;\n  height: calc(100vh - 240px);\n  min-height: 520px;\n}\n@media (max-width: 868px) {\n  .layout-ofertas {\n    flex-direction: column;\n    height: auto;\n  }\n}\n.columna-lista {\n  flex: 0 0 380px;\n  overflow-y: auto;\n  padding-right: 8px;\n}\n.columna-lista::-webkit-scrollbar {\n  width: 6px;\n}\n.columna-lista::-webkit-scrollbar-thumb {\n  background-color: #cbd5e1;\n  border-radius: 3px;\n}\n.columna-lista .sin-resultados {\n  color: #475569;\n  font-style: italic;\n  text-align: center;\n  padding: 30px 10px;\n}\n@media (max-width: 868px) {\n  .columna-lista {\n    flex: 1 1 auto;\n    max-height: 360px;\n    padding-right: 0;\n  }\n}\n.card-oferta {\n  background:\n    linear-gradient(\n      135deg,\n      #2d4c7e 0%,\n      #1e3a8a 50%,\n      #38bdf8 100%);\n  border: 1px solid rgba(255, 255, 255, 0.2);\n  border-radius: 12px;\n  padding: 16px;\n  margin-bottom: 14px;\n  cursor: pointer;\n  transition: all 0.2s ease-in-out;\n  box-shadow: 0 4px 12px rgba(45, 76, 126, 0.2);\n}\n.card-oferta .card-header {\n  display: flex;\n  justify-content: space-between;\n  align-items: flex-start;\n  gap: 10px;\n  margin-bottom: 8px;\n}\n.card-oferta .card-header h3 {\n  margin: 0;\n  font-size: 1.05rem;\n  color: #ffffff;\n  font-weight: 700;\n  line-height: 1.3;\n}\n.card-oferta .empresa-nombre {\n  margin: 0 0 12px 0;\n  color: #e2edf0;\n  font-size: 0.88rem;\n  font-weight: 600;\n}\n.card-oferta .tags-info {\n  display: flex;\n  gap: 14px;\n  font-size: 0.82rem;\n  color: #f1f5f9;\n}\n.card-oferta .tags-info span {\n  display: flex;\n  align-items: center;\n  gap: 5px;\n}\n.card-oferta .tags-info span i {\n  color: #92e4cb;\n}\n.card-oferta:hover {\n  transform: translateY(-2px);\n  box-shadow: 0 6px 16px rgba(56, 189, 248, 0.35);\n}\n.card-oferta.seleccionada {\n  background: #ffffff;\n  border: 2px solid #2d4c7e;\n  border-left: 6px solid #2d4c7e;\n  box-shadow: 0 8px 20px rgba(15, 23, 42, 0.15);\n  transform: translateX(4px);\n}\n@media (max-width: 868px) {\n  .card-oferta.seleccionada {\n    transform: none;\n  }\n}\n.card-oferta.seleccionada h3 {\n  color: #2d4c7e;\n}\n.card-oferta.seleccionada .empresa-nombre {\n  color: #0f172a;\n}\n.card-oferta.seleccionada .tags-info {\n  color: #475569;\n}\n.card-oferta.seleccionada .tags-info span i {\n  color: #2d4c7e;\n}\n.badge-estado {\n  display: inline-flex;\n  align-items: center;\n  padding: 3px 10px;\n  border-radius: 12px;\n  font-size: 0.72rem;\n  font-weight: 700;\n  text-transform: uppercase;\n  background-color: #fee2e2;\n  color: #991b1b;\n  border: 1px solid #fca5a5;\n  white-space: nowrap;\n}\n.badge-estado.abierta {\n  background-color: #dcfce7;\n  color: #166534;\n  border-color: #bbf7d0;\n}\n.columna-detalle {\n  flex: 1;\n  background-color: #ffffff;\n  border: 1px solid #cbd5e1;\n  border-radius: 12px;\n  padding: 30px;\n  overflow-y: auto;\n  box-shadow: 0 10px 25px rgba(15, 23, 42, 0.04);\n}\n.columna-detalle::-webkit-scrollbar {\n  width: 6px;\n}\n.columna-detalle::-webkit-scrollbar-thumb {\n  background-color: #cbd5e1;\n  border-radius: 3px;\n}\n.columna-detalle .sin-seleccion {\n  color: #94a3b8;\n  font-style: italic;\n  text-align: center;\n  margin-top: 100px;\n  font-size: 1.05rem;\n}\n.card-detalle-completo .detalle-header-top {\n  display: flex;\n  justify-content: space-between;\n  align-items: flex-start;\n  gap: 15px;\n}\n.card-detalle-completo .detalle-header-top h2 {\n  margin: 0;\n  font-size: 1.6rem;\n  color: #2d4c7e;\n  font-weight: 700;\n}\n.card-detalle-completo .detalle-header-top .empresa-detalle {\n  margin: 6px 0 0 0;\n  color: #475569;\n  font-weight: 600;\n}\n.card-detalle-completo .detalle-header-top .badge-modalidad {\n  background:\n    linear-gradient(\n      135deg,\n      #e0f2fe 0%,\n      #bae6fd 100%);\n  color: #2d4c7e;\n  border: 1px solid #38bdf8;\n  padding: 8px 16px;\n  border-radius: 20px;\n  font-size: 0.88rem;\n  font-weight: 700;\n  letter-spacing: 0.02em;\n  box-shadow: 0 2px 6px rgba(56, 189, 248, 0.2);\n}\n.card-detalle-completo hr {\n  border: 0;\n  border-top: 2px solid #0461bd;\n  margin: 20px 0;\n}\n.detalle-body .meta-item {\n  margin-bottom: 8px;\n  font-size: 0.95rem;\n  color: #475569;\n}\n.detalle-body .meta-item strong {\n  color: #0f172a;\n}\n.detalle-body h4 {\n  margin: 22px 0 12px 0;\n  color: #0f172a;\n  font-size: 1.1rem;\n  font-weight: 700;\n  border-left: 4px solid #92e4cb;\n  padding-left: 10px;\n}\n.detalle-body .descripcion-texto {\n  line-height: 1.7;\n  color: #475569;\n  font-size: 0.98rem;\n  white-space: pre-line;\n}\n.detalle-body .habilidades-container-view {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 8px;\n  margin-top: 10px;\n}\n.detalle-body .chip-skill-view {\n  background-color: #6be7ca;\n  border: 1px solid #92e4cb;\n  color: #0f172a;\n  font-weight: 700;\n  font-size: 0.85rem;\n  padding: 8px 16px;\n  border-radius: 20px;\n  box-shadow: 0 2px 4px rgba(146, 228, 203, 0.15);\n  transition: all 0.2s ease;\n}\n.detalle-body .chip-skill-view:hover {\n  background-color: #92e4cb;\n  color: #0f172a;\n}\n.detalle-footer {\n  margin-top: 35px;\n  border-top: 2px solid #f1f5f9;\n  padding-top: 25px;\n  display: flex;\n  justify-content: flex-end;\n  gap: 12px;\n  flex-wrap: wrap;\n}\n.detalle-footer button {\n  padding: 10px 20px;\n  border-radius: 8px;\n  font-size: 0.9rem;\n  font-weight: 600;\n  cursor: pointer;\n  display: inline-flex;\n  align-items: center;\n  gap: 8px;\n  border: none;\n  transition: all 0.2s ease;\n}\n.detalle-footer .btn-postularse,\n.detalle-footer .btn-primario,\n.detalle-footer .btn-crear {\n  background-color: #2d4c7e;\n  color: #b0e2b0;\n}\n.detalle-footer .btn-postularse:hover,\n.detalle-footer .btn-primario:hover,\n.detalle-footer .btn-crear:hover {\n  background-color: #1e3a63;\n  transform: translateY(-1px);\n}\n.detalle-footer .btn-secundario,\n.detalle-footer .btn-cancelar {\n  background-color: #f1f5f9;\n  color: #475569;\n  border: 1px solid #cbd5e1;\n}\n.detalle-footer .btn-secundario:hover,\n.detalle-footer .btn-cancelar:hover {\n  background-color: #e2e8f0;\n  color: #0f172a;\n}\n.detalle-footer .btn-candidatos {\n  background-color: #2563eb;\n  color: #ffffff;\n  border: 1px solid #1d4ed8;\n}\n.detalle-footer .btn-candidatos:hover {\n  background-color: #1d4ed8;\n  transform: translateY(-1px);\n}\n.detalle-footer .btn-editar {\n  background-color: #f1f5f9;\n  color: #0f172a;\n  border: 1px solid #cbd5e1;\n}\n.detalle-footer .btn-editar:hover {\n  background-color: #e2e8f0;\n}\n.detalle-footer .btn-duracion {\n  background-color: #fef3c7;\n  color: #92400e;\n  border: 1px solid #fde68a;\n}\n.detalle-footer .btn-duracion:hover {\n  background-color: #fde68a;\n}\n.detalle-footer .btn-cerrar-oferta {\n  background-color: #fee2e2;\n  color: #991b1b;\n  border: 1px solid #fca5a5;\n}\n.detalle-footer .btn-cerrar-oferta:hover {\n  background-color: #fca5a5;\n}\n.detalle-footer .btn-reabrir-oferta {\n  background-color: #dcfce7;\n  color: #166534;\n  border: 1px solid #bbf7d0;\n}\n.detalle-footer .btn-reabrir-oferta:hover {\n  background-color: #bbf7d0;\n}\n.detalle-footer .btn-postulado {\n  background-color: #e2e8f0;\n  color: #475569;\n  cursor: default;\n}\n.detalle-footer .btn-deshabilitado {\n  background-color: #f1f5f9;\n  color: #94a3b8;\n  cursor: not-allowed;\n}\n.detalle-footer .btn-eliminar-admin {\n  background-color: #ef4444;\n  color: #ffffff;\n}\n.detalle-footer .btn-eliminar-admin:hover {\n  background-color: #dc2626;\n}\n/*# sourceMappingURL=ofertas.css.map */\n'] }]
  }], () => [{ type: i15.FormBuilder }, { type: OfertaService }, { type: PostulacionesService }, { type: AuthService }, { type: i08.ChangeDetectorRef }, { type: i5.Router }], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i08.\u0275setClassDebugInfo(Ofertas, { className: "Ofertas", filePath: "app/pagina/ofertas/ofertas.ts", lineNumber: 28 });
})();
(() => {
  const id = "app%2Fpagina%2Fofertas%2Fofertas.ts%40Ofertas";
  function Ofertas_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i08.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i08.\u0275\u0275replaceMetadata(Ofertas, m.default, [i08, i15, i6, oferta_service_exports, postulaciones_service_exports, auth_service_exports, i5], [ReactiveFormsModule4, FormsModule, CommonModule3, Component6], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && Ofertas_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && Ofertas_HmrLoad(d.timestamp)));
})();

// src/app/pagina/postulaciones/postulaciones.ts
import { Component as Component7, inject as inject6, ChangeDetectorRef as ChangeDetectorRef2, DestroyRef } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import { CommonModule as CommonModule4 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_common.js?v=3d725e17";
import { ActivatedRoute, Router as Router5 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_router.js?v=3d725e17";
import { takeUntilDestroyed } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core_rxjs-interop.js?v=3d725e17";
import * as i09 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import * as i16 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_common.js?v=3d725e17";
function _forTrack03($index, $item) {
  return this.obtenerId($item);
}
function PostulacionesComponent_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275text(0, " Mis Postulaciones ");
  }
}
function PostulacionesComponent_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275text(0, " Postulaciones Recibidas ");
  }
}
function PostulacionesComponent_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275text(0, " Gesti\xF3n General de Postulaciones ");
  }
}
function PostulacionesComponent_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275text(0, " Seguimiento en tiempo real de tus postulaciones laborales. ");
  }
}
function PostulacionesComponent_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275text(0, " Revisa y gestiona los candidatos postulados a tus ofertas. ");
  }
}
function PostulacionesComponent_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275text(0, " Listado general y control de postulaciones registradas en ITB Conecta. ");
  }
}
function PostulacionesComponent_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275elementStart(0, "div", 4);
    i09.\u0275\u0275text(1);
    i09.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = i09.\u0275\u0275nextContext();
    i09.\u0275\u0275advance();
    i09.\u0275\u0275textInterpolate1(" \u{1F4CC} Filtrado por Oferta #", ctx_r0.idOfertaFiltro, " ");
  }
}
function PostulacionesComponent_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275elementStart(0, "div", 5);
    i09.\u0275\u0275element(1, "div", 8);
    i09.\u0275\u0275elementStart(2, "p");
    i09.\u0275\u0275text(3, "Cargando postulaciones...");
    i09.\u0275\u0275elementEnd()();
  }
}
function PostulacionesComponent_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275elementStart(0, "div", 6)(1, "p");
    i09.\u0275\u0275text(2, "No se encontraron postulaciones registradas.");
    i09.\u0275\u0275elementEnd()();
  }
}
function PostulacionesComponent_Conditional_14_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275elementStart(0, "th");
    i09.\u0275\u0275text(1, "Empresa");
    i09.\u0275\u0275elementEnd();
  }
}
function PostulacionesComponent_Conditional_14_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275elementStart(0, "th");
    i09.\u0275\u0275text(1, "Candidato");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275elementStart(2, "th");
    i09.\u0275\u0275text(3, "Contacto");
    i09.\u0275\u0275elementEnd();
  }
}
function PostulacionesComponent_Conditional_14_For_16_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275elementStart(0, "td", 13);
    i09.\u0275\u0275text(1);
    i09.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const item_r2 = i09.\u0275\u0275nextContext().$implicit;
    i09.\u0275\u0275advance();
    i09.\u0275\u0275textInterpolate1(" ", item_r2.razon_social || "N/A", " ");
  }
}
function PostulacionesComponent_Conditional_14_For_16_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275elementStart(0, "td", 20);
    i09.\u0275\u0275text(1);
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275elementStart(2, "td", 21)(3, "a", 22);
    i09.\u0275\u0275text(4);
    i09.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const item_r2 = i09.\u0275\u0275nextContext().$implicit;
    i09.\u0275\u0275advance();
    i09.\u0275\u0275textInterpolate2(" ", item_r2.nombre_postulante, " ", item_r2.apellido_postulante, " ");
    i09.\u0275\u0275advance(2);
    i09.\u0275\u0275property("href", "mailto:" + item_r2.email_postulante, i09.\u0275\u0275sanitizeUrl);
    i09.\u0275\u0275advance();
    i09.\u0275\u0275textInterpolate1(" ", item_r2.email_postulante, " ");
  }
}
function PostulacionesComponent_Conditional_14_For_16_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = i09.\u0275\u0275getCurrentView();
    i09.\u0275\u0275elementStart(0, "button", 23);
    i09.\u0275\u0275listener("click", function PostulacionesComponent_Conditional_14_For_16_Conditional_14_Template_button_click_0_listener() {
      i09.\u0275\u0275restoreView(_r3);
      const item_r2 = i09.\u0275\u0275nextContext().$implicit;
      const ctx_r0 = i09.\u0275\u0275nextContext(2);
      return i09.\u0275\u0275resetView(ctx_r0.verPerfilPostulante(item_r2.id_postulante));
    });
    i09.\u0275\u0275text(1, " \u{1F464} Perfil ");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275elementStart(2, "div", 24)(3, "select", 25);
    i09.\u0275\u0275listener("change", function PostulacionesComponent_Conditional_14_For_16_Conditional_14_Template_select_change_3_listener($event) {
      i09.\u0275\u0275restoreView(_r3);
      const item_r2 = i09.\u0275\u0275nextContext().$implicit;
      const ctx_r0 = i09.\u0275\u0275nextContext(2);
      return i09.\u0275\u0275resetView(ctx_r0.actualizarEstado(ctx_r0.obtenerId(item_r2), $event));
    });
    i09.\u0275\u0275elementStart(4, "option", 26);
    i09.\u0275\u0275text(5, "Pendiente");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275elementStart(6, "option", 27);
    i09.\u0275\u0275text(7, "En Revisi\xF3n");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275elementStart(8, "option", 28);
    i09.\u0275\u0275text(9, "Aceptado");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275elementStart(10, "option", 29);
    i09.\u0275\u0275text(11, "Rechazado");
    i09.\u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const item_r2 = i09.\u0275\u0275nextContext().$implicit;
    const ctx_r0 = i09.\u0275\u0275nextContext(2);
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275property("id", "estado-" + ctx_r0.obtenerId(item_r2))("value", (item_r2 == null ? null : item_r2.estado) || "Pendiente");
  }
}
function PostulacionesComponent_Conditional_14_For_16_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = i09.\u0275\u0275getCurrentView();
    i09.\u0275\u0275elementStart(0, "button", 30);
    i09.\u0275\u0275listener("click", function PostulacionesComponent_Conditional_14_For_16_Conditional_15_Template_button_click_0_listener() {
      i09.\u0275\u0275restoreView(_r4);
      const item_r2 = i09.\u0275\u0275nextContext().$implicit;
      const ctx_r0 = i09.\u0275\u0275nextContext(2);
      return i09.\u0275\u0275resetView(ctx_r0.eliminarPorModeracion(ctx_r0.obtenerId(item_r2)));
    });
    i09.\u0275\u0275text(1, " \u{1F5D1}\uFE0F ");
    i09.\u0275\u0275elementEnd();
  }
}
function PostulacionesComponent_Conditional_14_For_16_Conditional_16_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = i09.\u0275\u0275getCurrentView();
    i09.\u0275\u0275elementStart(0, "button", 33);
    i09.\u0275\u0275listener("click", function PostulacionesComponent_Conditional_14_For_16_Conditional_16_Conditional_0_Template_button_click_0_listener() {
      i09.\u0275\u0275restoreView(_r5);
      const item_r2 = i09.\u0275\u0275nextContext(2).$implicit;
      const ctx_r0 = i09.\u0275\u0275nextContext(2);
      return i09.\u0275\u0275resetView(ctx_r0.cancelarPostulacion(ctx_r0.obtenerId(item_r2)));
    });
    i09.\u0275\u0275text(1, " \u{1F6AB} Anular ");
    i09.\u0275\u0275elementEnd();
  }
}
function PostulacionesComponent_Conditional_14_For_16_Conditional_16_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275elementStart(0, "span", 32);
    i09.\u0275\u0275text(1, "\u2014");
    i09.\u0275\u0275elementEnd();
  }
}
function PostulacionesComponent_Conditional_14_For_16_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275conditionalCreate(0, PostulacionesComponent_Conditional_14_For_16_Conditional_16_Conditional_0_Template, 2, 0, "button", 31)(1, PostulacionesComponent_Conditional_14_For_16_Conditional_16_Conditional_1_Template, 2, 0, "span", 32);
  }
  if (rf & 2) {
    const item_r2 = i09.\u0275\u0275nextContext().$implicit;
    i09.\u0275\u0275conditional((item_r2.estado || "").toLowerCase() === "pendiente" || (item_r2.estado || "").toLowerCase() === "en revision" ? 0 : 1);
  }
}
function PostulacionesComponent_Conditional_14_For_16_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275elementStart(0, "tr")(1, "td", 11)(2, "span", 12);
    i09.\u0275\u0275text(3);
    i09.\u0275\u0275elementEnd()();
    i09.\u0275\u0275conditionalCreate(4, PostulacionesComponent_Conditional_14_For_16_Conditional_4_Template, 2, 1, "td", 13);
    i09.\u0275\u0275conditionalCreate(5, PostulacionesComponent_Conditional_14_For_16_Conditional_5_Template, 5, 4);
    i09.\u0275\u0275elementStart(6, "td", 14);
    i09.\u0275\u0275text(7);
    i09.\u0275\u0275pipe(8, "date");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275elementStart(9, "td", 15)(10, "span", 16);
    i09.\u0275\u0275text(11);
    i09.\u0275\u0275elementEnd()();
    i09.\u0275\u0275elementStart(12, "td", 17)(13, "div", 18);
    i09.\u0275\u0275conditionalCreate(14, PostulacionesComponent_Conditional_14_For_16_Conditional_14_Template, 12, 2);
    i09.\u0275\u0275conditionalCreate(15, PostulacionesComponent_Conditional_14_For_16_Conditional_15_Template, 2, 0, "button", 19);
    i09.\u0275\u0275conditionalCreate(16, PostulacionesComponent_Conditional_14_For_16_Conditional_16_Template, 2, 1);
    i09.\u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const item_r2 = ctx.$implicit;
    const ctx_r0 = i09.\u0275\u0275nextContext(2);
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275textInterpolate(item_r2.titulo_oferta);
    i09.\u0275\u0275advance();
    i09.\u0275\u0275conditional(ctx_r0.rolUsuario !== "empresa" ? 4 : -1);
    i09.\u0275\u0275advance();
    i09.\u0275\u0275conditional(ctx_r0.rolUsuario !== "postulante" ? 5 : -1);
    i09.\u0275\u0275advance(2);
    i09.\u0275\u0275textInterpolate1(" ", i09.\u0275\u0275pipeBind2(8, 9, item_r2.fecha_postulacion, "dd/MM/yyyy"), " ");
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275property("ngClass", (item_r2.estado || "pendiente").toLowerCase().replaceAll(" ", "-"));
    i09.\u0275\u0275advance();
    i09.\u0275\u0275textInterpolate1(" ", item_r2.estado, " ");
    i09.\u0275\u0275advance(3);
    i09.\u0275\u0275conditional(ctx_r0.rolUsuario === "empresa" || ctx_r0.rolUsuario === "admin" ? 14 : -1);
    i09.\u0275\u0275advance();
    i09.\u0275\u0275conditional(ctx_r0.rolUsuario === "admin" ? 15 : -1);
    i09.\u0275\u0275advance();
    i09.\u0275\u0275conditional(ctx_r0.rolUsuario === "postulante" ? 16 : -1);
  }
}
function PostulacionesComponent_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    i09.\u0275\u0275elementStart(0, "div", 7)(1, "table", 9)(2, "thead")(3, "tr")(4, "th");
    i09.\u0275\u0275text(5, "Oferta");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275conditionalCreate(6, PostulacionesComponent_Conditional_14_Conditional_6_Template, 2, 0, "th");
    i09.\u0275\u0275conditionalCreate(7, PostulacionesComponent_Conditional_14_Conditional_7_Template, 4, 0);
    i09.\u0275\u0275elementStart(8, "th");
    i09.\u0275\u0275text(9, "Fecha");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275elementStart(10, "th");
    i09.\u0275\u0275text(11, "Estado");
    i09.\u0275\u0275elementEnd();
    i09.\u0275\u0275elementStart(12, "th", 10);
    i09.\u0275\u0275text(13, "Acciones");
    i09.\u0275\u0275elementEnd()()();
    i09.\u0275\u0275elementStart(14, "tbody");
    i09.\u0275\u0275repeaterCreate(15, PostulacionesComponent_Conditional_14_For_16_Template, 17, 12, "tr", null, _forTrack03, true);
    i09.\u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r0 = i09.\u0275\u0275nextContext();
    i09.\u0275\u0275advance(6);
    i09.\u0275\u0275conditional(ctx_r0.rolUsuario !== "empresa" ? 6 : -1);
    i09.\u0275\u0275advance();
    i09.\u0275\u0275conditional(ctx_r0.rolUsuario !== "postulante" ? 7 : -1);
    i09.\u0275\u0275advance(8);
    i09.\u0275\u0275repeater(ctx_r0.postulaciones);
  }
}
var PostulacionesComponent = class _PostulacionesComponent {
  // --- Inyección de Servicios ---
  postulacionesService = inject6(PostulacionesService);
  authService = inject6(AuthService);
  cdr = inject6(ChangeDetectorRef2);
  destroyRef = inject6(DestroyRef);
  route = inject6(ActivatedRoute);
  router = inject6(Router5);
  // --- Estado del Componente ---
  postulaciones = [];
  rolUsuario = "";
  cargando = true;
  idOfertaFiltro = null;
  ngOnInit() {
    const usuario = this.authService.getUsuarioActual();
    this.rolUsuario = (usuario?.rol || this.authService.getTipoUsuario() || "postulante").toLowerCase();
    this.route.queryParams.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((params) => {
      this.idOfertaFiltro = params["oferta"] ? Number(params["oferta"]) : null;
      this.cargarPostulaciones(usuario);
    });
  }
  // --- Carga de Datos según Rol ---
  cargarPostulaciones(usuario) {
    if (!usuario) {
      this.cargando = false;
      return;
    }
    this.cargando = true;
    const handleSuccess = (data) => this.setDatos(data);
    const handleError = (err) => {
      console.error("Error al cargar postulaciones:", err);
      this.cargando = false;
      this.cdr.detectChanges();
    };
    switch (this.rolUsuario) {
      case "postulante": {
        const idPostulante = usuario.id_postulante || usuario.id;
        this.postulacionesService.getByPostulante(idPostulante).subscribe({
          next: handleSuccess,
          error: handleError
        });
        break;
      }
      case "empresa": {
        if (this.idOfertaFiltro) {
          this.postulacionesService.getByOferta(this.idOfertaFiltro).subscribe({
            next: handleSuccess,
            error: handleError
          });
        } else {
          const idEmpresa = usuario.id_empresa || usuario.id;
          this.postulacionesService.getByEmpresa(idEmpresa).subscribe({
            next: handleSuccess,
            error: handleError
          });
        }
        break;
      }
      case "admin": {
        this.postulacionesService.getTodas().subscribe({
          next: handleSuccess,
          error: handleError
        });
        break;
      }
      default: {
        this.cargando = false;
        break;
      }
    }
  }
  // --- Acciones ---
  actualizarEstado(id_postulacion, event) {
    if (!id_postulacion)
      return;
    const selectElement = event.target;
    const nuevoEstado = selectElement.value;
    this.postulacionesService.actualizarEstado(id_postulacion, nuevoEstado).subscribe({
      next: () => {
        const item = this.postulaciones.find((p) => this.obtenerId(p) === id_postulacion);
        if (item) {
          item.estado = nuevoEstado;
        }
        this.cdr.detectChanges();
      },
      error: (err) => console.error("Error al actualizar el estado:", err)
    });
  }
  cancelarPostulacion(id_postulacion) {
    if (!id_postulacion)
      return;
    if (!confirm("\xBFEst\xE1s seguro de que deseas retirar tu postulaci\xF3n a esta oferta?"))
      return;
    this.postulacionesService.cancelarPostulacion(id_postulacion).subscribe({
      next: () => {
        this.postulaciones = this.postulaciones.filter((p) => this.obtenerId(p) !== id_postulacion);
        this.cdr.detectChanges();
      },
      error: (err) => console.error("Error al cancelar postulaci\xF3n:", err)
    });
  }
  eliminarPorModeracion(id_postulacion) {
    if (!id_postulacion)
      return;
    if (!confirm("\xBFEliminar esta postulaci\xF3n del registro del sistema?"))
      return;
    this.postulacionesService.eliminarPorModeracion(id_postulacion).subscribe({
      next: () => {
        this.postulaciones = this.postulaciones.filter((p) => this.obtenerId(p) !== id_postulacion);
        this.cdr.detectChanges();
      },
      error: (err) => console.error("Error al eliminar postulaci\xF3n:", err)
    });
  }
  verPerfilPostulante(idPostulante) {
    if (idPostulante) {
      this.router.navigate(["/postulante", idPostulante]);
    }
  }
  // --- Métodos Auxiliares ---
  /**
   * Obtiene el ID soportando tanto snake_case como camelCase de la API
   */
  obtenerId(item) {
    return item.id_postulacion ?? item.idPostulacion;
  }
  obtenerClaseBadge(estado) {
    switch (estado) {
      case "Aceptado":
        return "badge-success";
      case "Rechazado":
        return "badge-danger";
      case "En Revision":
        return "badge-warning";
      default:
        return "badge-info";
    }
  }
  setDatos(data) {
    this.postulaciones = (data || []).map((item) => __spreadProps(__spreadValues({}, item), {
      estado: item.estado || "Pendiente"
    }));
    this.cargando = false;
    this.cdr.detectChanges();
  }
  static \u0275fac = function PostulacionesComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _PostulacionesComponent)();
  };
  static \u0275cmp = /* @__PURE__ */ i09.\u0275\u0275defineComponent({ type: _PostulacionesComponent, selectors: [["app-postulaciones"]], decls: 15, vars: 4, consts: [[1, "postulaciones-container"], [1, "header"], [1, "header-info"], [1, "subtitle"], [1, "filtro-activo-badge"], [1, "state-box", "loading"], [1, "state-box", "empty"], [1, "table-responsive"], [1, "spinner"], [1, "tabla-postulaciones"], [1, "text-center"], [1, "col-oferta"], [1, "titulo-oferta"], [1, "col-empresa"], [1, "col-fecha"], [1, "col-estado"], [1, "badge", 3, "ngClass"], [1, "col-acciones"], [1, "actions-wrapper"], ["type", "button", "title", "Eliminar Postulaci\xF3n", 1, "btn-eliminar-admin"], [1, "col-candidato"], [1, "col-contacto"], [1, "link-email", 3, "href"], ["type", "button", "title", "Ver Perfil del Candidato", 1, "btn-ver-perfil", 3, "click"], [1, "select-estado-wrapper"], [1, "select-estado", 3, "change", "id", "value"], ["value", "Pendiente"], ["value", "En Revision"], ["value", "Aceptado"], ["value", "Rechazado"], ["type", "button", "title", "Eliminar Postulaci\xF3n", 1, "btn-eliminar-admin", 3, "click"], ["type", "button", "title", "Anular postulaci\xF3n", 1, "btn-cancelar"], ["title", "Postulaci\xF3n en estado finalizado", 1, "sin-acciones"], ["type", "button", "title", "Anular postulaci\xF3n", 1, "btn-cancelar", 3, "click"]], template: function PostulacionesComponent_Template(rf, ctx) {
    if (rf & 1) {
      i09.\u0275\u0275elementStart(0, "div", 0)(1, "header", 1)(2, "div", 2)(3, "h2");
      i09.\u0275\u0275conditionalCreate(4, PostulacionesComponent_Conditional_4_Template, 1, 0)(5, PostulacionesComponent_Conditional_5_Template, 1, 0)(6, PostulacionesComponent_Conditional_6_Template, 1, 0);
      i09.\u0275\u0275elementEnd();
      i09.\u0275\u0275elementStart(7, "p", 3);
      i09.\u0275\u0275conditionalCreate(8, PostulacionesComponent_Conditional_8_Template, 1, 0)(9, PostulacionesComponent_Conditional_9_Template, 1, 0)(10, PostulacionesComponent_Conditional_10_Template, 1, 0);
      i09.\u0275\u0275elementEnd()();
      i09.\u0275\u0275conditionalCreate(11, PostulacionesComponent_Conditional_11_Template, 2, 1, "div", 4);
      i09.\u0275\u0275elementEnd();
      i09.\u0275\u0275conditionalCreate(12, PostulacionesComponent_Conditional_12_Template, 4, 0, "div", 5)(13, PostulacionesComponent_Conditional_13_Template, 3, 0, "div", 6)(14, PostulacionesComponent_Conditional_14_Template, 17, 2, "div", 7);
      i09.\u0275\u0275elementEnd();
    }
    if (rf & 2) {
      i09.\u0275\u0275advance(4);
      i09.\u0275\u0275conditional(ctx.rolUsuario === "postulante" ? 4 : ctx.rolUsuario === "empresa" ? 5 : 6);
      i09.\u0275\u0275advance(4);
      i09.\u0275\u0275conditional(ctx.rolUsuario === "postulante" ? 8 : ctx.rolUsuario === "empresa" ? 9 : 10);
      i09.\u0275\u0275advance(3);
      i09.\u0275\u0275conditional(ctx.idOfertaFiltro ? 11 : -1);
      i09.\u0275\u0275advance();
      i09.\u0275\u0275conditional(ctx.cargando ? 12 : ctx.postulaciones.length === 0 ? 13 : 14);
    }
  }, dependencies: [CommonModule4, i16.NgClass, i16.NgComponentOutlet, i16.NgForOf, i16.NgIf, i16.NgTemplateOutlet, i16.NgStyle, i16.NgSwitch, i16.NgSwitchCase, i16.NgSwitchDefault, i16.NgPlural, i16.NgPluralCase, i16.AsyncPipe, i16.UpperCasePipe, i16.LowerCasePipe, i16.JsonPipe, i16.SlicePipe, i16.DecimalPipe, i16.PercentPipe, i16.TitleCasePipe, i16.CurrencyPipe, i16.DatePipe, i16.I18nPluralPipe, i16.I18nSelectPipe, i16.KeyValuePipe], styles: ['\n[_nghost-%COMP%] {\n  display: block;\n  font-family:\n    "lucida grande",\n    "Segoe UI",\n    Roboto,\n    Helvetica,\n    Arial,\n    sans-serif;\n  color: #0f172a;\n}\n.postulaciones-container[_ngcontent-%COMP%] {\n  padding: 24px;\n  max-width: 1200px;\n  margin: 0 auto;\n}\n.header[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: flex-start;\n  margin-bottom: 24px;\n  border-bottom: 2px solid #92e4cb;\n  padding-bottom: 16px;\n  gap: 16px;\n  flex-wrap: wrap;\n}\n.header[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  margin: 0 0 6px 0;\n  color: #2d4c7e;\n  font-size: 1.6rem;\n  font-weight: 700;\n}\n.header[_ngcontent-%COMP%]   .subtitle[_ngcontent-%COMP%] {\n  margin: 0;\n  color: #475569;\n  font-size: 0.95rem;\n}\n.filtro-activo-badge[_ngcontent-%COMP%] {\n  background-color: #f0f9ff;\n  border: 1px solid #38bdf8;\n  color: #2d4c7e;\n  padding: 8px 14px;\n  border-radius: 20px;\n  font-size: 0.85rem;\n  font-weight: 600;\n}\n.state-box[_ngcontent-%COMP%] {\n  text-align: center;\n  padding: 50px 20px;\n  background-color: #ffffff;\n  border: 1px solid #cbd5e1;\n  border-radius: 12px;\n  color: #475569;\n}\n.state-box[_ngcontent-%COMP%]   .spinner[_ngcontent-%COMP%] {\n  width: 32px;\n  height: 32px;\n  border: 3px solid #e2e8f0;\n  border-top-color: #2d4c7e;\n  border-radius: 50%;\n  margin: 0 auto 12px;\n  animation: _ngcontent-%COMP%_spin 0.8s linear infinite;\n}\n@keyframes _ngcontent-%COMP%_spin {\n  to {\n    transform: rotate(360deg);\n  }\n}\n.table-responsive[_ngcontent-%COMP%] {\n  width: 100%;\n  overflow-x: auto;\n  background-color: #ffffff;\n  border: 1px solid #cbd5e1;\n  border-radius: 12px;\n  box-shadow: 0 4px 6px rgba(15, 23, 42, 0.04);\n}\n.tabla-postulaciones[_ngcontent-%COMP%] {\n  width: 100%;\n  border-collapse: collapse;\n  text-align: left;\n  font-size: 0.9rem;\n}\n.tabla-postulaciones[_ngcontent-%COMP%]   th[_ngcontent-%COMP%], \n.tabla-postulaciones[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\n  padding: 14px 16px;\n  border-bottom: 1px solid #f1f5f9;\n  vertical-align: middle;\n}\n.tabla-postulaciones[_ngcontent-%COMP%]   th[_ngcontent-%COMP%] {\n  background-color: #f8fafc;\n  color: #0f172a;\n  font-weight: 700;\n  font-size: 0.82rem;\n  text-transform: uppercase;\n  letter-spacing: 0.03em;\n  border-bottom: 2px solid #cbd5e1;\n}\n.tabla-postulaciones[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]:last-child   td[_ngcontent-%COMP%] {\n  border-bottom: none;\n}\n.tabla-postulaciones[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]:hover   td[_ngcontent-%COMP%] {\n  background-color: #f8fafc;\n}\n.tabla-postulaciones[_ngcontent-%COMP%]   .titulo-oferta[_ngcontent-%COMP%] {\n  font-weight: 700;\n  color: #2d4c7e;\n}\n.tabla-postulaciones[_ngcontent-%COMP%]   .link-email[_ngcontent-%COMP%] {\n  color: #2563eb;\n  text-decoration: none;\n}\n.tabla-postulaciones[_ngcontent-%COMP%]   .link-email[_ngcontent-%COMP%]:hover {\n  text-decoration: underline;\n}\n.tabla-postulaciones[_ngcontent-%COMP%]   .actions-wrapper[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  flex-wrap: wrap;\n}\n.tabla-postulaciones[_ngcontent-%COMP%] {\n}\n.tabla-postulaciones[_ngcontent-%COMP%]   button[_ngcontent-%COMP%] {\n  padding: 6px 12px;\n  border-radius: 6px;\n  font-size: 0.85rem;\n  font-weight: 600;\n  cursor: pointer;\n  border: 1px solid transparent;\n  transition: background-color 0.2s, border-color 0.2s;\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n}\n.tabla-postulaciones[_ngcontent-%COMP%]   button.btn-ver-perfil[_ngcontent-%COMP%] {\n  background-color: #ffffff;\n  color: #0f172a;\n  border-color: #cbd5e1;\n}\n.tabla-postulaciones[_ngcontent-%COMP%]   button.btn-ver-perfil[_ngcontent-%COMP%]:hover {\n  background-color: #f1f5f9;\n}\n.tabla-postulaciones[_ngcontent-%COMP%]   button.btn-cancelar[_ngcontent-%COMP%] {\n  background-color: #fee2e2;\n  color: #991b1b;\n  border-color: #fca5a5;\n}\n.tabla-postulaciones[_ngcontent-%COMP%]   button.btn-cancelar[_ngcontent-%COMP%]:hover {\n  background-color: #fca5a5;\n}\n.tabla-postulaciones[_ngcontent-%COMP%]   button.btn-eliminar-admin[_ngcontent-%COMP%] {\n  background-color: #ef4444;\n  color: #ffffff;\n  padding: 6px 10px;\n}\n.tabla-postulaciones[_ngcontent-%COMP%]   button.btn-eliminar-admin[_ngcontent-%COMP%]:hover {\n  background-color: #dc2626;\n}\n.tabla-postulaciones[_ngcontent-%COMP%]   .select-estado-wrapper[_ngcontent-%COMP%] {\n  display: inline-block;\n}\n.tabla-postulaciones[_ngcontent-%COMP%]   .select-estado-wrapper[_ngcontent-%COMP%]   .select-estado[_ngcontent-%COMP%] {\n  padding: 5px 8px;\n  border-radius: 6px;\n  border: 1px solid #cbd5e1;\n  font-size: 0.85rem;\n  background-color: #ffffff;\n  color: #0f172a;\n  cursor: pointer;\n}\n.tabla-postulaciones[_ngcontent-%COMP%]   .select-estado-wrapper[_ngcontent-%COMP%]   .select-estado[_ngcontent-%COMP%]:focus {\n  outline: none;\n  border-color: #2d4c7e;\n}\n.badge[_ngcontent-%COMP%] {\n  display: inline-block;\n  padding: 4px 10px;\n  border-radius: 12px;\n  font-size: 0.75rem;\n  font-weight: 700;\n  text-transform: uppercase;\n  letter-spacing: 0.03em;\n  background-color: #e0f2fe;\n  color: #075985;\n}\n.badge.pendiente[_ngcontent-%COMP%] {\n  background-color: #e0f2fe;\n  color: #075985;\n}\n.badge.en-revision[_ngcontent-%COMP%] {\n  background-color: #fef3c7;\n  color: #92400e;\n}\n.badge.aceptado[_ngcontent-%COMP%] {\n  background-color: #dcfce7;\n  color: #166534;\n}\n.badge.rechazado[_ngcontent-%COMP%] {\n  background-color: #fee2e2;\n  color: #991b1b;\n}\n/*# sourceMappingURL=postulaciones.css.map */'] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i09.\u0275setClassMetadata(PostulacionesComponent, [{
    type: Component7,
    args: [{ selector: "app-postulaciones", standalone: true, imports: [CommonModule4], template: `<div class="postulaciones-container">\r
  <header class="header">\r
    <div class="header-info">\r
      <h2>\r
        @if (rolUsuario === 'postulante') { Mis Postulaciones }\r
        @else if (rolUsuario === 'empresa') { Postulaciones Recibidas }\r
        @else { Gesti\xF3n General de Postulaciones }\r
      </h2>\r
      <p class="subtitle">\r
        @if (rolUsuario === 'postulante') { Seguimiento en tiempo real de tus postulaciones laborales. }\r
        @else if (rolUsuario === 'empresa') { Revisa y gestiona los candidatos postulados a tus ofertas. }\r
        @else { Listado general y control de postulaciones registradas en ITB Conecta. }\r
      </p>\r
    </div>\r
\r
    @if (idOfertaFiltro) {\r
      <div class="filtro-activo-badge">\r
        \u{1F4CC} Filtrado por Oferta #{{ idOfertaFiltro }}\r
      </div>\r
    }\r
  </header>\r
\r
  <!-- Estado de Carga -->\r
  @if (cargando) {\r
    <div class="state-box loading">\r
      <div class="spinner"></div>\r
      <p>Cargando postulaciones...</p>\r
    </div>\r
  } \r
\r
  <!-- Estado Vac\xEDo -->\r
  @else if (postulaciones.length === 0) {\r
    <div class="state-box empty">\r
      <p>No se encontraron postulaciones registradas.</p>\r
    </div>\r
  } \r
\r
  <!-- Listado Tabular de Postulaciones -->\r
  @else {\r
    <div class="table-responsive">\r
      <table class="tabla-postulaciones">\r
        <thead>\r
          <tr>\r
            <th>Oferta</th>\r
\r
            @if (rolUsuario !== 'empresa') {\r
              <th>Empresa</th>\r
            }\r
\r
            @if (rolUsuario !== 'postulante') {\r
              <th>Candidato</th>\r
              <th>Contacto</th>\r
            }\r
\r
            <th>Fecha</th>\r
            <th>Estado</th>\r
            <th class="text-center">Acciones</th>\r
          </tr>\r
        </thead>\r
        <tbody>\r
          @for (item of postulaciones; track obtenerId(item)) {\r
            <tr>\r
              <!-- Oferta -->\r
              <td class="col-oferta">\r
                <span class="titulo-oferta">{{ item.titulo_oferta }}</span>\r
              </td>\r
\r
              <!-- Empresa (visible para postulante y admin) -->\r
              @if (rolUsuario !== 'empresa') {\r
                <td class="col-empresa">\r
                  {{ item.razon_social || 'N/A' }}\r
                </td>\r
              }\r
\r
              <!-- Candidato y Contacto (visible para empresa y admin) -->\r
              @if (rolUsuario !== 'postulante') {\r
                <td class="col-candidato">\r
                  {{ item.nombre_postulante }} {{ item.apellido_postulante }}\r
                </td>\r
                <td class="col-contacto">\r
                  <a [href]="'mailto:' + item.email_postulante" class="link-email">\r
                    {{ item.email_postulante }}\r
                  </a>\r
                </td>\r
              }\r
\r
              <!-- Fecha -->\r
              <td class="col-fecha">\r
                {{ item.fecha_postulacion | date:'dd/MM/yyyy' }}\r
              </td>\r
\r
              <!-- Estado -->\r
              <td class="col-estado">\r
                <span class="badge" [ngClass]="(item.estado || 'pendiente').toLowerCase().replaceAll(' ', '-')">\r
                  {{ item.estado }}\r
                </span>\r
              </td>\r
\r
              <!-- Acciones -->\r
              <td class="col-acciones">\r
                <div class="actions-wrapper">\r
                  \r
                  <!-- Ver perfil y Cambiar Estado (Empresa / Admin) -->\r
                  @if (rolUsuario === 'empresa' || rolUsuario === 'admin') {\r
                    <button \r
                      type="button" \r
                      class="btn-ver-perfil" \r
                      (click)="verPerfilPostulante(item.id_postulante)"\r
                      title="Ver Perfil del Candidato">\r
                      \u{1F464} Perfil\r
                    </button>\r
\r
                    <div class="select-estado-wrapper">\r
                      <select \r
                        [id]="'estado-' + obtenerId(item)"\r
                        [value]="item?.estado || 'Pendiente'"\r
                        (change)="actualizarEstado(obtenerId(item), $event)"\r
                        class="select-estado">\r
                        <option value="Pendiente">Pendiente</option>\r
                        <option value="En Revision">En Revisi\xF3n</option>\r
                        <option value="Aceptado">Aceptado</option>\r
                        <option value="Rechazado">Rechazado</option>\r
                      </select>\r
                    </div>\r
                  }\r
\r
                  <!-- Moderaci\xF3n (Admin) -->\r
                  @if (rolUsuario === 'admin') {\r
                    <button \r
                      type="button" \r
                      class="btn-eliminar-admin" \r
                      (click)="eliminarPorModeracion(obtenerId(item))"\r
                      title="Eliminar Postulaci\xF3n">\r
                      \u{1F5D1}\uFE0F\r
                    </button>\r
                  }\r
\r
                  <!-- Acciones para el Postulante (Anular postulaci\xF3n) -->\r
                  @if (rolUsuario === 'postulante') {\r
                    @if ((item.estado || '').toLowerCase() === 'pendiente' || (item.estado || '').toLowerCase() === 'en revision') {\r
                      <button \r
                        type="button" \r
                        class="btn-cancelar" \r
                        (click)="cancelarPostulacion(obtenerId(item))"\r
                        title="Anular postulaci\xF3n">\r
                        \u{1F6AB} Anular\r
                      </button>\r
                    } @else {\r
                      <span class="sin-acciones" title="Postulaci\xF3n en estado finalizado">\u2014</span>\r
                    }\r
                  }\r
\r
                </div>\r
              </td>\r
            </tr>\r
          }\r
        </tbody>\r
      </table>\r
    </div>\r
  }\r
</div>`, styles: ['/* src/app/pagina/postulaciones/postulaciones.scss */\n:host {\n  display: block;\n  font-family:\n    "lucida grande",\n    "Segoe UI",\n    Roboto,\n    Helvetica,\n    Arial,\n    sans-serif;\n  color: #0f172a;\n}\n.postulaciones-container {\n  padding: 24px;\n  max-width: 1200px;\n  margin: 0 auto;\n}\n.header {\n  display: flex;\n  justify-content: space-between;\n  align-items: flex-start;\n  margin-bottom: 24px;\n  border-bottom: 2px solid #92e4cb;\n  padding-bottom: 16px;\n  gap: 16px;\n  flex-wrap: wrap;\n}\n.header h2 {\n  margin: 0 0 6px 0;\n  color: #2d4c7e;\n  font-size: 1.6rem;\n  font-weight: 700;\n}\n.header .subtitle {\n  margin: 0;\n  color: #475569;\n  font-size: 0.95rem;\n}\n.filtro-activo-badge {\n  background-color: #f0f9ff;\n  border: 1px solid #38bdf8;\n  color: #2d4c7e;\n  padding: 8px 14px;\n  border-radius: 20px;\n  font-size: 0.85rem;\n  font-weight: 600;\n}\n.state-box {\n  text-align: center;\n  padding: 50px 20px;\n  background-color: #ffffff;\n  border: 1px solid #cbd5e1;\n  border-radius: 12px;\n  color: #475569;\n}\n.state-box .spinner {\n  width: 32px;\n  height: 32px;\n  border: 3px solid #e2e8f0;\n  border-top-color: #2d4c7e;\n  border-radius: 50%;\n  margin: 0 auto 12px;\n  animation: spin 0.8s linear infinite;\n}\n@keyframes spin {\n  to {\n    transform: rotate(360deg);\n  }\n}\n.table-responsive {\n  width: 100%;\n  overflow-x: auto;\n  background-color: #ffffff;\n  border: 1px solid #cbd5e1;\n  border-radius: 12px;\n  box-shadow: 0 4px 6px rgba(15, 23, 42, 0.04);\n}\n.tabla-postulaciones {\n  width: 100%;\n  border-collapse: collapse;\n  text-align: left;\n  font-size: 0.9rem;\n}\n.tabla-postulaciones th,\n.tabla-postulaciones td {\n  padding: 14px 16px;\n  border-bottom: 1px solid #f1f5f9;\n  vertical-align: middle;\n}\n.tabla-postulaciones th {\n  background-color: #f8fafc;\n  color: #0f172a;\n  font-weight: 700;\n  font-size: 0.82rem;\n  text-transform: uppercase;\n  letter-spacing: 0.03em;\n  border-bottom: 2px solid #cbd5e1;\n}\n.tabla-postulaciones tr:last-child td {\n  border-bottom: none;\n}\n.tabla-postulaciones tr:hover td {\n  background-color: #f8fafc;\n}\n.tabla-postulaciones .titulo-oferta {\n  font-weight: 700;\n  color: #2d4c7e;\n}\n.tabla-postulaciones .link-email {\n  color: #2563eb;\n  text-decoration: none;\n}\n.tabla-postulaciones .link-email:hover {\n  text-decoration: underline;\n}\n.tabla-postulaciones .actions-wrapper {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  flex-wrap: wrap;\n}\n.tabla-postulaciones {\n}\n.tabla-postulaciones button {\n  padding: 6px 12px;\n  border-radius: 6px;\n  font-size: 0.85rem;\n  font-weight: 600;\n  cursor: pointer;\n  border: 1px solid transparent;\n  transition: background-color 0.2s, border-color 0.2s;\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n}\n.tabla-postulaciones button.btn-ver-perfil {\n  background-color: #ffffff;\n  color: #0f172a;\n  border-color: #cbd5e1;\n}\n.tabla-postulaciones button.btn-ver-perfil:hover {\n  background-color: #f1f5f9;\n}\n.tabla-postulaciones button.btn-cancelar {\n  background-color: #fee2e2;\n  color: #991b1b;\n  border-color: #fca5a5;\n}\n.tabla-postulaciones button.btn-cancelar:hover {\n  background-color: #fca5a5;\n}\n.tabla-postulaciones button.btn-eliminar-admin {\n  background-color: #ef4444;\n  color: #ffffff;\n  padding: 6px 10px;\n}\n.tabla-postulaciones button.btn-eliminar-admin:hover {\n  background-color: #dc2626;\n}\n.tabla-postulaciones .select-estado-wrapper {\n  display: inline-block;\n}\n.tabla-postulaciones .select-estado-wrapper .select-estado {\n  padding: 5px 8px;\n  border-radius: 6px;\n  border: 1px solid #cbd5e1;\n  font-size: 0.85rem;\n  background-color: #ffffff;\n  color: #0f172a;\n  cursor: pointer;\n}\n.tabla-postulaciones .select-estado-wrapper .select-estado:focus {\n  outline: none;\n  border-color: #2d4c7e;\n}\n.badge {\n  display: inline-block;\n  padding: 4px 10px;\n  border-radius: 12px;\n  font-size: 0.75rem;\n  font-weight: 700;\n  text-transform: uppercase;\n  letter-spacing: 0.03em;\n  background-color: #e0f2fe;\n  color: #075985;\n}\n.badge.pendiente {\n  background-color: #e0f2fe;\n  color: #075985;\n}\n.badge.en-revision {\n  background-color: #fef3c7;\n  color: #92400e;\n}\n.badge.aceptado {\n  background-color: #dcfce7;\n  color: #166534;\n}\n.badge.rechazado {\n  background-color: #fee2e2;\n  color: #991b1b;\n}\n/*# sourceMappingURL=postulaciones.css.map */\n'] }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i09.\u0275setClassDebugInfo(PostulacionesComponent, { className: "PostulacionesComponent", filePath: "app/pagina/postulaciones/postulaciones.ts", lineNumber: 15 });
})();
(() => {
  const id = "app%2Fpagina%2Fpostulaciones%2Fpostulaciones.ts%40PostulacionesComponent";
  function PostulacionesComponent_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i09.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i09.\u0275\u0275replaceMetadata(PostulacionesComponent, m.default, [i09, i16], [CommonModule4, Component7], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && PostulacionesComponent_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && PostulacionesComponent_HmrLoad(d.timestamp)));
})();

// src/app/pagina/panel-admin/panel-admin.ts
import { Component as Component9, inject as inject9, ChangeDetectorRef as ChangeDetectorRef3 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import { CommonModule as CommonModule6 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_common.js?v=3d725e17";
import { Router as Router6 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_router.js?v=3d725e17";

// src/app/pagina/panel-admin/skills/skills.ts
import { Component as Component8, inject as inject8 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import { CommonModule as CommonModule5 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_common.js?v=3d725e17";
import { FormBuilder as FormBuilder2, ReactiveFormsModule as ReactiveFormsModule5, Validators as Validators5, FormsModule as FormsModule2 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_forms.js?v=3d725e17";

// src/app/services/admin.ts
import { Injectable as Injectable3, inject as inject7 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import { HttpClient as HttpClient3 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_common_http.js?v=3d725e17";
import { map } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/rxjs_operators.js?v=3d725e17";
import * as i010 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
var AdminService = class _AdminService {
  http = inject7(HttpClient3);
  API_URL = "http://localhost:3000/api/admin";
  getMetricas() {
    return this.http.get(`${this.API_URL}/metricas`);
  }
  // ------------------------------------------
  // B. GESTIÓN DE EMPRESAS
  // ------------------------------------------
  getEmpresas() {
    return this.http.get(`${this.API_URL}/empresas`);
  }
  cambiarEstadoEmpresa(id_empresa, estado) {
    return this.http.put(`${this.API_URL}/empresa/estado`, { id_empresa, estado });
  }
  // ------------------------------------------
  // C. GESTIÓN DE OFERTAS
  // ------------------------------------------
  getOfertas() {
    return this.http.get(`${this.API_URL}/ofertas`);
  }
  eliminarOferta(id_oferta) {
    return this.http.delete(`${this.API_URL}/oferta/${id_oferta}`);
  }
  // ------------------------------------------
  // D. GESTIÓN DE POSTULANTES
  // ------------------------------------------
  getPostulantes() {
    return this.http.get(`${this.API_URL}/postulantes`);
  }
  // ------------------------------------------
  // E. CATÁLOGOS Y TABLAS MAESTRAS (Categorías y Skills)
  // ------------------------------------------
  getCategoriasSkills() {
    return this.http.get(`${this.API_URL}/categorias-skills`).pipe(map((res) => res.categorias || []));
  }
  getSkills() {
    return this.http.get(`${this.API_URL}/skills`).pipe(map((res) => res.skills || []));
  }
  // Opcional: si necesitás obtener skills filtradas por una categoría en particular
  getSkillsPorCategoria(idCategoria) {
    return this.http.get(`${this.API_URL}/categorias/${idCategoria}/skills`).pipe(map((res) => res.skills || []));
  }
  crearSkill(payload) {
    return this.http.post(`${this.API_URL}/skills`, payload);
  }
  actualizarSkill(id, payload) {
    return this.http.put(`${this.API_URL}/skills/${id}`, payload);
  }
  eliminarSkill(id) {
    return this.http.delete(`${this.API_URL}/skills/${id}`);
  }
  static \u0275fac = function AdminService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _AdminService)();
  };
  static \u0275prov = /* @__PURE__ */ i010.\u0275\u0275defineInjectable({ token: _AdminService, factory: _AdminService.\u0275fac, providedIn: "root" });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i010.\u0275setClassMetadata(AdminService, [{
    type: Injectable3,
    args: [{
      providedIn: "root"
    }]
  }], null, null);
})();

// src/app/pagina/panel-admin/skills/skills.ts
import * as i011 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import * as i17 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_common.js?v=3d725e17";
import * as i23 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_forms.js?v=3d725e17";
var _forTrack04 = ($index, $item) => $item.id;
function Skills_For_19_Template(rf, ctx) {
  if (rf & 1) {
    i011.\u0275\u0275elementStart(0, "option", 9);
    i011.\u0275\u0275text(1);
    i011.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const cat_r1 = ctx.$implicit;
    i011.\u0275\u0275property("value", cat_r1.id);
    i011.\u0275\u0275advance();
    i011.\u0275\u0275textInterpolate(cat_r1.nombre);
  }
}
function Skills_For_34_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = i011.\u0275\u0275getCurrentView();
    i011.\u0275\u0275elementStart(0, "tr")(1, "td");
    i011.\u0275\u0275text(2);
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275elementStart(3, "td")(4, "strong");
    i011.\u0275\u0275text(5);
    i011.\u0275\u0275elementEnd()();
    i011.\u0275\u0275elementStart(6, "td")(7, "span", 13);
    i011.\u0275\u0275text(8);
    i011.\u0275\u0275elementEnd()();
    i011.\u0275\u0275elementStart(9, "td", 11)(10, "button", 14);
    i011.\u0275\u0275listener("click", function Skills_For_34_Template_button_click_10_listener() {
      const skill_r4 = i011.\u0275\u0275restoreView(_r3).$implicit;
      const ctx_r1 = i011.\u0275\u0275nextContext();
      return i011.\u0275\u0275resetView(ctx_r1.prepararEdicion(skill_r4));
    });
    i011.\u0275\u0275text(11, " \u270F\uFE0F ");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275elementStart(12, "button", 15);
    i011.\u0275\u0275listener("click", function Skills_For_34_Template_button_click_12_listener() {
      const skill_r4 = i011.\u0275\u0275restoreView(_r3).$implicit;
      const ctx_r1 = i011.\u0275\u0275nextContext();
      return i011.\u0275\u0275resetView(ctx_r1.eliminarSkill(skill_r4.id));
    });
    i011.\u0275\u0275text(13, " \u{1F5D1}\uFE0F ");
    i011.\u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const skill_r4 = ctx.$implicit;
    const ctx_r1 = i011.\u0275\u0275nextContext();
    i011.\u0275\u0275advance(2);
    i011.\u0275\u0275textInterpolate1("#", skill_r4.id);
    i011.\u0275\u0275advance(3);
    i011.\u0275\u0275textInterpolate(skill_r4.nombre);
    i011.\u0275\u0275advance(3);
    i011.\u0275\u0275textInterpolate(ctx_r1.obtenerNombreCategoria(skill_r4.categoria_id));
  }
}
function Skills_ForEmpty_35_Template(rf, ctx) {
  if (rf & 1) {
    i011.\u0275\u0275elementStart(0, "tr")(1, "td", 16);
    i011.\u0275\u0275text(2);
    i011.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = i011.\u0275\u0275nextContext();
    i011.\u0275\u0275advance(2);
    i011.\u0275\u0275textInterpolate1(" ", ctx_r1.cargando ? "Cargando habilidades..." : "No se encontraron habilidades.", " ");
  }
}
function Skills_Conditional_36_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    i011.\u0275\u0275elementStart(0, "span", 25);
    i011.\u0275\u0275text(1, "El nombre es obligatorio (m\xEDnimo 2 caracteres).");
    i011.\u0275\u0275elementEnd();
  }
}
function Skills_Conditional_36_For_20_Template(rf, ctx) {
  if (rf & 1) {
    i011.\u0275\u0275elementStart(0, "option", 9);
    i011.\u0275\u0275text(1);
    i011.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const cat_r6 = ctx.$implicit;
    i011.\u0275\u0275property("value", cat_r6.id);
    i011.\u0275\u0275advance();
    i011.\u0275\u0275textInterpolate(cat_r6.nombre);
  }
}
function Skills_Conditional_36_Conditional_21_Template(rf, ctx) {
  if (rf & 1) {
    i011.\u0275\u0275elementStart(0, "span", 25);
    i011.\u0275\u0275text(1, "Seleccion\xE1 una categor\xEDa v\xE1lida.");
    i011.\u0275\u0275elementEnd();
  }
}
function Skills_Conditional_36_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = i011.\u0275\u0275getCurrentView();
    i011.\u0275\u0275elementStart(0, "div", 17);
    i011.\u0275\u0275listener("click", function Skills_Conditional_36_Template_div_click_0_listener() {
      i011.\u0275\u0275restoreView(_r5);
      const ctx_r1 = i011.\u0275\u0275nextContext();
      return i011.\u0275\u0275resetView(ctx_r1.cerrarModal());
    });
    i011.\u0275\u0275elementStart(1, "div", 18);
    i011.\u0275\u0275listener("click", function Skills_Conditional_36_Template_div_click_1_listener($event) {
      return $event.stopPropagation();
    });
    i011.\u0275\u0275elementStart(2, "header", 19)(3, "h4");
    i011.\u0275\u0275text(4);
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275elementStart(5, "button", 20);
    i011.\u0275\u0275listener("click", function Skills_Conditional_36_Template_button_click_5_listener() {
      i011.\u0275\u0275restoreView(_r5);
      const ctx_r1 = i011.\u0275\u0275nextContext();
      return i011.\u0275\u0275resetView(ctx_r1.cerrarModal());
    });
    i011.\u0275\u0275text(6, "\u2715");
    i011.\u0275\u0275elementEnd()();
    i011.\u0275\u0275elementStart(7, "form", 21);
    i011.\u0275\u0275listener("ngSubmit", function Skills_Conditional_36_Template_form_ngSubmit_7_listener() {
      i011.\u0275\u0275restoreView(_r5);
      const ctx_r1 = i011.\u0275\u0275nextContext();
      return i011.\u0275\u0275resetView(ctx_r1.guardarSkill());
    });
    i011.\u0275\u0275elementStart(8, "div", 22)(9, "label", 23);
    i011.\u0275\u0275text(10, "Nombre de la Habilidad");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275element(11, "input", 24);
    i011.\u0275\u0275conditionalCreate(12, Skills_Conditional_36_Conditional_12_Template, 2, 0, "span", 25);
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275elementStart(13, "div", 22)(14, "label", 26);
    i011.\u0275\u0275text(15, "Categor\xEDa");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275elementStart(16, "select", 27)(17, "option", 28);
    i011.\u0275\u0275text(18, "Seleccion\xE1 una categor\xEDa");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275repeaterCreate(19, Skills_Conditional_36_For_20_Template, 2, 2, "option", 9, _forTrack04);
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275conditionalCreate(21, Skills_Conditional_36_Conditional_21_Template, 2, 0, "span", 25);
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275elementStart(22, "div", 29)(23, "button", 30);
    i011.\u0275\u0275listener("click", function Skills_Conditional_36_Template_button_click_23_listener() {
      i011.\u0275\u0275restoreView(_r5);
      const ctx_r1 = i011.\u0275\u0275nextContext();
      return i011.\u0275\u0275resetView(ctx_r1.cerrarModal());
    });
    i011.\u0275\u0275text(24, " Cancelar ");
    i011.\u0275\u0275elementEnd();
    i011.\u0275\u0275elementStart(25, "button", 31);
    i011.\u0275\u0275text(26);
    i011.\u0275\u0275elementEnd()()()()();
  }
  if (rf & 2) {
    let tmp_3_0;
    let tmp_4_0;
    let tmp_5_0;
    let tmp_7_0;
    const ctx_r1 = i011.\u0275\u0275nextContext();
    i011.\u0275\u0275advance(4);
    i011.\u0275\u0275textInterpolate(ctx_r1.modoEdicion ? "\u270F\uFE0F Editar Habilidad" : "\u2795 Nueva Habilidad");
    i011.\u0275\u0275advance(3);
    i011.\u0275\u0275property("formGroup", ctx_r1.skillForm);
    i011.\u0275\u0275advance(4);
    i011.\u0275\u0275classProp("is-invalid", ((tmp_3_0 = ctx_r1.skillForm.get("nombre")) == null ? null : tmp_3_0.invalid) && ((tmp_3_0 = ctx_r1.skillForm.get("nombre")) == null ? null : tmp_3_0.touched));
    i011.\u0275\u0275advance();
    i011.\u0275\u0275conditional(((tmp_4_0 = ctx_r1.skillForm.get("nombre")) == null ? null : tmp_4_0.invalid) && ((tmp_4_0 = ctx_r1.skillForm.get("nombre")) == null ? null : tmp_4_0.touched) ? 12 : -1);
    i011.\u0275\u0275advance(4);
    i011.\u0275\u0275classProp("is-invalid", ((tmp_5_0 = ctx_r1.skillForm.get("categoria_id")) == null ? null : tmp_5_0.invalid) && ((tmp_5_0 = ctx_r1.skillForm.get("categoria_id")) == null ? null : tmp_5_0.touched));
    i011.\u0275\u0275advance(3);
    i011.\u0275\u0275repeater(ctx_r1.categorias);
    i011.\u0275\u0275advance(2);
    i011.\u0275\u0275conditional(((tmp_7_0 = ctx_r1.skillForm.get("categoria_id")) == null ? null : tmp_7_0.invalid) && ((tmp_7_0 = ctx_r1.skillForm.get("categoria_id")) == null ? null : tmp_7_0.touched) ? 21 : -1);
    i011.\u0275\u0275advance(4);
    i011.\u0275\u0275property("disabled", ctx_r1.skillForm.invalid);
    i011.\u0275\u0275advance();
    i011.\u0275\u0275textInterpolate1(" ", ctx_r1.modoEdicion ? "Guardar Cambios" : "Crear Habilidad", " ");
  }
}
var Skills = class _Skills {
  fb = inject8(FormBuilder2);
  adminService = inject8(AdminService);
  categorias = [];
  skills = [];
  skillsFiltradas = [];
  categoriaSeleccionadaId = "todas";
  textoBusqueda = "";
  modalAbierto = false;
  modoEdicion = false;
  idSkillEnEdicion = null;
  cargando = false;
  skillForm = this.fb.group({
    nombre: ["", [Validators5.required, Validators5.minLength(2)]],
    categoria_id: ["", [Validators5.required]]
  });
  ngOnInit() {
    this.cargarCategorias();
    this.cargarSkills();
  }
  cargarCategorias() {
    this.adminService.getCategoriasSkills().subscribe({
      next: (data) => this.categorias = data,
      error: (err) => console.error("Error al cargar categor\xEDas", err)
    });
  }
  obtenerNombreCategoria(categoriaId) {
    if (!categoriaId || this.categorias.length === 0)
      return "Sin categor\xEDa";
    const cat = this.categorias.find((c) => Number(c.id) === Number(categoriaId));
    return cat ? cat.nombre : "Sin categor\xEDa";
  }
  cargarSkills() {
    this.cargando = true;
    this.adminService.getSkills().subscribe({
      next: (data) => {
        this.skills = data;
        this.aplicarFiltros();
        this.cargando = false;
      },
      error: (err) => {
        console.error("Error al cargar skills", err);
        this.cargando = false;
      }
    });
  }
  aplicarFiltros() {
    this.skillsFiltradas = this.skills.filter((s) => {
      const coincideCategoria = this.categoriaSeleccionadaId === "todas" || s.categoria_id === Number(this.categoriaSeleccionadaId);
      const coincideTexto = s.nombre.toLowerCase().includes(this.textoBusqueda.toLowerCase().trim());
      return coincideCategoria && coincideTexto;
    });
  }
  onBuscarTexto(event) {
    this.textoBusqueda = event.target.value;
    this.aplicarFiltros();
  }
  onSeleccionarCategoria(event) {
    const valor = event.target.value;
    this.categoriaSeleccionadaId = valor === "todas" ? "todas" : Number(valor);
    this.aplicarFiltros();
  }
  abrirModalCrear() {
    this.modoEdicion = false;
    this.idSkillEnEdicion = null;
    this.skillForm.reset();
    this.modalAbierto = true;
  }
  prepararEdicion(skill) {
    this.modoEdicion = true;
    this.idSkillEnEdicion = skill.id;
    this.skillForm.patchValue({
      nombre: skill.nombre,
      categoria_id: skill.categoria_id
    });
    this.modalAbierto = true;
  }
  cerrarModal() {
    this.modalAbierto = false;
    this.modoEdicion = false;
    this.idSkillEnEdicion = null;
    this.skillForm.reset();
  }
  guardarSkill() {
    if (this.skillForm.invalid) {
      this.skillForm.markAllAsTouched();
      return;
    }
    const payload = {
      nombre: this.skillForm.value.nombre,
      categoria_id: Number(this.skillForm.value.categoria_id)
    };
    if (this.modoEdicion && this.idSkillEnEdicion) {
      this.adminService.actualizarSkill(this.idSkillEnEdicion, payload).subscribe({
        next: () => {
          this.cargarSkills();
          this.cerrarModal();
        },
        error: (err) => console.error("Error al actualizar skill:", err)
      });
    } else {
      this.adminService.crearSkill(payload).subscribe({
        next: () => {
          this.cargarSkills();
          this.cerrarModal();
        },
        error: (err) => console.error("Error al crear skill:", err)
      });
    }
  }
  eliminarSkill(id) {
    if (confirm("\xBFEst\xE1s seguro de eliminar esta habilidad?")) {
      this.adminService.eliminarSkill(id).subscribe({
        next: () => this.cargarSkills(),
        error: (err) => console.error("Error al eliminar skill:", err)
      });
    }
  }
  static \u0275fac = function Skills_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Skills)();
  };
  static \u0275cmp = /* @__PURE__ */ i011.\u0275\u0275defineComponent({ type: _Skills, selectors: [["app-skills"]], decls: 37, vars: 3, consts: [[1, "skills-container"], [1, "header-section"], [1, "btn-primary", 3, "click"], [1, "card-list"], [1, "list-header"], [1, "controles-busqueda"], ["type", "text", "placeholder", "\u{1F50D} Buscar skill...", 1, "input-search", 3, "input"], [1, "select-cat", 3, "change"], ["value", "todas"], [3, "value"], [1, "table-responsive"], [1, "text-right"], [1, "modal-backdrop"], [1, "badge-cat"], ["title", "Editar", 1, "btn-icon", "edit", 3, "click"], ["title", "Eliminar", 1, "btn-icon", "delete", 3, "click"], ["colspan", "4", 1, "empty-state"], [1, "modal-backdrop", 3, "click"], [1, "modal-content", "card-form", 3, "click"], [1, "modal-header"], ["type", "button", 1, "btn-close", 3, "click"], [3, "ngSubmit", "formGroup"], [1, "form-group"], ["for", "nombre"], ["type", "text", "id", "nombre", "formControlName", "nombre", "placeholder", "Ej: Angular, Python, SQL..."], [1, "error-msg"], ["for", "categoria_id"], ["id", "categoria_id", "formControlName", "categoria_id"], ["value", "", "disabled", "", "selected", ""], [1, "form-actions"], ["type", "button", 1, "btn-secondary", 3, "click"], ["type", "submit", 1, "btn-primary", 3, "disabled"]], template: function Skills_Template(rf, ctx) {
    if (rf & 1) {
      i011.\u0275\u0275elementStart(0, "div", 0)(1, "header", 1)(2, "div")(3, "h3");
      i011.\u0275\u0275text(4, "\u{1F6E0}\uFE0F Gesti\xF3n de Habilidades (Skills)");
      i011.\u0275\u0275elementEnd();
      i011.\u0275\u0275elementStart(5, "p");
      i011.\u0275\u0275text(6, "Cat\xE1logo global de conocimientos t\xE9cnicos e institucionales.");
      i011.\u0275\u0275elementEnd()();
      i011.\u0275\u0275elementStart(7, "button", 2);
      i011.\u0275\u0275listener("click", function Skills_Template_button_click_7_listener() {
        return ctx.abrirModalCrear();
      });
      i011.\u0275\u0275text(8, " \u2795 Nueva Habilidad ");
      i011.\u0275\u0275elementEnd()();
      i011.\u0275\u0275elementStart(9, "section", 3)(10, "div", 4)(11, "h4");
      i011.\u0275\u0275text(12);
      i011.\u0275\u0275elementEnd();
      i011.\u0275\u0275elementStart(13, "div", 5)(14, "input", 6);
      i011.\u0275\u0275listener("input", function Skills_Template_input_input_14_listener($event) {
        return ctx.onBuscarTexto($event);
      });
      i011.\u0275\u0275elementEnd();
      i011.\u0275\u0275elementStart(15, "select", 7);
      i011.\u0275\u0275listener("change", function Skills_Template_select_change_15_listener($event) {
        return ctx.onSeleccionarCategoria($event);
      });
      i011.\u0275\u0275elementStart(16, "option", 8);
      i011.\u0275\u0275text(17, "Todas las categor\xEDas");
      i011.\u0275\u0275elementEnd();
      i011.\u0275\u0275repeaterCreate(18, Skills_For_19_Template, 2, 2, "option", 9, _forTrack04);
      i011.\u0275\u0275elementEnd()()();
      i011.\u0275\u0275elementStart(20, "div", 10)(21, "table")(22, "thead")(23, "tr")(24, "th");
      i011.\u0275\u0275text(25, "ID");
      i011.\u0275\u0275elementEnd();
      i011.\u0275\u0275elementStart(26, "th");
      i011.\u0275\u0275text(27, "Habilidad");
      i011.\u0275\u0275elementEnd();
      i011.\u0275\u0275elementStart(28, "th");
      i011.\u0275\u0275text(29, "Categor\xEDa");
      i011.\u0275\u0275elementEnd();
      i011.\u0275\u0275elementStart(30, "th", 11);
      i011.\u0275\u0275text(31, "Acciones");
      i011.\u0275\u0275elementEnd()()();
      i011.\u0275\u0275elementStart(32, "tbody");
      i011.\u0275\u0275repeaterCreate(33, Skills_For_34_Template, 14, 3, "tr", null, _forTrack04, false, Skills_ForEmpty_35_Template, 3, 1, "tr");
      i011.\u0275\u0275elementEnd()()()();
      i011.\u0275\u0275conditionalCreate(36, Skills_Conditional_36_Template, 27, 10, "div", 12);
      i011.\u0275\u0275elementEnd();
    }
    if (rf & 2) {
      i011.\u0275\u0275advance(12);
      i011.\u0275\u0275textInterpolate1("Listado de Habilidades (", ctx.skillsFiltradas.length, ")");
      i011.\u0275\u0275advance(6);
      i011.\u0275\u0275repeater(ctx.categorias);
      i011.\u0275\u0275advance(15);
      i011.\u0275\u0275repeater(ctx.skillsFiltradas);
      i011.\u0275\u0275advance(3);
      i011.\u0275\u0275conditional(ctx.modalAbierto ? 36 : -1);
    }
  }, dependencies: [CommonModule5, i17.NgClass, i17.NgComponentOutlet, i17.NgForOf, i17.NgIf, i17.NgTemplateOutlet, i17.NgStyle, i17.NgSwitch, i17.NgSwitchCase, i17.NgSwitchDefault, i17.NgPlural, i17.NgPluralCase, ReactiveFormsModule5, i23.\u0275NgNoValidate, i23.NgSelectOption, i23.\u0275NgSelectMultipleOption, i23.DefaultValueAccessor, i23.NumberValueAccessor, i23.RangeValueAccessor, i23.CheckboxControlValueAccessor, i23.SelectControlValueAccessor, i23.SelectMultipleControlValueAccessor, i23.RadioControlValueAccessor, i23.NgControlStatus, i23.NgControlStatusGroup, i23.RequiredValidator, i23.MinLengthValidator, i23.MaxLengthValidator, i23.PatternValidator, i23.CheckboxRequiredValidator, i23.EmailValidator, i23.MinValidator, i23.MaxValidator, i23.FormControlDirective, i23.FormGroupDirective, i23.FormArrayDirective, i23.FormControlName, i23.FormGroupName, i23.FormArrayName, FormsModule2, i23.NgModel, i23.NgModelGroup, i23.NgForm, i17.AsyncPipe, i17.UpperCasePipe, i17.LowerCasePipe, i17.JsonPipe, i17.SlicePipe, i17.DecimalPipe, i17.PercentPipe, i17.TitleCasePipe, i17.CurrencyPipe, i17.DatePipe, i17.I18nPluralPipe, i17.I18nSelectPipe, i17.KeyValuePipe], styles: ["\n[_nghost-%COMP%] {\n  display: block;\n  width: 100%;\n}\n.skills-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 1.5rem;\n}\n.skills-container[_ngcontent-%COMP%]   .header-section[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\n.skills-container[_ngcontent-%COMP%]   .header-section[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  font-size: 1.4rem;\n  color: #321f57;\n  margin-bottom: 0.2rem;\n}\n.skills-container[_ngcontent-%COMP%]   .header-section[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  color: #5d4b7a;\n  font-size: 0.875rem;\n}\n.skills-container[_ngcontent-%COMP%] {\n}\n.skills-container[_ngcontent-%COMP%]   .btn-primary[_ngcontent-%COMP%] {\n  background-color: #7755f4;\n  color: #ffffff;\n  border: none;\n  padding: 0.6rem 1.1rem;\n  border-radius: 6px;\n  font-size: 0.875rem;\n  font-weight: 600;\n  cursor: pointer;\n  transition: background-color 0.2s ease;\n}\n.skills-container[_ngcontent-%COMP%]   .btn-primary[_ngcontent-%COMP%]:hover {\n  background-color: rgb(88.3436464088, 46.679558011, 241.520441989);\n}\n.skills-container[_ngcontent-%COMP%]   .btn-primary[_ngcontent-%COMP%]:disabled {\n  background-color: #a991e6;\n  opacity: 0.6;\n  cursor: not-allowed;\n}\n.skills-container[_ngcontent-%COMP%]   .btn-secondary[_ngcontent-%COMP%] {\n  background-color: #e9e1ff;\n  color: #321f57;\n  border: 1px solid #bfa9f5;\n  padding: 0.6rem 1rem;\n  border-radius: 6px;\n  font-size: 0.875rem;\n  font-weight: 600;\n  cursor: pointer;\n}\n.skills-container[_ngcontent-%COMP%]   .btn-secondary[_ngcontent-%COMP%]:hover {\n  background-color: rgb(218.04, 204.6, 255);\n}\n.skills-container[_ngcontent-%COMP%] {\n}\n.skills-container[_ngcontent-%COMP%]   .card-list[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border: 1px solid #d2c2ff;\n  border-radius: 10px;\n  padding: 1.25rem;\n  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);\n}\n.skills-container[_ngcontent-%COMP%]   .card-list[_ngcontent-%COMP%]   .list-header[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-bottom: 1.2rem;\n  flex-wrap: wrap;\n  gap: 1rem;\n}\n.skills-container[_ngcontent-%COMP%]   .card-list[_ngcontent-%COMP%]   .list-header[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  font-size: 1.1rem;\n  color: #321f57;\n}\n.skills-container[_ngcontent-%COMP%]   .card-list[_ngcontent-%COMP%]   .list-header[_ngcontent-%COMP%]   .controles-busqueda[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 0.5rem;\n}\n.skills-container[_ngcontent-%COMP%]   .card-list[_ngcontent-%COMP%]   .list-header[_ngcontent-%COMP%]   .controles-busqueda[_ngcontent-%COMP%]   .input-search[_ngcontent-%COMP%], \n.skills-container[_ngcontent-%COMP%]   .card-list[_ngcontent-%COMP%]   .list-header[_ngcontent-%COMP%]   .controles-busqueda[_ngcontent-%COMP%]   .select-cat[_ngcontent-%COMP%] {\n  padding: 0.45rem 0.75rem;\n  border: 1px solid #a991e6;\n  border-radius: 6px;\n  font-size: 0.85rem;\n  outline: none;\n  color: #321f57;\n  background-color: #ffffff;\n}\n.skills-container[_ngcontent-%COMP%]   .card-list[_ngcontent-%COMP%]   .list-header[_ngcontent-%COMP%]   .controles-busqueda[_ngcontent-%COMP%]   .input-search[_ngcontent-%COMP%]:focus, \n.skills-container[_ngcontent-%COMP%]   .card-list[_ngcontent-%COMP%]   .list-header[_ngcontent-%COMP%]   .controles-busqueda[_ngcontent-%COMP%]   .select-cat[_ngcontent-%COMP%]:focus {\n  border-color: #7755f4;\n}\n.skills-container[_ngcontent-%COMP%]   .card-list[_ngcontent-%COMP%]   .list-header[_ngcontent-%COMP%]   .controles-busqueda[_ngcontent-%COMP%]   .input-search[_ngcontent-%COMP%] {\n  min-width: 200px;\n}\n.skills-container[_ngcontent-%COMP%]   .card-list[_ngcontent-%COMP%]   .table-responsive[_ngcontent-%COMP%] {\n  overflow-x: auto;\n}\n.skills-container[_ngcontent-%COMP%]   .card-list[_ngcontent-%COMP%]   .table-responsive[_ngcontent-%COMP%]   table[_ngcontent-%COMP%] {\n  width: 100%;\n  border-collapse: collapse;\n}\n.skills-container[_ngcontent-%COMP%]   .card-list[_ngcontent-%COMP%]   .table-responsive[_ngcontent-%COMP%]   table[_ngcontent-%COMP%]   th[_ngcontent-%COMP%], \n.skills-container[_ngcontent-%COMP%]   .card-list[_ngcontent-%COMP%]   .table-responsive[_ngcontent-%COMP%]   table[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\n  padding: 0.8rem 1rem;\n  text-align: left;\n  border-bottom: 1px solid #d2c2ff;\n  font-size: 0.9rem;\n  color: #321f57;\n}\n.skills-container[_ngcontent-%COMP%]   .card-list[_ngcontent-%COMP%]   .table-responsive[_ngcontent-%COMP%]   table[_ngcontent-%COMP%]   th[_ngcontent-%COMP%] {\n  background-color: #e9e1ff;\n  color: #321f57;\n  font-weight: 600;\n}\n.skills-container[_ngcontent-%COMP%]   .card-list[_ngcontent-%COMP%]   .table-responsive[_ngcontent-%COMP%]   table[_ngcontent-%COMP%]   .badge-cat[_ngcontent-%COMP%] {\n  background-color: #e9e1ff;\n  color: #5b44c2;\n  padding: 0.25rem 0.6rem;\n  border-radius: 12px;\n  font-size: 0.8rem;\n  font-weight: 600;\n  border: 1px solid #bfa9f5;\n}\n.skills-container[_ngcontent-%COMP%]   .card-list[_ngcontent-%COMP%]   .table-responsive[_ngcontent-%COMP%]   table[_ngcontent-%COMP%]   .text-right[_ngcontent-%COMP%] {\n  text-align: right;\n}\n.skills-container[_ngcontent-%COMP%]   .card-list[_ngcontent-%COMP%]   .table-responsive[_ngcontent-%COMP%]   table[_ngcontent-%COMP%]   .btn-icon[_ngcontent-%COMP%] {\n  background: none;\n  border: none;\n  cursor: pointer;\n  font-size: 1rem;\n  padding: 0.3rem 0.5rem;\n  border-radius: 4px;\n}\n.skills-container[_ngcontent-%COMP%]   .card-list[_ngcontent-%COMP%]   .table-responsive[_ngcontent-%COMP%]   table[_ngcontent-%COMP%]   .btn-icon[_ngcontent-%COMP%]:hover {\n  background-color: #e9e1ff;\n}\n.skills-container[_ngcontent-%COMP%]   .card-list[_ngcontent-%COMP%]   .table-responsive[_ngcontent-%COMP%]   table[_ngcontent-%COMP%]   .empty-state[_ngcontent-%COMP%] {\n  text-align: center;\n  color: #5d4b7a;\n  padding: 2rem 0;\n}\n.skills-container[_ngcontent-%COMP%] {\n}\n.skills-container[_ngcontent-%COMP%]   .modal-backdrop[_ngcontent-%COMP%] {\n  position: fixed;\n  top: 0;\n  left: 0;\n  width: 100vw;\n  height: 100vh;\n  background-color: rgba(42, 31, 76, 0.4);\n  -webkit-backdrop-filter: blur(2px);\n  backdrop-filter: blur(2px);\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  z-index: 1000;\n}\n.skills-container[_ngcontent-%COMP%]   .modal-backdrop[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%] {\n  background: #ffffff;\n  width: 100%;\n  max-width: 450px;\n  border-radius: 12px;\n  padding: 1.5rem;\n  border: 1px solid #d2c2ff;\n  box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);\n  animation: _ngcontent-%COMP%_modalFadeIn 0.2s ease-out;\n}\n.skills-container[_ngcontent-%COMP%]   .modal-backdrop[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%]   .modal-header[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-bottom: 1.25rem;\n}\n.skills-container[_ngcontent-%COMP%]   .modal-backdrop[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%]   .modal-header[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  font-size: 1.15rem;\n  color: #321f57;\n}\n.skills-container[_ngcontent-%COMP%]   .modal-backdrop[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%]   .modal-header[_ngcontent-%COMP%]   .btn-close[_ngcontent-%COMP%] {\n  background: none;\n  border: none;\n  font-size: 1.2rem;\n  color: #5d4b7a;\n  cursor: pointer;\n}\n.skills-container[_ngcontent-%COMP%]   .modal-backdrop[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%]   .modal-header[_ngcontent-%COMP%]   .btn-close[_ngcontent-%COMP%]:hover {\n  color: #321f57;\n}\n.skills-container[_ngcontent-%COMP%]   .modal-backdrop[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 0.4rem;\n  margin-bottom: 1rem;\n}\n.skills-container[_ngcontent-%COMP%]   .modal-backdrop[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  font-size: 0.85rem;\n  font-weight: 600;\n  color: #321f57;\n}\n.skills-container[_ngcontent-%COMP%]   .modal-backdrop[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   input[_ngcontent-%COMP%], \n.skills-container[_ngcontent-%COMP%]   .modal-backdrop[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   select[_ngcontent-%COMP%] {\n  padding: 0.65rem 0.8rem;\n  border: 1px solid #a991e6;\n  border-radius: 6px;\n  font-size: 0.9rem;\n  outline: none;\n  color: #321f57;\n  background-color: #ffffff;\n}\n.skills-container[_ngcontent-%COMP%]   .modal-backdrop[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   input[_ngcontent-%COMP%]:focus, \n.skills-container[_ngcontent-%COMP%]   .modal-backdrop[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   select[_ngcontent-%COMP%]:focus {\n  border-color: #7755f4;\n}\n.skills-container[_ngcontent-%COMP%]   .modal-backdrop[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   input.is-invalid[_ngcontent-%COMP%], \n.skills-container[_ngcontent-%COMP%]   .modal-backdrop[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   select.is-invalid[_ngcontent-%COMP%] {\n  border-color: #dc2626;\n}\n.skills-container[_ngcontent-%COMP%]   .modal-backdrop[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%]   .form-group[_ngcontent-%COMP%]   .error-msg[_ngcontent-%COMP%] {\n  color: #dc2626;\n  font-size: 0.75rem;\n}\n.skills-container[_ngcontent-%COMP%]   .modal-backdrop[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%]   .form-actions[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: flex-end;\n  gap: 0.75rem;\n  margin-top: 1.5rem;\n}\n@keyframes _ngcontent-%COMP%_modalFadeIn {\n  from {\n    opacity: 0;\n    transform: translateY(-10px);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0);\n  }\n}\n/*# sourceMappingURL=skills.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i011.\u0275setClassMetadata(Skills, [{
    type: Component8,
    args: [{ selector: "app-skills", standalone: true, imports: [CommonModule5, ReactiveFormsModule5, FormsModule2], template: `<div class="skills-container">
  <header class="header-section">
    <div>
      <h3>\u{1F6E0}\uFE0F Gesti\xF3n de Habilidades (Skills)</h3>
      <p>Cat\xE1logo global de conocimientos t\xE9cnicos e institucionales.</p>
    </div>
    <button class="btn-primary" (click)="abrirModalCrear()">
      \u2795 Nueva Habilidad
    </button>
  </header>

  <!-- Tabla Principal de Ancho Completo -->
  <section class="card-list">
    <div class="list-header">
      <h4>Listado de Habilidades ({{ skillsFiltradas.length }})</h4>

      <div class="controles-busqueda">
        <input
          type="text"
          class="input-search"
          placeholder="\u{1F50D} Buscar skill..."
          (input)="onBuscarTexto($event)"
        />

        <select class="select-cat" (change)="onSeleccionarCategoria($event)">
          <option value="todas">Todas las categor\xEDas</option>
          @for (cat of categorias; track cat.id) {
            <option [value]="cat.id">{{ cat.nombre }}</option>
          }
        </select>
      </div>
    </div>

    <div class="table-responsive">
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Habilidad</th>
            <th>Categor\xEDa</th>
            <th class="text-right">Acciones</th>
          </tr>
        </thead>
        <tbody>
          @for (skill of skillsFiltradas; track skill.id) {
            <tr>
              <td>#{{ skill.id }}</td>
              <td><strong>{{ skill.nombre }}</strong></td>
              <td>
                <span class="badge-cat">{{ obtenerNombreCategoria(skill.categoria_id) }}</span>
              </td>
              <td class="text-right">
                <button class="btn-icon edit" (click)="prepararEdicion(skill)" title="Editar">
                  \u270F\uFE0F
                </button>
                <button class="btn-icon delete" (click)="eliminarSkill(skill.id)" title="Eliminar">
                  \u{1F5D1}\uFE0F
                </button>
              </td>
            </tr>
          } @empty {
            <tr>
              <td colspan="4" class="empty-state">
                {{ cargando ? 'Cargando habilidades...' : 'No se encontraron habilidades.' }}
              </td>
            </tr>
          }
        </tbody>
      </table>
    </div>
  </section>

  <!-- MODAL FLOTANTE DE REGISTRO / EDICI\xD3N -->
  @if (modalAbierto) {
    <div class="modal-backdrop" (click)="cerrarModal()">
      <div class="modal-content card-form" (click)="$event.stopPropagation()">
        <header class="modal-header">
          <h4>{{ modoEdicion ? '\u270F\uFE0F Editar Habilidad' : '\u2795 Nueva Habilidad' }}</h4>
          <button type="button" class="btn-close" (click)="cerrarModal()">\u2715</button>
        </header>

        <form [formGroup]="skillForm" (ngSubmit)="guardarSkill()">
          <div class="form-group">
            <label for="nombre">Nombre de la Habilidad</label>
            <input
              type="text"
              id="nombre"
              formControlName="nombre"
              placeholder="Ej: Angular, Python, SQL..."
              [class.is-invalid]="skillForm.get('nombre')?.invalid && skillForm.get('nombre')?.touched"
            />
            @if (skillForm.get('nombre')?.invalid && skillForm.get('nombre')?.touched) {
              <span class="error-msg">El nombre es obligatorio (m\xEDnimo 2 caracteres).</span>
            }
          </div>

          <div class="form-group">
            <label for="categoria_id">Categor\xEDa</label>
            <select
              id="categoria_id"
              formControlName="categoria_id"
              [class.is-invalid]="skillForm.get('categoria_id')?.invalid && skillForm.get('categoria_id')?.touched"
            >
              <option value="" disabled selected>Seleccion\xE1 una categor\xEDa</option>
              @for (cat of categorias; track cat.id) {
                <option [value]="cat.id">{{ cat.nombre }}</option>
              }
            </select>
            @if (skillForm.get('categoria_id')?.invalid && skillForm.get('categoria_id')?.touched) {
              <span class="error-msg">Seleccion\xE1 una categor\xEDa v\xE1lida.</span>
            }
          </div>

          <div class="form-actions">
            <button type="button" class="btn-secondary" (click)="cerrarModal()">
              Cancelar
            </button>
            <button type="submit" class="btn-primary" [disabled]="skillForm.invalid">
              {{ modoEdicion ? 'Guardar Cambios' : 'Crear Habilidad' }}
            </button>
          </div>
        </form>
      </div>
    </div>
  }
</div>`, styles: ["/* src/app/pagina/panel-admin/skills/skills.scss */\n:host {\n  display: block;\n  width: 100%;\n}\n.skills-container {\n  display: flex;\n  flex-direction: column;\n  gap: 1.5rem;\n}\n.skills-container .header-section {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\n.skills-container .header-section h3 {\n  font-size: 1.4rem;\n  color: #321f57;\n  margin-bottom: 0.2rem;\n}\n.skills-container .header-section p {\n  color: #5d4b7a;\n  font-size: 0.875rem;\n}\n.skills-container {\n}\n.skills-container .btn-primary {\n  background-color: #7755f4;\n  color: #ffffff;\n  border: none;\n  padding: 0.6rem 1.1rem;\n  border-radius: 6px;\n  font-size: 0.875rem;\n  font-weight: 600;\n  cursor: pointer;\n  transition: background-color 0.2s ease;\n}\n.skills-container .btn-primary:hover {\n  background-color: rgb(88.3436464088, 46.679558011, 241.520441989);\n}\n.skills-container .btn-primary:disabled {\n  background-color: #a991e6;\n  opacity: 0.6;\n  cursor: not-allowed;\n}\n.skills-container .btn-secondary {\n  background-color: #e9e1ff;\n  color: #321f57;\n  border: 1px solid #bfa9f5;\n  padding: 0.6rem 1rem;\n  border-radius: 6px;\n  font-size: 0.875rem;\n  font-weight: 600;\n  cursor: pointer;\n}\n.skills-container .btn-secondary:hover {\n  background-color: rgb(218.04, 204.6, 255);\n}\n.skills-container {\n}\n.skills-container .card-list {\n  background: #ffffff;\n  border: 1px solid #d2c2ff;\n  border-radius: 10px;\n  padding: 1.25rem;\n  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);\n}\n.skills-container .card-list .list-header {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-bottom: 1.2rem;\n  flex-wrap: wrap;\n  gap: 1rem;\n}\n.skills-container .card-list .list-header h4 {\n  font-size: 1.1rem;\n  color: #321f57;\n}\n.skills-container .card-list .list-header .controles-busqueda {\n  display: flex;\n  gap: 0.5rem;\n}\n.skills-container .card-list .list-header .controles-busqueda .input-search,\n.skills-container .card-list .list-header .controles-busqueda .select-cat {\n  padding: 0.45rem 0.75rem;\n  border: 1px solid #a991e6;\n  border-radius: 6px;\n  font-size: 0.85rem;\n  outline: none;\n  color: #321f57;\n  background-color: #ffffff;\n}\n.skills-container .card-list .list-header .controles-busqueda .input-search:focus,\n.skills-container .card-list .list-header .controles-busqueda .select-cat:focus {\n  border-color: #7755f4;\n}\n.skills-container .card-list .list-header .controles-busqueda .input-search {\n  min-width: 200px;\n}\n.skills-container .card-list .table-responsive {\n  overflow-x: auto;\n}\n.skills-container .card-list .table-responsive table {\n  width: 100%;\n  border-collapse: collapse;\n}\n.skills-container .card-list .table-responsive table th,\n.skills-container .card-list .table-responsive table td {\n  padding: 0.8rem 1rem;\n  text-align: left;\n  border-bottom: 1px solid #d2c2ff;\n  font-size: 0.9rem;\n  color: #321f57;\n}\n.skills-container .card-list .table-responsive table th {\n  background-color: #e9e1ff;\n  color: #321f57;\n  font-weight: 600;\n}\n.skills-container .card-list .table-responsive table .badge-cat {\n  background-color: #e9e1ff;\n  color: #5b44c2;\n  padding: 0.25rem 0.6rem;\n  border-radius: 12px;\n  font-size: 0.8rem;\n  font-weight: 600;\n  border: 1px solid #bfa9f5;\n}\n.skills-container .card-list .table-responsive table .text-right {\n  text-align: right;\n}\n.skills-container .card-list .table-responsive table .btn-icon {\n  background: none;\n  border: none;\n  cursor: pointer;\n  font-size: 1rem;\n  padding: 0.3rem 0.5rem;\n  border-radius: 4px;\n}\n.skills-container .card-list .table-responsive table .btn-icon:hover {\n  background-color: #e9e1ff;\n}\n.skills-container .card-list .table-responsive table .empty-state {\n  text-align: center;\n  color: #5d4b7a;\n  padding: 2rem 0;\n}\n.skills-container {\n}\n.skills-container .modal-backdrop {\n  position: fixed;\n  top: 0;\n  left: 0;\n  width: 100vw;\n  height: 100vh;\n  background-color: rgba(42, 31, 76, 0.4);\n  -webkit-backdrop-filter: blur(2px);\n  backdrop-filter: blur(2px);\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  z-index: 1000;\n}\n.skills-container .modal-backdrop .modal-content {\n  background: #ffffff;\n  width: 100%;\n  max-width: 450px;\n  border-radius: 12px;\n  padding: 1.5rem;\n  border: 1px solid #d2c2ff;\n  box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);\n  animation: modalFadeIn 0.2s ease-out;\n}\n.skills-container .modal-backdrop .modal-content .modal-header {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-bottom: 1.25rem;\n}\n.skills-container .modal-backdrop .modal-content .modal-header h4 {\n  font-size: 1.15rem;\n  color: #321f57;\n}\n.skills-container .modal-backdrop .modal-content .modal-header .btn-close {\n  background: none;\n  border: none;\n  font-size: 1.2rem;\n  color: #5d4b7a;\n  cursor: pointer;\n}\n.skills-container .modal-backdrop .modal-content .modal-header .btn-close:hover {\n  color: #321f57;\n}\n.skills-container .modal-backdrop .modal-content .form-group {\n  display: flex;\n  flex-direction: column;\n  gap: 0.4rem;\n  margin-bottom: 1rem;\n}\n.skills-container .modal-backdrop .modal-content .form-group label {\n  font-size: 0.85rem;\n  font-weight: 600;\n  color: #321f57;\n}\n.skills-container .modal-backdrop .modal-content .form-group input,\n.skills-container .modal-backdrop .modal-content .form-group select {\n  padding: 0.65rem 0.8rem;\n  border: 1px solid #a991e6;\n  border-radius: 6px;\n  font-size: 0.9rem;\n  outline: none;\n  color: #321f57;\n  background-color: #ffffff;\n}\n.skills-container .modal-backdrop .modal-content .form-group input:focus,\n.skills-container .modal-backdrop .modal-content .form-group select:focus {\n  border-color: #7755f4;\n}\n.skills-container .modal-backdrop .modal-content .form-group input.is-invalid,\n.skills-container .modal-backdrop .modal-content .form-group select.is-invalid {\n  border-color: #dc2626;\n}\n.skills-container .modal-backdrop .modal-content .form-group .error-msg {\n  color: #dc2626;\n  font-size: 0.75rem;\n}\n.skills-container .modal-backdrop .modal-content .form-actions {\n  display: flex;\n  justify-content: flex-end;\n  gap: 0.75rem;\n  margin-top: 1.5rem;\n}\n@keyframes modalFadeIn {\n  from {\n    opacity: 0;\n    transform: translateY(-10px);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0);\n  }\n}\n/*# sourceMappingURL=skills.css.map */\n"] }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i011.\u0275setClassDebugInfo(Skills, { className: "Skills", filePath: "app/pagina/panel-admin/skills/skills.ts", lineNumber: 13 });
})();
(() => {
  const id = "app%2Fpagina%2Fpanel-admin%2Fskills%2Fskills.ts%40Skills";
  function Skills_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i011.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i011.\u0275\u0275replaceMetadata(Skills, m.default, [i011, i17, i23], [CommonModule5, ReactiveFormsModule5, FormsModule2, Component8], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && Skills_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && Skills_HmrLoad(d.timestamp)));
})();

// src/app/pagina/panel-admin/panel-admin.ts
import * as i012 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import * as i18 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_common.js?v=3d725e17";
var _forTrack05 = ($index, $item) => $item.id_empresa;
var _forTrack13 = ($index, $item) => $item.id_oferta || $index;
var _forTrack22 = ($index, $item) => $item.id_postulante || $item.id || $index;
var _forTrack3 = ($index, $item) => $item.key;
function PanelAdmin_Conditional_42_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275elementStart(0, "div", 15);
    i012.\u0275\u0275text(1, "\u23F3 Cargando empresas desde el servidor...");
    i012.\u0275\u0275elementEnd();
  }
}
function PanelAdmin_Conditional_42_Conditional_3_For_17_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = i012.\u0275\u0275getCurrentView();
    i012.\u0275\u0275elementStart(0, "tr")(1, "td");
    i012.\u0275\u0275text(2);
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(3, "td")(4, "strong");
    i012.\u0275\u0275text(5);
    i012.\u0275\u0275elementEnd()();
    i012.\u0275\u0275elementStart(6, "td");
    i012.\u0275\u0275text(7);
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(8, "td");
    i012.\u0275\u0275text(9);
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(10, "td")(11, "span", 18);
    i012.\u0275\u0275text(12);
    i012.\u0275\u0275elementEnd()();
    i012.\u0275\u0275elementStart(13, "td", 19)(14, "button", 20);
    i012.\u0275\u0275listener("click", function PanelAdmin_Conditional_42_Conditional_3_For_17_Template_button_click_14_listener() {
      const emp_r2 = i012.\u0275\u0275restoreView(_r1).$implicit;
      const ctx_r2 = i012.\u0275\u0275nextContext(3);
      return i012.\u0275\u0275resetView(ctx_r2.verDetalle(emp_r2));
    });
    i012.\u0275\u0275text(15, " \u{1F50D} Detalle ");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(16, "button", 21);
    i012.\u0275\u0275listener("click", function PanelAdmin_Conditional_42_Conditional_3_For_17_Template_button_click_16_listener() {
      const emp_r2 = i012.\u0275\u0275restoreView(_r1).$implicit;
      const ctx_r2 = i012.\u0275\u0275nextContext(3);
      return i012.\u0275\u0275resetView(ctx_r2.abrirPerfilEmpresa(emp_r2.id_empresa));
    });
    i012.\u0275\u0275text(17, " \u{1F3E2} Perfil ");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(18, "button", 22);
    i012.\u0275\u0275listener("click", function PanelAdmin_Conditional_42_Conditional_3_For_17_Template_button_click_18_listener() {
      const emp_r2 = i012.\u0275\u0275restoreView(_r1).$implicit;
      const ctx_r2 = i012.\u0275\u0275nextContext(3);
      return i012.\u0275\u0275resetView(ctx_r2.cambiarEstado(emp_r2.id_empresa, emp_r2.estado));
    });
    i012.\u0275\u0275text(19);
    i012.\u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const emp_r2 = ctx.$implicit;
    i012.\u0275\u0275advance(2);
    i012.\u0275\u0275textInterpolate1("#", emp_r2.id_empresa);
    i012.\u0275\u0275advance(3);
    i012.\u0275\u0275textInterpolate(emp_r2.razonSocial);
    i012.\u0275\u0275advance(2);
    i012.\u0275\u0275textInterpolate(emp_r2.cuit);
    i012.\u0275\u0275advance(2);
    i012.\u0275\u0275textInterpolate(emp_r2.email);
    i012.\u0275\u0275advance(2);
    i012.\u0275\u0275classProp("activo", emp_r2.estado === "Activo")("inactivo", emp_r2.estado === "Inactivo")("pendiente", emp_r2.estado === "Pendiente");
    i012.\u0275\u0275advance();
    i012.\u0275\u0275textInterpolate1(" ", emp_r2.estado, " ");
    i012.\u0275\u0275advance(6);
    i012.\u0275\u0275classProp("btn-desactivar", emp_r2.estado === "Activo")("btn-activar", emp_r2.estado !== "Activo");
    i012.\u0275\u0275advance();
    i012.\u0275\u0275textInterpolate1(" ", emp_r2.estado === "Activo" ? "Desactivar" : "Activar", " ");
  }
}
function PanelAdmin_Conditional_42_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275elementStart(0, "table", 16)(1, "thead")(2, "tr")(3, "th");
    i012.\u0275\u0275text(4, "ID");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(5, "th");
    i012.\u0275\u0275text(6, "Raz\xF3n Social");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(7, "th");
    i012.\u0275\u0275text(8, "CUIT");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(9, "th");
    i012.\u0275\u0275text(10, "Email");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(11, "th");
    i012.\u0275\u0275text(12, "Estado");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(13, "th");
    i012.\u0275\u0275text(14, "Acciones");
    i012.\u0275\u0275elementEnd()()();
    i012.\u0275\u0275elementStart(15, "tbody");
    i012.\u0275\u0275repeaterCreate(16, PanelAdmin_Conditional_42_Conditional_3_For_17_Template, 20, 16, "tr", null, _forTrack05);
    i012.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r2 = i012.\u0275\u0275nextContext(2);
    i012.\u0275\u0275advance(16);
    i012.\u0275\u0275repeater(ctx_r2.empresas);
  }
}
function PanelAdmin_Conditional_42_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275elementStart(0, "div", 17);
    i012.\u0275\u0275text(1, "\u26A0\uFE0F No se encontraron empresas en la base de datos.");
    i012.\u0275\u0275elementEnd();
  }
}
function PanelAdmin_Conditional_42_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275elementStart(0, "h3");
    i012.\u0275\u0275text(1, "\u{1F3E2} Empresas Registradas");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275conditionalCreate(2, PanelAdmin_Conditional_42_Conditional_2_Template, 2, 0, "div", 15)(3, PanelAdmin_Conditional_42_Conditional_3_Template, 18, 0, "table", 16)(4, PanelAdmin_Conditional_42_Conditional_4_Template, 2, 0, "div", 17);
  }
  if (rf & 2) {
    const ctx_r2 = i012.\u0275\u0275nextContext();
    i012.\u0275\u0275advance(2);
    i012.\u0275\u0275conditional(ctx_r2.cargando ? 2 : ctx_r2.empresas.length > 0 ? 3 : 4);
  }
}
function PanelAdmin_Conditional_43_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275elementStart(0, "div", 15);
    i012.\u0275\u0275text(1, "\u23F3 Cargando ofertas desde el servidor...");
    i012.\u0275\u0275elementEnd();
  }
}
function PanelAdmin_Conditional_43_Conditional_3_For_19_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275elementStart(0, "span", 24);
    i012.\u0275\u0275text(1);
    i012.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const oferta_r5 = i012.\u0275\u0275nextContext().$implicit;
    i012.\u0275\u0275advance();
    i012.\u0275\u0275textInterpolate1("Expir\xF3 (", oferta_r5.dias_duracion || 10, "d)");
  }
}
function PanelAdmin_Conditional_43_Conditional_3_For_19_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275elementStart(0, "span", 25);
    i012.\u0275\u0275text(1);
    i012.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    i012.\u0275\u0275nextContext();
    const infoEstado_r6 = i012.\u0275\u0275readContextLet(0);
    i012.\u0275\u0275advance();
    i012.\u0275\u0275textInterpolate1("\u231B Quedan ", infoEstado_r6.dias, " d\xEDas");
  }
}
function PanelAdmin_Conditional_43_Conditional_3_For_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = i012.\u0275\u0275getCurrentView();
    i012.\u0275\u0275declareLet(0);
    i012.\u0275\u0275elementStart(1, "tr")(2, "td");
    i012.\u0275\u0275text(3);
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(4, "td")(5, "strong");
    i012.\u0275\u0275text(6);
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275element(7, "br");
    i012.\u0275\u0275elementStart(8, "small", 23);
    i012.\u0275\u0275text(9);
    i012.\u0275\u0275elementEnd()();
    i012.\u0275\u0275elementStart(10, "td");
    i012.\u0275\u0275text(11);
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(12, "td");
    i012.\u0275\u0275conditionalCreate(13, PanelAdmin_Conditional_43_Conditional_3_For_19_Conditional_13_Template, 2, 1, "span", 24)(14, PanelAdmin_Conditional_43_Conditional_3_For_19_Conditional_14_Template, 2, 1, "span", 25);
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(15, "td");
    i012.\u0275\u0275text(16);
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(17, "td")(18, "span", 18);
    i012.\u0275\u0275text(19);
    i012.\u0275\u0275elementEnd()();
    i012.\u0275\u0275elementStart(20, "td")(21, "button", 26);
    i012.\u0275\u0275listener("click", function PanelAdmin_Conditional_43_Conditional_3_For_19_Template_button_click_21_listener() {
      const oferta_r5 = i012.\u0275\u0275restoreView(_r4).$implicit;
      const ctx_r2 = i012.\u0275\u0275nextContext(3);
      return i012.\u0275\u0275resetView(ctx_r2.bajaOfertaAdmin(oferta_r5.id_oferta));
    });
    i012.\u0275\u0275text(22, " \u{1F5D1}\uFE0F Eliminar ");
    i012.\u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const oferta_r5 = ctx.$implicit;
    const ctx_r2 = i012.\u0275\u0275nextContext(3);
    const infoEstado_r7 = i012.\u0275\u0275storeLet(ctx_r2.obtenerEstadoYConteo(oferta_r5.fecha_publicacion, oferta_r5.dias_duracion));
    i012.\u0275\u0275advance(3);
    i012.\u0275\u0275textInterpolate1("#", oferta_r5.id_oferta);
    i012.\u0275\u0275advance(3);
    i012.\u0275\u0275textInterpolate(oferta_r5.titulo);
    i012.\u0275\u0275advance(3);
    i012.\u0275\u0275textInterpolate(oferta_r5.razonSocial || "Empresa #" + oferta_r5.id_empresa);
    i012.\u0275\u0275advance(2);
    i012.\u0275\u0275textInterpolate(ctx_r2.formatearFecha(oferta_r5.fecha_publicacion));
    i012.\u0275\u0275advance(2);
    i012.\u0275\u0275conditional(infoEstado_r7.finalizada ? 13 : 14);
    i012.\u0275\u0275advance(3);
    i012.\u0275\u0275textInterpolate2("", oferta_r5.modalidad, " (", oferta_r5.experiencia, ")");
    i012.\u0275\u0275advance(2);
    i012.\u0275\u0275classProp("activo", !infoEstado_r7.finalizada)("inactivo", infoEstado_r7.finalizada);
    i012.\u0275\u0275advance();
    i012.\u0275\u0275textInterpolate1(" ", infoEstado_r7.estadoText, " ");
  }
}
function PanelAdmin_Conditional_43_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275elementStart(0, "table", 16)(1, "thead")(2, "tr")(3, "th");
    i012.\u0275\u0275text(4, "ID");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(5, "th");
    i012.\u0275\u0275text(6, "T\xEDtulo / Empresa");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(7, "th");
    i012.\u0275\u0275text(8, "Fecha Publicaci\xF3n");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(9, "th");
    i012.\u0275\u0275text(10, "Vencimiento / Duraci\xF3n");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(11, "th");
    i012.\u0275\u0275text(12, "Modalidad");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(13, "th");
    i012.\u0275\u0275text(14, "Estado");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(15, "th");
    i012.\u0275\u0275text(16, "Acci\xF3n");
    i012.\u0275\u0275elementEnd()()();
    i012.\u0275\u0275elementStart(17, "tbody");
    i012.\u0275\u0275repeaterCreate(18, PanelAdmin_Conditional_43_Conditional_3_For_19_Template, 23, 13, "tr", null, _forTrack13);
    i012.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r2 = i012.\u0275\u0275nextContext(2);
    i012.\u0275\u0275advance(18);
    i012.\u0275\u0275repeater(ctx_r2.ofertas);
  }
}
function PanelAdmin_Conditional_43_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275elementStart(0, "div", 17);
    i012.\u0275\u0275text(1, "\u26A0\uFE0F No se encontraron ofertas de empleo registradas en el sistema.");
    i012.\u0275\u0275elementEnd();
  }
}
function PanelAdmin_Conditional_43_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275elementStart(0, "h3");
    i012.\u0275\u0275text(1, "\u{1F4BC} Moderaci\xF3n de Ofertas de Empleo");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275conditionalCreate(2, PanelAdmin_Conditional_43_Conditional_2_Template, 2, 0, "div", 15)(3, PanelAdmin_Conditional_43_Conditional_3_Template, 20, 0, "table", 16)(4, PanelAdmin_Conditional_43_Conditional_4_Template, 2, 0, "div", 17);
  }
  if (rf & 2) {
    const ctx_r2 = i012.\u0275\u0275nextContext();
    i012.\u0275\u0275advance(2);
    i012.\u0275\u0275conditional(ctx_r2.cargando ? 2 : ctx_r2.ofertas.length > 0 ? 3 : 4);
  }
}
function PanelAdmin_Conditional_44_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275elementStart(0, "div", 15);
    i012.\u0275\u0275text(1, "\u23F3 Cargando postulantes desde el servidor...");
    i012.\u0275\u0275elementEnd();
  }
}
function PanelAdmin_Conditional_44_Conditional_3_For_21_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = i012.\u0275\u0275getCurrentView();
    i012.\u0275\u0275elementStart(0, "tr")(1, "td");
    i012.\u0275\u0275text(2);
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(3, "td")(4, "strong");
    i012.\u0275\u0275text(5);
    i012.\u0275\u0275elementEnd()();
    i012.\u0275\u0275elementStart(6, "td");
    i012.\u0275\u0275text(7);
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(8, "td");
    i012.\u0275\u0275text(9);
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(10, "td");
    i012.\u0275\u0275text(11);
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(12, "td");
    i012.\u0275\u0275text(13);
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(14, "td")(15, "span", 18);
    i012.\u0275\u0275text(16);
    i012.\u0275\u0275elementEnd()();
    i012.\u0275\u0275elementStart(17, "td")(18, "button", 27);
    i012.\u0275\u0275listener("click", function PanelAdmin_Conditional_44_Conditional_3_For_21_Template_button_click_18_listener() {
      const post_r9 = i012.\u0275\u0275restoreView(_r8).$implicit;
      const ctx_r2 = i012.\u0275\u0275nextContext(3);
      return i012.\u0275\u0275resetView(ctx_r2.verDetallePostulante(post_r9));
    });
    i012.\u0275\u0275text(19, " \u{1F50D} Ver Perfil/CV ");
    i012.\u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const post_r9 = ctx.$implicit;
    i012.\u0275\u0275advance(2);
    i012.\u0275\u0275textInterpolate1("#", post_r9.id_postulante || post_r9.id);
    i012.\u0275\u0275advance(3);
    i012.\u0275\u0275textInterpolate2("", post_r9.nombres || post_r9.nombre, " ", post_r9.apellidos || post_r9.apellido);
    i012.\u0275\u0275advance(2);
    i012.\u0275\u0275textInterpolate(post_r9.dni || "S/D");
    i012.\u0275\u0275advance(2);
    i012.\u0275\u0275textInterpolate(post_r9.legajo || "S/L");
    i012.\u0275\u0275advance(2);
    i012.\u0275\u0275textInterpolate(post_r9.carrera || "Analista de Sistemas / IA");
    i012.\u0275\u0275advance(2);
    i012.\u0275\u0275textInterpolate(post_r9.email);
    i012.\u0275\u0275advance(2);
    i012.\u0275\u0275classProp("activo", post_r9.estado !== "Inactivo")("inactivo", post_r9.estado === "Inactivo");
    i012.\u0275\u0275advance();
    i012.\u0275\u0275textInterpolate1(" ", post_r9.estado || "Activo", " ");
  }
}
function PanelAdmin_Conditional_44_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275elementStart(0, "table", 16)(1, "thead")(2, "tr")(3, "th");
    i012.\u0275\u0275text(4, "ID");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(5, "th");
    i012.\u0275\u0275text(6, "Nombre y Apellido");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(7, "th");
    i012.\u0275\u0275text(8, "DNI");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(9, "th");
    i012.\u0275\u0275text(10, "Legajo");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(11, "th");
    i012.\u0275\u0275text(12, "Carrera");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(13, "th");
    i012.\u0275\u0275text(14, "Email");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(15, "th");
    i012.\u0275\u0275text(16, "Estado");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(17, "th");
    i012.\u0275\u0275text(18, "Acci\xF3n");
    i012.\u0275\u0275elementEnd()()();
    i012.\u0275\u0275elementStart(19, "tbody");
    i012.\u0275\u0275repeaterCreate(20, PanelAdmin_Conditional_44_Conditional_3_For_21_Template, 20, 12, "tr", null, _forTrack22);
    i012.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r2 = i012.\u0275\u0275nextContext(2);
    i012.\u0275\u0275advance(20);
    i012.\u0275\u0275repeater(ctx_r2.postulantes);
  }
}
function PanelAdmin_Conditional_44_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275elementStart(0, "div", 17);
    i012.\u0275\u0275text(1, "\u26A0\uFE0F No se encontraron postulantes registrados en la base de datos.");
    i012.\u0275\u0275elementEnd();
  }
}
function PanelAdmin_Conditional_44_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275elementStart(0, "h3");
    i012.\u0275\u0275text(1, "\u{1F393} Padr\xF3n de Postulantes (Alumnos y Egresados)");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275conditionalCreate(2, PanelAdmin_Conditional_44_Conditional_2_Template, 2, 0, "div", 15)(3, PanelAdmin_Conditional_44_Conditional_3_Template, 22, 0, "table", 16)(4, PanelAdmin_Conditional_44_Conditional_4_Template, 2, 0, "div", 17);
  }
  if (rf & 2) {
    const ctx_r2 = i012.\u0275\u0275nextContext();
    i012.\u0275\u0275advance(2);
    i012.\u0275\u0275conditional(ctx_r2.cargando ? 2 : ctx_r2.postulantes.length > 0 ? 3 : 4);
  }
}
function PanelAdmin_Conditional_45_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275element(0, "app-postulaciones");
  }
}
function PanelAdmin_Conditional_49_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275element(0, "app-skills");
  }
}
function PanelAdmin_Conditional_50_For_10_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275elementStart(0, "div", 36)(1, "label");
    i012.\u0275\u0275text(2);
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(3, "span");
    i012.\u0275\u0275text(4);
    i012.\u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const item_r11 = i012.\u0275\u0275nextContext().$implicit;
    const ctx_r2 = i012.\u0275\u0275nextContext(2);
    i012.\u0275\u0275advance(2);
    i012.\u0275\u0275textInterpolate1("", ctx_r2.formatearClave(ctx_r2.normalizarClave(item_r11.key.toString())), ":");
    i012.\u0275\u0275advance(2);
    i012.\u0275\u0275textInterpolate(item_r11.value !== null && item_r11.value !== "" ? item_r11.value : "No especificado");
  }
}
function PanelAdmin_Conditional_50_For_10_Template(rf, ctx) {
  if (rf & 1) {
    i012.\u0275\u0275conditionalCreate(0, PanelAdmin_Conditional_50_For_10_Conditional_0_Template, 5, 2, "div", 36);
  }
  if (rf & 2) {
    const item_r11 = ctx.$implicit;
    const ctx_r2 = i012.\u0275\u0275nextContext(2);
    i012.\u0275\u0275conditional(ctx_r2.esCampoVisible(ctx_r2.normalizarClave(item_r11.key.toString())) ? 0 : -1);
  }
}
function PanelAdmin_Conditional_50_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = i012.\u0275\u0275getCurrentView();
    i012.\u0275\u0275elementStart(0, "div", 28);
    i012.\u0275\u0275listener("click", function PanelAdmin_Conditional_50_Template_div_click_0_listener() {
      i012.\u0275\u0275restoreView(_r10);
      const ctx_r2 = i012.\u0275\u0275nextContext();
      return i012.\u0275\u0275resetView(ctx_r2.cerrarModal());
    });
    i012.\u0275\u0275elementStart(1, "div", 29);
    i012.\u0275\u0275listener("click", function PanelAdmin_Conditional_50_Template_div_click_1_listener($event) {
      return $event.stopPropagation();
    });
    i012.\u0275\u0275elementStart(2, "div", 30)(3, "h3");
    i012.\u0275\u0275text(4, "\u{1F3E2} Ficha de Registro de Empresa");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(5, "button", 31);
    i012.\u0275\u0275listener("click", function PanelAdmin_Conditional_50_Template_button_click_5_listener() {
      i012.\u0275\u0275restoreView(_r10);
      const ctx_r2 = i012.\u0275\u0275nextContext();
      return i012.\u0275\u0275resetView(ctx_r2.cerrarModal());
    });
    i012.\u0275\u0275text(6, "\u2715");
    i012.\u0275\u0275elementEnd()();
    i012.\u0275\u0275elementStart(7, "div", 32)(8, "div", 33);
    i012.\u0275\u0275repeaterCreate(9, PanelAdmin_Conditional_50_For_10_Template, 1, 1, null, null, _forTrack3);
    i012.\u0275\u0275pipe(11, "keyvalue");
    i012.\u0275\u0275elementEnd()();
    i012.\u0275\u0275elementStart(12, "div", 34)(13, "button", 22);
    i012.\u0275\u0275listener("click", function PanelAdmin_Conditional_50_Template_button_click_13_listener() {
      i012.\u0275\u0275restoreView(_r10);
      const ctx_r2 = i012.\u0275\u0275nextContext();
      return i012.\u0275\u0275resetView(ctx_r2.cambiarEstado(ctx_r2.empresaSeleccionada.id_empresa, ctx_r2.empresaSeleccionada.estado));
    });
    i012.\u0275\u0275text(14);
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(15, "button", 35);
    i012.\u0275\u0275listener("click", function PanelAdmin_Conditional_50_Template_button_click_15_listener() {
      i012.\u0275\u0275restoreView(_r10);
      const ctx_r2 = i012.\u0275\u0275nextContext();
      return i012.\u0275\u0275resetView(ctx_r2.cerrarModal());
    });
    i012.\u0275\u0275text(16, "Cerrar");
    i012.\u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r2 = i012.\u0275\u0275nextContext();
    i012.\u0275\u0275advance(9);
    i012.\u0275\u0275repeater(i012.\u0275\u0275pipeBind1(11, 5, ctx_r2.empresaSeleccionada));
    i012.\u0275\u0275advance(4);
    i012.\u0275\u0275classProp("btn-desactivar", ctx_r2.empresaSeleccionada.estado === "Activo")("btn-activar", ctx_r2.empresaSeleccionada.estado !== "Activo");
    i012.\u0275\u0275advance();
    i012.\u0275\u0275textInterpolate1(" ", ctx_r2.empresaSeleccionada.estado === "Activo" ? "Desactivar Empresa" : "Activar Empresa", " ");
  }
}
function PanelAdmin_Conditional_51_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = i012.\u0275\u0275getCurrentView();
    i012.\u0275\u0275elementStart(0, "div", 28);
    i012.\u0275\u0275listener("click", function PanelAdmin_Conditional_51_Template_div_click_0_listener() {
      i012.\u0275\u0275restoreView(_r12);
      const ctx_r2 = i012.\u0275\u0275nextContext();
      return i012.\u0275\u0275resetView(ctx_r2.cerrarModalPerfil());
    });
    i012.\u0275\u0275elementStart(1, "div", 37);
    i012.\u0275\u0275listener("click", function PanelAdmin_Conditional_51_Template_div_click_1_listener($event) {
      return $event.stopPropagation();
    });
    i012.\u0275\u0275elementStart(2, "div", 30)(3, "h3");
    i012.\u0275\u0275text(4, "\u{1F3E2} Perfil de la Empresa");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(5, "button", 31);
    i012.\u0275\u0275listener("click", function PanelAdmin_Conditional_51_Template_button_click_5_listener() {
      i012.\u0275\u0275restoreView(_r12);
      const ctx_r2 = i012.\u0275\u0275nextContext();
      return i012.\u0275\u0275resetView(ctx_r2.cerrarModalPerfil());
    });
    i012.\u0275\u0275text(6, "\u2715");
    i012.\u0275\u0275elementEnd()();
    i012.\u0275\u0275elementStart(7, "div", 32)(8, "app-empresa-profile", 38);
    i012.\u0275\u0275listener("cerrarModal", function PanelAdmin_Conditional_51_Template_app_empresa_profile_cerrarModal_8_listener() {
      i012.\u0275\u0275restoreView(_r12);
      const ctx_r2 = i012.\u0275\u0275nextContext();
      return i012.\u0275\u0275resetView(ctx_r2.cerrarModalPerfil());
    });
    i012.\u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r2 = i012.\u0275\u0275nextContext();
    i012.\u0275\u0275advance(8);
    i012.\u0275\u0275property("idEmpresaInput", ctx_r2.empresaPerfilId)("esModoAdmin", true);
  }
}
function PanelAdmin_Conditional_52_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = i012.\u0275\u0275getCurrentView();
    i012.\u0275\u0275elementStart(0, "div", 28);
    i012.\u0275\u0275listener("click", function PanelAdmin_Conditional_52_Template_div_click_0_listener() {
      i012.\u0275\u0275restoreView(_r13);
      const ctx_r2 = i012.\u0275\u0275nextContext();
      return i012.\u0275\u0275resetView(ctx_r2.cerrarModalPostulante());
    });
    i012.\u0275\u0275elementStart(1, "div", 29);
    i012.\u0275\u0275listener("click", function PanelAdmin_Conditional_52_Template_div_click_1_listener($event) {
      return $event.stopPropagation();
    });
    i012.\u0275\u0275elementStart(2, "div", 30)(3, "h3");
    i012.\u0275\u0275text(4, "\u{1F393} Ficha del Postulante");
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(5, "button", 31);
    i012.\u0275\u0275listener("click", function PanelAdmin_Conditional_52_Template_button_click_5_listener() {
      i012.\u0275\u0275restoreView(_r13);
      const ctx_r2 = i012.\u0275\u0275nextContext();
      return i012.\u0275\u0275resetView(ctx_r2.cerrarModalPostulante());
    });
    i012.\u0275\u0275text(6, "\u2715");
    i012.\u0275\u0275elementEnd()();
    i012.\u0275\u0275elementStart(7, "div", 32);
    i012.\u0275\u0275element(8, "app-postulante-profile", 39);
    i012.\u0275\u0275elementEnd();
    i012.\u0275\u0275elementStart(9, "div", 34)(10, "button", 35);
    i012.\u0275\u0275listener("click", function PanelAdmin_Conditional_52_Template_button_click_10_listener() {
      i012.\u0275\u0275restoreView(_r13);
      const ctx_r2 = i012.\u0275\u0275nextContext();
      return i012.\u0275\u0275resetView(ctx_r2.cerrarModalPostulante());
    });
    i012.\u0275\u0275text(11, "Cerrar");
    i012.\u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r2 = i012.\u0275\u0275nextContext();
    i012.\u0275\u0275advance(8);
    i012.\u0275\u0275property("idPostulanteInput", ctx_r2.postulanteSeleccionado.id_postulante || ctx_r2.postulanteSeleccionado.id)("esModoAdmin", true);
  }
}
var PanelAdmin = class _PanelAdmin {
  adminService = inject9(AdminService);
  cdr = inject9(ChangeDetectorRef3);
  router = inject9(Router6);
  authService = inject9(AuthService);
  // Control de Vistas
  mostrarSkills = false;
  pestanaActiva = "empresas";
  // Control de Cargas Únicas (Evita re-peticiones a la API)
  cargadoEmpresas = false;
  cargadoOfertas = false;
  cargadoPostulantes = false;
  // Estado Global y Métricas
  cargando = false;
  metricas = {
    totalOfertas: 0,
    totalEmpresas: 0,
    totalPostulantes: 0,
    totalPostulaciones: 0
  };
  // Arreglos de Datos
  empresas = [];
  ofertas = [];
  postulantes = [];
  // Modales
  empresaSeleccionada = null;
  mostrarModal = false;
  // 👈 Modal Perfil de Empresa (EmpresaProfile)
  empresaPerfilId = null;
  postulanteSeleccionado = null;
  mostrarModalPostulante = false;
  ngOnInit() {
    this.cargarDatos();
  }
  toggleSkills() {
    this.mostrarSkills = !this.mostrarSkills;
  }
  // Cambiar de pestaña
  cambiarPestana(nuevaPestana) {
    this.mostrarSkills = false;
    this.pestanaActiva = nuevaPestana;
    if (nuevaPestana === "empresas" && !this.cargadoEmpresas) {
      this.cargarEmpresas();
    } else if (nuevaPestana === "ofertas" && !this.cargadoOfertas) {
      this.cargarOfertas();
    } else if (nuevaPestana === "postulantes" && !this.cargadoPostulantes) {
      this.cargarPostulantes();
    }
  }
  cargarDatos() {
    this.cargarMetricas();
    this.cargarEmpresas();
  }
  // Métricas Generales
  cargarMetricas() {
    this.adminService.getMetricas().subscribe({
      next: (res) => {
        if (res && res.success && res.metricas) {
          this.metricas = res.metricas;
        }
      },
      error: (err) => console.error("Error al cargar m\xE9tricas:", err)
    });
  }
  // Carga de Empresas
  cargarEmpresas() {
    this.cargando = true;
    this.adminService.getEmpresas().subscribe({
      next: (res) => {
        if (res && res.success && res.empresas) {
          this.empresas = res.empresas;
        }
        this.cargadoEmpresas = true;
        this.cargando = false;
      },
      error: (err) => {
        console.error("Error al cargar empresas:", err);
        this.cargadoEmpresas = true;
        this.cargando = false;
      }
    });
  }
  // Carga de Ofertas
  cargarOfertas() {
    this.cargando = true;
    this.adminService.getOfertas().subscribe({
      next: (res) => {
        if (res && res.success && res.ofertas) {
          this.ofertas = res.ofertas;
        } else if (Array.isArray(res)) {
          this.ofertas = res;
        }
        this.cargadoOfertas = true;
        this.cargando = false;
      },
      error: (err) => {
        console.error("Error al cargar ofertas en el admin:", err);
        this.cargadoOfertas = true;
        this.cargando = false;
      }
    });
  }
  // Carga de Postulantes
  cargarPostulantes() {
    this.cargando = true;
    this.adminService.getPostulantes().subscribe({
      next: (res) => {
        if (res && res.success && res.postulantes) {
          this.postulantes = res.postulantes;
        } else if (Array.isArray(res)) {
          this.postulantes = res;
        }
        this.cargadoPostulantes = true;
        this.cargando = false;
      },
      error: (err) => {
        console.error("Error al cargar postulantes en el admin:", err);
        this.cargadoPostulantes = true;
        this.cargando = false;
      }
    });
  }
  // Moderación de Ofertas
  bajaOfertaAdmin(idOferta) {
    if (confirm(`\xBFEst\xE1 seguro de que desea eliminar la oferta #${idOferta} de manera permanente?`)) {
      this.adminService.eliminarOferta(idOferta).subscribe({
        next: (res) => {
          if (res.success) {
            alert(`Oferta #${idOferta} eliminada con \xE9xito.`);
            this.ofertas = this.ofertas.filter((o) => o.id_oferta !== idOferta);
          }
        },
        error: (err) => console.error("Error al eliminar oferta:", err)
      });
    }
  }
  // Helpers de Fechas
  formatearFecha(fechaRaw) {
    if (!fechaRaw)
      return "Sin fecha";
    const fecha = new Date(fechaRaw);
    if (isNaN(fecha.getTime()))
      return "Sin fecha";
    return fecha.toLocaleDateString("es-AR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric"
    });
  }
  obtenerEstadoYConteo(fechaPub, diasDuracion = 10) {
    if (!fechaPub)
      return { estadoText: "Sin Fecha", dias: 0, finalizada: true };
    const inicio = new Date(fechaPub);
    if (isNaN(inicio.getTime()))
      return { estadoText: "Sin Fecha", dias: 0, finalizada: true };
    const fin = new Date(inicio);
    fin.setDate(inicio.getDate() + Number(diasDuracion));
    const hoy = /* @__PURE__ */ new Date();
    const diferenciaMs = fin.getTime() - hoy.getTime();
    const diasRestantes = Math.ceil(diferenciaMs / (1e3 * 60 * 60 * 24));
    if (diasRestantes <= 0) {
      return { estadoText: "Finalizada", dias: 0, finalizada: true };
    }
    return {
      estadoText: "Vigente",
      dias: diasRestantes,
      finalizada: false
    };
  }
  // Modales y Acciones (Empresas)
  cambiarEstado(idEmpresa, estadoActual) {
    const esActivo = estadoActual?.toString().trim().toLowerCase() === "activo";
    const nuevoEstado = esActivo ? "Inactivo" : "Activo";
    this.adminService.cambiarEstadoEmpresa(idEmpresa, nuevoEstado).subscribe({
      next: (res) => {
        if (res.success) {
          const emp = this.empresas.find((e) => e.id_empresa === idEmpresa);
          if (emp) {
            emp.estado = nuevoEstado;
          }
          if (this.empresaSeleccionada && this.empresaSeleccionada.id_empresa === idEmpresa) {
            this.empresaSeleccionada.estado = nuevoEstado;
          }
          this.cdr.detectChanges();
        } else {
          alert(res.mensaje || "No se pudo cambiar el estado de la empresa.");
        }
      },
      error: (err) => {
        console.error("Error al cambiar estado:", err);
        alert("Ocurri\xF3 un error al comunicarse con el servidor.");
      }
    });
  }
  verDetalle(empresa) {
    this.empresaSeleccionada = empresa;
    this.mostrarModal = true;
  }
  cerrarModal() {
    this.mostrarModal = false;
    this.empresaSeleccionada = null;
  }
  // 👈  MODAL 2 PERFIL COMPLETO (EmpresaProfile)
  abrirPerfilEmpresa(idEmpresa) {
    this.empresaPerfilId = idEmpresa;
  }
  cerrarModalPerfil() {
    this.empresaPerfilId = null;
  }
  // Modales y Acciones (Postulantes)
  verDetallePostulante(postulante) {
    this.postulanteSeleccionado = postulante;
    this.mostrarModalPostulante = true;
  }
  cerrarModalPostulante() {
    this.mostrarModalPostulante = false;
    this.postulanteSeleccionado = null;
  }
  // Cierre de Sesión Centralizado
  cerrarSesion() {
    this.authService.logout();
    this.router.navigate(["/sesion"]);
  }
  // KeyValuePipe Helpers
  normalizarClave(clave) {
    return clave.toString();
  }
  esCampoVisible(clave) {
    const valor = this.normalizarClave(clave).toLowerCase();
    const camposOcultos = ["password", "contrasena", "clave", "pass", "token"];
    return !camposOcultos.includes(valor);
  }
  formatearClave(clave) {
    return this.normalizarClave(clave).replace(/_/g, " ").toUpperCase();
  }
  static \u0275fac = function PanelAdmin_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _PanelAdmin)();
  };
  static \u0275cmp = /* @__PURE__ */ i012.\u0275\u0275defineComponent({ type: _PanelAdmin, selectors: [["app-panel-admin"]], decls: 53, vars: 31, consts: [[1, "dashboard-layout"], [1, "sidebar"], [2, "cursor", "pointer", 3, "click"], [1, "logout", 3, "click"], [1, "admin-container"], [1, "subtitulo"], [1, "metricas-grid"], [1, "card-kpi", 3, "click"], [1, "numero"], [1, "label"], [1, "card-kpi", "highlight", 2, "cursor", "pointer", 3, "click"], [1, "tabla-seccion"], [1, "contenedor-toggle-skills", 2, "margin-top", "2rem"], [1, "btn-toggle-skills", 3, "click"], [1, "modal-overlay"], [1, "loading"], [1, "tabla-admin"], [1, "no-datos"], [1, "badge"], [1, "acciones-cell"], ["title", "Ver detalle fiscal", 1, "btn-info", 3, "click"], ["title", "Ver perfil p\xFAblico", 1, "btn-info", 3, "click"], [1, "btn-estado", 3, "click"], [1, "text-muted"], [1, "badge", "inactivo"], [1, "badge", "activo"], [1, "btn-estado", "btn-desactivar", 3, "click"], [1, "btn-info", 3, "click"], [1, "modal-overlay", 3, "click"], [1, "modal-content", 3, "click"], [1, "modal-header"], [1, "btn-cerrar", 3, "click"], [1, "modal-body"], [1, "grid-datos"], [1, "modal-footer"], [1, "btn-secundario", 3, "click"], [1, "dato-item"], [1, "modal-content", "modal-perfil-ancho", 3, "click"], [3, "cerrarModal", "idEmpresaInput", "esModoAdmin"], [3, "idPostulanteInput", "esModoAdmin"]], template: function PanelAdmin_Template(rf, ctx) {
    if (rf & 1) {
      i012.\u0275\u0275elementStart(0, "div", 0)(1, "aside", 1)(2, "nav")(3, "a", 2);
      i012.\u0275\u0275listener("click", function PanelAdmin_Template_a_click_3_listener() {
        return ctx.mostrarSkills = true;
      });
      i012.\u0275\u0275text(4, "\u{1F6E0}\uFE0F Skills y Categor\xEDas");
      i012.\u0275\u0275elementEnd();
      i012.\u0275\u0275elementStart(5, "a", 2);
      i012.\u0275\u0275listener("click", function PanelAdmin_Template_a_click_5_listener() {
        ctx.mostrarSkills = false;
        return ctx.cambiarPestana("postulantes");
      });
      i012.\u0275\u0275text(6, "\u{1F465} Postulantes");
      i012.\u0275\u0275elementEnd();
      i012.\u0275\u0275elementStart(7, "a", 2);
      i012.\u0275\u0275listener("click", function PanelAdmin_Template_a_click_7_listener() {
        ctx.mostrarSkills = false;
        return ctx.cambiarPestana("empresas");
      });
      i012.\u0275\u0275text(8, "\u{1F3E2} Empresas");
      i012.\u0275\u0275elementEnd();
      i012.\u0275\u0275elementStart(9, "a", 2);
      i012.\u0275\u0275listener("click", function PanelAdmin_Template_a_click_9_listener() {
        ctx.mostrarSkills = false;
        return ctx.cambiarPestana("ofertas");
      });
      i012.\u0275\u0275text(10, "\u{1F4BC} Ofertas");
      i012.\u0275\u0275elementEnd();
      i012.\u0275\u0275elementStart(11, "a", 2);
      i012.\u0275\u0275listener("click", function PanelAdmin_Template_a_click_11_listener() {
        ctx.mostrarSkills = false;
        return ctx.cambiarPestana("postulaciones");
      });
      i012.\u0275\u0275text(12, "\u{1F4C4} Postulaciones");
      i012.\u0275\u0275elementEnd()();
      i012.\u0275\u0275elementStart(13, "button", 3);
      i012.\u0275\u0275listener("click", function PanelAdmin_Template_button_click_13_listener() {
        return ctx.cerrarSesion();
      });
      i012.\u0275\u0275text(14, "Cerrar Sesi\xF3n");
      i012.\u0275\u0275elementEnd()();
      i012.\u0275\u0275elementStart(15, "div", 4)(16, "h2");
      i012.\u0275\u0275text(17, "\u{1F6E0}\uFE0F Panel de Control Institucional ITBCONECTA");
      i012.\u0275\u0275elementEnd();
      i012.\u0275\u0275elementStart(18, "p", 5);
      i012.\u0275\u0275text(19, "Gesti\xF3n de usuarios, empresas y moderaci\xF3n de la plataforma");
      i012.\u0275\u0275elementEnd();
      i012.\u0275\u0275elementStart(20, "div", 6)(21, "div", 7);
      i012.\u0275\u0275listener("click", function PanelAdmin_Template_div_click_21_listener() {
        return ctx.cambiarPestana("empresas");
      });
      i012.\u0275\u0275elementStart(22, "span", 8);
      i012.\u0275\u0275text(23);
      i012.\u0275\u0275elementEnd();
      i012.\u0275\u0275elementStart(24, "span", 9);
      i012.\u0275\u0275text(25, "Empresas Registradas");
      i012.\u0275\u0275elementEnd()();
      i012.\u0275\u0275elementStart(26, "div", 7);
      i012.\u0275\u0275listener("click", function PanelAdmin_Template_div_click_26_listener() {
        return ctx.cambiarPestana("ofertas");
      });
      i012.\u0275\u0275elementStart(27, "span", 8);
      i012.\u0275\u0275text(28);
      i012.\u0275\u0275elementEnd();
      i012.\u0275\u0275elementStart(29, "span", 9);
      i012.\u0275\u0275text(30, "Ofertas Publicadas");
      i012.\u0275\u0275elementEnd()();
      i012.\u0275\u0275elementStart(31, "div", 7);
      i012.\u0275\u0275listener("click", function PanelAdmin_Template_div_click_31_listener() {
        return ctx.cambiarPestana("postulantes");
      });
      i012.\u0275\u0275elementStart(32, "span", 8);
      i012.\u0275\u0275text(33);
      i012.\u0275\u0275elementEnd();
      i012.\u0275\u0275elementStart(34, "span", 9);
      i012.\u0275\u0275text(35, "Postulantes Registrados");
      i012.\u0275\u0275elementEnd()();
      i012.\u0275\u0275elementStart(36, "div", 10);
      i012.\u0275\u0275listener("click", function PanelAdmin_Template_div_click_36_listener() {
        ctx.mostrarSkills = false;
        return ctx.cambiarPestana("postulaciones");
      });
      i012.\u0275\u0275elementStart(37, "span", 8);
      i012.\u0275\u0275text(38);
      i012.\u0275\u0275elementEnd();
      i012.\u0275\u0275elementStart(39, "span", 9);
      i012.\u0275\u0275text(40, "Postulaciones Totales");
      i012.\u0275\u0275elementEnd()()();
      i012.\u0275\u0275elementStart(41, "div", 11);
      i012.\u0275\u0275conditionalCreate(42, PanelAdmin_Conditional_42_Template, 5, 1);
      i012.\u0275\u0275conditionalCreate(43, PanelAdmin_Conditional_43_Template, 5, 1);
      i012.\u0275\u0275conditionalCreate(44, PanelAdmin_Conditional_44_Template, 5, 1);
      i012.\u0275\u0275conditionalCreate(45, PanelAdmin_Conditional_45_Template, 1, 0, "app-postulaciones");
      i012.\u0275\u0275elementEnd();
      i012.\u0275\u0275elementStart(46, "div", 12)(47, "button", 13);
      i012.\u0275\u0275listener("click", function PanelAdmin_Template_button_click_47_listener() {
        return ctx.toggleSkills();
      });
      i012.\u0275\u0275text(48);
      i012.\u0275\u0275elementEnd()();
      i012.\u0275\u0275conditionalCreate(49, PanelAdmin_Conditional_49_Template, 1, 0, "app-skills");
      i012.\u0275\u0275elementEnd();
      i012.\u0275\u0275conditionalCreate(50, PanelAdmin_Conditional_50_Template, 17, 7, "div", 14);
      i012.\u0275\u0275conditionalCreate(51, PanelAdmin_Conditional_51_Template, 9, 2, "div", 14);
      i012.\u0275\u0275conditionalCreate(52, PanelAdmin_Conditional_52_Template, 12, 2, "div", 14);
      i012.\u0275\u0275elementEnd();
    }
    if (rf & 2) {
      i012.\u0275\u0275advance(3);
      i012.\u0275\u0275classProp("active", ctx.mostrarSkills);
      i012.\u0275\u0275advance(2);
      i012.\u0275\u0275classProp("active", ctx.pestanaActiva === "postulantes" && !ctx.mostrarSkills);
      i012.\u0275\u0275advance(2);
      i012.\u0275\u0275classProp("active", ctx.pestanaActiva === "empresas" && !ctx.mostrarSkills);
      i012.\u0275\u0275advance(2);
      i012.\u0275\u0275classProp("active", ctx.pestanaActiva === "ofertas" && !ctx.mostrarSkills);
      i012.\u0275\u0275advance(2);
      i012.\u0275\u0275classProp("active", ctx.pestanaActiva === "postulaciones" && !ctx.mostrarSkills);
      i012.\u0275\u0275advance(10);
      i012.\u0275\u0275classProp("activa", ctx.pestanaActiva === "empresas");
      i012.\u0275\u0275advance(2);
      i012.\u0275\u0275textInterpolate(ctx.metricas.totalEmpresas);
      i012.\u0275\u0275advance(3);
      i012.\u0275\u0275classProp("activa", ctx.pestanaActiva === "ofertas");
      i012.\u0275\u0275advance(2);
      i012.\u0275\u0275textInterpolate(ctx.metricas.totalOfertas);
      i012.\u0275\u0275advance(3);
      i012.\u0275\u0275classProp("activa", ctx.pestanaActiva === "postulantes");
      i012.\u0275\u0275advance(2);
      i012.\u0275\u0275textInterpolate(ctx.metricas.totalPostulantes);
      i012.\u0275\u0275advance(3);
      i012.\u0275\u0275classProp("activa", ctx.pestanaActiva === "postulaciones");
      i012.\u0275\u0275advance(2);
      i012.\u0275\u0275textInterpolate(ctx.metricas.totalPostulaciones);
      i012.\u0275\u0275advance(4);
      i012.\u0275\u0275conditional(ctx.pestanaActiva === "empresas" ? 42 : -1);
      i012.\u0275\u0275advance();
      i012.\u0275\u0275conditional(ctx.pestanaActiva === "ofertas" ? 43 : -1);
      i012.\u0275\u0275advance();
      i012.\u0275\u0275conditional(ctx.pestanaActiva === "postulantes" ? 44 : -1);
      i012.\u0275\u0275advance();
      i012.\u0275\u0275conditional(ctx.pestanaActiva === "postulaciones" ? 45 : -1);
      i012.\u0275\u0275advance(3);
      i012.\u0275\u0275textInterpolate1(" ", ctx.mostrarSkills ? "\u25B2 Ocultar Gesti\xF3n de Skills" : "\u25BC Ver / Administrar Skills", " ");
      i012.\u0275\u0275advance();
      i012.\u0275\u0275conditional(ctx.mostrarSkills ? 49 : -1);
      i012.\u0275\u0275advance();
      i012.\u0275\u0275conditional(ctx.mostrarModal && ctx.empresaSeleccionada ? 50 : -1);
      i012.\u0275\u0275advance();
      i012.\u0275\u0275conditional(ctx.empresaPerfilId ? 51 : -1);
      i012.\u0275\u0275advance();
      i012.\u0275\u0275conditional(ctx.mostrarModalPostulante && ctx.postulanteSeleccionado ? 52 : -1);
    }
  }, dependencies: [CommonModule6, i18.NgClass, i18.NgComponentOutlet, i18.NgForOf, i18.NgIf, i18.NgTemplateOutlet, i18.NgStyle, i18.NgSwitch, i18.NgSwitchCase, i18.NgSwitchDefault, i18.NgPlural, i18.NgPluralCase, Skills, PostulanteProfile, EmpresaProfile, PostulacionesComponent, i18.AsyncPipe, i18.UpperCasePipe, i18.LowerCasePipe, i18.JsonPipe, i18.SlicePipe, i18.DecimalPipe, i18.PercentPipe, i18.TitleCasePipe, i18.CurrencyPipe, i18.DatePipe, i18.I18nPluralPipe, i18.I18nSelectPipe, i18.KeyValuePipe], styles: ['@charset "UTF-8";\n\n\n@keyframes _ngcontent-%COMP%_fadeIn {\n  from {\n    opacity: 0;\n    transform: scale(0.95);\n  }\n  to {\n    opacity: 1;\n    transform: scale(1);\n  }\n}\n@keyframes _ngcontent-%COMP%_modalEntrada {\n  from {\n    opacity: 0;\n    transform: translateY(15px) scale(0.98);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0) scale(1);\n  }\n}\n.dashboard-layout[_ngcontent-%COMP%] {\n  display: flex;\n  height: 100vh;\n  width: 100%;\n  background-color: #f8f9fa;\n  overflow: hidden;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .sidebar[_ngcontent-%COMP%] {\n  width: 260px;\n  height: 100%;\n  flex-shrink: 0;\n  background-color: #1e293b;\n  color: #ffffff;\n  padding: 2rem 1.25rem;\n  display: flex;\n  flex-direction: column;\n  justify-content: space-between;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .sidebar[_ngcontent-%COMP%]   nav[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 0.5rem;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .sidebar[_ngcontent-%COMP%]   nav[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 0.75rem;\n  padding: 0.85rem 1rem;\n  color: #94a3b8;\n  text-decoration: none;\n  border-radius: 8px;\n  font-weight: 500;\n  transition: all 0.2s ease;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .sidebar[_ngcontent-%COMP%]   nav[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover, \n.dashboard-layout[_ngcontent-%COMP%]   .sidebar[_ngcontent-%COMP%]   nav[_ngcontent-%COMP%]   a.active[_ngcontent-%COMP%] {\n  background-color: #334155;\n  color: #ffffff;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .sidebar[_ngcontent-%COMP%]   .logout[_ngcontent-%COMP%] {\n  margin-top: auto;\n  background-color: #ef4444;\n  color: #ffffff;\n  border: none;\n  padding: 0.75rem 1rem;\n  border-radius: 8px;\n  cursor: pointer;\n  font-weight: 600;\n  transition: background-color 0.2s;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .sidebar[_ngcontent-%COMP%]   .logout[_ngcontent-%COMP%]:hover {\n  background-color: #dc2626;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%], \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%] {\n  flex: 1;\n  height: 100%;\n  overflow-y: auto;\n  padding: 30px 20px;\n  max-width: 1200px;\n  margin: 0 auto;\n  font-family:\n    "Lucida Sans",\n    "Lucida Grande",\n    "Lucida Sans Unicode",\n    Geneva,\n    Verdana,\n    sans-serif;\n  animation: _ngcontent-%COMP%_fadeIn 0.3s ease-in-out;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%], \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  color: #2a1f4c;\n  font-size: 1.8rem;\n  margin-bottom: 6px;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .subtitulo[_ngcontent-%COMP%], \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .subtitulo[_ngcontent-%COMP%] {\n  color: #5d4b7a;\n  font-size: 1rem;\n  margin-bottom: 25px;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%], \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%] {\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .metricas-grid[_ngcontent-%COMP%], \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .metricas-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));\n  gap: 20px;\n  margin-bottom: 35px;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .card-kpi[_ngcontent-%COMP%], \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .card-kpi[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border: 1px solid #d2c2ff;\n  border-radius: 18px;\n  padding: 20px;\n  box-shadow: 0 10px 25px rgba(103, 87, 176, 0.06);\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n  transition:\n    transform 0.2s ease,\n    box-shadow 0.2s ease,\n    border-color 0.2s ease,\n    background-color 0.2s ease;\n  cursor: pointer;\n  -webkit-user-select: none;\n  user-select: none;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .card-kpi[_ngcontent-%COMP%]:hover, \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .card-kpi[_ngcontent-%COMP%]:hover {\n  transform: translateY(-3px);\n  box-shadow: 0 14px 28px rgba(103, 87, 176, 0.1);\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .card-kpi.activa[_ngcontent-%COMP%], \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .card-kpi.activa[_ngcontent-%COMP%] {\n  border-color: #7755f4;\n  background-color: #e9e1ff;\n  box-shadow: 0 12px 26px rgba(103, 87, 176, 0.12);\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .card-kpi[_ngcontent-%COMP%]   .numero[_ngcontent-%COMP%], \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .card-kpi[_ngcontent-%COMP%]   .numero[_ngcontent-%COMP%] {\n  font-size: 2.2rem;\n  font-weight: bold;\n  color: #7755f4;\n  line-height: 1.1;\n  margin-bottom: 6px;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .card-kpi[_ngcontent-%COMP%]   .label[_ngcontent-%COMP%], \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .card-kpi[_ngcontent-%COMP%]   .label[_ngcontent-%COMP%] {\n  font-size: 0.9rem;\n  color: #5d4b7a;\n  font-weight: 600;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .card-kpi.highlight[_ngcontent-%COMP%], \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .card-kpi.highlight[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      135deg,\n      #ffffff 0%,\n      #e9e1ff 100%);\n  border-color: #bfa9f5;\n  cursor: default;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .card-kpi.highlight[_ngcontent-%COMP%]:hover, \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .card-kpi.highlight[_ngcontent-%COMP%]:hover {\n  transform: none;\n  box-shadow: 0 10px 25px rgba(103, 87, 176, 0.06);\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .card-kpi.highlight[_ngcontent-%COMP%]   .numero[_ngcontent-%COMP%], \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .card-kpi.highlight[_ngcontent-%COMP%]   .numero[_ngcontent-%COMP%] {\n  color: #321f57;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%], \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%] {\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .tabla-seccion[_ngcontent-%COMP%], \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .tabla-seccion[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border: 1px solid #bfa9f5;\n  border-radius: 20px;\n  padding: 24px;\n  box-shadow: 0 16px 30px rgba(103, 87, 176, 0.08);\n  margin-bottom: 30px;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .tabla-seccion[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%], \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .tabla-seccion[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  color: #2a1f4c;\n  font-size: 1.3rem;\n  margin-bottom: 20px;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .tabla-seccion[_ngcontent-%COMP%]   .loading[_ngcontent-%COMP%], \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .tabla-seccion[_ngcontent-%COMP%]   .loading[_ngcontent-%COMP%] {\n  text-align: center;\n  padding: 30px;\n  color: #5d4b7a;\n  font-weight: bold;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .tabla-seccion[_ngcontent-%COMP%]   .tabla-admin[_ngcontent-%COMP%], \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .tabla-seccion[_ngcontent-%COMP%]   .tabla-admin[_ngcontent-%COMP%] {\n  width: 100%;\n  border-collapse: collapse;\n  text-align: left;\n  font-size: 0.95rem;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .tabla-seccion[_ngcontent-%COMP%]   .tabla-admin[_ngcontent-%COMP%]   thead[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%], \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .tabla-seccion[_ngcontent-%COMP%]   .tabla-admin[_ngcontent-%COMP%]   thead[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%] {\n  background-color: #e9e1ff;\n  color: #321f57;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .tabla-seccion[_ngcontent-%COMP%]   .tabla-admin[_ngcontent-%COMP%]   thead[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]   th[_ngcontent-%COMP%], \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .tabla-seccion[_ngcontent-%COMP%]   .tabla-admin[_ngcontent-%COMP%]   thead[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]   th[_ngcontent-%COMP%] {\n  padding: 14px 16px;\n  font-weight: bold;\n  border-bottom: 2px solid #d2c2ff;\n  white-space: nowrap;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .tabla-seccion[_ngcontent-%COMP%]   .tabla-admin[_ngcontent-%COMP%]   thead[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]   th[_ngcontent-%COMP%]:first-child, \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .tabla-seccion[_ngcontent-%COMP%]   .tabla-admin[_ngcontent-%COMP%]   thead[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]   th[_ngcontent-%COMP%]:first-child {\n  border-top-left-radius: 12px;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .tabla-seccion[_ngcontent-%COMP%]   .tabla-admin[_ngcontent-%COMP%]   thead[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]   th[_ngcontent-%COMP%]:last-child, \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .tabla-seccion[_ngcontent-%COMP%]   .tabla-admin[_ngcontent-%COMP%]   thead[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]   th[_ngcontent-%COMP%]:last-child {\n  border-top-right-radius: 12px;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .tabla-seccion[_ngcontent-%COMP%]   .tabla-admin[_ngcontent-%COMP%]   tbody[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%], \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .tabla-seccion[_ngcontent-%COMP%]   .tabla-admin[_ngcontent-%COMP%]   tbody[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%] {\n  border-bottom: 1px solid #d2c2ff;\n  transition: background-color 0.2s ease;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .tabla-seccion[_ngcontent-%COMP%]   .tabla-admin[_ngcontent-%COMP%]   tbody[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]:hover, \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .tabla-seccion[_ngcontent-%COMP%]   .tabla-admin[_ngcontent-%COMP%]   tbody[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]:hover {\n  background-color: rgba(233, 225, 255, 0.3);\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .tabla-seccion[_ngcontent-%COMP%]   .tabla-admin[_ngcontent-%COMP%]   tbody[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]   td[_ngcontent-%COMP%], \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .tabla-seccion[_ngcontent-%COMP%]   .tabla-admin[_ngcontent-%COMP%]   tbody[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\n  padding: 14px 16px;\n  color: #321f57;\n  vertical-align: middle;\n  white-space: nowrap;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%], \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%] {\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .badge[_ngcontent-%COMP%], \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .badge[_ngcontent-%COMP%] {\n  display: inline-block;\n  padding: 5px 12px;\n  border-radius: 20px;\n  font-size: 0.85rem;\n  font-weight: bold;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .badge.activo[_ngcontent-%COMP%], \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .badge.activo[_ngcontent-%COMP%] {\n  background-color: #d1fae5;\n  color: #065f46;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .badge.inactivo[_ngcontent-%COMP%], \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .badge.inactivo[_ngcontent-%COMP%] {\n  background-color: #fee2e2;\n  color: #991b1b;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .btn-info[_ngcontent-%COMP%], \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .btn-info[_ngcontent-%COMP%] {\n  background-color: #e9e1ff;\n  color: #321f57;\n  border: 1px solid #d2c2ff;\n  padding: 8px 14px;\n  border-radius: 10px;\n  font-size: 0.88rem;\n  font-weight: bold;\n  cursor: pointer;\n  transition: background-color 0.2s ease;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .btn-info[_ngcontent-%COMP%]:hover, \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .btn-info[_ngcontent-%COMP%]:hover {\n  background-color: rgb(214.3, 199.5, 255);\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .btn-estado[_ngcontent-%COMP%], \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .btn-estado[_ngcontent-%COMP%] {\n  border: none;\n  padding: 8px 14px;\n  border-radius: 10px;\n  font-size: 0.88rem;\n  font-weight: bold;\n  cursor: pointer;\n  transition: opacity 0.2s ease, transform 0.1s ease;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .btn-estado[_ngcontent-%COMP%]:active, \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .btn-estado[_ngcontent-%COMP%]:active {\n  transform: scale(0.97);\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .btn-estado.btn-desactivar[_ngcontent-%COMP%], \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .btn-estado.btn-desactivar[_ngcontent-%COMP%] {\n  background-color: #fecaca;\n  color: #991b1b;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .btn-estado.btn-desactivar[_ngcontent-%COMP%]:hover, \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .btn-estado.btn-desactivar[_ngcontent-%COMP%]:hover {\n  background-color: #fca5a5;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .btn-estado.btn-activar[_ngcontent-%COMP%], \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .btn-estado.btn-activar[_ngcontent-%COMP%] {\n  background-color: #7755f4;\n  color: #ffffff;\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .btn-estado.btn-activar[_ngcontent-%COMP%]:hover, \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .btn-estado.btn-activar[_ngcontent-%COMP%]:hover {\n  background-color: rgb(88.3436464088, 46.679558011, 241.520441989);\n}\n.dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%], \n.dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%] {\n}\n@media (max-width: 768px) {\n  .dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%], \n   .dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%] {\n    padding: 20px 15px;\n  }\n  .dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .metricas-grid[_ngcontent-%COMP%], \n   .dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .metricas-grid[_ngcontent-%COMP%] {\n    grid-template-columns: repeat(2, 1fr);\n  }\n}\n@media (max-width: 576px) {\n  .dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%], \n   .dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%] {\n    padding: 15px 10px;\n  }\n  .dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%], \n   .dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n    font-size: 1.4rem;\n  }\n  .dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .metricas-grid[_ngcontent-%COMP%], \n   .dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .metricas-grid[_ngcontent-%COMP%] {\n    grid-template-columns: 1fr;\n  }\n  .dashboard-layout[_ngcontent-%COMP%]   .main-content[_ngcontent-%COMP%]   .tabla-seccion[_ngcontent-%COMP%], \n   .dashboard-layout[_ngcontent-%COMP%]   .admin-container[_ngcontent-%COMP%]   .tabla-seccion[_ngcontent-%COMP%] {\n    padding: 15px;\n  }\n}\n.modal-overlay[_ngcontent-%COMP%] {\n  position: fixed;\n  top: 0;\n  left: 0;\n  width: 100vw;\n  height: 100vh;\n  background: rgba(42, 31, 76, 0.5);\n  -webkit-backdrop-filter: blur(4px);\n  backdrop-filter: blur(4px);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  z-index: 1000;\n  padding: 15px;\n}\n.modal-overlay[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border: 1px solid #bfa9f5;\n  border-radius: 20px;\n  width: 100%;\n  max-width: 650px;\n  max-height: 90vh;\n  display: flex;\n  flex-direction: column;\n  box-shadow: 0 20px 40px rgba(42, 31, 76, 0.25);\n  animation: _ngcontent-%COMP%_modalEntrada 0.25s ease-out;\n}\n.modal-overlay[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%]   .modal-header[_ngcontent-%COMP%] {\n  padding: 20px 24px;\n  border-bottom: 1px solid #d2c2ff;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n.modal-overlay[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%]   .modal-header[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  margin: 0;\n  color: #2a1f4c;\n  font-size: 1.25rem;\n}\n.modal-overlay[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%]   .modal-header[_ngcontent-%COMP%]   .btn-cerrar[_ngcontent-%COMP%] {\n  background: transparent;\n  border: none;\n  font-size: 1.3rem;\n  color: #5d4b7a;\n  cursor: pointer;\n}\n.modal-overlay[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%]   .modal-header[_ngcontent-%COMP%]   .btn-cerrar[_ngcontent-%COMP%]:hover {\n  color: #2a1f4c;\n}\n.modal-overlay[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%]   .modal-body[_ngcontent-%COMP%] {\n  padding: 24px;\n  overflow-y: auto;\n}\n.modal-overlay[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%]   .modal-body[_ngcontent-%COMP%]   .grid-datos[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));\n  gap: 16px;\n}\n.modal-overlay[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%]   .modal-body[_ngcontent-%COMP%]   .grid-datos[_ngcontent-%COMP%]   .dato-item[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n}\n.modal-overlay[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%]   .modal-body[_ngcontent-%COMP%]   .grid-datos[_ngcontent-%COMP%]   .dato-item[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  font-size: 0.82rem;\n  font-weight: bold;\n  color: #5d4b7a;\n  text-transform: uppercase;\n}\n.modal-overlay[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%]   .modal-body[_ngcontent-%COMP%]   .grid-datos[_ngcontent-%COMP%]   .dato-item[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-size: 0.95rem;\n  color: #321f57;\n  font-weight: 500;\n  word-break: break-word;\n}\n.modal-overlay[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%]   .modal-footer[_ngcontent-%COMP%] {\n  padding: 16px 24px;\n  border-top: 1px solid #d2c2ff;\n  display: flex;\n  justify-content: flex-end;\n  gap: 12px;\n}\n.modal-overlay[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%]   .modal-footer[_ngcontent-%COMP%]   .btn-secundario[_ngcontent-%COMP%] {\n  background-color: #e9e1ff;\n  color: #321f57;\n  border: 1px solid #d2c2ff;\n  padding: 10px 18px;\n  border-radius: 10px;\n  font-weight: bold;\n  cursor: pointer;\n}\n.modal-overlay[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%]   .modal-footer[_ngcontent-%COMP%]   .btn-secundario[_ngcontent-%COMP%]:hover {\n  background-color: rgb(218.04, 204.6, 255);\n}\n/*# sourceMappingURL=panel-admin.css.map */'] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i012.\u0275setClassMetadata(PanelAdmin, [{
    type: Component9,
    args: [{ selector: "app-panel-admin", standalone: true, imports: [CommonModule6, Skills, PostulanteProfile, EmpresaProfile, PostulacionesComponent], template: `<div class="dashboard-layout">
  <!-- Sidebar de navegaci\xF3n -->
  <aside class="sidebar">
    <nav>
      <a (click)="mostrarSkills = true" [class.active]="mostrarSkills" style="cursor: pointer;">\u{1F6E0}\uFE0F Skills y Categor\xEDas</a>
      <a (click)="mostrarSkills = false; cambiarPestana('postulantes')" [class.active]="pestanaActiva === 'postulantes' && !mostrarSkills" style="cursor: pointer;">\u{1F465} Postulantes</a>
      <a (click)="mostrarSkills = false; cambiarPestana('empresas')" [class.active]="pestanaActiva === 'empresas' && !mostrarSkills" style="cursor: pointer;">\u{1F3E2} Empresas</a>
      <a (click)="mostrarSkills = false; cambiarPestana('ofertas')" [class.active]="pestanaActiva === 'ofertas' && !mostrarSkills" style="cursor: pointer;">\u{1F4BC} Ofertas</a>
      <a (click)="mostrarSkills = false; cambiarPestana('postulaciones')" [class.active]="pestanaActiva === 'postulaciones' && !mostrarSkills" style="cursor: pointer;">\u{1F4C4} Postulaciones</a>
    </nav>

  <button class="logout" (click)="cerrarSesion()">Cerrar Sesi\xF3n</button>
    
  </aside>

  <div class="admin-container">
    <h2>\u{1F6E0}\uFE0F Panel de Control Institucional ITBCONECTA</h2>
    <p class="subtitulo">Gesti\xF3n de usuarios, empresas y moderaci\xF3n de la plataforma</p>

    <!-- TARJETAS DE M\xC9TRICAS -->
    <div class="metricas-grid">
      <div 
        class="card-kpi" 
        [class.activa]="pestanaActiva === 'empresas'" 
        (click)="cambiarPestana('empresas')">
        <span class="numero">{{ metricas.totalEmpresas }}</span>
        <span class="label">Empresas Registradas</span>
      </div>

      <div 
        class="card-kpi" 
        [class.activa]="pestanaActiva === 'ofertas'" 
        (click)="cambiarPestana('ofertas')">
        <span class="numero">{{ metricas.totalOfertas }}</span>
        <span class="label">Ofertas Publicadas</span>
      </div>

      <div 
        class="card-kpi" 
        [class.activa]="pestanaActiva === 'postulantes'" 
        (click)="cambiarPestana('postulantes')">
        <span class="numero">{{ metricas.totalPostulantes }}</span>
        <span class="label">Postulantes Registrados</span>
      </div>

      <div 
        class="card-kpi highlight" 
        [class.activa]="pestanaActiva === 'postulaciones'" 
        (click)="mostrarSkills = false; cambiarPestana('postulaciones')"
        style="cursor: pointer;">
        <span class="numero">{{ metricas.totalPostulaciones }}</span>
        <span class="label">Postulaciones Totales</span>
      </div>
    </div>

    <!-- SECCI\xD3N DIN\xC1MICA DE CONTENIDO -->
    <div class="tabla-seccion">

      <!-- VISTA 1: EMPRESAS -->
      @if (pestanaActiva === 'empresas') {
        <h3>\u{1F3E2} Empresas Registradas</h3>

        @if (cargando) {
          <div class="loading">\u23F3 Cargando empresas desde el servidor...</div>
        } @else if (empresas.length > 0) {
          <table class="tabla-admin">
            <thead>
              <tr>
                <th>ID</th>
                <th>Raz\xF3n Social</th>
                <th>CUIT</th>
                <th>Email</th>
                <th>Estado</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              @for (emp of empresas; track emp.id_empresa) {
    <tr>
      <td>#{{ emp.id_empresa }}</td>
      <td><strong>{{ emp.razonSocial }}</strong></td>
      <td>{{ emp.cuit }}</td>
      <td>{{ emp.email }}</td>
      <td>
        <span class="badge" 
              [class.activo]="emp.estado === 'Activo'" 
              [class.inactivo]="emp.estado === 'Inactivo'"
              [class.pendiente]="emp.estado === 'Pendiente'">
          {{ emp.estado }}
        </span>
      </td>
      <td class="acciones-cell">
        <button class="btn-info" (click)="verDetalle(emp)" title="Ver detalle fiscal">
          \u{1F50D} Detalle
        </button>
        
        <button class="btn-info" (click)="abrirPerfilEmpresa(emp.id_empresa)" title="Ver perfil p\xFAblico">
          \u{1F3E2} Perfil
        </button>
        
        <button 
          class="btn-estado" 
          [class.btn-desactivar]="emp.estado === 'Activo'"
          [class.btn-activar]="emp.estado !== 'Activo'"
          (click)="cambiarEstado(emp.id_empresa, emp.estado)">
          {{ emp.estado === 'Activo' ? 'Desactivar' : 'Activar' }}
        </button>
        </td>
        </tr>
              }
        </tbody>
          </table>
        } @else {
          <div class="no-datos">\u26A0\uFE0F No se encontraron empresas en la base de datos.</div>
        }
      }

      <!-- VISTA 2: OFERTAS -->
      @if (pestanaActiva === 'ofertas') {
        <h3>\u{1F4BC} Moderaci\xF3n de Ofertas de Empleo</h3>
        @if (cargando) {
          <div class="loading">\u23F3 Cargando ofertas desde el servidor...</div>
        } @else if (ofertas.length > 0) {
          <table class="tabla-admin">
            <thead>
              <tr>
                <th>ID</th>
                <th>T\xEDtulo / Empresa</th>
                <th>Fecha Publicaci\xF3n</th>
                <th>Vencimiento / Duraci\xF3n</th>
                <th>Modalidad</th>
                <th>Estado</th>
                <th>Acci\xF3n</th>
              </tr>
            </thead>
            <tbody>
              @for (oferta of ofertas; track (oferta.id_oferta || $index)) {
                @let infoEstado = obtenerEstadoYConteo(oferta.fecha_publicacion, oferta.dias_duracion);
                <tr>
                  <td>#{{ oferta.id_oferta }}</td>
                  <td>
                    <strong>{{ oferta.titulo }}</strong><br>
                    <small class="text-muted">{{ oferta.razonSocial || 'Empresa #' + oferta.id_empresa }}</small>
                  </td>
                  <td>{{ formatearFecha(oferta.fecha_publicacion) }}</td>
                  <td>
                    @if (infoEstado.finalizada) {
                      <span class="badge inactivo">Expir\xF3 ({{ oferta.dias_duracion || 10 }}d)</span>
                    } @else {
                      <span class="badge activo">\u231B Quedan {{ infoEstado.dias }} d\xEDas</span>
                    }
                  </td>
                  <td>{{ oferta.modalidad }} ({{ oferta.experiencia }})</td>
                  <td>
                    <span class="badge" [class.activo]="!infoEstado.finalizada" [class.inactivo]="infoEstado.finalizada">
                      {{ infoEstado.estadoText }}
                    </span>
                  </td>
                  <td>
                    <button class="btn-estado btn-desactivar" (click)="bajaOfertaAdmin(oferta.id_oferta)">
                      \u{1F5D1}\uFE0F Eliminar
                    </button>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        } @else {
          <div class="no-datos">\u26A0\uFE0F No se encontraron ofertas de empleo registradas en el sistema.</div>
        }
      }

      <!-- VISTA 3: POSTULANTES -->
      @if (pestanaActiva === 'postulantes') {
        <h3>\u{1F393} Padr\xF3n de Postulantes (Alumnos y Egresados)</h3>

        @if (cargando) {
          <div class="loading">\u23F3 Cargando postulantes desde el servidor...</div>
        } @else if (postulantes.length > 0) {
          <table class="tabla-admin">
            <thead>
              <tr>
                <th>ID</th>
                <th>Nombre y Apellido</th>
                <th>DNI</th>
                <th>Legajo</th>
                <th>Carrera</th>
                <th>Email</th>
                <th>Estado</th>
                <th>Acci\xF3n</th>
              </tr>
            </thead>
            <tbody>
              @for (post of postulantes; track (post.id_postulante || post.id || $index)) {
                <tr>
                  <td>#{{ post.id_postulante || post.id }}</td>
                  <td><strong>{{ post.nombres || post.nombre }} {{ post.apellidos || post.apellido }}</strong></td>
                  <td>{{ post.dni || 'S/D' }}</td>
                  <td>{{ post.legajo || 'S/L' }}</td>
                  <td>{{ post.carrera || 'Analista de Sistemas / IA' }}</td>
                  <td>{{ post.email }}</td>
                  <td>
                    <span class="badge" [class.activo]="post.estado !== 'Inactivo'" [class.inactivo]="post.estado === 'Inactivo'">
                      {{ post.estado || 'Activo' }}
                    </span>
                  </td>
                  <td>
                    <button class="btn-info" (click)="verDetallePostulante(post)">
                      \u{1F50D} Ver Perfil/CV
                    </button>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        } @else {
          <div class="no-datos">\u26A0\uFE0F No se encontraron postulantes registrados en la base de datos.</div>
        }
      }

      <!-- VISTA 4: GESTI\xD3N DE POSTULACIONES COMPLETA -->
      @if (pestanaActiva === 'postulaciones') {
        <app-postulaciones />
      }

    </div>

    <!-- BOT\xD3N TOGGLE Y COMPONENTE INDEPENDIENTE DE SKILLS -->
    <div class="contenedor-toggle-skills" style="margin-top: 2rem;">
      <button class="btn-toggle-skills" (click)="toggleSkills()">
        {{ mostrarSkills ? '\u25B2 Ocultar Gesti\xF3n de Skills' : '\u25BC Ver / Administrar Skills' }}
      </button>
    </div>

    <!-- COMPONENTE SKILLS CONDICIONAL -->
    @if (mostrarSkills) {
      <app-skills />
    }
  </div>

  <!-- MODAL DIN\xC1MICO DE DETALLE DE EMPRESA -->
  @if (mostrarModal && empresaSeleccionada) {
    <div class="modal-overlay" (click)="cerrarModal()">
      <div class="modal-content" (click)="$event.stopPropagation()">
        <div class="modal-header">
          <h3>\u{1F3E2} Ficha de Registro de Empresa</h3>
          <button class="btn-cerrar" (click)="cerrarModal()">\u2715</button>
        </div>
        
        <div class="modal-body">
          <div class="grid-datos">
            @for (item of empresaSeleccionada | keyvalue; track item.key) {
              @if (esCampoVisible(normalizarClave(item.key.toString()))) {
                <div class="dato-item">
                  <label>{{ formatearClave(normalizarClave(item.key.toString())) }}:</label>
                  <span>{{ item.value !== null && item.value !== '' ? item.value : 'No especificado' }}</span>
                </div>
              }
            }
          </div>
        </div>

        <div class="modal-footer">
          <button 
            class="btn-estado" 
            [class.btn-desactivar]="empresaSeleccionada.estado === 'Activo'"
            [class.btn-activar]="empresaSeleccionada.estado !== 'Activo'"
            (click)="cambiarEstado(empresaSeleccionada.id_empresa, empresaSeleccionada.estado)">
            {{ empresaSeleccionada.estado === 'Activo' ? 'Desactivar Empresa' : 'Activar Empresa' }}
          </button>
          <button class="btn-secundario" (click)="cerrarModal()">Cerrar</button>
        </div>
      </div>
    </div>
  }
<!-- ========================================== -->
<!-- 2. MODAL DE PERFIL EMPRESA -->
<!-- ========================================== -->
@if (empresaPerfilId) {
  <div class="modal-overlay" (click)="cerrarModalPerfil()">
    <div class="modal-content modal-perfil-ancho" (click)="$event.stopPropagation()">
      <div class="modal-header">
        <h3>\u{1F3E2} Perfil de la Empresa</h3>
        <button class="btn-cerrar" (click)="cerrarModalPerfil()">\u2715</button>
      </div>
      
      <div class="modal-body">
        <app-empresa-profile 
          [idEmpresaInput]="empresaPerfilId" 
          [esModoAdmin]="true"
          (cerrarModal)="cerrarModalPerfil()">
        </app-empresa-profile>
      </div>
    </div>
  </div>
}

  <!-- MODAL FLOTANTE: VER PERFIL Y CV DEL POSTULANTE -->
@if (mostrarModalPostulante && postulanteSeleccionado) {
  <div class="modal-overlay" (click)="cerrarModalPostulante()">
    <div class="modal-content" (click)="$event.stopPropagation()">
      <div class="modal-header">
        <h3>\u{1F393} Ficha del Postulante</h3>
        <button class="btn-cerrar" (click)="cerrarModalPostulante()">\u2715</button>
      </div>
      
      <div class="modal-body">
        <!-- El componente resuelve solo la b\xFAsqueda de perfil, datos personales y previsualizaci\xF3n/descarga de CV -->
        <app-postulante-profile 
          [idPostulanteInput]="postulanteSeleccionado.id_postulante || postulanteSeleccionado.id"
          [esModoAdmin]="true">
        </app-postulante-profile>
      </div>

      <div class="modal-footer">
        <button class="btn-secundario" (click)="cerrarModalPostulante()">Cerrar</button>
      </div>
    </div>
  </div>
}
</div>`, styles: ['@charset "UTF-8";\n\n/* src/app/pagina/panel-admin/panel-admin.scss */\n@keyframes fadeIn {\n  from {\n    opacity: 0;\n    transform: scale(0.95);\n  }\n  to {\n    opacity: 1;\n    transform: scale(1);\n  }\n}\n@keyframes modalEntrada {\n  from {\n    opacity: 0;\n    transform: translateY(15px) scale(0.98);\n  }\n  to {\n    opacity: 1;\n    transform: translateY(0) scale(1);\n  }\n}\n.dashboard-layout {\n  display: flex;\n  height: 100vh;\n  width: 100%;\n  background-color: #f8f9fa;\n  overflow: hidden;\n}\n.dashboard-layout .sidebar {\n  width: 260px;\n  height: 100%;\n  flex-shrink: 0;\n  background-color: #1e293b;\n  color: #ffffff;\n  padding: 2rem 1.25rem;\n  display: flex;\n  flex-direction: column;\n  justify-content: space-between;\n}\n.dashboard-layout .sidebar nav {\n  display: flex;\n  flex-direction: column;\n  gap: 0.5rem;\n}\n.dashboard-layout .sidebar nav a {\n  display: flex;\n  align-items: center;\n  gap: 0.75rem;\n  padding: 0.85rem 1rem;\n  color: #94a3b8;\n  text-decoration: none;\n  border-radius: 8px;\n  font-weight: 500;\n  transition: all 0.2s ease;\n}\n.dashboard-layout .sidebar nav a:hover,\n.dashboard-layout .sidebar nav a.active {\n  background-color: #334155;\n  color: #ffffff;\n}\n.dashboard-layout .sidebar .logout {\n  margin-top: auto;\n  background-color: #ef4444;\n  color: #ffffff;\n  border: none;\n  padding: 0.75rem 1rem;\n  border-radius: 8px;\n  cursor: pointer;\n  font-weight: 600;\n  transition: background-color 0.2s;\n}\n.dashboard-layout .sidebar .logout:hover {\n  background-color: #dc2626;\n}\n.dashboard-layout .main-content,\n.dashboard-layout .admin-container {\n  flex: 1;\n  height: 100%;\n  overflow-y: auto;\n  padding: 30px 20px;\n  max-width: 1200px;\n  margin: 0 auto;\n  font-family:\n    "Lucida Sans",\n    "Lucida Grande",\n    "Lucida Sans Unicode",\n    Geneva,\n    Verdana,\n    sans-serif;\n  animation: fadeIn 0.3s ease-in-out;\n}\n.dashboard-layout .main-content h2,\n.dashboard-layout .admin-container h2 {\n  color: #2a1f4c;\n  font-size: 1.8rem;\n  margin-bottom: 6px;\n}\n.dashboard-layout .main-content .subtitulo,\n.dashboard-layout .admin-container .subtitulo {\n  color: #5d4b7a;\n  font-size: 1rem;\n  margin-bottom: 25px;\n}\n.dashboard-layout .main-content,\n.dashboard-layout .admin-container {\n}\n.dashboard-layout .main-content .metricas-grid,\n.dashboard-layout .admin-container .metricas-grid {\n  display: grid;\n  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));\n  gap: 20px;\n  margin-bottom: 35px;\n}\n.dashboard-layout .main-content .card-kpi,\n.dashboard-layout .admin-container .card-kpi {\n  background: #ffffff;\n  border: 1px solid #d2c2ff;\n  border-radius: 18px;\n  padding: 20px;\n  box-shadow: 0 10px 25px rgba(103, 87, 176, 0.06);\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n  transition:\n    transform 0.2s ease,\n    box-shadow 0.2s ease,\n    border-color 0.2s ease,\n    background-color 0.2s ease;\n  cursor: pointer;\n  -webkit-user-select: none;\n  user-select: none;\n}\n.dashboard-layout .main-content .card-kpi:hover,\n.dashboard-layout .admin-container .card-kpi:hover {\n  transform: translateY(-3px);\n  box-shadow: 0 14px 28px rgba(103, 87, 176, 0.1);\n}\n.dashboard-layout .main-content .card-kpi.activa,\n.dashboard-layout .admin-container .card-kpi.activa {\n  border-color: #7755f4;\n  background-color: #e9e1ff;\n  box-shadow: 0 12px 26px rgba(103, 87, 176, 0.12);\n}\n.dashboard-layout .main-content .card-kpi .numero,\n.dashboard-layout .admin-container .card-kpi .numero {\n  font-size: 2.2rem;\n  font-weight: bold;\n  color: #7755f4;\n  line-height: 1.1;\n  margin-bottom: 6px;\n}\n.dashboard-layout .main-content .card-kpi .label,\n.dashboard-layout .admin-container .card-kpi .label {\n  font-size: 0.9rem;\n  color: #5d4b7a;\n  font-weight: 600;\n}\n.dashboard-layout .main-content .card-kpi.highlight,\n.dashboard-layout .admin-container .card-kpi.highlight {\n  background:\n    linear-gradient(\n      135deg,\n      #ffffff 0%,\n      #e9e1ff 100%);\n  border-color: #bfa9f5;\n  cursor: default;\n}\n.dashboard-layout .main-content .card-kpi.highlight:hover,\n.dashboard-layout .admin-container .card-kpi.highlight:hover {\n  transform: none;\n  box-shadow: 0 10px 25px rgba(103, 87, 176, 0.06);\n}\n.dashboard-layout .main-content .card-kpi.highlight .numero,\n.dashboard-layout .admin-container .card-kpi.highlight .numero {\n  color: #321f57;\n}\n.dashboard-layout .main-content,\n.dashboard-layout .admin-container {\n}\n.dashboard-layout .main-content .tabla-seccion,\n.dashboard-layout .admin-container .tabla-seccion {\n  background: #ffffff;\n  border: 1px solid #bfa9f5;\n  border-radius: 20px;\n  padding: 24px;\n  box-shadow: 0 16px 30px rgba(103, 87, 176, 0.08);\n  margin-bottom: 30px;\n}\n.dashboard-layout .main-content .tabla-seccion h3,\n.dashboard-layout .admin-container .tabla-seccion h3 {\n  color: #2a1f4c;\n  font-size: 1.3rem;\n  margin-bottom: 20px;\n}\n.dashboard-layout .main-content .tabla-seccion .loading,\n.dashboard-layout .admin-container .tabla-seccion .loading {\n  text-align: center;\n  padding: 30px;\n  color: #5d4b7a;\n  font-weight: bold;\n}\n.dashboard-layout .main-content .tabla-seccion .tabla-admin,\n.dashboard-layout .admin-container .tabla-seccion .tabla-admin {\n  width: 100%;\n  border-collapse: collapse;\n  text-align: left;\n  font-size: 0.95rem;\n}\n.dashboard-layout .main-content .tabla-seccion .tabla-admin thead tr,\n.dashboard-layout .admin-container .tabla-seccion .tabla-admin thead tr {\n  background-color: #e9e1ff;\n  color: #321f57;\n}\n.dashboard-layout .main-content .tabla-seccion .tabla-admin thead tr th,\n.dashboard-layout .admin-container .tabla-seccion .tabla-admin thead tr th {\n  padding: 14px 16px;\n  font-weight: bold;\n  border-bottom: 2px solid #d2c2ff;\n  white-space: nowrap;\n}\n.dashboard-layout .main-content .tabla-seccion .tabla-admin thead tr th:first-child,\n.dashboard-layout .admin-container .tabla-seccion .tabla-admin thead tr th:first-child {\n  border-top-left-radius: 12px;\n}\n.dashboard-layout .main-content .tabla-seccion .tabla-admin thead tr th:last-child,\n.dashboard-layout .admin-container .tabla-seccion .tabla-admin thead tr th:last-child {\n  border-top-right-radius: 12px;\n}\n.dashboard-layout .main-content .tabla-seccion .tabla-admin tbody tr,\n.dashboard-layout .admin-container .tabla-seccion .tabla-admin tbody tr {\n  border-bottom: 1px solid #d2c2ff;\n  transition: background-color 0.2s ease;\n}\n.dashboard-layout .main-content .tabla-seccion .tabla-admin tbody tr:hover,\n.dashboard-layout .admin-container .tabla-seccion .tabla-admin tbody tr:hover {\n  background-color: rgba(233, 225, 255, 0.3);\n}\n.dashboard-layout .main-content .tabla-seccion .tabla-admin tbody tr td,\n.dashboard-layout .admin-container .tabla-seccion .tabla-admin tbody tr td {\n  padding: 14px 16px;\n  color: #321f57;\n  vertical-align: middle;\n  white-space: nowrap;\n}\n.dashboard-layout .main-content,\n.dashboard-layout .admin-container {\n}\n.dashboard-layout .main-content .badge,\n.dashboard-layout .admin-container .badge {\n  display: inline-block;\n  padding: 5px 12px;\n  border-radius: 20px;\n  font-size: 0.85rem;\n  font-weight: bold;\n}\n.dashboard-layout .main-content .badge.activo,\n.dashboard-layout .admin-container .badge.activo {\n  background-color: #d1fae5;\n  color: #065f46;\n}\n.dashboard-layout .main-content .badge.inactivo,\n.dashboard-layout .admin-container .badge.inactivo {\n  background-color: #fee2e2;\n  color: #991b1b;\n}\n.dashboard-layout .main-content .btn-info,\n.dashboard-layout .admin-container .btn-info {\n  background-color: #e9e1ff;\n  color: #321f57;\n  border: 1px solid #d2c2ff;\n  padding: 8px 14px;\n  border-radius: 10px;\n  font-size: 0.88rem;\n  font-weight: bold;\n  cursor: pointer;\n  transition: background-color 0.2s ease;\n}\n.dashboard-layout .main-content .btn-info:hover,\n.dashboard-layout .admin-container .btn-info:hover {\n  background-color: rgb(214.3, 199.5, 255);\n}\n.dashboard-layout .main-content .btn-estado,\n.dashboard-layout .admin-container .btn-estado {\n  border: none;\n  padding: 8px 14px;\n  border-radius: 10px;\n  font-size: 0.88rem;\n  font-weight: bold;\n  cursor: pointer;\n  transition: opacity 0.2s ease, transform 0.1s ease;\n}\n.dashboard-layout .main-content .btn-estado:active,\n.dashboard-layout .admin-container .btn-estado:active {\n  transform: scale(0.97);\n}\n.dashboard-layout .main-content .btn-estado.btn-desactivar,\n.dashboard-layout .admin-container .btn-estado.btn-desactivar {\n  background-color: #fecaca;\n  color: #991b1b;\n}\n.dashboard-layout .main-content .btn-estado.btn-desactivar:hover,\n.dashboard-layout .admin-container .btn-estado.btn-desactivar:hover {\n  background-color: #fca5a5;\n}\n.dashboard-layout .main-content .btn-estado.btn-activar,\n.dashboard-layout .admin-container .btn-estado.btn-activar {\n  background-color: #7755f4;\n  color: #ffffff;\n}\n.dashboard-layout .main-content .btn-estado.btn-activar:hover,\n.dashboard-layout .admin-container .btn-estado.btn-activar:hover {\n  background-color: rgb(88.3436464088, 46.679558011, 241.520441989);\n}\n.dashboard-layout .main-content,\n.dashboard-layout .admin-container {\n}\n@media (max-width: 768px) {\n  .dashboard-layout .main-content,\n  .dashboard-layout .admin-container {\n    padding: 20px 15px;\n  }\n  .dashboard-layout .main-content .metricas-grid,\n  .dashboard-layout .admin-container .metricas-grid {\n    grid-template-columns: repeat(2, 1fr);\n  }\n}\n@media (max-width: 576px) {\n  .dashboard-layout .main-content,\n  .dashboard-layout .admin-container {\n    padding: 15px 10px;\n  }\n  .dashboard-layout .main-content h2,\n  .dashboard-layout .admin-container h2 {\n    font-size: 1.4rem;\n  }\n  .dashboard-layout .main-content .metricas-grid,\n  .dashboard-layout .admin-container .metricas-grid {\n    grid-template-columns: 1fr;\n  }\n  .dashboard-layout .main-content .tabla-seccion,\n  .dashboard-layout .admin-container .tabla-seccion {\n    padding: 15px;\n  }\n}\n.modal-overlay {\n  position: fixed;\n  top: 0;\n  left: 0;\n  width: 100vw;\n  height: 100vh;\n  background: rgba(42, 31, 76, 0.5);\n  -webkit-backdrop-filter: blur(4px);\n  backdrop-filter: blur(4px);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  z-index: 1000;\n  padding: 15px;\n}\n.modal-overlay .modal-content {\n  background: #ffffff;\n  border: 1px solid #bfa9f5;\n  border-radius: 20px;\n  width: 100%;\n  max-width: 650px;\n  max-height: 90vh;\n  display: flex;\n  flex-direction: column;\n  box-shadow: 0 20px 40px rgba(42, 31, 76, 0.25);\n  animation: modalEntrada 0.25s ease-out;\n}\n.modal-overlay .modal-content .modal-header {\n  padding: 20px 24px;\n  border-bottom: 1px solid #d2c2ff;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n.modal-overlay .modal-content .modal-header h3 {\n  margin: 0;\n  color: #2a1f4c;\n  font-size: 1.25rem;\n}\n.modal-overlay .modal-content .modal-header .btn-cerrar {\n  background: transparent;\n  border: none;\n  font-size: 1.3rem;\n  color: #5d4b7a;\n  cursor: pointer;\n}\n.modal-overlay .modal-content .modal-header .btn-cerrar:hover {\n  color: #2a1f4c;\n}\n.modal-overlay .modal-content .modal-body {\n  padding: 24px;\n  overflow-y: auto;\n}\n.modal-overlay .modal-content .modal-body .grid-datos {\n  display: grid;\n  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));\n  gap: 16px;\n}\n.modal-overlay .modal-content .modal-body .grid-datos .dato-item {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n}\n.modal-overlay .modal-content .modal-body .grid-datos .dato-item label {\n  font-size: 0.82rem;\n  font-weight: bold;\n  color: #5d4b7a;\n  text-transform: uppercase;\n}\n.modal-overlay .modal-content .modal-body .grid-datos .dato-item span {\n  font-size: 0.95rem;\n  color: #321f57;\n  font-weight: 500;\n  word-break: break-word;\n}\n.modal-overlay .modal-content .modal-footer {\n  padding: 16px 24px;\n  border-top: 1px solid #d2c2ff;\n  display: flex;\n  justify-content: flex-end;\n  gap: 12px;\n}\n.modal-overlay .modal-content .modal-footer .btn-secundario {\n  background-color: #e9e1ff;\n  color: #321f57;\n  border: 1px solid #d2c2ff;\n  padding: 10px 18px;\n  border-radius: 10px;\n  font-weight: bold;\n  cursor: pointer;\n}\n.modal-overlay .modal-content .modal-footer .btn-secundario:hover {\n  background-color: rgb(218.04, 204.6, 255);\n}\n/*# sourceMappingURL=panel-admin.css.map */\n'] }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i012.\u0275setClassDebugInfo(PanelAdmin, { className: "PanelAdmin", filePath: "app/pagina/panel-admin/panel-admin.ts", lineNumber: 27 });
})();
(() => {
  const id = "app%2Fpagina%2Fpanel-admin%2Fpanel-admin.ts%40PanelAdmin";
  function PanelAdmin_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i012.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i012.\u0275\u0275replaceMetadata(PanelAdmin, m.default, [i012, i18], [CommonModule6, Skills, PostulanteProfile, EmpresaProfile, PostulacionesComponent, Component9], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && PanelAdmin_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && PanelAdmin_HmrLoad(d.timestamp)));
})();

// src/app/guards/auth.guard.ts
import { inject as inject10 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import { Router as Router7 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_router.js?v=3d725e17";
var authGuard = (route, state) => {
  const authService = inject10(AuthService);
  const router = inject10(Router7);
  if (authService.isLoggedIn()) {
    return true;
  }
  return router.createUrlTree(["/sesion"]);
};

// src/app/guards/admin.guard.ts
import { inject as inject11 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import { Router as Router8 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_router.js?v=3d725e17";
var adminGuard = (route, state) => {
  const authService = inject11(AuthService);
  const router = inject11(Router8);
  if (!authService.isLoggedIn()) {
    return router.createUrlTree(["/sesion"]);
  }
  if (authService.getTipoUsuario() === "admin") {
    return true;
  }
  const rol = authService.getTipoUsuario();
  if (rol === "empresa") {
    return router.createUrlTree(["/empresa/mis-candidatos"]);
  }
  return router.createUrlTree(["/mis-postulaciones"]);
};

// src/app/guards/postulante.guard.ts
import { inject as inject12 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import { Router as Router9 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_router.js?v=3d725e17";
var postulanteGuard = () => {
  const authService = inject12(AuthService);
  const router = inject12(Router9);
  if (authService.isLoggedIn() && authService.getTipoUsuario() === "postulante") {
    return true;
  }
  return router.createUrlTree(["/sesion"]);
};

// src/app/guards/empresa.guard.ts
import { inject as inject13 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import { Router as Router10 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_router.js?v=3d725e17";
var empresaGuard = () => {
  const authService = inject13(AuthService);
  const router = inject13(Router10);
  if (authService.isLoggedIn() && authService.getTipoUsuario() === "empresa") {
    return true;
  }
  return router.createUrlTree(["/sesion"]);
};

// src/app/app.routes.ts
var routes = [
  // ===================================================
  // 1. RUTAS PÚBLICAS Y AUTENTICACIÓN
  // ===================================================
  { path: "", component: Principal },
  { path: "sesion", component: Sesion },
  { path: "registrar", component: RegistrarHome },
  { path: "registrar-postulante", component: RegistrarPostulante },
  { path: "registrar-empresa", component: RegistrarEmpresa },
  // Cartelera pública (lectura para todos)
  { path: "ofertas", component: Ofertas },
  // Mis publicaciones (Reutiliza Ofertas filtrando por la empresa logueada)
  {
    path: "mis-ofertas",
    component: Ofertas,
    canActivate: [empresaGuard]
  },
  // ===================================================
  // 2. VISTAS PROTEGIDAS DE PERFILES INDIVIDUALES
  // ===================================================
  {
    path: "empresa/:id",
    loadComponent: () => import("/chunk-WVPOJJLQ.js").then((m) => m.EmpresaProfile),
    canActivate: [authGuard]
  },
  {
    path: "postulante/:id",
    loadComponent: () => import("/chunk-AWACUVP3.js").then((m) => m.PostulanteProfile),
    canActivate: [authGuard]
  },
  // ===================================================
  // 3. RUTAS POR ROL ESPECÍFICO
  // ===================================================
  // Vista para el Postulante ("Mis Postulaciones")
  {
    path: "postulaciones",
    component: PostulacionesComponent,
    canActivate: [authGuard]
  },
  // Vista para la Empresa ("Candidatos de una Oferta concreta")
  {
    path: "postulaciones/oferta/:idOferta",
    component: PostulacionesComponent,
    canActivate: [authGuard]
  },
  {
    path: "panel-admin",
    component: PanelAdmin,
    canActivate: [adminGuard]
  },
  // ===================================================
  // 4. EDICIÓN DE PERFILES Y PANEL (Layout con Sidebar)
  // ===================================================
  {
    path: "perfil",
    loadComponent: () => import("/chunk-OF3TZJQ6.js").then((m) => m.Sidebar),
    canActivate: [authGuard],
    children: [
      {
        path: "postulante",
        loadComponent: () => import("/chunk-AWACUVP3.js").then((m) => m.PostulanteProfile),
        canActivate: [postulanteGuard]
      },
      {
        path: "curriculum",
        loadComponent: () => import("/chunk-CGLQPF3B.js").then((m) => m.Curriculum),
        canActivate: [postulanteGuard]
      },
      {
        path: "empresa",
        loadComponent: () => import("/chunk-WVPOJJLQ.js").then((m) => m.EmpresaProfile),
        canActivate: [empresaGuard]
      },
      // 👈 RUTAS DEL BUSCADOR INTEGRADAS AL SIDEBAR
      {
        path: "empresas",
        loadComponent: () => import("/chunk-COA7KSLL.js").then((m) => m.Buscador)
      },
      {
        path: "postulantes",
        loadComponent: () => import("/chunk-COA7KSLL.js").then((m) => m.Buscador)
      }
    ]
  },
  // ===================================================
  // 5. REDIRECCIÓN POR DEFECTO
  // ===================================================
  { path: "**", redirectTo: "" }
];

// src/app/app.config.ts
import { provideClientHydration, withEventReplay } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_platform-browser.js?v=3d725e17";

// src/app/interceptors/auth.interceptor.ts
import { inject as inject14, PLATFORM_ID } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import { isPlatformBrowser } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_common.js?v=3d725e17";
import { Router as Router11 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_router.js?v=3d725e17";
import { catchError, throwError } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/rxjs.js?v=3d725e17";
var authInterceptor = (req, next) => {
  const platformId = inject14(PLATFORM_ID);
  const router = inject14(Router11);
  let token = null;
  if (isPlatformBrowser(platformId)) {
    const rawToken = localStorage.getItem("token");
    if (rawToken) {
      token = rawToken;
    } else {
      const usuarioSesion = localStorage.getItem("usuario");
      if (usuarioSesion) {
        try {
          const userObj = JSON.parse(usuarioSesion);
          token = userObj.token || userObj.jwt || null;
        } catch (e) {
          console.error("Error parseando usuario en el interceptor:", e);
        }
      }
    }
    if (token) {
      token = token.replace(/^"|"$/g, "").trim();
    }
  }
  const authReq = token ? req.clone({
    setHeaders: {
      Authorization: `Bearer ${token}`
    }
  }) : req;
  return next(authReq).pipe(catchError((error) => {
    if (isPlatformBrowser(platformId)) {
      if (error.status === 401) {
        localStorage.removeItem("token");
        localStorage.removeItem("usuario");
        if (router.url !== "/sesion") {
          router.navigate(["/sesion"]);
        }
      } else if (error.status === 403) {
        console.warn("Acceso denegado (403): No cuentas con el rol necesario para esta acci\xF3n.");
      }
    }
    return throwError(() => error);
  }));
};

// src/app/app.config.ts
registerLocaleData(localeEs);
var appConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideRouter(routes),
    provideClientHydration(withEventReplay()),
    provideHttpClient(withFetch(), withInterceptors([authInterceptor])),
    { provide: LOCALE_ID, useValue: "es" }
  ]
};

// src/app/app.ts
import { Component as Component12, signal } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import { RouterOutlet as RouterOutlet2 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_router.js?v=3d725e17";

// src/app/componentes/header/header.ts
import { Component as Component10, inject as inject15 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import { RouterLink as RouterLink6, Router as Router12 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_router.js?v=3d725e17";
import * as i013 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
function Header_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    i013.\u0275\u0275elementStart(0, "a", 3);
    i013.\u0275\u0275text(1, "Registrarse");
    i013.\u0275\u0275elementEnd();
    i013.\u0275\u0275elementStart(2, "a", 4);
    i013.\u0275\u0275text(3, "Iniciar sesi\xF3n");
    i013.\u0275\u0275elementEnd();
  }
}
function Header_Conditional_9_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    i013.\u0275\u0275elementStart(0, "a", 5);
    i013.\u0275\u0275text(1, "Panel Admin");
    i013.\u0275\u0275elementEnd();
  }
}
function Header_Conditional_9_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    i013.\u0275\u0275elementStart(0, "a", 6);
    i013.\u0275\u0275text(1, "Ir al Perfil");
    i013.\u0275\u0275elementEnd();
  }
}
function Header_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = i013.\u0275\u0275getCurrentView();
    i013.\u0275\u0275conditionalCreate(0, Header_Conditional_9_Conditional_0_Template, 2, 0, "a", 5);
    i013.\u0275\u0275conditionalCreate(1, Header_Conditional_9_Conditional_1_Template, 2, 0, "a", 6);
    i013.\u0275\u0275elementStart(2, "a", 7);
    i013.\u0275\u0275listener("click", function Header_Conditional_9_Template_a_click_2_listener() {
      i013.\u0275\u0275restoreView(_r1);
      const ctx_r1 = i013.\u0275\u0275nextContext();
      return i013.\u0275\u0275resetView(ctx_r1.cerrarSesion());
    });
    i013.\u0275\u0275text(3, "Cerrar sesi\xF3n");
    i013.\u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = i013.\u0275\u0275nextContext();
    i013.\u0275\u0275conditional(ctx_r1.authService.getTipoUsuario() === "admin" ? 0 : -1);
    i013.\u0275\u0275advance();
    i013.\u0275\u0275conditional(ctx_r1.authService.getTipoUsuario() === "postulante" || ctx_r1.authService.getTipoUsuario() === "empresa" ? 1 : -1);
  }
}
var Header = class _Header {
  authService = inject15(AuthService);
  router = inject15(Router12);
  cerrarSesion() {
    this.authService.logout();
    this.router.navigate(["/sesion"]);
  }
  irPerfil() {
    const tipo = localStorage.getItem("tipo");
    if (tipo === "empresa") {
      this.router.navigate(["/perfil-empresa"]);
    } else if (tipo === "postulante") {
      this.router.navigate(["/perfil-postulante"]);
    } else {
      this.router.navigate(["/sesion"]);
    }
  }
  static \u0275fac = function Header_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Header)();
  };
  static \u0275cmp = /* @__PURE__ */ i013.\u0275\u0275defineComponent({ type: _Header, selectors: [["app-header"]], decls: 10, vars: 1, consts: [["routerLink", "/principal"], ["src", "Logotrans.png", "alt", "Logo ITB", 1, "logo-header"], ["routerLink", "/ofertas"], ["routerLink", "/registrar"], ["routerLink", "/sesion"], ["routerLink", "/panel-admin"], ["routerLink", "/perfil"], [2, "cursor", "pointer", 3, "click"]], template: function Header_Template(rf, ctx) {
    if (rf & 1) {
      i013.\u0275\u0275elementStart(0, "header")(1, "nav")(2, "a", 0);
      i013.\u0275\u0275element(3, "img", 1);
      i013.\u0275\u0275elementEnd();
      i013.\u0275\u0275elementStart(4, "a", 0);
      i013.\u0275\u0275text(5, "Inicio");
      i013.\u0275\u0275elementEnd();
      i013.\u0275\u0275elementStart(6, "a", 2);
      i013.\u0275\u0275text(7, "Oportunidades");
      i013.\u0275\u0275elementEnd();
      i013.\u0275\u0275conditionalCreate(8, Header_Conditional_8_Template, 4, 0)(9, Header_Conditional_9_Template, 4, 2);
      i013.\u0275\u0275elementEnd()();
    }
    if (rf & 2) {
      i013.\u0275\u0275advance(8);
      i013.\u0275\u0275conditional(!ctx.authService.isLoggedIn() ? 8 : 9);
    }
  }, dependencies: [RouterLink6], styles: ['\nheader[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      90deg,\n      #06245c,\n      #0aa7b8);\n  color: white;\n  padding: 1.5rem 2rem;\n  width: 100%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 2rem;\n  border-radius: 32px;\n  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);\n}\nimg[_ngcontent-%COMP%] {\n  width: 140px;\n  height: auto;\n}\nnav[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 1rem;\n  align-items: center;\n}\nnav[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  color: #ffffff;\n  text-decoration: none;\n  padding: 0.75rem 1.2rem;\n  font-family:\n    "Lucida Sans",\n    "Lucida Grande",\n    "Lucida Sans Unicode",\n    Geneva,\n    Verdana,\n    sans-serif;\n  font-size: 1.2rem;\n  font-weight: 600;\n  border-radius: 999px;\n  transition: 0.3s;\n}\nnav[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover {\n  background-color: rgba(255, 255, 255, 0.18);\n  color: #dffcff;\n  transform: translateY(-2px);\n}\n@media (min-width: 768px) and (max-width: 1024px) {\n  header[_ngcontent-%COMP%] {\n    justify-content: space-between;\n    padding: 1.2rem 1.5rem;\n    gap: 1rem;\n  }\n  img[_ngcontent-%COMP%] {\n    width: 110px;\n  }\n  nav[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n    font-size: 1.05rem;\n    padding: 0.6rem 1rem;\n  }\n}\n@media (max-width: 767px) {\n  header[_ngcontent-%COMP%] {\n    justify-content: space-between;\n    padding: 0.6rem 1rem;\n    gap: 0.5rem;\n    border-radius: 16px;\n  }\n  img[_ngcontent-%COMP%] {\n    width: 85px;\n  }\n  nav[_ngcontent-%COMP%] {\n    gap: 0.2rem;\n  }\n  nav[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n    font-size: 0.85rem;\n    padding: 0.4rem 0.6rem;\n    font-weight: 700;\n  }\n}\n/*# sourceMappingURL=header.css.map */'] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i013.\u0275setClassMetadata(Header, [{
    type: Component10,
    args: [{ selector: "app-header", standalone: true, imports: [RouterLink6], template: `<header>\r
    \r
<nav>\r
    <!-- Logo e Inicio (siempre visibles) -->\r
    <a routerLink="/principal">\r
      <img src="Logotrans.png" alt="Logo ITB" class="logo-header">\r
    </a>  \r
    <a routerLink="/principal">Inicio</a> \r
    <a routerLink="/ofertas">Oportunidades</a>\r
\r
    <!-- SI NO HAY SESI\xD3N ACTIVA -->\r
    @if (!authService.isLoggedIn()) {\r
      <a routerLink="/registrar">Registrarse</a>\r
      <a routerLink="/sesion">Iniciar sesi\xF3n</a>\r
    } \r
    <!-- SI HAY SESI\xD3N ACTIVA -->\r
    @else {\r
      <!-- Solo si es Admin -->\r
      @if (authService.getTipoUsuario() === 'admin') {\r
        <a routerLink="/panel-admin">Panel Admin</a>\r
      }\r
\r
      <!-- Solo si es Postulante o Empresa -->\r
      @if (authService.getTipoUsuario() === 'postulante' || authService.getTipoUsuario() === 'empresa') {\r
        <a routerLink="/perfil">Ir al Perfil</a>\r
      }\r
\r
      <!-- Opci\xF3n para salir -->\r
      <a (click)="cerrarSesion()" style="cursor: pointer;">Cerrar sesi\xF3n</a>\r
    }\r
  </nav>\r
\r
</header>\r
`, styles: ['/* src/app/componentes/header/header.scss */\nheader {\n  background:\n    linear-gradient(\n      90deg,\n      #06245c,\n      #0aa7b8);\n  color: white;\n  padding: 1.5rem 2rem;\n  width: 100%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 2rem;\n  border-radius: 32px;\n  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);\n}\nimg {\n  width: 140px;\n  height: auto;\n}\nnav {\n  display: flex;\n  gap: 1rem;\n  align-items: center;\n}\nnav a {\n  color: #ffffff;\n  text-decoration: none;\n  padding: 0.75rem 1.2rem;\n  font-family:\n    "Lucida Sans",\n    "Lucida Grande",\n    "Lucida Sans Unicode",\n    Geneva,\n    Verdana,\n    sans-serif;\n  font-size: 1.2rem;\n  font-weight: 600;\n  border-radius: 999px;\n  transition: 0.3s;\n}\nnav a:hover {\n  background-color: rgba(255, 255, 255, 0.18);\n  color: #dffcff;\n  transform: translateY(-2px);\n}\n@media (min-width: 768px) and (max-width: 1024px) {\n  header {\n    justify-content: space-between;\n    padding: 1.2rem 1.5rem;\n    gap: 1rem;\n  }\n  img {\n    width: 110px;\n  }\n  nav a {\n    font-size: 1.05rem;\n    padding: 0.6rem 1rem;\n  }\n}\n@media (max-width: 767px) {\n  header {\n    justify-content: space-between;\n    padding: 0.6rem 1rem;\n    gap: 0.5rem;\n    border-radius: 16px;\n  }\n  img {\n    width: 85px;\n  }\n  nav {\n    gap: 0.2rem;\n  }\n  nav a {\n    font-size: 0.85rem;\n    padding: 0.4rem 0.6rem;\n    font-weight: 700;\n  }\n}\n/*# sourceMappingURL=header.css.map */\n'] }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i013.\u0275setClassDebugInfo(Header, { className: "Header", filePath: "app/componentes/header/header.ts", lineNumber: 13 });
})();
(() => {
  const id = "app%2Fcomponentes%2Fheader%2Fheader.ts%40Header";
  function Header_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i013.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i013.\u0275\u0275replaceMetadata(Header, m.default, [i013], [RouterLink6, Component10], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && Header_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && Header_HmrLoad(d.timestamp)));
})();

// src/app/componentes/footer/footer.ts
import { Component as Component11 } from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
import * as i014 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
var Footer = class _Footer {
  static \u0275fac = function Footer_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Footer)();
  };
  static \u0275cmp = /* @__PURE__ */ i014.\u0275\u0275defineComponent({ type: _Footer, selectors: [["app-footer"]], decls: 7, vars: 0, consts: [["href", "mailto:info@nuestrosistema.com"]], template: function Footer_Template(rf, ctx) {
    if (rf & 1) {
      i014.\u0275\u0275domElementStart(0, "footer")(1, "h4");
      i014.\u0275\u0275text(2, "\xA9 2026 Nuestro Sistema de Intermediaci\xF3n Laboral. Todos los derechos reservados.");
      i014.\u0275\u0275domElementEnd();
      i014.\u0275\u0275domElementStart(3, "p");
      i014.\u0275\u0275text(4, "Contacto: ");
      i014.\u0275\u0275domElementStart(5, "a", 0);
      i014.\u0275\u0275text(6, "info@nuestrosistema.com");
      i014.\u0275\u0275domElementEnd()()();
    }
  }, styles: ["\nfooter[_ngcontent-%COMP%] {\n  background:\n    linear-gradient(\n      90deg,\n      #06245c,\n      #0aa7b8);\n  color: white;\n  text-align: center;\n  padding: 1.5rem 1rem;\n  width: 100%;\n  margin-top: auto;\n  border-radius: 32px;\n  box-shadow: 0 18px 40px rgba(0, 0, 0, 0.12);\n}\nfooter[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  margin: 0.5rem 0;\n  font-size: 1rem;\n  color: white;\n}\nfooter[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 0.5rem 0;\n  font-size: 0.95rem;\n  color: #e7f9fb;\n}\nfooter[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  color: white;\n  text-decoration: none;\n  transition: 0.3s;\n}\nfooter[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover {\n  color: #dffcff;\n}\n/*# sourceMappingURL=footer.css.map */"] });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i014.\u0275setClassMetadata(Footer, [{
    type: Component11,
    args: [{ selector: "app-footer", imports: [], template: '<footer>\n\n<h4>&copy; 2026 Nuestro Sistema de Intermediaci\xF3n Laboral. Todos los derechos reservados.</h4>\n<p>Contacto: <a href="mailto:info@nuestrosistema.com">info@nuestrosistema.com</a></p>\n\n</footer>', styles: ["/* src/app/componentes/footer/footer.scss */\nfooter {\n  background:\n    linear-gradient(\n      90deg,\n      #06245c,\n      #0aa7b8);\n  color: white;\n  text-align: center;\n  padding: 1.5rem 1rem;\n  width: 100%;\n  margin-top: auto;\n  border-radius: 32px;\n  box-shadow: 0 18px 40px rgba(0, 0, 0, 0.12);\n}\nfooter h4 {\n  margin: 0.5rem 0;\n  font-size: 1rem;\n  color: white;\n}\nfooter p {\n  margin: 0.5rem 0;\n  font-size: 0.95rem;\n  color: #e7f9fb;\n}\nfooter a {\n  color: white;\n  text-decoration: none;\n  transition: 0.3s;\n}\nfooter a:hover {\n  color: #dffcff;\n}\n/*# sourceMappingURL=footer.css.map */\n"] }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i014.\u0275setClassDebugInfo(Footer, { className: "Footer", filePath: "app/componentes/footer/footer.ts", lineNumber: 9 });
})();
(() => {
  const id = "app%2Fcomponentes%2Ffooter%2Ffooter.ts%40Footer";
  function Footer_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i014.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i014.\u0275\u0275replaceMetadata(Footer, m.default, [i014], [Component11], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && Footer_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && Footer_HmrLoad(d.timestamp)));
})();

// src/app/app.ts
import * as i015 from "/@fs/C:/algo3/Conecta/.angular/cache/21.2.8/Conecta/vite/deps/@angular_core.js?v=3d725e17";
var App = class _App {
  title = signal("Conecta", ...ngDevMode ? [{ debugName: "title" }] : (
    /* istanbul ignore next */
    []
  ));
  static \u0275fac = function App_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _App)();
  };
  static \u0275cmp = /* @__PURE__ */ i015.\u0275\u0275defineComponent({ type: _App, selectors: [["app-root"]], decls: 4, vars: 0, template: function App_Template(rf, ctx) {
    if (rf & 1) {
      i015.\u0275\u0275element(0, "app-header");
      i015.\u0275\u0275elementStart(1, "main");
      i015.\u0275\u0275element(2, "router-outlet");
      i015.\u0275\u0275elementEnd();
      i015.\u0275\u0275element(3, "app-footer");
    }
  }, dependencies: [RouterOutlet2, Header, Footer], encapsulation: 2 });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i015.\u0275setClassMetadata(App, [{
    type: Component12,
    args: [{ standalone: true, selector: "app-root", imports: [RouterOutlet2, Header, Footer], template: "<app-header></app-header>\r\n<main>\r\n  <router-outlet></router-outlet>\r\n</main>\r\n\r\n<app-footer></app-footer>" }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && i015.\u0275setClassDebugInfo(App, { className: "App", filePath: "app/app.ts", lineNumber: 14 });
})();
(() => {
  const id = "app%2Fapp.ts%40App";
  function App_HmrLoad(t) {
    import(
      /* @vite-ignore */
      __vite__injectQuery(i015.\u0275\u0275getReplaceMetadataURL(id, t, import.meta.url), 'import')
    ).then((m) => m.default && i015.\u0275\u0275replaceMetadata(App, m.default, [i015], [RouterOutlet2, Header, Footer, Component12], import.meta, id));
  }
  (typeof ngDevMode === "undefined" || ngDevMode) && App_HmrLoad(Date.now());
  (typeof ngDevMode === "undefined" || ngDevMode) && (import.meta.hot && import.meta.hot.on("angular:component-update", (d) => d.id === id && App_HmrLoad(d.timestamp)));
})();

// src/main.ts
bootstrapApplication(App, appConfig).catch((err) => console.error(err));


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9tYWluLnRzIiwic3JjL2FwcC9hcHAuY29uZmlnLnRzIiwic3JjL2FwcC9wYWdpbmEvcHJpbmNpcGFsL3ByaW5jaXBhbC50cyIsInNyYy9hcHAvcGFnaW5hL3ByaW5jaXBhbC9wcmluY2lwYWwuaHRtbCIsInNyYy9hcHAvcGFnaW5hL3Nlc2lvbi9zZXNpb24udHMiLCJzcmMvYXBwL3BhZ2luYS9zZXNpb24vc2VzaW9uLmh0bWwiLCJzcmMvYXBwL3BhZ2luYS9yZWdpc3RyYXIvcmVnaXN0cmFyLWhvbWUvcmVnaXN0cmFyLWhvbWUudHMiLCJzcmMvYXBwL3BhZ2luYS9yZWdpc3RyYXIvcmVnaXN0cmFyLWhvbWUvcmVnaXN0cmFyLWhvbWUuaHRtbCIsInNyYy9hcHAvcGFnaW5hL3JlZ2lzdHJhci9yZWdpc3RyYXItcG9zdHVsYW50ZS9yZWdpc3RyYXItcG9zdHVsYW50ZS50cyIsInNyYy9hcHAvcGFnaW5hL3JlZ2lzdHJhci9yZWdpc3RyYXItcG9zdHVsYW50ZS9yZWdpc3RyYXItcG9zdHVsYW50ZS5odG1sIiwic3JjL2FwcC9wYWdpbmEvcmVnaXN0cmFyL3JlZ2lzdHJhci1lbXByZXNhL3JlZ2lzdHJhci1lbXByZXNhLnRzIiwic3JjL2FwcC9wYWdpbmEvcmVnaXN0cmFyL3JlZ2lzdHJhci1lbXByZXNhL3JlZ2lzdHJhci1lbXByZXNhLmh0bWwiLCJzcmMvYXBwL3BhZ2luYS9vZmVydGFzL29mZXJ0YXMudHMiLCJzcmMvYXBwL3BhZ2luYS9vZmVydGFzL29mZXJ0YXMuaHRtbCIsInNyYy9hcHAvc2VydmljZXMvb2ZlcnRhX3NlcnZpY2UudHMiLCJzcmMvYXBwL3NlcnZpY2VzL3Bvc3R1bGFjaW9uZXMuc2VydmljZS50cyIsInNyYy9hcHAvcGFnaW5hL3Bvc3R1bGFjaW9uZXMvcG9zdHVsYWNpb25lcy50cyIsInNyYy9hcHAvcGFnaW5hL3Bvc3R1bGFjaW9uZXMvcG9zdHVsYWNpb25lcy5odG1sIiwic3JjL2FwcC9wYWdpbmEvcGFuZWwtYWRtaW4vcGFuZWwtYWRtaW4udHMiLCJzcmMvYXBwL3BhZ2luYS9wYW5lbC1hZG1pbi9wYW5lbC1hZG1pbi5odG1sIiwic3JjL2FwcC9wYWdpbmEvcGFuZWwtYWRtaW4vc2tpbGxzL3NraWxscy50cyIsInNyYy9hcHAvcGFnaW5hL3BhbmVsLWFkbWluL3NraWxscy9za2lsbHMuaHRtbCIsInNyYy9hcHAvc2VydmljZXMvYWRtaW4udHMiLCJzcmMvYXBwL2d1YXJkcy9hdXRoLmd1YXJkLnRzIiwic3JjL2FwcC9ndWFyZHMvYWRtaW4uZ3VhcmQudHMiLCJzcmMvYXBwL2d1YXJkcy9wb3N0dWxhbnRlLmd1YXJkLnRzIiwic3JjL2FwcC9ndWFyZHMvZW1wcmVzYS5ndWFyZC50cyIsInNyYy9hcHAvYXBwLnJvdXRlcy50cyIsInNyYy9hcHAvaW50ZXJjZXB0b3JzL2F1dGguaW50ZXJjZXB0b3IudHMiLCJzcmMvYXBwL2FwcC50cyIsInNyYy9hcHAvYXBwLmh0bWwiLCJzcmMvYXBwL2NvbXBvbmVudGVzL2hlYWRlci9oZWFkZXIudHMiLCJzcmMvYXBwL2NvbXBvbmVudGVzL2hlYWRlci9oZWFkZXIuaHRtbCIsInNyYy9hcHAvY29tcG9uZW50ZXMvZm9vdGVyL2Zvb3Rlci50cyIsInNyYy9hcHAvY29tcG9uZW50ZXMvZm9vdGVyL2Zvb3Rlci5odG1sIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGJvb3RzdHJhcEFwcGxpY2F0aW9uIH0gZnJvbSAnQGFuZ3VsYXIvcGxhdGZvcm0tYnJvd3Nlcic7XHJcbmltcG9ydCB7IGFwcENvbmZpZyB9IGZyb20gJy4vYXBwL2FwcC5jb25maWcnO1xyXG5pbXBvcnQgeyBBcHAgfSBmcm9tICcuL2FwcC9hcHAnO1xyXG5cclxuYm9vdHN0cmFwQXBwbGljYXRpb24oQXBwLCBhcHBDb25maWcpXHJcbiAgLmNhdGNoKChlcnIpID0+IGNvbnNvbGUuZXJyb3IoZXJyKSk7XHJcbiIsImltcG9ydCB7IEFwcGxpY2F0aW9uQ29uZmlnLCBwcm92aWRlQnJvd3Nlckdsb2JhbEVycm9yTGlzdGVuZXJzLCBMT0NBTEVfSUQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgcHJvdmlkZVJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XHJcbmltcG9ydCB7IHByb3ZpZGVIdHRwQ2xpZW50LCB3aXRoRmV0Y2gsIHdpdGhJbnRlcmNlcHRvcnMgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XHJcbmltcG9ydCB7IHJlZ2lzdGVyTG9jYWxlRGF0YSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XHJcbmltcG9ydCBsb2NhbGVFcyBmcm9tICdAYW5ndWxhci9jb21tb24vbG9jYWxlcy9lcyc7XHJcblxyXG5pbXBvcnQgeyByb3V0ZXMgfSBmcm9tICcuL2FwcC5yb3V0ZXMnO1xyXG5pbXBvcnQgeyBwcm92aWRlQ2xpZW50SHlkcmF0aW9uLCB3aXRoRXZlbnRSZXBsYXkgfSBmcm9tICdAYW5ndWxhci9wbGF0Zm9ybS1icm93c2VyJztcclxuaW1wb3J0IHsgYXV0aEludGVyY2VwdG9yIH0gZnJvbSAnLi9pbnRlcmNlcHRvcnMvYXV0aC5pbnRlcmNlcHRvcic7XHJcblxyXG4vLyBSZWdpc3RyYXIgbG9zIGRhdG9zIGRlbCBpZGlvbWEgZXNwYcOxb2xcclxucmVnaXN0ZXJMb2NhbGVEYXRhKGxvY2FsZUVzKTtcclxuXHJcbmV4cG9ydCBjb25zdCBhcHBDb25maWc6IEFwcGxpY2F0aW9uQ29uZmlnID0ge1xyXG4gIHByb3ZpZGVyczogW1xyXG4gICAgcHJvdmlkZUJyb3dzZXJHbG9iYWxFcnJvckxpc3RlbmVycygpLFxyXG4gICAgcHJvdmlkZVJvdXRlcihyb3V0ZXMpLCBcclxuICAgIHByb3ZpZGVDbGllbnRIeWRyYXRpb24od2l0aEV2ZW50UmVwbGF5KCkpLFxyXG4gICAgcHJvdmlkZUh0dHBDbGllbnQoXHJcbiAgICAgIHdpdGhGZXRjaCgpLFxyXG4gICAgICB3aXRoSW50ZXJjZXB0b3JzKFthdXRoSW50ZXJjZXB0b3JdKVxyXG4gICAgKSxcclxuICAgIHsgcHJvdmlkZTogTE9DQUxFX0lELCB1c2VWYWx1ZTogJ2VzJyB9XHJcbiAgXVxyXG59OyIsImltcG9ydCB7IENvbXBvbmVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBSb3V0ZXJMaW5rIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcclxuXHJcbmludGVyZmFjZSBFc3RhZGlzdGljYSB7XHJcbiAgdmFsb3I6IHN0cmluZztcclxuICBsYWJlbDogc3RyaW5nO1xyXG59XHJcblxyXG5pbnRlcmZhY2UgUGFzbyB7XHJcbiAgaWNvbm86IHN0cmluZzsgLy8gY2xhc2UgZGUgRm9udEF3ZXNvbWUsIGVqOiAnZmEtdXNlci1wbHVzJ1xyXG4gIHRpdHVsbzogc3RyaW5nO1xyXG4gIGRlc2NyaXBjaW9uOiBzdHJpbmc7XHJcbn1cclxuXHJcbmludGVyZmFjZSBPZmVydGFEZXN0YWNhZGEge1xyXG4gIGlkOiBzdHJpbmc7XHJcbiAgdGl0dWxvOiBzdHJpbmc7XHJcbiAgZW1wcmVzYTogc3RyaW5nO1xyXG4gIHRlY25vbG9naWFzOiBzdHJpbmdbXTtcclxufVxyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdhcHAtcHJpbmNpcGFsJyxcclxuICBzdGFuZGFsb25lOiB0cnVlLFxyXG4gIGltcG9ydHM6IFtSb3V0ZXJMaW5rXSxcclxuICB0ZW1wbGF0ZVVybDogJy4vcHJpbmNpcGFsLmh0bWwnLFxyXG4gIHN0eWxlVXJsOiAnLi9wcmluY2lwYWwuc2NzcycsXHJcbn0pXHJcblxyXG5leHBvcnQgY2xhc3MgUHJpbmNpcGFsIHtcclxuICAvLyA9PT09PT09PT09PT0gRVNUQUTDjVNUSUNBUyA9PT09PT09PT09PT1cclxuICBlc3RhZGlzdGljYXM6IEVzdGFkaXN0aWNhW10gPSBbXHJcbiAgICB7IHZhbG9yOiAnNDUrJywgbGFiZWw6ICdPZmVydGFzIFB1YmxpY2FkYXMnIH0sXHJcbiAgICB7IHZhbG9yOiAnMjArJywgbGFiZWw6ICdFbXByZXNhcyBSZWdpc3RyYWRhcycgfSxcclxuICAgIHsgdmFsb3I6ICcxNTArJywgbGFiZWw6ICdQb3N0dWxhbnRlcyBBY3Rpdm9zJyB9LFxyXG4gICAgeyB2YWxvcjogJzMwKycsIGxhYmVsOiAnUG9zdHVsYWNpb25lcyBFeGl0b3NhcycgfSxcclxuICBdO1xyXG5cclxuICAvLyA9PT09PT09PT09PT0gQ8OTTU8gRlVOQ0lPTkEgPT09PT09PT09PT09XHJcbiAgcGFzb3M6IFBhc29bXSA9IFtcclxuICAgIHtcclxuICAgICAgaWNvbm86ICdmYS11c2VyLXBlbicsXHJcbiAgICAgIHRpdHVsbzogJ0NyZcOhIHR1IHBlcmZpbCcsXHJcbiAgICAgIGRlc2NyaXBjaW9uOiAnQ2FyZ8OhIHR1cyBoYWJpbGlkYWRlcywgZXN0dWRpb3MgeSBsaW5rcyBhIHR1IHBvcnRmb2xpbyBlbiBwb2NvcyBtaW51dG9zLicsXHJcbiAgICAgIFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgaWNvbm86ICdmYS1tYWduaWZ5aW5nLWdsYXNzJyxcclxuICAgICAgdGl0dWxvOiAnUG9zdHVsYXRlIGEgb2ZlcnRhcycsXHJcbiAgICAgIGRlc2NyaXBjaW9uOiAnRXhwbG9yw6Egb3BvcnR1bmlkYWRlcyBmaWx0cmFkYXMgcG9yIHRlY25vbG9nw61hLCBlbXByZXNhIG8gbW9kYWxpZGFkLicsXHJcbiAgICAgIFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgaWNvbm86ICdmYS1oYW5kc2hha2UnLFxyXG4gICAgICB0aXR1bG86ICdDb25lY3TDoSBjb24gZW1wcmVzYXMnLFxyXG4gICAgICBkZXNjcmlwY2lvbjogJ0xhcyBlbXByZXNhcyByZXZpc2FuIHR1IHBlcmZpbCB5IHRlIGNvbnRhY3RhbiBkaXJlY3RhbWVudGUuJyxcclxuICAgICAgXHJcbiAgICB9LFxyXG4gIF07XHJcblxyXG4gIC8vID09PT09PT09PT09PSBPRkVSVEFTIERFU1RBQ0FEQVMgPT09PT09PT09PT09XHJcbiAgLy8gRGVqYWxhcyBoYXJkY29kZWFkYXMgcGFyYSBsYSBkZW1vIHNpIHRvZGF2w61hIG5vIHRlbsOpcyBlbCBzZXJ2aWNlIGNvbmVjdGFkby5cclxuICBvZmVydGFzRGVzdGFjYWRhczogT2ZlcnRhRGVzdGFjYWRhW10gPSBbXHJcbiAgICB7XHJcbiAgICAgIGlkOiAnb2YtMScsXHJcbiAgICAgIHRpdHVsbzogJ0Rlc2Fycm9sbGFkb3IvYSBGcm9udGVuZCBBbmd1bGFyIEpyLicsXHJcbiAgICAgIGVtcHJlc2E6ICdUZWNoTWluZCBTb2x1dGlvbnMnLFxyXG4gICAgICB0ZWNub2xvZ2lhczogWydBbmd1bGFyJywgJ1R5cGVTY3JpcHQnLCAnQ1NTJ10sXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBpZDogJ29mLTInLFxyXG4gICAgICB0aXR1bG86ICdBbmFsaXN0YSBkZSBTaXN0ZW1hcyDigJQgU29wb3J0ZSB5IERlc2Fycm9sbG8nLFxyXG4gICAgICBlbXByZXNhOiAnTm92YVNvZnQnLFxyXG4gICAgICB0ZWNub2xvZ2lhczogWycuTkVUJywgJ1NRTCBTZXJ2ZXInXSxcclxuICAgIH0sXHJcbiAgXTtcclxuXHJcbiAgLy8gPT09PT09PT09PT09IEZBUSAodHUgY8OzZGlnbyBvcmlnaW5hbCwgc2luIHRvY2FyKSA9PT09PT09PT09PT1cclxuICBmYXFzID0gW1xyXG4gICAge1xyXG4gICAgICBwcmVndW50YTogJ8K/Q8OzbW8gbWUgcmVnaXN0cm8gZW4gbGEgcGxhdGFmb3JtYT8nLFxyXG4gICAgICByZXNwdWVzdGE6ICdFcyBzw7pwZXIgZsOhY2lsLiBIYWPDqXMgY2xpYyBlbiBlbCBib3TDs24gZGUgUmVnaXN0cmFyc2UsIHNlbGVjY2lvbsOhcyBsYSBvcGNpw7NuIGRlIEVzdHVkaWFudGUvRWdyZXNhZG8sIGNvbXBsZXTDoXMgdHVzIGRhdG9zIChJbXBvcnRhbnRlOiB0dSBuw7ptZXJvIGRlIExlZ2FqbyBkZWwgSVRCKSwgY29ycmVvIHkgY29udHJhc2XDsWEgZW50cmUgb3Ryb3MgeSBsaXN0by4gWWEgcG9kw6lzIExvZ3VlYXJ0ZSBhcm1hciB0dSBwZXJmaWwuJyxcclxuICAgICAgYWJpZXJ0YTogZmFsc2VcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHByZWd1bnRhOiAnwr9UaWVuZSBhbGfDum4gY29zdG8gZWwgdXNvIGRlbCBzaXN0ZW1hPycsXHJcbiAgICAgIHJlc3B1ZXN0YTogJ05vIHRpZW5lIGNvc3RvLiBJVEIgQ29uZWN0YSBlcyB1bmEgaGVycmFtaWVudGEgZGUgaW50ZXJtZWRpYWNpw7NuIGxhYm9yYWwgY29tcGxldGFtZW50ZSBncmF0dWl0YSB0YW50byBwYXJhIGVzdHVkaWFudGVzIGRlIHRlcmNlciBhw7FvIGRlIGxhcyBjYXJyZXJhcyBjb21vIHBhcmEgbG9zIGVncmVzYWRvcyBkZSBsYSBpbnN0aXR1Y2nDs24uJyxcclxuICAgICAgYWJpZXJ0YTogZmFsc2VcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHByZWd1bnRhOiAnU295IHVuYSBlbXByZXNhLCDCv2PDs21vIHB1ZWRvIHB1YmxpY2FyIG9mZXJ0YXM/JyxcclxuICAgICAgcmVzcHVlc3RhOiAnQWwgcmVnaXN0cmFydGUgY29tbyBFbXByZXNhLCBudWVzdHJvIGVxdWlwbyB2YWxpZGFyw6EgdHUgcGVyZmlsIGluc3RpdHVjaW9uYWwuIFVuYSB2ZXogYXByb2JhZG8sIHZhcyBhIHRlbmVyIHVuIHBhbmVsIGV4Y2x1c2l2byBwYXJhIHN1YmlyIHkgZ2VzdGlvbmFyIHR1cyB2YWNhbnRlcy4nLFxyXG4gICAgICBhYmllcnRhOiBmYWxzZVxyXG4gICAgfVxyXG4gIF07XHJcblxyXG4gIC8vIEZ1bmNpw7NuIHBhcmEgYWx0ZXJuYXIgZWwgZGVzcGxlZ2FibGVcclxuICB0b2dnbGVGYXEoaW5kZXg6IG51bWJlcik6IHZvaWQge1xyXG4gICAgdGhpcy5mYXFzW2luZGV4XS5hYmllcnRhID0gIXRoaXMuZmFxc1tpbmRleF0uYWJpZXJ0YTtcclxuICB9XHJcbn0iLCI8ZGl2IGNsYXNzPVwicG9ydGFkYS1jb250YWluZXJcIj5cclxuXHJcbiAgPGhlYWRlciBjbGFzcz1cImhlcm8tc2VjdGlvblwiPlxyXG4gICAgPGRpdiBjbGFzcz1cImhlcm8tY29udGVudFwiPlxyXG4gICAgICA8c3BhbiBjbGFzcz1cImJhZGdlLXRlY2hcIj5QbGF0YWZvcm1hIGRlIEludGVybWVkaWFjacOzbiBMYWJvcmFsPC9zcGFuPlxyXG4gICAgICA8aDI+wqFCaWVudmVuaWRvcyBhIElUQiBDb25lY3RhITwvaDI+XHJcblxyXG4gICAgICA8aDI+VW5pZW5kbyB0YWxlbnRvIHkgb3BvcnR1bmlkYWRlcyBlbiBlbCBJVEI8L2gyPlxyXG5cclxuICAgICAgPHA+XHJcbiAgICAgICAgRWwgcHVlbnRlIGRpZ2l0YWwgZXhjbHVzaXZvIHF1ZSBjb25lY3RhIGEgZXN0dWRpYW50ZXMgeSBncmFkdWFkb3MgZGVcclxuICAgICAgICA8c3Ryb25nPkFuw6FsaXNpcyBkZSBTaXN0ZW1hczwvc3Ryb25nPiBlIDxzdHJvbmc+SW50ZWxpZ2VuY2lhIEFydGlmaWNpYWw8L3N0cm9uZz5cclxuICAgICAgICBjb24gbG9zIHByb3llY3RvcyBtw6FzIGlubm92YWRvcmVzIGRlIGVtcHJlc2FzIHRlY25vbMOzZ2ljYXMgeSBkZSBjb211bmljYWNpw7NuLlxyXG4gICAgICA8L3A+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzPVwiaGVyby1hY3Rpb25zXCI+XHJcbiAgICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0bi1wcmluY2lwYWwtaGVyb1wiIHJvdXRlckxpbms9XCIvb2ZlcnRhc1wiPlxyXG4gICAgICAgICAgQnVzY2FyIGVuIGxhcyBPZmVydGFzIExhYm9yYWxlcyA8aSBjbGFzcz1cImZhLXNvbGlkIGZhLWNvbXBhc3NcIj48L2k+XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcblxyXG4gICAgPGRpdiBjbGFzcz1cImhlcm8tdmlzdWFsXCI+IDxkaXYgY2xhc3M9XCJ0ZWNoLW1vY2t1cFwiPlxyXG4gICAgXHJcbiAgICA8aW1nIHNyYz1cIkxvZ290cmFucy5wbmdcIiBhbHQ9XCJJVEIgQ29uZWN0YVwiIGNsYXNzPVwibG9nby1pdGItZnV0dXJpc3RhXCI+XHJcbiAgICBcclxuICAgIDxkaXYgY2xhc3M9XCJmbG9hdGluZy1iYWRnZVwiPlxyXG4gICAgICA8aSBjbGFzcz1cImZhLXNvbGlkIGZhLWNpcmNsZS1jaGVja1wiIHN0eWxlPVwiY29sb3I6ICMxMGI5ODE7XCI+PC9pPlxyXG4gICAgICA8c3Bhbj5Db25leGnDs24gRXhpdG9zYTwvc3Bhbj5cclxuICAgIDwvZGl2PlxyXG4gICAgXHJcbiAgPC9kaXY+XHJcbjwvZGl2PlxyXG4gIDwvaGVhZGVyPlxyXG5cclxuICA8IS0tID09PT09PT09PT09PSBOVUVWTzogRVNUQUTDjVNUSUNBUyA9PT09PT09PT09PT0gLS0+XHJcbiAgPHNlY3Rpb24gY2xhc3M9XCJzdGF0cy1zZWN0aW9uXCI+XHJcbiAgICA8ZGl2IGNsYXNzPVwic3RhdHMtZ3JpZFwiPlxyXG4gICAgICBAZm9yIChzdGF0IG9mIGVzdGFkaXN0aWNhczsgdHJhY2sgc3RhdC5sYWJlbCkge1xyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJzdGF0LWNhcmRcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJzdGF0LW51bWVyb1wiPnt7IHN0YXQudmFsb3IgfX08L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJzdGF0LWxhYmVsXCI+e3sgc3RhdC5sYWJlbCB9fTwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICB9XHJcbiAgICA8L2Rpdj5cclxuICA8L3NlY3Rpb24+XHJcblxyXG4gIDwhLS0gPT09PT09PT09PT09IE5VRVZPOiBDw5NNTyBGVU5DSU9OQSA9PT09PT09PT09PT0gLS0+XHJcbiAgPHNlY3Rpb24gY2xhc3M9XCJwYXNvcy1zZWN0aW9uXCI+XHJcbiAgICA8ZGl2IGNsYXNzPVwic2VjdGlvbi10aXRsZVwiPlxyXG4gICAgICA8aDI+wr9Dw7NtbyBmdW5jaW9uYT88L2gyPlxyXG4gICAgICA8cCBjbGFzcz1cInN1YnRpdHVsb1wiPkVtcGV6w6EgYSBjb25lY3RhciBjb24gb3BvcnR1bmlkYWRlcyBlbiAzIHNpbXBsZXMgcGFzb3MuPC9wPlxyXG4gICAgPC9kaXY+XHJcblxyXG4gICAgPGRpdiBjbGFzcz1cInBhc29zLWdyaWRcIj5cclxuICAgICAgQGZvciAocGFzbyBvZiBwYXNvczsgdHJhY2sgJGluZGV4KSB7XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInBhc28tY2FyZFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cInBhc28tbnVtZXJvXCI+e3sgJGluZGV4ICsgMSB9fTwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImljb24tYm94XCI+XHJcbiAgICAgICAgICAgIDxpIGNsYXNzPVwiZmEtc29saWQge3sgcGFzby5pY29ubyB9fVwiPjwvaT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGgzPnt7IHBhc28udGl0dWxvIH19PC9oMz5cclxuICAgICAgICAgIDxwPnt7IHBhc28uZGVzY3JpcGNpb24gfX08L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIH1cclxuICAgIDwvZGl2PlxyXG4gIDwvc2VjdGlvbj5cclxuXHJcbiAgPCEtLSA9PT09PT09PT09PT0gTlVFVk86IE9GRVJUQVMgREVTVEFDQURBUyA9PT09PT09PT09PT0gLS0+XHJcbiAgPHNlY3Rpb24gY2xhc3M9XCJvZmVydGFzLWRlc3RhY2FkYXMtc2VjdGlvblwiPlxyXG4gICAgPGRpdiBjbGFzcz1cInNlY3Rpb24tdGl0bGVcIj5cclxuICAgICAgPGgyPk9wb3J0dW5pZGFkZXMgZGVzdGFjYWRhczwvaDI+XHJcbiAgICAgIDxwIGNsYXNzPVwic3VidGl0dWxvXCI+QWxndW5hcyBkZSBsYXMgw7psdGltYXMgb2ZlcnRhcyBwdWJsaWNhZGFzIHBvciBlbXByZXNhcyBkZWwgZWNvc2lzdGVtYS48L3A+XHJcbiAgICA8L2Rpdj5cclxuXHJcbiAgICA8ZGl2IGNsYXNzPVwib2ZlcnRhcy1kZXN0YWNhZGFzLWdyaWRcIj5cclxuICAgICAgQGZvciAob2ZlcnRhIG9mIG9mZXJ0YXNEZXN0YWNhZGFzOyB0cmFjayBvZmVydGEuaWQpIHtcclxuICAgICAgICA8ZGl2IGNsYXNzPVwib2ZlcnRhLWRlc3RhY2FkYS1jYXJkXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwib2ZlcnRhLWhlYWRlclwiPlxyXG4gICAgICAgICAgICA8aDM+e3sgb2ZlcnRhLnRpdHVsbyB9fTwvaDM+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwib2ZlcnRhLWVtcHJlc2FcIj57eyBvZmVydGEuZW1wcmVzYSB9fTwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cIm9mZXJ0YS10YWdzXCI+XHJcbiAgICAgICAgICAgIEBmb3IgKHRlYyBvZiBvZmVydGEudGVjbm9sb2dpYXM7IHRyYWNrIHRlYykge1xyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGFnLXRlY1wiPnt7IHRlYyB9fTwvc3Bhbj5cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuLXZlci1vZmVydGFcIiBbcm91dGVyTGlua109XCJbJy9vZmVydGFzJ11cIiBbcXVlcnlQYXJhbXNdPVwieyBpZDogb2ZlcnRhLmlkIH1cIj5cclxuICAgICAgICAgICAgVmVyIGRldGFsbGUgPGkgY2xhc3M9XCJmYS1zb2xpZCBmYS1hcnJvdy1yaWdodFwiPjwvaT5cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICB9IEBlbXB0eSB7XHJcbiAgICAgICAgPHAgY2xhc3M9XCJzaW4tb2ZlcnRhc1wiPlRvZGF2w61hIG5vIGhheSBvZmVydGFzIHB1YmxpY2FkYXMg4oCUIMKhc8OpIGxhIHByaW1lcmEgZW1wcmVzYSE8L3A+XHJcbiAgICAgIH1cclxuICAgIDwvZGl2PlxyXG5cclxuICAgIDxkaXYgY2xhc3M9XCJ2ZXItdG9kYXMtd3JhcHBlclwiPlxyXG4gICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuLXNlY3VuZGFyaW9cIiByb3V0ZXJMaW5rPVwiL29mZXJ0YXNcIj5WZXIgdG9kYXMgbGFzIG9mZXJ0YXM8L2J1dHRvbj5cclxuICAgIDwvZGl2PlxyXG4gIDwvc2VjdGlvbj5cclxuXHJcbiAgPHNlY3Rpb24gY2xhc3M9XCJyYXpvbmVzLXNlY3Rpb25cIj5cclxuICAgIDxkaXYgY2xhc3M9XCJzZWN0aW9uLXRpdGxlXCI+XHJcbiAgICAgIDxoMj7Cv1BvciBxdcOpIHJlZ2lzdHJhcnRlIGVuIElUQiBDb25lY3RhPzwvaDI+XHJcbiAgICAgIDxwIGNsYXNzPVwic3VidGl0dWxvXCI+RGlzZcOxYWRvIGVzcGVjw61maWNhbWVudGUgcGFyYSBsYXMgZGVtYW5kYXMgZGVsIGVjb3Npc3RlbWEgdGVjaCBhY3R1YWwuPC9wPlxyXG4gICAgPC9kaXY+XHJcblxyXG4gICAgPGRpdiBjbGFzcz1cInJhem9uZXMtZ3JpZFwiPlxyXG5cclxuICAgICAgPGRpdiBjbGFzcz1cInJhem9uLWNhcmRcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwiaWNvbi1ib3hcIj5cclxuICAgICAgICAgIDxpIGNsYXNzPVwiZmEtc29saWQgZmEtdXNlci1hc3Ryb25hdXRcIj48L2k+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGgzPlBlcmZpbCBFc3BlY2lhbGl6YWRvPC9oMz5cclxuICAgICAgICA8cD5Nb3N0csOhIHR1cyBwcm95ZWN0b3MsIHR1cyB0ZWNub2xvZ8OtYXMgcHJlZmVyaWRhcyB5IGVsIGVzdGFkbyBkZSB0dSBjYXJyZXJhLiBBY8OhIGxhcyBlbXByZXNhcyBidXNjYW4gdGFsZW50byB0w6ljbmljbyBlc3BlY8OtZmljbywgbm8gcGVyZmlsZXMgZ2Vuw6lyaWNvcy48L3A+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGRpdiBjbGFzcz1cInJhem9uLWNhcmQgZGVzdGFjYWRvXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cImljb24tYm94XCI+XHJcbiAgICAgICAgICA8aSBjbGFzcz1cImZhLXNvbGlkIGZhLWxhcHRvcC1jb2RlXCI+PC9pPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxoMz5PcG9ydHVuaWRhZGVzIFJlYWxlczwvaDM+XHJcbiAgICAgICAgPHA+QWNjZWTDqSBhIHBhc2FudMOtYXMsIG1vZGFsaWRhZGVzIGjDrWJyaWRhcyBvIHJlbW90YXMgeSBwb3NpY2lvbmVzIHBlbnNhZGFzIHBhcmEgdHUgY3JlY2ltaWVudG8gcHJvZmVzaW9uYWwgZW4gZW1wcmVzYXMgZGUgc29mdHdhcmUgeSBjb211bmljYWNpw7NuLjwvcD5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzPVwicmF6b24tY2FyZFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJpY29uLWJveFwiPlxyXG4gICAgICAgICAgPGkgY2xhc3M9XCJmYS1zb2xpZCBmYS1icmFpblwiPjwvaT5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8aDM+SW1wdWxzYWRvIHBvciBJQTwvaDM+XHJcbiAgICAgICAgPHA+VW4gZW50b3JubyBtb2Rlcm5vIG9wdGltaXphZG8gcGFyYSBxdWUgbG9zIGFsZ29yaXRtb3MgZGUgYsO6c3F1ZWRhIHVuYW4gbGEgbmVjZXNpZGFkIGRlIGxhIGVtcHJlc2EgY29uIHR1cyBoYWJpbGlkYWRlcyBkZSBmb3JtYSBpbnRlbGlnZW50ZSB5IHRyYW5zcGFyZW50ZS48L3A+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgIDwvZGl2PlxyXG4gIDwvc2VjdGlvbj5cclxuXHJcbiAgPCEtLSA9PT09PT09PT09PT0gTlVFVk86IENUQSBQQVJBIEVNUFJFU0FTID09PT09PT09PT09PSAtLT5cclxuICA8c2VjdGlvbiBjbGFzcz1cImN0YS1lbXByZXNhcy1zZWN0aW9uXCI+XHJcbiAgICA8ZGl2IGNsYXNzPVwiY3RhLWVtcHJlc2FzLWNvbnRlbnRcIj5cclxuICAgICAgPGRpdj5cclxuICAgICAgICA8c3BhbiBjbGFzcz1cImJhZGdlLXRlY2hcIj5QYXJhIGVtcHJlc2FzPC9zcGFuPlxyXG4gICAgICAgIDxoMj7Cv0J1c2PDoXMgdGFsZW50byB0w6ljbmljbyBwYXJhIHR1IGVxdWlwbz88L2gyPlxyXG4gICAgICAgIDxwPlB1YmxpY8OhIHR1cyBvcG9ydHVuaWRhZGVzIHkgYWNjZWTDqSBhIGVzdHVkaWFudGVzIHkgZ3JhZHVhZG9zIGRlIEFuw6FsaXNpcyBkZSBTaXN0ZW1hcyBlIElBIGRlbCBJVEIsIGxpc3RvcyBwYXJhIHN1bWFyc2UgYSB0dXMgcHJveWVjdG9zLjwvcD5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxidXR0b24gY2xhc3M9XCJidG4tcHJpbmNpcGFsLWhlcm8gY3RhLWVtcHJlc2FzLWJ0blwiIHJvdXRlckxpbms9XCIvcmVnaXN0cmFyXCI+XHJcbiAgICAgICAgUHVibGljYXIgdW5hIG9mZXJ0YSA8aSBjbGFzcz1cImZhLXNvbGlkIGZhLWJyaWVmY2FzZVwiPjwvaT5cclxuICAgICAgPC9idXR0b24+XHJcbiAgICA8L2Rpdj5cclxuICA8L3NlY3Rpb24+XHJcblxyXG4gIDxzZWN0aW9uIGNsYXNzPVwiZmFxLXNlY3Rpb25cIj5cclxuICAgIDxkaXYgY2xhc3M9XCJzZWN0aW9uLXRpdGxlXCI+XHJcbiAgICAgIDxoMj5QcmVndW50YXMgRnJlY3VlbnRlczwvaDI+XHJcbiAgICAgIDxwIGNsYXNzPVwic3VidGl0dWxvXCI+VG9kbyBsbyBxdWUgbmVjZXNpdMOhcyBzYWJlciBzb2JyZSBJVEIgQ29uZWN0YTwvcD5cclxuICAgIDwvZGl2PlxyXG5cclxuICAgIDxkaXYgY2xhc3M9XCJmYXEtY29udGFpbmVyXCI+XHJcbiAgICAgIEBmb3IgKGZhcSBvZiBmYXFzOyB0cmFjayAkaW5kZXgpIHtcclxuICAgICAgICA8ZGl2IGNsYXNzPVwiZmFxLWl0ZW1cIiBbY2xhc3MuZmFxLWFiaWVydGFdPVwiZmFxLmFiaWVydGFcIj5cclxuXHJcbiAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiZmFxLXByZWd1bnRhXCIgKGNsaWNrKT1cInRvZ2dsZUZhcSgkaW5kZXgpXCI+XHJcbiAgICAgICAgICAgIDxzcGFuPnt7IGZhcS5wcmVndW50YSB9fTwvc3Bhbj5cclxuICAgICAgICAgICAgPGkgY2xhc3M9XCJmYS1zb2xpZFwiIFtjbGFzcy5mYS1jaGV2cm9uLWRvd25dPVwiIWZhcS5hYmllcnRhXCIgW2NsYXNzLmZhLWNoZXZyb24tdXBdPVwiZmFxLmFiaWVydGFcIj48L2k+XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICBAaWYgKGZhcS5hYmllcnRhKSB7XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmYXEtcmVzcHVlc3RhXCI+XHJcbiAgICAgICAgICAgICAgPHA+e3sgZmFxLnJlc3B1ZXN0YSB9fTwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICB9XHJcbiAgICA8L2Rpdj5cclxuICA8L3NlY3Rpb24+XHJcblxyXG48L2Rpdj4iLCJpbXBvcnQgeyBDb21wb25lbnQsIGluamVjdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBGb3JtR3JvdXAsIEZvcm1Db250cm9sLCBWYWxpZGF0b3JzLCBSZWFjdGl2ZUZvcm1zTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xyXG5pbXBvcnQgeyBSb3V0ZXJMaW5rLCBSb3V0ZXIgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xyXG5pbXBvcnQgeyBBdXRoU2VydmljZSB9IGZyb20gJy4uLy4uL3NlcnZpY2VzL2F1dGguc2VydmljZSc7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogJ2FwcC1zZXNpb24nLFxyXG4gIHN0YW5kYWxvbmU6IHRydWUsXHJcbiAgaW1wb3J0czogW1JvdXRlckxpbmssIFJlYWN0aXZlRm9ybXNNb2R1bGVdLFxyXG4gIHRlbXBsYXRlVXJsOiAnLi9zZXNpb24uaHRtbCcsXHJcbiAgc3R5bGVVcmw6ICcuL3Nlc2lvbi5zY3NzJyxcclxufSlcclxuZXhwb3J0IGNsYXNzIFNlc2lvbiB7XHJcblxyXG4gIC8vIFNFUlZJQ0lPU1xyXG4gIHByaXZhdGUgYXV0aFNlcnZpY2UgPSBpbmplY3QoQXV0aFNlcnZpY2UpO1xyXG4gIHByaXZhdGUgcm91dGVyID0gaW5qZWN0KFJvdXRlcik7XHJcblxyXG4gIC8vIE1PU1RSQVIgLyBPQ1VMVEFSIFBBU1NXT1JEXHJcbiAgbW9zdHJhclBhc3N3b3JkID0gZmFsc2U7XHJcblxyXG4gIHRvZ2dsZVBhc3N3b3JkKCkge1xyXG4gICAgdGhpcy5tb3N0cmFyUGFzc3dvcmQgPSAhdGhpcy5tb3N0cmFyUGFzc3dvcmQ7XHJcbiAgfVxyXG5cclxuICAvLyBGT1JNVUxBUklPXHJcbiAgbG9naW5Gb3JtID0gbmV3IEZvcm1Hcm91cCh7XHJcbiAgICBlbWFpbDogbmV3IEZvcm1Db250cm9sKCcnLCBbXHJcbiAgICAgIFZhbGlkYXRvcnMucmVxdWlyZWQsXHJcbiAgICAgIFZhbGlkYXRvcnMuZW1haWxcclxuICAgIF0pLFxyXG4gICAgcGFzc3dvcmQ6IG5ldyBGb3JtQ29udHJvbCgnJywgW1xyXG4gICAgICBWYWxpZGF0b3JzLnJlcXVpcmVkLFxyXG4gICAgICBWYWxpZGF0b3JzLm1pbkxlbmd0aCg4KSxcclxuICAgICAgVmFsaWRhdG9ycy5wYXR0ZXJuKC9eKD89LipbQS1aXSkoPz0uKlxcZCkuKyQvKVxyXG4gICAgXSlcclxuICB9KTtcclxuXHJcbiAgLy8gTE9HSU5cclxuICBpbmdyZXNhcigpIHtcclxuICAgIGlmICh0aGlzLmxvZ2luRm9ybS52YWxpZCkge1xyXG4gICAgICBjb25zdCBjcmVkZW5jaWFsZXMgPSB0aGlzLmxvZ2luRm9ybS52YWx1ZTtcclxuXHJcbiAgICAgIGNvbnNvbGUubG9nKCdFbnZpYW5kbyBkYXRvcyBhbCBzZXJ2aWRvcjonLCBjcmVkZW5jaWFsZXMuZW1haWwpO1xyXG5cclxuICAgICAgdGhpcy5hdXRoU2VydmljZS5sb2dpbihjcmVkZW5jaWFsZXMpLnN1YnNjcmliZSh7XHJcbiAgICAgICAgbmV4dDogKHJlczogYW55KSA9PiB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZygnwqHDiXhpdG8hIFJlc3B1ZXN0YSBjb21wbGV0YSBkZWwgc2Vydmlkb3I6JywgcmVzKTtcclxuXHJcbiAgICAgICAgICBpZiAocmVzLnN1Y2Nlc3MpIHtcclxuICAgICAgICAgICAgLy8gMS4gR1VBUkRBUiBFTiBMT0NBTFNUT1JBR0VcclxuICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3Rva2VuJywgcmVzLnRva2VuKTtcclxuICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3RpcG8nLCByZXMudGlwbyk7XHJcbiAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCd1c2VyJywgSlNPTi5zdHJpbmdpZnkocmVzLnVzZXIpKTtcclxuXHJcbiAgICAgICAgICAgIC8vIDIuIFJFRElSRUNDScOTTiBTRUfDmk4gRUwgUk9MIERFIFVTVUFSSU9cclxuICAgICAgICAgICAgaWYgKHJlcy50aXBvID09PSAnYWRtaW4nKSB7XHJcbiAgICAgICAgICAgICAgYWxlcnQoJ8KhQmllbnZlbmlkby9hIEFkbWluaXN0cmFkb3IvYSEnKTtcclxuICAgICAgICAgICAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbJy9wYW5lbC1hZG1pbiddKTtcclxuICAgICAgICAgICAgfSBcclxuICAgICAgICAgICAgZWxzZSBpZiAocmVzLnRpcG8gPT09ICdlbXByZXNhJykge1xyXG4gICAgICAgICAgICAgIGFsZXJ0KCfCoUJpZW52ZW5pZGEgRW1wcmVzYSEnKTtcclxuICAgICAgICAgICAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbJy9wZXJmaWxlcy9lbXByZXNhLXByb2ZpbGUnXSk7XHJcbiAgICAgICAgICAgIH0gXHJcbiAgICAgICAgICAgIGVsc2UgaWYgKHJlcy50aXBvID09PSAncG9zdHVsYW50ZScpIHtcclxuICAgICAgICAgICAgICBhbGVydCgnwqFCaWVudmVuaWRvL2EgUG9zdHVsYW50ZSEnKTtcclxuICAgICAgICAgICAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbJy9vZmVydGFzJ10pO1xyXG4gICAgICAgICAgICB9IFxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICBhbGVydCgnwqFCaWVudmVuaWRvL2EhJyk7XHJcbiAgICAgICAgICAgICAgdGhpcy5yb3V0ZXIubmF2aWdhdGUoWycvJ10pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSxcclxuXHJcbiAgICAgICAgZXJyb3I6IChlcnIpID0+IHtcclxuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGVuIGVsIGxvZ2luOicsIGVycik7XHJcbiAgICAgICAgICBhbGVydChcclxuICAgICAgICAgICAgJ0Vycm9yOiAnICtcclxuICAgICAgICAgICAgKGVyci5lcnJvcj8ubWVzc2FnZSB8fCAnTm8gc2UgcHVkbyBpbmljaWFyIHNlc2nDs24nKVxyXG4gICAgICAgICAgKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgdGhpcy5sb2dpbkZvcm0ubWFya0FsbEFzVG91Y2hlZCgpO1xyXG4gICAgICBhbGVydCgnUG9yIGZhdm9yLCBjb21wbGV0YSBsb3MgY2FtcG9zIGNvcnJlY3RhbWVudGUuJyk7XHJcbiAgICB9XHJcbiAgfVxyXG59IiwiPGRpdiBjbGFzcz1cIm1haW4tc3BsaXQtY29udGFpbmVyXCI+XHJcbiAgXHJcbiAgPCEtLSBDT0xVTU5BIElaUVVJRVJEQSAtLT5cclxuICA8ZGl2IGNsYXNzPVwiaW5mby1jb2x1bW5cIj5cclxuICAgIDxkaXYgY2xhc3M9XCJpbmZvLWNvbnRlbnRcIj5cclxuXHJcbiAgICAgIDxoMj5BY2Nlc28gYWwgU2lzdGVtYTwvaDI+XHJcblxyXG4gICAgICA8cD5cclxuICAgICAgICBJbmdyZXNhIGNvbiBlbCBjb3JyZW8gZWxlY3Ryw7NuaWNvIHkgY29udHJhc2XDsWEgcXVlIHJlZ2lzdHJhc3RlIHByZXZpYW1lbnRlIFxyXG4gICAgICAgIHBhcmEgYWNjZWRlciBhbCBTaXN0ZW1hIGRlIEludGVybWVkaWFjacOzbiBMYWJvcmFsLlxyXG4gICAgICA8L3A+XHJcblxyXG4gICAgICA8aW1nIFxyXG4gICAgICAgIHNyYz1cImltZy9wbGF0YWZvcm1hLnBuZ1wiIFxyXG4gICAgICAgIGFsdD1cIklUQiBDb25lY3RhXCIgXHJcbiAgICAgICAgY2xhc3M9XCJpbWctZmx1aWRhXCI+XHJcblxyXG4gICAgPC9kaXY+XHJcbiAgPC9kaXY+XHJcblxyXG4gIDwhLS0gQ09MVU1OQSBERVJFQ0hBIC0tPlxyXG4gIDxkaXYgY2xhc3M9XCJmb3JtLWNvbHVtblwiPlxyXG5cclxuICAgIDxkaXYgY2xhc3M9XCJsb2dpbi1ib3hcIj5cclxuXHJcbiAgICAgIDxmb3JtIFtmb3JtR3JvdXBdPVwibG9naW5Gb3JtXCIgKG5nU3VibWl0KT1cImluZ3Jlc2FyKClcIj5cclxuXHJcbiAgICAgICAgPCEtLSBFTUFJTCAtLT5cclxuICAgICAgICA8aW5wdXQgXHJcbiAgICAgICAgICB0eXBlPVwiZW1haWxcIlxyXG4gICAgICAgICAgZm9ybUNvbnRyb2xOYW1lPVwiZW1haWxcIlxyXG4gICAgICAgICAgcGxhY2Vob2xkZXI9XCJUdSBjb3JyZW9cIj5cclxuXHJcbiAgICAgICAgPCEtLSBQQVNTV09SRCAtLT5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwicGFzc3dvcmQtY29udGFpbmVyXCI+XHJcblxyXG4gICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgIFt0eXBlXT1cIm1vc3RyYXJQYXNzd29yZCA/ICd0ZXh0JyA6ICdwYXNzd29yZCdcIlxyXG4gICAgICAgICAgICBmb3JtQ29udHJvbE5hbWU9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiVHUgY29udHJhc2XDsWFcIj5cclxuXHJcbiAgICAgICAgICA8IS0tIE9KSVRPIC0tPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3M9XCJvam9cIiAoY2xpY2spPVwidG9nZ2xlUGFzc3dvcmQoKVwiPlxyXG5cclxuICAgICAgICAgICAgPGlcclxuICAgICAgICAgICAgICBjbGFzcz1cImZhLXNvbGlkXCJcclxuICAgICAgICAgICAgICBbY2xhc3MuZmEtZXllXT1cIm1vc3RyYXJQYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgW2NsYXNzLmZhLWV5ZS1zbGFzaF09XCIhbW9zdHJhclBhc3N3b3JkXCI+XHJcbiAgICAgICAgICAgIDwvaT5cclxuXHJcbiAgICAgICAgICA8L3NwYW4+XHJcblxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8IS0tIEVSUk9SIFBBU1NXT1JEIC0tPlxyXG4gICAgICAgIEBpZiAobG9naW5Gb3JtLmdldCgncGFzc3dvcmQnKT8uZXJyb3JzPy5bJ3BhdHRlcm4nXVxyXG4gICAgICAgICAgICAgJiYgbG9naW5Gb3JtLmdldCgncGFzc3dvcmQnKT8udG91Y2hlZCkge1xyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImVycm9yXCI+XHJcbiAgICAgICAgICAgIExhIGNvbnRyYXNlw7FhIGRlYmUgdGVuZXI6XHJcbiAgICAgICAgICAgIDxicj5cclxuICAgICAgICAgICAg4oCiIEFsIG1lbm9zIHVuYSBtYXnDunNjdWxhXHJcbiAgICAgICAgICAgIDxicj5cclxuICAgICAgICAgICAg4oCiIFVuIG7Dum1lcm9cclxuICAgICAgICAgICAgPGJyPlxyXG4gICAgICAgICAgICDigKIgTcOtbmltbyA4IGNhcmFjdGVyZXNcclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgPCEtLSBCT1RPTiAtLT5cclxuICAgICAgICA8YnV0dG9uIFxyXG4gICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICBbZGlzYWJsZWRdPVwibG9naW5Gb3JtLmludmFsaWRcIj5cclxuXHJcbiAgICAgICAgICBJbmljaWFyIFNlc2nDs25cclxuXHJcbiAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICA8L2Zvcm0+XHJcblxyXG4gICAgICA8IS0tIEVOTEFDRSAtLT5cclxuICAgICAgPGRpdiBjbGFzcz1cImNvbnRlbmVkb3ItZW5sYWNlXCI+XHJcblxyXG4gICAgICAgIDxwPlxyXG4gICAgICAgICAgU2kgYcO6biBubyB0aWVuZXMgdW5hIGN1ZW50YSwgcHVlZGVzIHJlZ2lzdHJhcnRlIGhhY2llbmRvIGNsaWMgZW4gZWwgc2lndWllbnRlIGVubGFjZS5cclxuICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgIDxhIHJvdXRlckxpbms9XCIvcmVnaXN0cmFyXCIgY2xhc3M9XCJtaS1lbmxhY2VcIj5cclxuICAgICAgICAgIElyIGEgUmVnaXN0cmFyc2VcclxuICAgICAgICA8L2E+XHJcblxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICA8L2Rpdj5cclxuXHJcbiAgPC9kaXY+XHJcblxyXG48L2Rpdj4iLCJpbXBvcnQgeyBDb21wb25lbnQsIFZpZXdFbmNhcHN1bGF0aW9uIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBSb3V0ZXJNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xuXG5cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnYXBwLXJlZ2lzdHJhci1ob21lJyxcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgaW1wb3J0czogW1JvdXRlck1vZHVsZV0sXG4gIHRlbXBsYXRlVXJsOiAnLi9yZWdpc3RyYXItaG9tZS5odG1sJyxcbiAgc3R5bGVVcmw6ICcuL3JlZ2lzdHJhci1ob21lLnNjc3MnLFxuICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lXG59KVxuZXhwb3J0IGNsYXNzIFJlZ2lzdHJhckhvbWUge1xuICBcbiAgXG59IiwiPGRpdiBjbGFzcz1cIm1haW4tc3BsaXQtY29udGFpbmVyXCI+XG4gIFxuICA8ZGl2IGNsYXNzPVwiaW5mby1jb2x1bW5cIj5cbiAgICA8ZGl2IGNsYXNzPVwiaW5mby1jb250ZW50XCI+ICBcbiAgICAgIDxpbWcgc3JjPVwiaW1nL2NyZWFyY3VlbnRhLnBuZ1wiIGFsdD1cIklUQiBDb25lY3RhXCIgY2xhc3M9XCJpbWctZmx1aWRhXCI+XG4gICAgPC9kaXY+XG4gIDwvZGl2PlxuXG4gIDxkaXYgY2xhc3M9XCJyZWdpc3Ryby1jb250YWluZXJcIj5cbiAgICA8aDI+wqFUZSBkYW1vcyBsYSBiaWVudmVuaWRhIGEgSVRCIENvbmVjdGEhPC9oMj5cbiAgICA8cD5QYXJhIGNvbWVuemFyLCBzZWxlY2Npb25hIHR1IHBlcmZpbDo8L3A+XG5cbiAgICA8ZGl2IGNsYXNzPVwiY2FyZHMtZ3JpZFwiPlxuICAgICAgPGRpdiBjbGFzcz1cImNhcmRcIiByb3V0ZXJMaW5rPVwiL3JlZ2lzdHJhci1wb3N0dWxhbnRlXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJpY29uXCI+8J+OkzwvZGl2PlxuICAgICAgICA8aDM+UG9zdHVsYW50ZTwvaDM+XG4gICAgICAgIDxwPlBvc3TDumxhdGUgYSBvZmVydGFzIHkgbWVqb3JhIHR1IHBlcmZpbCBwcm9mZXNpb25hbC48L3A+XG4gICAgICAgIDxidXR0b24gY2xhc3M9XCJidG4tc2VsZWN0XCI+U295IEVzdHVkaWFudGUvRWdyZXNhZG88L2J1dHRvbj5cbiAgICAgIDwvZGl2PiAgICAgICBcblxuICAgICAgPGRpdiBjbGFzcz1cImNhcmRcIiByb3V0ZXJMaW5rPVwiL3JlZ2lzdHJhci1lbXByZXNhXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJpY29uXCI+8J+PojwvZGl2PlxuICAgICAgICA8aDM+RW1wcmVzYTwvaDM+XG4gICAgICAgIDxwPkVuY3VlbnRyYSBlbCBtZWpvciB0YWxlbnRvIHTDqWNuaWNvIHBhcmEgdHUgSW5zdGl0dWNpw7NuIG8gRW1wcmVzYS48L3A+XG4gICAgICAgIDxidXR0b24gY2xhc3M9XCJidG4tc2VsZWN0XCI+U295IEVtcHJlc2E8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuXG4gIDwvZGl2PlxuPC9kaXY+IiwiaW1wb3J0IHsgQ29tcG9uZW50LCBpbmplY3QgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgQXV0aFNlcnZpY2UgfSBmcm9tICcuLi8uLi8uLi9zZXJ2aWNlcy9hdXRoLnNlcnZpY2UnO1xyXG5cclxuaW1wb3J0IHtcclxuICBGb3JtQ29udHJvbCxcclxuICBGb3JtR3JvdXAsXHJcbiAgUmVhY3RpdmVGb3Jtc01vZHVsZSxcclxuICBWYWxpZGF0b3JzXHJcbn0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xyXG5cclxuaW1wb3J0IHsgQ29tbW9uTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcclxuaW1wb3J0IHsgUm91dGVyLCBSb3V0ZXJMaW5rIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnYXBwLXJlZ2lzdHJhci1wb3N0dWxhbnRlJyxcclxuICBzdGFuZGFsb25lOiB0cnVlLFxyXG4gIGltcG9ydHM6IFtcclxuICBSZWFjdGl2ZUZvcm1zTW9kdWxlLFxyXG4gIENvbW1vbk1vZHVsZSxcclxuICBSb3V0ZXJMaW5rXHJcbl0sXHJcbiAgdGVtcGxhdGVVcmw6ICcuL3JlZ2lzdHJhci1wb3N0dWxhbnRlLmh0bWwnLFxyXG4gIHN0eWxlVXJsOiAnLi9yZWdpc3RyYXItcG9zdHVsYW50ZS5zY3NzJyxcclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBSZWdpc3RyYXJQb3N0dWxhbnRlIHtcclxuXHJcbiAgcHJpdmF0ZSBhdXRoU2VydmljZSA9IGluamVjdChBdXRoU2VydmljZSk7XHJcbiAgcHJpdmF0ZSByb3V0ZXIgPSBpbmplY3QoUm91dGVyKTtcclxuXHJcbiAgLy8gTU9TVFJBUiAvIE9DVUxUQVIgUEFTU1dPUkRcclxuICBtb3N0cmFyUGFzc3dvcmQgPSBmYWxzZTtcclxuXHJcbiAgdG9nZ2xlUGFzc3dvcmQoKSB7XHJcbiAgICB0aGlzLm1vc3RyYXJQYXNzd29yZCA9ICF0aGlzLm1vc3RyYXJQYXNzd29yZDtcclxuICB9XHJcblxyXG4gIC8vIEZPUk1VTEFSSU9cclxuICBmb3JtUmVnaXN0cm8gPSBuZXcgRm9ybUdyb3VwKHtcclxuXHJcbiAgICBub21icmVzOiBuZXcgRm9ybUNvbnRyb2woJycsIFtcclxuICAgICAgVmFsaWRhdG9ycy5yZXF1aXJlZCxcclxuICAgICAgVmFsaWRhdG9ycy5taW5MZW5ndGgoMylcclxuICAgIF0pLFxyXG5cclxuICAgIGFwZWxsaWRvczogbmV3IEZvcm1Db250cm9sKCcnLCBbXHJcbiAgICAgIFZhbGlkYXRvcnMucmVxdWlyZWRcclxuICAgIF0pLFxyXG5cclxuICAgIGRuaTogbmV3IEZvcm1Db250cm9sKCcnLCBbXHJcbiAgICAgIFZhbGlkYXRvcnMucmVxdWlyZWQsXHJcbiAgICAgIFZhbGlkYXRvcnMucGF0dGVybihcIl5bMC05XSokXCIpLFxyXG4gICAgICBWYWxpZGF0b3JzLm1pbkxlbmd0aCg3KSxcclxuICAgICAgVmFsaWRhdG9ycy5tYXhMZW5ndGgoOClcclxuICAgIF0pLFxyXG5cclxuICAgIGxlZ2FqbzogbmV3IEZvcm1Db250cm9sKCcnLCBbXHJcbiAgICAgIFZhbGlkYXRvcnMucmVxdWlyZWRcclxuICAgIF0pLFxyXG5cclxuICAgIGNhcnJlcmE6IG5ldyBGb3JtQ29udHJvbCgnJywgW1xyXG4gICAgICBWYWxpZGF0b3JzLnJlcXVpcmVkXHJcbiAgICBdKSxcclxuXHJcbiAgICBlbWFpbDogbmV3IEZvcm1Db250cm9sKCcnLCBbXHJcbiAgICAgIFZhbGlkYXRvcnMucmVxdWlyZWQsXHJcbiAgICAgIFZhbGlkYXRvcnMuZW1haWxcclxuICAgIF0pLFxyXG5cclxuICAgIHBhc3N3b3JkOiBuZXcgRm9ybUNvbnRyb2woJycsIFtcclxuICAgICAgVmFsaWRhdG9ycy5yZXF1aXJlZCxcclxuICAgICAgVmFsaWRhdG9ycy5taW5MZW5ndGgoOCksXHJcbiAgICAgIFZhbGlkYXRvcnMucGF0dGVybigvXig/PS4qW0EtWl0pKD89LipcXGQpLiskLylcclxuICAgIF0pLFxyXG5cclxuICAgIGNvbmZpcm1QYXNzd29yZDogbmV3IEZvcm1Db250cm9sKCcnLCBbXHJcbiAgICAgIFZhbGlkYXRvcnMucmVxdWlyZWRcclxuICAgIF0pXHJcblxyXG4gIH0pO1xyXG5cclxuICAvLyBSRUdJU1RSQVIgUE9TVFVMQU5URVxyXG4gIHJlZ2lzdHJhclBvc3R1bGFudGUoKSB7XHJcblxyXG4gICAgaWYgKFxyXG4gICAgICB0aGlzLmZvcm1SZWdpc3Ryby52YWx1ZS5wYXNzd29yZCAhPT1cclxuICAgICAgdGhpcy5mb3JtUmVnaXN0cm8udmFsdWUuY29uZmlybVBhc3N3b3JkXHJcbiAgICApIHtcclxuICAgICAgYWxlcnQoJ0xhcyBjb250cmFzZcOxYXMgbm8gY29pbmNpZGVuJyk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAodGhpcy5mb3JtUmVnaXN0cm8udmFsaWQpIHtcclxuXHJcbiAgICAgIGNvbnN0IGRhdG9zID0gdGhpcy5mb3JtUmVnaXN0cm8udmFsdWU7XHJcblxyXG4gICAgICB0aGlzLmF1dGhTZXJ2aWNlLnJlZ2lzdHJhclBvc3R1bGFudGUoZGF0b3MpLnN1YnNjcmliZSh7XHJcblxyXG4gICAgICAgIG5leHQ6IChyZXMpID0+IHtcclxuXHJcbiAgICAgICAgICBjb25zb2xlLmxvZygnwqFQb3N0dWxhbnRlIGNyZWFkbyBjb24gw6l4aXRvIScsIHJlcyk7XHJcblxyXG4gICAgICAgICAgYWxlcnQoJ1JlZ2lzdHJvIGV4aXRvc28uJyk7XHJcblxyXG4gICAgICAgICAgdGhpcy5yb3V0ZXIubmF2aWdhdGUoWycvc2VzaW9uJ10pO1xyXG5cclxuICAgICAgICB9LFxyXG5cclxuICAgICAgICBlcnJvcjogKGVycikgPT4ge1xyXG5cclxuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGRldGFsbGFkbyBkZXNkZSBlbCBzZXJ2aWRvcjonLCBlcnIpO1xyXG5cclxuICAgICAgICAgIGNvbnN0IG1lbnNhamVFcnJvciA9XHJcbiAgICAgICAgICAgIGVyci5lcnJvcj8ubWVzc2FnZSB8fFxyXG4gICAgICAgICAgICAnSHVibyB1biBlcnJvciBhbCBjcmVhciBsYSBjdWVudGEnO1xyXG5cclxuICAgICAgICAgIGFsZXJ0KG1lbnNhamVFcnJvcik7XHJcblxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgIH0pO1xyXG5cclxuICAgIH1cclxuXHJcbiAgICBlbHNlIHtcclxuXHJcbiAgICAgIHRoaXMuZm9ybVJlZ2lzdHJvLm1hcmtBbGxBc1RvdWNoZWQoKTtcclxuXHJcbiAgICAgIGFsZXJ0KCdQb3IgZmF2b3IsIGNvbXBsZXRhIHRvZG9zIGxvcyBjYW1wb3Mgb2JsaWdhdG9yaW9zIGNvcnJlY3RhbWVudGUuJyk7XHJcblxyXG4gICAgfVxyXG5cclxuICB9XHJcblxyXG59IiwiPGRpdiBjbGFzcz1cInJlZ2lzdHJvLWNvbnRhaW5lclwiPlxyXG4gIFxyXG4gIDxoMj7Cv1F1aWVyZXMgcmVnaXN0cmFydGUgY29tbyBwb3N0dWxhbnRlPzwvaDI+XHJcblxyXG4gIDxwPlxyXG4gICAgQ29tcGxldGEgbG9zIGRhdG9zIHBhcmEgYWNjZWRlciBhbCBTaXN0ZW1hIGRlIGludGVybWVkaWFjacOzbiBMYWJvcmFsXHJcbiAgPC9wPlxyXG5cclxuICA8Zm9ybVxyXG4gICAgW2Zvcm1Hcm91cF09XCJmb3JtUmVnaXN0cm9cIlxyXG4gICAgKG5nU3VibWl0KT1cInJlZ2lzdHJhclBvc3R1bGFudGUoKTsgJGV2ZW50LnByZXZlbnREZWZhdWx0KClcIj5cclxuXHJcbiAgICA8IS0tIE5PTUJSRVMgLS0+XHJcbiAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxyXG5cclxuICAgICAgPGxhYmVsPk5vbWJyZXM6PC9sYWJlbD5cclxuXHJcbiAgICAgIDxpbnB1dFxyXG4gICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICBmb3JtQ29udHJvbE5hbWU9XCJub21icmVzXCJcclxuICAgICAgICBwbGFjZWhvbGRlcj1cIkVqOiBKdWFuIFBhYmxvXCI+XHJcblxyXG4gICAgPC9kaXY+XHJcblxyXG4gICAgPCEtLSBBUEVMTElET1MgLS0+XHJcbiAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxyXG5cclxuICAgICAgPGxhYmVsPkFwZWxsaWRvczo8L2xhYmVsPlxyXG5cclxuICAgICAgPGlucHV0XHJcbiAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgIGZvcm1Db250cm9sTmFtZT1cImFwZWxsaWRvc1wiXHJcbiAgICAgICAgcGxhY2Vob2xkZXI9XCJFajogUMOpcmV6IEdhcmNpYVwiPlxyXG5cclxuICAgIDwvZGl2PlxyXG5cclxuICAgIDwhLS0gRE5JIC0tPlxyXG4gICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cclxuXHJcbiAgICAgIDxsYWJlbD5ETkk6PC9sYWJlbD5cclxuXHJcbiAgICAgIDxpbnB1dFxyXG4gICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICBmb3JtQ29udHJvbE5hbWU9XCJkbmlcIlxyXG4gICAgICAgIHBsYWNlaG9sZGVyPVwiU29sbyBuw7ptZXJvcywgc2luIHB1bnRvc1wiPlxyXG5cclxuICAgICAgQGlmIChmb3JtUmVnaXN0cm8uZ2V0KCdkbmknKT8uaW52YWxpZCAmJlxyXG4gICAgICAgICAgIGZvcm1SZWdpc3Ryby5nZXQoJ2RuaScpPy50b3VjaGVkKSB7XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJlcnJvci1tc2dcIj5cclxuXHJcbiAgICAgICAgICBAaWYgKGZvcm1SZWdpc3Ryby5nZXQoJ2RuaScpPy5lcnJvcnM/LlsncmVxdWlyZWQnXSkge1xyXG4gICAgICAgICAgICA8c21hbGw+RWwgRE5JIGVzIG9ibGlnYXRvcmlvLjwvc21hbGw+XHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgQGlmIChmb3JtUmVnaXN0cm8uZ2V0KCdkbmknKT8uZXJyb3JzPy5bJ3BhdHRlcm4nXSkge1xyXG4gICAgICAgICAgICA8c21hbGw+U29sbyBzZSBwZXJtaXRlbiBuw7ptZXJvcy48L3NtYWxsPlxyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIH1cclxuXHJcbiAgICA8L2Rpdj5cclxuXHJcbiAgICA8IS0tIExFR0FKTyAtLT5cclxuICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XHJcblxyXG4gICAgICA8bGFiZWw+TGVnYWpvOjwvbGFiZWw+XHJcblxyXG4gICAgICA8aW5wdXRcclxuICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgZm9ybUNvbnRyb2xOYW1lPVwibGVnYWpvXCJcclxuICAgICAgICBwbGFjZWhvbGRlcj1cIk7Dum1lcm8gZGFkbyBwb3IgSVRCXCI+XHJcblxyXG4gICAgPC9kaXY+XHJcblxyXG4gICAgPCEtLSBDQVJSRVJBIC0tPlxyXG4gICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cclxuXHJcbiAgICAgIDxsYWJlbD5DYXJyZXJhOjwvbGFiZWw+XHJcblxyXG4gICAgICA8aW5wdXRcclxuICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgZm9ybUNvbnRyb2xOYW1lPVwiY2FycmVyYVwiXHJcbiAgICAgICAgcGxhY2Vob2xkZXI9XCJFajogQW5hbGlzdGEgZGUgU2lzdGVtYXNcIj5cclxuXHJcbiAgICA8L2Rpdj5cclxuXHJcbiAgICA8IS0tIEVNQUlMIC0tPlxyXG4gICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cclxuXHJcbiAgICAgIDxsYWJlbD5Db3JyZW8gRWxlY3Ryw7NuaWNvOjwvbGFiZWw+XHJcblxyXG4gICAgICA8aW5wdXRcclxuICAgICAgICB0eXBlPVwiZW1haWxcIlxyXG4gICAgICAgIGZvcm1Db250cm9sTmFtZT1cImVtYWlsXCJcclxuICAgICAgICBwbGFjZWhvbGRlcj1cIkVqOiB1c3VhcmlvQGliZWx0cmFuLmNvbS5hclwiPlxyXG5cclxuICAgICAgQGlmIChmb3JtUmVnaXN0cm8uZ2V0KCdlbWFpbCcpPy5pbnZhbGlkICYmXHJcbiAgICAgICAgICAgZm9ybVJlZ2lzdHJvLmdldCgnZW1haWwnKT8udG91Y2hlZCkge1xyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwiZXJyb3ItbXNnXCI+XHJcblxyXG4gICAgICAgICAgQGlmIChmb3JtUmVnaXN0cm8uZ2V0KCdlbWFpbCcpPy5lcnJvcnM/LlsncmVxdWlyZWQnXSkge1xyXG4gICAgICAgICAgICA8c21hbGw+RWwgY29ycmVvIGVzIG9ibGlnYXRvcmlvLjwvc21hbGw+XHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgQGlmIChmb3JtUmVnaXN0cm8uZ2V0KCdlbWFpbCcpPy5lcnJvcnM/LlsnZW1haWwnXSkge1xyXG4gICAgICAgICAgICA8c21hbGw+Rm9ybWF0byBkZSBjb3JyZW8gbm8gdsOhbGlkby48L3NtYWxsPlxyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIH1cclxuXHJcbiAgICA8L2Rpdj5cclxuXHJcbiAgICA8IS0tIFBBU1NXT1JEIC0tPlxyXG4gICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cclxuXHJcbiAgICAgIDxsYWJlbD5Db250cmFzZcOxYTwvbGFiZWw+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzPVwicGFzc3dvcmQtY29udGFpbmVyXCI+XHJcblxyXG4gICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgW3R5cGVdPVwibW9zdHJhclBhc3N3b3JkID8gJ3RleHQnIDogJ3Bhc3N3b3JkJ1wiXHJcbiAgICAgICAgICBmb3JtQ29udHJvbE5hbWU9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIk3DrW5pbW8gOCBjYXJhY3RlcmVzXCI+XHJcblxyXG4gICAgICAgIDwhLS0gT0pJVE8gLS0+XHJcbiAgICAgICAgPHNwYW4gY2xhc3M9XCJvam9cIiAoY2xpY2spPVwidG9nZ2xlUGFzc3dvcmQoKVwiPlxyXG5cclxuICAgICAgICAgIDxpXHJcbiAgICAgICAgICAgIGNsYXNzPVwiZmEtc29saWRcIlxyXG4gICAgICAgICAgICBbY2xhc3MuZmEtZXllXT1cIm1vc3RyYXJQYXNzd29yZFwiXHJcbiAgICAgICAgICAgIFtjbGFzcy5mYS1leWUtc2xhc2hdPVwiIW1vc3RyYXJQYXNzd29yZFwiPlxyXG4gICAgICAgICAgPC9pPlxyXG5cclxuICAgICAgICA8L3NwYW4+XHJcblxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIEBpZiAoZm9ybVJlZ2lzdHJvLmdldCgncGFzc3dvcmQnKT8uaW52YWxpZCAmJlxyXG4gICAgICAgICAgIGZvcm1SZWdpc3Ryby5nZXQoJ3Bhc3N3b3JkJyk/LnRvdWNoZWQpIHtcclxuXHJcbiAgICAgICAgPGRpdiBjbGFzcz1cImVycm9yLW1zZ1wiPlxyXG5cclxuICAgICAgICAgIEBpZiAoZm9ybVJlZ2lzdHJvLmdldCgncGFzc3dvcmQnKT8uZXJyb3JzPy5bJ3JlcXVpcmVkJ10pIHtcclxuICAgICAgICAgICAgPHNtYWxsPkxhIGNvbnRyYXNlw7FhIGVzIG9ibGlnYXRvcmlhLjwvc21hbGw+XHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgQGlmIChmb3JtUmVnaXN0cm8uZ2V0KCdwYXNzd29yZCcpPy5lcnJvcnM/LlsnbWlubGVuZ3RoJ10pIHtcclxuICAgICAgICAgICAgPHNtYWxsPkRlYmUgdGVuZXIgYWwgbWVub3MgOCBjYXJhY3RlcmVzLjwvc21hbGw+XHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgQGlmIChmb3JtUmVnaXN0cm8uZ2V0KCdwYXNzd29yZCcpPy5lcnJvcnM/LlsncGF0dGVybiddKSB7XHJcbiAgICAgICAgICAgIDxzbWFsbD5cclxuICAgICAgICAgICAgICBEZWJlIGNvbnRlbmVyIGFsIG1lbm9zIHVuYSBtYXnDunNjdWxhIHkgdW4gbsO6bWVyby5cclxuICAgICAgICAgICAgPC9zbWFsbD5cclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB9XHJcblxyXG4gICAgPC9kaXY+XHJcbiAgICA8IS0tIENPTkZJUk1BUiBQQVNTV09SRCAtLT5cclxuPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cclxuXHJcbiAgPGxhYmVsPkNvbmZpcm1hciBDb250cmFzZcOxYTwvbGFiZWw+XHJcblxyXG4gIDxkaXYgY2xhc3M9XCJwYXNzd29yZC1jb250YWluZXJcIj5cclxuXHJcbiAgICA8aW5wdXRcclxuICAgICAgW3R5cGVdPVwibW9zdHJhclBhc3N3b3JkID8gJ3RleHQnIDogJ3Bhc3N3b3JkJ1wiXHJcbiAgICAgIGZvcm1Db250cm9sTmFtZT1cImNvbmZpcm1QYXNzd29yZFwiXHJcbiAgICAgIHBsYWNlaG9sZGVyPVwiUmVwZXTDrSB0dSBjb250cmFzZcOxYVwiPlxyXG5cclxuICAgIDwhLS0gT0pJVE8gLS0+XHJcbiAgICA8c3BhbiBjbGFzcz1cIm9qb1wiIChjbGljayk9XCJ0b2dnbGVQYXNzd29yZCgpXCI+XHJcblxyXG4gICAgICA8aVxyXG4gICAgICAgIGNsYXNzPVwiZmEtc29saWRcIlxyXG4gICAgICAgIFtjbGFzcy5mYS1leWVdPVwibW9zdHJhclBhc3N3b3JkXCJcclxuICAgICAgICBbY2xhc3MuZmEtZXllLXNsYXNoXT1cIiFtb3N0cmFyUGFzc3dvcmRcIj5cclxuICAgICAgPC9pPlxyXG5cclxuICAgIDwvc3Bhbj5cclxuXHJcbiAgPC9kaXY+XHJcblxyXG4gIEBpZiAoXHJcbiAgICBmb3JtUmVnaXN0cm8uZ2V0KCdjb25maXJtUGFzc3dvcmQnKT8udG91Y2hlZCAmJlxyXG4gICAgZm9ybVJlZ2lzdHJvLmdldCgncGFzc3dvcmQnKT8udmFsdWUgIT09XHJcbiAgICBmb3JtUmVnaXN0cm8uZ2V0KCdjb25maXJtUGFzc3dvcmQnKT8udmFsdWVcclxuICApIHtcclxuXHJcbiAgICA8ZGl2IGNsYXNzPVwiZXJyb3ItbXNnXCI+XHJcbiAgICAgIDxzbWFsbD5MYXMgY29udHJhc2XDsWFzIG5vIGNvaW5jaWRlbi48L3NtYWxsPlxyXG4gICAgPC9kaXY+XHJcblxyXG4gIH1cclxuXHJcbjwvZGl2PlxyXG5cclxuICAgIDwhLS0gQk9UT04gY3JlYXIgY3VlbnRhIC0tPlxyXG4gICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCI+XHJcbiAgQ3JlYXIgQ3VlbnRhXHJcbjwvYnV0dG9uPlxyXG5cclxuICA8L2Zvcm0+XHJcbiAgPGRpdiBjbGFzcz1cImFjY2lvbmVzLWV4dHJhXCI+XHJcblxyXG4gIDwhLS0gVk9MVkVSIC0tPlxyXG4gIDxidXR0b25cclxuICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgY2xhc3M9XCJidG4tdm9sdmVyXCJcclxuICAgIHJvdXRlckxpbms9XCIvcmVnaXN0cmFyXCI+XHJcblxyXG4gICAg4oaQIFZvbHZlclxyXG5cclxuICA8L2J1dHRvbj5cclxuXHJcbiAgPCEtLSBZQSBURU5HTyBDVUVOVEEgLS0+XHJcbiAgPGJ1dHRvblxyXG4gICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICBjbGFzcz1cImJ0bi1sb2dpblwiXHJcbiAgICByb3V0ZXJMaW5rPVwiL3Nlc2lvblwiPlxyXG5cclxuICAgIFlhIHRlbmdvIGN1ZW50YVxyXG5cclxuICA8L2J1dHRvbj5cclxuXHJcblxyXG48L2Rpdj4iLCJpbXBvcnQgeyBDb21wb25lbnQsIGluamVjdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBBdXRoU2VydmljZSB9IGZyb20gJy4uLy4uLy4uL3NlcnZpY2VzL2F1dGguc2VydmljZSc7XHJcblxyXG5pbXBvcnQge1xyXG4gIEZvcm1Db250cm9sLFxyXG4gIEZvcm1Hcm91cCxcclxuICBSZWFjdGl2ZUZvcm1zTW9kdWxlLFxyXG4gIFZhbGlkYXRvcnNcclxufSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XHJcblxyXG5pbXBvcnQgeyBDb21tb25Nb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xyXG5pbXBvcnQgeyBSb3V0ZXIsIFJvdXRlckxpbmsgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdhcHAtcmVnaXN0cmFyLWVtcHJlc2EnLFxyXG4gIHN0YW5kYWxvbmU6IHRydWUsXHJcbiAgaW1wb3J0czogW1xyXG4gIFJlYWN0aXZlRm9ybXNNb2R1bGUsXHJcbiAgQ29tbW9uTW9kdWxlLFxyXG4gIFJvdXRlckxpbmtcclxuXSxcclxuICB0ZW1wbGF0ZVVybDogJy4vcmVnaXN0cmFyLWVtcHJlc2EuaHRtbCcsXHJcbiAgc3R5bGVVcmw6ICcuL3JlZ2lzdHJhci1lbXByZXNhLnNjc3MnLFxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIFJlZ2lzdHJhckVtcHJlc2Ege1xyXG5cclxuICBwcml2YXRlIGF1dGhTZXJ2aWNlID0gaW5qZWN0KEF1dGhTZXJ2aWNlKTtcclxuICBwcml2YXRlIHJvdXRlciA9IGluamVjdChSb3V0ZXIpO1xyXG5cclxuICAvLyBNT1NUUkFSIC8gT0NVTFRBUiBQQVNTV09SRFxyXG4gIG1vc3RyYXJQYXNzd29yZCA9IGZhbHNlO1xyXG5cclxuICB0b2dnbGVQYXNzd29yZCgpIHtcclxuICAgIHRoaXMubW9zdHJhclBhc3N3b3JkID0gIXRoaXMubW9zdHJhclBhc3N3b3JkO1xyXG4gIH1cclxuXHJcbiAgLy8gRk9STVVMQVJJT1xyXG4gIGZvcm1SZWdpc3RybyA9IG5ldyBGb3JtR3JvdXAoe1xyXG5cclxuICAgIHJhem9uU29jaWFsOiBuZXcgRm9ybUNvbnRyb2woJycsIFtcclxuICAgICAgVmFsaWRhdG9ycy5yZXF1aXJlZFxyXG4gICAgXSksXHJcblxyXG4gICAgZmFudGFzaWE6IG5ldyBGb3JtQ29udHJvbCgnJyksXHJcblxyXG4gICAgb3JnYW5pemFjaW9uOiBuZXcgRm9ybUNvbnRyb2woJycsIFtcclxuICAgICAgVmFsaWRhdG9ycy5yZXF1aXJlZFxyXG4gICAgXSksXHJcblxyXG4gICAgY3VpdDogbmV3IEZvcm1Db250cm9sKCcnLCBbXHJcbiAgICAgIFZhbGlkYXRvcnMucmVxdWlyZWQsXHJcbiAgICAgIFZhbGlkYXRvcnMucGF0dGVybignXlswLTldezJ9LVswLTldezh9LVswLTldezF9JCcpXHJcbiAgICBdKSxcclxuXHJcbiAgICBzZWN0b3I6IG5ldyBGb3JtQ29udHJvbCgnJywgW1xyXG4gICAgICBWYWxpZGF0b3JzLnJlcXVpcmVkXHJcbiAgICBdKSxcclxuXHJcbiAgICBwYWlzOiBuZXcgRm9ybUNvbnRyb2woJycsIFtcclxuICAgICAgVmFsaWRhdG9ycy5yZXF1aXJlZFxyXG4gICAgXSksXHJcblxyXG4gICAgcHJvdmluY2lhOiBuZXcgRm9ybUNvbnRyb2woJycsIFtcclxuICAgICAgVmFsaWRhdG9ycy5yZXF1aXJlZFxyXG4gICAgXSksXHJcblxyXG4gICAgY2l1ZGFkOiBuZXcgRm9ybUNvbnRyb2woJycsIFtcclxuICAgICAgVmFsaWRhdG9ycy5yZXF1aXJlZFxyXG4gICAgXSksXHJcblxyXG4gICAgY3A6IG5ldyBGb3JtQ29udHJvbCgnJyksXHJcblxyXG4gICAgY2FsbGU6IG5ldyBGb3JtQ29udHJvbCgnJywgW1xyXG4gICAgICBWYWxpZGF0b3JzLnJlcXVpcmVkXHJcbiAgICBdKSxcclxuXHJcbiAgICBudW1lcm86IG5ldyBGb3JtQ29udHJvbCgnJyksXHJcblxyXG4gICAgcGlzbzogbmV3IEZvcm1Db250cm9sKCcnKSxcclxuXHJcbiAgICBkcHRvOiBuZXcgRm9ybUNvbnRyb2woJycpLFxyXG5cclxuICAgIGVtYWlsOiBuZXcgRm9ybUNvbnRyb2woJycsIFtcclxuICAgICAgVmFsaWRhdG9ycy5yZXF1aXJlZCxcclxuICAgICAgVmFsaWRhdG9ycy5lbWFpbFxyXG4gICAgXSksXHJcblxyXG4gICAgd2ViOiBuZXcgRm9ybUNvbnRyb2woJycpLFxyXG5cclxuICAgIHRlbGVmb25vOiBuZXcgRm9ybUNvbnRyb2woJycsIFtcclxuICAgICAgVmFsaWRhdG9ycy5yZXF1aXJlZFxyXG4gICAgXSksXHJcblxyXG4gICAgcmVzcG9uc2FibGU6IG5ldyBGb3JtQ29udHJvbCgnJywgW1xyXG4gICAgICBWYWxpZGF0b3JzLnJlcXVpcmVkXHJcbiAgICBdKSxcclxuXHJcbiAgICBwYXNzd29yZDogbmV3IEZvcm1Db250cm9sKCcnLCBbXHJcblxyXG4gICAgICBWYWxpZGF0b3JzLnJlcXVpcmVkLFxyXG5cclxuICAgICAgVmFsaWRhdG9ycy5taW5MZW5ndGgoOCksXHJcblxyXG4gICAgICAvLyBBTCBNRU5PUyAxIE1BWVVTQ1VMQSBZIDEgTlVNRVJPXHJcbiAgICAgIFZhbGlkYXRvcnMucGF0dGVybigvXig/PS4qW0EtWl0pKD89LipcXGQpLiskLylcclxuXHJcbiAgICBdKSxcclxuXHJcbiAgICAvLyBDT05GSVJNQVIgUEFTU1dPUkRcclxuICAgIGNvbmZpcm1QYXNzd29yZDogbmV3IEZvcm1Db250cm9sKCcnLCBbXHJcbiAgICAgIFZhbGlkYXRvcnMucmVxdWlyZWRcclxuICAgIF0pXHJcblxyXG4gIH0pO1xyXG5cclxuICAvLyBSRUdJU1RSQVIgRU1QUkVTQVxyXG4gIHJlZ2lzdHJhckVtcHJlc2EoKSB7XHJcblxyXG4gICAgLy8gVkFMSURBUiBTSSBMQVMgQ09OVFJBU0XDkUFTIENPSU5DSURFTlxyXG4gICAgaWYgKFxyXG4gICAgICB0aGlzLmZvcm1SZWdpc3Ryby52YWx1ZS5wYXNzd29yZCAhPT1cclxuICAgICAgdGhpcy5mb3JtUmVnaXN0cm8udmFsdWUuY29uZmlybVBhc3N3b3JkXHJcbiAgICApIHtcclxuXHJcbiAgICAgIGFsZXJ0KCdMYXMgY29udHJhc2XDsWFzIG5vIGNvaW5jaWRlbicpO1xyXG4gICAgICByZXR1cm47XHJcblxyXG4gICAgfVxyXG5cclxuICAgIGlmICh0aGlzLmZvcm1SZWdpc3Ryby52YWxpZCkge1xyXG5cclxuICAgICAgY29uc3QgZGF0b3MgPSB0aGlzLmZvcm1SZWdpc3Ryby52YWx1ZTtcclxuXHJcbiAgICAgIHRoaXMuYXV0aFNlcnZpY2UucmVnaXN0cmFyRW1wcmVzYShkYXRvcykuc3Vic2NyaWJlKHtcclxuXHJcbiAgICAgICAgbmV4dDogKHJlcykgPT4ge1xyXG5cclxuICAgICAgICAgIGNvbnNvbGUubG9nKFxyXG4gICAgICAgICAgICAnwqFFbXByZXNhIHJlZ2lzdHJhZGEgY29uIMOpeGl0byEnLFxyXG4gICAgICAgICAgICByZXNcclxuICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgYWxlcnQoXHJcbiAgICAgICAgICAgICfCoUVtcHJlc2EgcmVnaXN0cmFkYSBjb24gw6l4aXRvISBZYSBwb2TDqXMgaW5pY2lhciBzZXNpw7NuLidcclxuICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgdGhpcy5yb3V0ZXIubmF2aWdhdGUoWycvc2VzaW9uJ10pO1xyXG5cclxuICAgICAgICB9LFxyXG5cclxuICAgICAgICBlcnJvcjogKGVycikgPT4ge1xyXG5cclxuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXHJcbiAgICAgICAgICAgICdFcnJvciBhbCByZWdpc3RyYXI6JyxcclxuICAgICAgICAgICAgZXJyXHJcbiAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgIGFsZXJ0KFxyXG4gICAgICAgICAgICAnSHVibyB1biBlcnJvciBhbCBjcmVhciBsYSBjdWVudGEnXHJcbiAgICAgICAgICApO1xyXG5cclxuICAgICAgICB9XHJcblxyXG4gICAgICB9KTtcclxuXHJcbiAgICB9XHJcblxyXG4gICAgZWxzZSB7XHJcblxyXG4gICAgICB0aGlzLmZvcm1SZWdpc3Ryby5tYXJrQWxsQXNUb3VjaGVkKCk7XHJcblxyXG4gICAgICBhbGVydChcclxuICAgICAgICAnUG9yIGZhdm9yLCBjb21wbGV0w6EgdG9kb3MgbG9zIGNhbXBvcyBjb3JyZWN0YW1lbnRlLidcclxuICAgICAgKTtcclxuXHJcbiAgICB9XHJcblxyXG4gIH1cclxuXHJcbn0iLCI8ZGl2IGNsYXNzPVwicmVnaXN0cm8tY29udGFpbmVyXCI+XHJcblxyXG4gIDxoMj5SZWdpc3RyZSBzdSBFbXByZXNhIGFxdcOtPC9oMj5cclxuXHJcbiAgPHA+XHJcbiAgICBDb21wbGV0ZSBsb3MgZGF0b3MgcGFyYSBhY2NlZGVyIGFsIFNpc3RlbWEgZGUgSW50ZXJtZWRpYWNpw7NuIExhYm9yYWxcclxuICA8L3A+XHJcblxyXG4gIDxmb3JtXHJcbiAgICBbZm9ybUdyb3VwXT1cImZvcm1SZWdpc3Ryb1wiXHJcbiAgICAobmdTdWJtaXQpPVwicmVnaXN0cmFyRW1wcmVzYSgpOyAkZXZlbnQucHJldmVudERlZmF1bHQoKVwiPlxyXG5cclxuICAgIDwhLS0gUkFaT04gU09DSUFMIC0tPlxyXG4gICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgPGxhYmVsPlJhesOzbiBTb2NpYWw6PC9sYWJlbD5cclxuXHJcbiAgICAgIDxpbnB1dFxyXG4gICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICBmb3JtQ29udHJvbE5hbWU9XCJyYXpvblNvY2lhbFwiXHJcbiAgICAgICAgcGxhY2Vob2xkZXI9XCJFajogRW1wcmVzYSBTLkEuXCI+XHJcbiAgICA8L2Rpdj5cclxuXHJcbiAgICA8IS0tIEZBTlRBU0lBIC0tPlxyXG4gICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgPGxhYmVsPk5vbWJyZSBkZSBGYW50YXPDrWE6PC9sYWJlbD5cclxuXHJcbiAgICAgIDxpbnB1dFxyXG4gICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICBmb3JtQ29udHJvbE5hbWU9XCJmYW50YXNpYVwiXHJcbiAgICAgICAgcGxhY2Vob2xkZXI9XCJFajogTWlFbXByZXNhXCI+XHJcbiAgICA8L2Rpdj5cclxuXHJcbiAgICA8IS0tIE9SR0FOSVpBQ0lPTiAtLT5cclxuICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgIDxsYWJlbD5Pcmdhbml6YWNpw7NuOjwvbGFiZWw+XHJcblxyXG4gICAgICA8aW5wdXRcclxuICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgZm9ybUNvbnRyb2xOYW1lPVwib3JnYW5pemFjaW9uXCJcclxuICAgICAgICBwbGFjZWhvbGRlcj1cIkVqOiBTLlIuTC4sIFMuQS4sIE9OR1wiPlxyXG4gICAgPC9kaXY+XHJcblxyXG4gICAgPCEtLSBDVUlUIC0tPlxyXG4gICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cclxuXHJcbiAgICAgIDxsYWJlbD5DVUlUOjwvbGFiZWw+XHJcblxyXG4gICAgICA8aW5wdXRcclxuICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgZm9ybUNvbnRyb2xOYW1lPVwiY3VpdFwiXHJcbiAgICAgICAgcGxhY2Vob2xkZXI9XCJFajogMzAtMTIzNDU2NzgtOVwiPlxyXG5cclxuICAgICAgQGlmIChmb3JtUmVnaXN0cm8uZ2V0KCdjdWl0Jyk/LmludmFsaWQgJiZcclxuICAgICAgICAgICBmb3JtUmVnaXN0cm8uZ2V0KCdjdWl0Jyk/LnRvdWNoZWQpIHtcclxuXHJcbiAgICAgICAgPGRpdiBjbGFzcz1cImVycm9yLW1zZ1wiPlxyXG5cclxuICAgICAgICAgIEBpZiAoZm9ybVJlZ2lzdHJvLmdldCgnY3VpdCcpPy5lcnJvcnM/LlsncmVxdWlyZWQnXSkge1xyXG4gICAgICAgICAgICA8c21hbGw+RWwgQ1VJVCBlcyBvYmxpZ2F0b3Jpby48L3NtYWxsPlxyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIEBpZiAoZm9ybVJlZ2lzdHJvLmdldCgnY3VpdCcpPy5lcnJvcnM/LlsncGF0dGVybiddKSB7XHJcbiAgICAgICAgICAgIDxzbWFsbD5Gb3JtYXRvIGludsOhbGlkby4gRWo6IDMwLTEyMzQ1Njc4LTk8L3NtYWxsPlxyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIH1cclxuXHJcbiAgICA8L2Rpdj5cclxuXHJcbiAgICA8IS0tIFNFQ1RPUiAtLT5cclxuICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgIDxsYWJlbD5TZWN0b3I6PC9sYWJlbD5cclxuXHJcbiAgICAgIDxpbnB1dFxyXG4gICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICBmb3JtQ29udHJvbE5hbWU9XCJzZWN0b3JcIlxyXG4gICAgICAgIHBsYWNlaG9sZGVyPVwiRWo6IFRlY25vbG9nw61hLCBTYWx1ZFwiPlxyXG4gICAgPC9kaXY+XHJcblxyXG4gICAgPCEtLSBQQUlTIC0tPlxyXG4gICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgPGxhYmVsPlBhw61zOjwvbGFiZWw+XHJcblxyXG4gICAgICA8aW5wdXRcclxuICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgZm9ybUNvbnRyb2xOYW1lPVwicGFpc1wiXHJcbiAgICAgICAgcGxhY2Vob2xkZXI9XCJFajogQXJnZW50aW5hXCI+XHJcbiAgICA8L2Rpdj5cclxuXHJcbiAgICA8IS0tIFBST1ZJTkNJQSAtLT5cclxuICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgIDxsYWJlbD5Qcm92aW5jaWE6PC9sYWJlbD5cclxuXHJcbiAgICAgIDxpbnB1dFxyXG4gICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICBmb3JtQ29udHJvbE5hbWU9XCJwcm92aW5jaWFcIlxyXG4gICAgICAgIHBsYWNlaG9sZGVyPVwiRWo6IEJ1ZW5vcyBBaXJlc1wiPlxyXG4gICAgPC9kaXY+XHJcblxyXG4gICAgPCEtLSBDSVVEQUQgLS0+XHJcbiAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICA8bGFiZWw+Q2l1ZGFkOjwvbGFiZWw+XHJcblxyXG4gICAgICA8aW5wdXRcclxuICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgZm9ybUNvbnRyb2xOYW1lPVwiY2l1ZGFkXCJcclxuICAgICAgICBwbGFjZWhvbGRlcj1cIkVqOiBTYW4gTWFydMOtblwiPlxyXG4gICAgPC9kaXY+XHJcblxyXG4gICAgPCEtLSBDT0RJR08gUE9TVEFMIC0tPlxyXG4gICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgPGxhYmVsPkPDs2RpZ28gUG9zdGFsOjwvbGFiZWw+XHJcblxyXG4gICAgICA8aW5wdXRcclxuICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgZm9ybUNvbnRyb2xOYW1lPVwiY3BcIlxyXG4gICAgICAgIHBsYWNlaG9sZGVyPVwiRWo6IDE2NTBcIj5cclxuICAgIDwvZGl2PlxyXG5cclxuICAgIDwhLS0gQ0FMTEUgLS0+XHJcbiAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICA8bGFiZWw+Q2FsbGU6PC9sYWJlbD5cclxuXHJcbiAgICAgIDxpbnB1dFxyXG4gICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICBmb3JtQ29udHJvbE5hbWU9XCJjYWxsZVwiXHJcbiAgICAgICAgcGxhY2Vob2xkZXI9XCJFajogQXYuIExpYmVydGFkb3JcIj5cclxuICAgIDwvZGl2PlxyXG5cclxuICAgIDwhLS0gTlVNRVJPIC0tPlxyXG4gICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgPGxhYmVsPk7CsDo8L2xhYmVsPlxyXG5cclxuICAgICAgPGlucHV0XHJcbiAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgIGZvcm1Db250cm9sTmFtZT1cIm51bWVyb1wiXHJcbiAgICAgICAgcGxhY2Vob2xkZXI9XCJFajogMTIzNFwiPlxyXG4gICAgPC9kaXY+XHJcblxyXG4gICAgPCEtLSBQSVNPIC0tPlxyXG4gICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgPGxhYmVsPlBpc286PC9sYWJlbD5cclxuXHJcbiAgICAgIDxpbnB1dFxyXG4gICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICBmb3JtQ29udHJvbE5hbWU9XCJwaXNvXCJcclxuICAgICAgICBwbGFjZWhvbGRlcj1cIkVqOiAzXCI+XHJcbiAgICA8L2Rpdj5cclxuXHJcbiAgICA8IS0tIERQVE8gLS0+XHJcbiAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICA8bGFiZWw+RGVwYXJ0YW1lbnRvOjwvbGFiZWw+XHJcblxyXG4gICAgICA8aW5wdXRcclxuICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgZm9ybUNvbnRyb2xOYW1lPVwiZHB0b1wiXHJcbiAgICAgICAgcGxhY2Vob2xkZXI9XCJFajogQlwiPlxyXG4gICAgPC9kaXY+XHJcblxyXG4gICAgPCEtLSBFTUFJTCAtLT5cclxuICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XHJcblxyXG4gICAgICA8bGFiZWw+RW1haWw6PC9sYWJlbD5cclxuXHJcbiAgICAgIDxpbnB1dFxyXG4gICAgICAgIHR5cGU9XCJlbWFpbFwiXHJcbiAgICAgICAgZm9ybUNvbnRyb2xOYW1lPVwiZW1haWxcIlxyXG4gICAgICAgIHBsYWNlaG9sZGVyPVwiRWo6IGNvbnRhY3RvQGVtcHJlc2EuY29tXCI+XHJcblxyXG4gICAgICBAaWYgKGZvcm1SZWdpc3Ryby5nZXQoJ2VtYWlsJyk/LmludmFsaWQgJiZcclxuICAgICAgICAgICBmb3JtUmVnaXN0cm8uZ2V0KCdlbWFpbCcpPy50b3VjaGVkKSB7XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJlcnJvci1tc2dcIj5cclxuXHJcbiAgICAgICAgICBAaWYgKGZvcm1SZWdpc3Ryby5nZXQoJ2VtYWlsJyk/LmVycm9ycz8uWydyZXF1aXJlZCddKSB7XHJcbiAgICAgICAgICAgIDxzbWFsbD5FbCBjb3JyZW8gZXMgb2JsaWdhdG9yaW8uPC9zbWFsbD5cclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICBAaWYgKGZvcm1SZWdpc3Ryby5nZXQoJ2VtYWlsJyk/LmVycm9ycz8uWydlbWFpbCddKSB7XHJcbiAgICAgICAgICAgIDxzbWFsbD5Gb3JtYXRvIGRlIGNvcnJlbyBubyB2w6FsaWRvLjwvc21hbGw+XHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgfVxyXG5cclxuICAgIDwvZGl2PlxyXG5cclxuICAgIDwhLS0gV0VCIC0tPlxyXG4gICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgPGxhYmVsPlNpdGlvIFdlYjo8L2xhYmVsPlxyXG5cclxuICAgICAgPGlucHV0XHJcbiAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgIGZvcm1Db250cm9sTmFtZT1cIndlYlwiXHJcbiAgICAgICAgcGxhY2Vob2xkZXI9XCJFajogd3d3Lm1pZW1wcmVzYS5jb21cIj5cclxuICAgIDwvZGl2PlxyXG5cclxuICAgIDwhLS0gVEVMRUZPTk8gLS0+XHJcbiAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICA8bGFiZWw+VGVsw6lmb25vIGRlIENvbnRhY3RvOjwvbGFiZWw+XHJcblxyXG4gICAgICA8aW5wdXRcclxuICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgZm9ybUNvbnRyb2xOYW1lPVwidGVsZWZvbm9cIlxyXG4gICAgICAgIHBsYWNlaG9sZGVyPVwiRWo6IDAxMS00NTY3LTg5MDBcIj5cclxuICAgIDwvZGl2PlxyXG5cclxuICAgIDwhLS0gUkVTUE9OU0FCTEUgLS0+XHJcbiAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cCBmdWxsLXdpZHRoXCI+XHJcblxyXG4gICAgICA8bGFiZWw+Tm9tYnJlIGRlbCBSZXNwb25zYWJsZSBkZWwgw4FyZWE6PC9sYWJlbD5cclxuXHJcbiAgICAgIDxpbnB1dFxyXG4gICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICBmb3JtQ29udHJvbE5hbWU9XCJyZXNwb25zYWJsZVwiXHJcbiAgICAgICAgcGxhY2Vob2xkZXI9XCJFajogTWFyw61hIEdvbnrDoWxlelwiPlxyXG5cclxuICAgIDwvZGl2PlxyXG5cclxuICAgIDwhLS0gUEFTU1dPUkQgLS0+XHJcbiAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cCBmdWxsLXdpZHRoXCI+XHJcblxyXG4gICAgICA8bGFiZWw+Q29udHJhc2XDsWE6PC9sYWJlbD5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3M9XCJwYXNzd29yZC1jb250YWluZXJcIj5cclxuXHJcbiAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICBbdHlwZV09XCJtb3N0cmFyUGFzc3dvcmQgPyAndGV4dCcgOiAncGFzc3dvcmQnXCJcclxuICAgICAgICAgIGZvcm1Db250cm9sTmFtZT1cInBhc3N3b3JkXCJcclxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTcOtbmltbyA4IGNhcmFjdGVyZXNcIj5cclxuXHJcbiAgICAgICAgPCEtLSBPSklUTyAtLT5cclxuICAgICAgICA8c3BhbiBjbGFzcz1cIm9qb1wiIChjbGljayk9XCJ0b2dnbGVQYXNzd29yZCgpXCI+XHJcblxyXG4gICAgICAgICAgPGlcclxuICAgICAgICAgICAgY2xhc3M9XCJmYS1zb2xpZFwiXHJcbiAgICAgICAgICAgIFtjbGFzcy5mYS1leWVdPVwibW9zdHJhclBhc3N3b3JkXCJcclxuICAgICAgICAgICAgW2NsYXNzLmZhLWV5ZS1zbGFzaF09XCIhbW9zdHJhclBhc3N3b3JkXCI+XHJcbiAgICAgICAgICA8L2k+XHJcblxyXG4gICAgICAgIDwvc3Bhbj5cclxuXHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgQGlmIChmb3JtUmVnaXN0cm8uZ2V0KCdwYXNzd29yZCcpPy5pbnZhbGlkICYmXHJcbiAgICAgICAgICAgZm9ybVJlZ2lzdHJvLmdldCgncGFzc3dvcmQnKT8udG91Y2hlZCkge1xyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwiZXJyb3ItbXNnXCI+XHJcblxyXG4gICAgICAgICAgQGlmIChmb3JtUmVnaXN0cm8uZ2V0KCdwYXNzd29yZCcpPy5lcnJvcnM/LlsncmVxdWlyZWQnXSkge1xyXG4gICAgICAgICAgICA8c21hbGw+TGEgY29udHJhc2XDsWEgZXMgb2JsaWdhdG9yaWEuPC9zbWFsbD5cclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICBAaWYgKGZvcm1SZWdpc3Ryby5nZXQoJ3Bhc3N3b3JkJyk/LmVycm9ycz8uWydtaW5sZW5ndGgnXSkge1xyXG4gICAgICAgICAgICA8c21hbGw+RGViZSB0ZW5lciBhbCBtZW5vcyA4IGNhcmFjdGVyZXMuPC9zbWFsbD5cclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICBAaWYgKGZvcm1SZWdpc3Ryby5nZXQoJ3Bhc3N3b3JkJyk/LmVycm9ycz8uWydwYXR0ZXJuJ10pIHtcclxuICAgICAgICAgICAgPHNtYWxsPlxyXG4gICAgICAgICAgICAgIERlYmUgY29udGVuZXIgYWwgbWVub3MgdW5hIG1hecO6c2N1bGEgeSB1biBuw7ptZXJvLlxyXG4gICAgICAgICAgICA8L3NtYWxsPlxyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIH1cclxuXHJcbiAgICA8L2Rpdj5cclxuICAgIDwhLS0gQ09ORklSTUFSIFBBU1NXT1JEIC0tPlxyXG48ZGl2IGNsYXNzPVwiZm9ybS1ncm91cCBmdWxsLXdpZHRoXCI+XHJcblxyXG4gIDxsYWJlbD5Db25maXJtYXIgQ29udHJhc2XDsWE6PC9sYWJlbD5cclxuXHJcbiAgPGRpdiBjbGFzcz1cInBhc3N3b3JkLWNvbnRhaW5lclwiPlxyXG5cclxuICAgIDxpbnB1dFxyXG4gICAgICBbdHlwZV09XCJtb3N0cmFyUGFzc3dvcmQgPyAndGV4dCcgOiAncGFzc3dvcmQnXCJcclxuICAgICAgZm9ybUNvbnRyb2xOYW1lPVwiY29uZmlybVBhc3N3b3JkXCJcclxuICAgICAgcGxhY2Vob2xkZXI9XCJSZXBldMOtIHR1IGNvbnRyYXNlw7FhXCI+XHJcblxyXG4gICAgPCEtLSBPSklUTyAtLT5cclxuICAgIDxzcGFuIGNsYXNzPVwib2pvXCIgKGNsaWNrKT1cInRvZ2dsZVBhc3N3b3JkKClcIj5cclxuXHJcbiAgICAgIDxpXHJcbiAgICAgICAgY2xhc3M9XCJmYS1zb2xpZFwiXHJcbiAgICAgICAgW2NsYXNzLmZhLWV5ZV09XCJtb3N0cmFyUGFzc3dvcmRcIlxyXG4gICAgICAgIFtjbGFzcy5mYS1leWUtc2xhc2hdPVwiIW1vc3RyYXJQYXNzd29yZFwiPlxyXG4gICAgICA8L2k+XHJcblxyXG4gICAgPC9zcGFuPlxyXG5cclxuICA8L2Rpdj5cclxuXHJcbiAgQGlmIChcclxuICAgIGZvcm1SZWdpc3Ryby5nZXQoJ2NvbmZpcm1QYXNzd29yZCcpPy50b3VjaGVkICYmXHJcbiAgICBmb3JtUmVnaXN0cm8uZ2V0KCdwYXNzd29yZCcpPy52YWx1ZSAhPT1cclxuICAgIGZvcm1SZWdpc3Ryby5nZXQoJ2NvbmZpcm1QYXNzd29yZCcpPy52YWx1ZVxyXG4gICkge1xyXG5cclxuICAgIDxkaXYgY2xhc3M9XCJlcnJvci1tc2dcIj5cclxuICAgICAgPHNtYWxsPkxhcyBjb250cmFzZcOxYXMgbm8gY29pbmNpZGVuLjwvc21hbGw+XHJcbiAgICA8L2Rpdj5cclxuXHJcbiAgfVxyXG5cclxuPC9kaXY+XHJcblxyXG4gICAgPCEtLSBCT1RPTiAtLT5cclxuICAgIDxidXR0b25cclxuICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgIFtkaXNhYmxlZF09XCJmb3JtUmVnaXN0cm8uaW52YWxpZFwiPlxyXG5cclxuICAgICAgQ3JlYXIgQ3VlbnRhXHJcblxyXG4gICAgPC9idXR0b24+XHJcblxyXG4gIDwvZm9ybT5cclxuPGRpdiBjbGFzcz1cImFjY2lvbmVzLWV4dHJhXCI+XHJcblxyXG4gIDwhLS0gVk9MVkVSIC0tPlxyXG4gIDxidXR0b25cclxuICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgY2xhc3M9XCJidG4tdm9sdmVyXCJcclxuICAgIHJvdXRlckxpbms9XCIvcmVnaXN0cmFyXCI+XHJcblxyXG4gICAg4oaQIFZvbHZlclxyXG5cclxuICA8L2J1dHRvbj5cclxuXHJcbiAgPCEtLSBZQSBURU5HTyBDVUVOVEEgLS0+XHJcbiAgPGJ1dHRvblxyXG4gICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICBjbGFzcz1cImJ0bi1sb2dpblwiXHJcbiAgICByb3V0ZXJMaW5rPVwiL3Nlc2lvblwiPlxyXG5cclxuICAgIFlhIHRlbmdvIGN1ZW50YVxyXG5cclxuICA8L2J1dHRvbj5cclxuXHJcblxyXG48L2Rpdj4iLCJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCwgQ2hhbmdlRGV0ZWN0b3JSZWYgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgRm9ybUJ1aWxkZXIsIEZvcm1Hcm91cCwgVmFsaWRhdG9ycywgRm9ybXNNb2R1bGUsIFJlYWN0aXZlRm9ybXNNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XHJcbmltcG9ydCB7IENvbW1vbk1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XHJcbmltcG9ydCB7IFJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XHJcblxyXG5pbXBvcnQgeyBPZmVydGFTZXJ2aWNlIH0gZnJvbSAnLi4vLi4vc2VydmljZXMvb2ZlcnRhX3NlcnZpY2UnO1xyXG5pbXBvcnQgeyBQb3N0dWxhY2lvbmVzU2VydmljZSB9IGZyb20gJy4uLy4uL3NlcnZpY2VzL3Bvc3R1bGFjaW9uZXMuc2VydmljZSc7XHJcbmltcG9ydCB7IEF1dGhTZXJ2aWNlIH0gZnJvbSAnLi4vLi4vc2VydmljZXMvYXV0aC5zZXJ2aWNlJztcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgU2tpbGwge1xyXG4gIHNraWxsX2lkOiBudW1iZXI7XHJcbiAgbm9tYnJlOiBzdHJpbmc7XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgQ2F0ZWdvcmlhU2tpbGwge1xyXG4gIGNhdGVnb3JpYV9pZDogbnVtYmVyO1xyXG4gIG5vbWJyZTogc3RyaW5nO1xyXG4gIHNraWxsczogU2tpbGxbXTtcclxufVxyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdhcHAtb2ZlcnRhcycsXHJcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcclxuICBpbXBvcnRzOiBbUmVhY3RpdmVGb3Jtc01vZHVsZSwgRm9ybXNNb2R1bGUsIENvbW1vbk1vZHVsZV0sXHJcbiAgdGVtcGxhdGVVcmw6ICcuL29mZXJ0YXMuaHRtbCcsXHJcbiAgc3R5bGVVcmw6ICcuL29mZXJ0YXMuc2NzcycsXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBPZmVydGFzIGltcGxlbWVudHMgT25Jbml0IHtcclxuICByb2xVc3VhcmlvOiBzdHJpbmcgPSAnJztcclxuICBpZFVzdWFyaW86IHN0cmluZyB8IG51bGwgPSAnJztcclxuICBub21icmVVc3VhcmlvOiBzdHJpbmcgfCBudWxsID0gJyc7XHJcblxyXG4gIG1vc3RyYXJGb3JtdWxhcmlvOiBib29sZWFuID0gZmFsc2U7XHJcbiAgbW9kb0VkaWNpb246IGJvb2xlYW4gPSBmYWxzZTtcclxuICBpZE9mZXJ0YUVuRWRpY2lvbjogbnVtYmVyIHwgbnVsbCA9IG51bGw7XHJcbiAgb2ZlcnRhRm9ybSE6IEZvcm1Hcm91cDtcclxuXHJcbiAgY2F0ZWdvcmlhc0NvblNraWxsczogQ2F0ZWdvcmlhU2tpbGxbXSA9IFtdO1xyXG4gIHNraWxsc1NlbGVjY2lvbmFkYXNJZHM6IG51bWJlcltdID0gW107XHJcblxyXG4gIG9mZXJ0YXNEZUJhc2VEZURhdG9zOiBhbnlbXSA9IFtdO1xyXG4gIG9mZXJ0YXNGaWx0cmFkYXM6IGFueVtdID0gW107XHJcbiAgb2ZlcnRhU2VsZWNjaW9uYWRhOiBhbnkgPSBudWxsO1xyXG5cclxuICBwb3N0dWxhY2lvbmVzUmVhbGl6YWRhczogU2V0PG51bWJlcj4gPSBuZXcgU2V0KCk7XHJcblxyXG4gIHNlYXJjaFF1ZXJ5OiBzdHJpbmcgPSAnJztcclxuICBmaWx0cm9Nb2RhbGlkYWQ6IHN0cmluZyA9ICd0b2Rvcyc7XHJcbiAgZmlsdHJvRXN0YWRvOiAndG9kYXMnIHwgJ2FiaWVydGFzJyB8ICdjZXJyYWRhcycgPSAnYWJpZXJ0YXMnO1xyXG5cclxuICBjb25zdHJ1Y3RvcihcclxuICAgIHByaXZhdGUgZmI6IEZvcm1CdWlsZGVyLFxyXG4gICAgcHJpdmF0ZSBvZmVydGFTZXJ2aWNlOiBPZmVydGFTZXJ2aWNlLFxyXG4gICAgcHJpdmF0ZSBwb3N0dWxhY2lvbmVzU2VydmljZTogUG9zdHVsYWNpb25lc1NlcnZpY2UsXHJcbiAgICBwcml2YXRlIGF1dGhTZXJ2aWNlOiBBdXRoU2VydmljZSxcclxuICAgIHByaXZhdGUgY2RyOiBDaGFuZ2VEZXRlY3RvclJlZixcclxuICAgIHByaXZhdGUgcm91dGVyOiBSb3V0ZXJcclxuICApIHt9XHJcblxyXG4gIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgY29uc3QgdXN1YXJpb0xvZ3VlYWRvID0gdGhpcy5hdXRoU2VydmljZS5nZXRVc3VhcmlvQWN0dWFsKCk7XHJcbiAgICBcclxuICAgIC8vIE5vcm1hbGl6YW1vcyBlbCByb2wgZW4gbWluw7pzY3VsYXMgKCdwb3N0dWxhbnRlJywgJ2VtcHJlc2EnLCAnYWRtaW4nKVxyXG4gICAgY29uc3Qgcm9sUmF3ID0gdGhpcy5hdXRoU2VydmljZS5nZXRUaXBvVXN1YXJpbygpIHx8IHVzdWFyaW9Mb2d1ZWFkbz8ucm9sIHx8ICd2aXNpdGFudGUnO1xyXG4gICAgdGhpcy5yb2xVc3VhcmlvID0gU3RyaW5nKHJvbFJhdykudG9Mb3dlckNhc2UoKTtcclxuXHJcbiAgICB0aGlzLmlkVXN1YXJpbyA9IHVzdWFyaW9Mb2d1ZWFkbyA/IFN0cmluZyh1c3VhcmlvTG9ndWVhZG8uaWRfcG9zdHVsYW50ZSB8fCB1c3VhcmlvTG9ndWVhZG8uaWRfZW1wcmVzYSB8fCB1c3VhcmlvTG9ndWVhZG8uaWQpIDogbnVsbDtcclxuICAgIHRoaXMubm9tYnJlVXN1YXJpbyA9IHVzdWFyaW9Mb2d1ZWFkbyA/IHVzdWFyaW9Mb2d1ZWFkby5ub21icmUgOiAnVXN1YXJpbyc7XHJcblxyXG4gICAgdGhpcy5pbmljaWFsaXphckZvcm11bGFyaW8oKTtcclxuXHJcbiAgICAvLyAxLiBDYXJnYXIgb2ZlcnRhcyB2aWdlbnRlcyAoQWNjZXNvIHDDumJsaWNvKVxyXG4gICAgdGhpcy5jYXJnYXJPZmVydGFzRGVzZGVCYWNrZW5kKCk7XHJcblxyXG4gICAgLy8gMi4gU29sbyBzaSBoYXkgc2VzacOzbiBpbmljaWFkYSBjYXJnYW1vcyBjYXRlZ29yw61hcy9za2lsbHMgeSBwb3N0dWxhY2lvbmVzXHJcbiAgICBpZiAodXN1YXJpb0xvZ3VlYWRvKSB7XHJcbiAgICAgIHRoaXMuY2FyZ2FySGFiaWxpZGFkZXNZQ2F0ZWdvcmlhcygpO1xyXG5cclxuICAgICAgaWYgKHRoaXMucm9sVXN1YXJpbyA9PT0gJ3Bvc3R1bGFudGUnKSB7XHJcbiAgICAgICAgdGhpcy5jYXJnYXJNaXNQb3N0dWxhY2lvbmVzKCk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIGluaWNpYWxpemFyRm9ybXVsYXJpbygpOiB2b2lkIHtcclxuICAgIHRoaXMub2ZlcnRhRm9ybSA9IHRoaXMuZmIuZ3JvdXAoe1xyXG4gICAgICB0aXR1bG86IFsnJywgW1ZhbGlkYXRvcnMucmVxdWlyZWQsIFZhbGlkYXRvcnMubWluTGVuZ3RoKDUpXV0sXHJcbiAgICAgIG1vZGFsaWRhZDogWydIw61icmlkbycsIFZhbGlkYXRvcnMucmVxdWlyZWRdLFxyXG4gICAgICBleHBlcmllbmNpYTogWydKdW5pb3InLCBWYWxpZGF0b3JzLnJlcXVpcmVkXSxcclxuICAgICAgZGVzY3JpcGNpb246IFsnJywgW1ZhbGlkYXRvcnMucmVxdWlyZWQsIFZhbGlkYXRvcnMubWluTGVuZ3RoKDIwKV1dLFxyXG4gICAgICB0aXBvRHVyYWNpb246IFsnMTAnLCBWYWxpZGF0b3JzLnJlcXVpcmVkXSxcclxuICAgICAgZGlhc1BlcnNvbmFsaXphZG9zOiBbbnVsbF1cclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgcmVzZXRlYXJGb3JtdWxhcmlvKCk6IHZvaWQge1xyXG4gICAgdGhpcy5tb2RvRWRpY2lvbiA9IGZhbHNlO1xyXG4gICAgdGhpcy5pZE9mZXJ0YUVuRWRpY2lvbiA9IG51bGw7XHJcbiAgICB0aGlzLnNraWxsc1NlbGVjY2lvbmFkYXNJZHMgPSBbXTtcclxuICAgIHRoaXMub2ZlcnRhRm9ybS5yZXNldCh7IFxyXG4gICAgICBtb2RhbGlkYWQ6ICdIw61icmlkbycsIFxyXG4gICAgICBleHBlcmllbmNpYTogJ0p1bmlvcicsIFxyXG4gICAgICB0aXBvRHVyYWNpb246ICcxMCcgXHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIGdldCBza2lsbHNTZWxlY2Npb25hZGFzT2JqZXRvcygpOiBTa2lsbFtdIHtcclxuICAgIGNvbnN0IHNlbGVjY2lvbmFkYXM6IFNraWxsW10gPSBbXTtcclxuICAgIGZvciAoY29uc3QgY2F0IG9mIHRoaXMuY2F0ZWdvcmlhc0NvblNraWxscykge1xyXG4gICAgICBmb3IgKGNvbnN0IHNraWxsIG9mIGNhdC5za2lsbHMpIHtcclxuICAgICAgICBpZiAodGhpcy5za2lsbHNTZWxlY2Npb25hZGFzSWRzLmluY2x1ZGVzKHNraWxsLnNraWxsX2lkKSkge1xyXG4gICAgICAgICAgc2VsZWNjaW9uYWRhcy5wdXNoKHNraWxsKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHJldHVybiBzZWxlY2Npb25hZGFzO1xyXG4gIH1cclxuXHJcbiAgY2FyZ2FyTWlzUG9zdHVsYWNpb25lcygpOiB2b2lkIHtcclxuICAgIGlmICghdGhpcy5pZFVzdWFyaW8pIHJldHVybjtcclxuICAgIHRoaXMucG9zdHVsYWNpb25lc1NlcnZpY2UuZ2V0QnlQb3N0dWxhbnRlKE51bWJlcih0aGlzLmlkVXN1YXJpbykpLnN1YnNjcmliZSh7XHJcbiAgICAgIG5leHQ6IChwb3N0dWxhY2lvbmVzKSA9PiB7XHJcbiAgICAgICAgdGhpcy5wb3N0dWxhY2lvbmVzUmVhbGl6YWRhcyA9IG5ldyBTZXQocG9zdHVsYWNpb25lcy5tYXAocCA9PiBOdW1iZXIocC5pZF9vZmVydGEpKSk7XHJcbiAgICAgICAgdGhpcy5jZHIuZGV0ZWN0Q2hhbmdlcygpO1xyXG4gICAgICB9LFxyXG4gICAgICBlcnJvcjogKGVycikgPT4gY29uc29sZS5lcnJvcignRXJyb3IgYWwgb2J0ZW5lciBwb3N0dWxhY2lvbmVzOicsIGVycilcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgY2FyZ2FyT2ZlcnRhc0Rlc2RlQmFja2VuZCgpOiB2b2lkIHtcclxuICAgIHRoaXMub2ZlcnRhU2VydmljZS5nZXRPZmVydGFzVmlnZW50ZXMoKS5zdWJzY3JpYmUoe1xyXG4gICAgICBuZXh0OiAoZGF0YTogYW55W10pID0+IHtcclxuICAgICAgICB0aGlzLm9mZXJ0YXNEZUJhc2VEZURhdG9zID0gKGRhdGEgfHwgW10pLm1hcChvID0+IHtcclxuICAgICAgICAgIGNvbnN0IGZlY2hhRGV0ZWN0YWRhID0gXHJcbiAgICAgICAgICAgIG8uZmVjaGFfcHVibGljYWNpb24gfHwgXHJcbiAgICAgICAgICAgIG8uZmVjaGFQdWJsaWNhY2lvbiB8fCBcclxuICAgICAgICAgICAgby5jcmVhdGVkX2F0IHx8IFxyXG4gICAgICAgICAgICBvLmNyZWF0ZWRBdCB8fCBcclxuICAgICAgICAgICAgby5mZWNoYV9jcmVhY2lvbiB8fCBcclxuICAgICAgICAgICAgby5mZWNoYTtcclxuXHJcbiAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAuLi5vLFxyXG4gICAgICAgICAgICBkaWFzX2R1cmFjaW9uOiBvLmRpYXNfZHVyYWNpb24gfHwgby5kaWFzRHVyYWNpb24gfHwgMTAsXHJcbiAgICAgICAgICAgIGZlY2hhX3B1YmxpY2FjaW9uOiBmZWNoYURldGVjdGFkYVxyXG4gICAgICAgICAgfTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgdGhpcy5maWx0cmFyT2ZlcnRhc0xvY2FsKCk7XHJcbiAgICAgICAgdGhpcy5jZHIuZGV0ZWN0Q2hhbmdlcygpO1xyXG4gICAgICB9LFxyXG4gICAgICBlcnJvcjogKGVycikgPT4gY29uc29sZS5lcnJvcignRXJyb3IgYWwgY2FyZ2FyIG9mZXJ0YXM6JywgZXJyKVxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBjYXJnYXJIYWJpbGlkYWRlc1lDYXRlZ29yaWFzKCk6IHZvaWQge1xyXG4gICAgdGhpcy5vZmVydGFTZXJ2aWNlLmdldENhdGVnb3JpYXNDb25Ta2lsbHMoKS5zdWJzY3JpYmUoe1xyXG4gICAgICBuZXh0OiAoZGF0YSkgPT4ge1xyXG4gICAgICAgIHRoaXMuY2F0ZWdvcmlhc0NvblNraWxscyA9IGRhdGE7XHJcbiAgICAgICAgdGhpcy5jZHIuZGV0ZWN0Q2hhbmdlcygpO1xyXG4gICAgICB9LFxyXG4gICAgICBlcnJvcjogKGVycikgPT4gY29uc29sZS5lcnJvcignRXJyb3IgYWwgY2FyZ2FyIGhhYmlsaWRhZGVzOicsIGVycilcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgb25UaXBvRHVyYWNpb25DaGFuZ2UoKTogdm9pZCB7XHJcbiAgICBjb25zdCB0aXBvID0gdGhpcy5vZmVydGFGb3JtLmdldCgndGlwb0R1cmFjaW9uJyk/LnZhbHVlO1xyXG4gICAgY29uc3QgY29udHJvbERpYXMgPSB0aGlzLm9mZXJ0YUZvcm0uZ2V0KCdkaWFzUGVyc29uYWxpemFkb3MnKTtcclxuICAgIGlmICh0aXBvID09PSAncGVyc29uYWxpemFkbycpIHtcclxuICAgICAgY29udHJvbERpYXM/LnNldFZhbGlkYXRvcnMoW1ZhbGlkYXRvcnMucmVxdWlyZWQsIFZhbGlkYXRvcnMubWluKDEpLCBWYWxpZGF0b3JzLm1heCg5MCldKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGNvbnRyb2xEaWFzPy5jbGVhclZhbGlkYXRvcnMoKTtcclxuICAgICAgY29udHJvbERpYXM/LnNldFZhbHVlKG51bGwpO1xyXG4gICAgfVxyXG4gICAgY29udHJvbERpYXM/LnVwZGF0ZVZhbHVlQW5kVmFsaWRpdHkoKTtcclxuICB9XHJcblxyXG4gIGFsdGVybmFySGFiaWxpZGFkKHNraWxsX0lkOiBudW1iZXIpOiB2b2lkIHtcclxuICAgIGNvbnN0IGluZGV4ID0gdGhpcy5za2lsbHNTZWxlY2Npb25hZGFzSWRzLmluZGV4T2Yoc2tpbGxfSWQpO1xyXG4gICAgaWYgKGluZGV4ID4gLTEpIHtcclxuICAgICAgdGhpcy5za2lsbHNTZWxlY2Npb25hZGFzSWRzLnNwbGljZShpbmRleCwgMSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICB0aGlzLnNraWxsc1NlbGVjY2lvbmFkYXNJZHMucHVzaChza2lsbF9JZCk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBzZWxlY2Npb25hck9mZXJ0YShvZmVydGE6IGFueSk6IHZvaWQge1xyXG4gICAgaWYgKCFvZmVydGEpIHJldHVybjtcclxuICAgIHRoaXMub2ZlcnRhU2VsZWNjaW9uYWRhID0ge1xyXG4gICAgICAuLi5vZmVydGEsXHJcbiAgICAgIGlkX29mZXJ0YTogb2ZlcnRhLmlkX29mZXJ0YSB8fCBvZmVydGEuaWQsXHJcbiAgICAgIGRpYXNfZHVyYWNpb246IG9mZXJ0YS5kaWFzX2R1cmFjaW9uIHx8IG9mZXJ0YS5kaWFzRHVyYWNpb24gfHwgMTAsXHJcbiAgICAgIHNraWxsc19ub21icmVzOiBvZmVydGEuc2tpbGxzX25vbWJyZXMgfHwgW11cclxuICAgIH07XHJcbiAgfVxyXG5cclxuICBwcml2YXRlIHNlbGVjY2lvbmFyUHJpbWVyYURpc3BvbmlibGUobGlzdGE6IGFueVtdKTogdm9pZCB7XHJcbiAgICBpZiAobGlzdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICB0aGlzLnNlbGVjY2lvbmFyT2ZlcnRhKGxpc3RhWzBdKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHRoaXMub2ZlcnRhU2VsZWNjaW9uYWRhID0gbnVsbDtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGVzQ2FtcG9JbnZhbGlkbyhjYW1wbzogc3RyaW5nKTogYm9vbGVhbiB7XHJcbiAgICBjb25zdCBjb250cm9sID0gdGhpcy5vZmVydGFGb3JtLmdldChjYW1wbyk7XHJcbiAgICByZXR1cm4gISEoY29udHJvbCAmJiBjb250cm9sLmludmFsaWQgJiYgKGNvbnRyb2wuZGlydHkgfHwgY29udHJvbC50b3VjaGVkKSk7XHJcbiAgfVxyXG5cclxuICB0b2dnbGVWaXN0YSh2ZXJGb3JtOiBib29sZWFuLCBlZGl0YXJPZmVydGE6IGFueSA9IG51bGwpOiB2b2lkIHtcclxuICAgIHRoaXMubW9zdHJhckZvcm11bGFyaW8gPSB2ZXJGb3JtO1xyXG5cclxuICAgIGlmICh2ZXJGb3JtKSB7XHJcbiAgICAgIGlmICh0aGlzLmNhdGVnb3JpYXNDb25Ta2lsbHMubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgdGhpcy5jYXJnYXJIYWJpbGlkYWRlc1lDYXRlZ29yaWFzKCk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmIChlZGl0YXJPZmVydGEpIHtcclxuICAgICAgICB0aGlzLm1vZG9FZGljaW9uID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLmlkT2ZlcnRhRW5FZGljaW9uID0gZWRpdGFyT2ZlcnRhLmlkX29mZXJ0YTtcclxuICAgICAgICB0aGlzLm9mZXJ0YUZvcm0ucGF0Y2hWYWx1ZSh7XHJcbiAgICAgICAgICB0aXR1bG86IGVkaXRhck9mZXJ0YS50aXR1bG8sXHJcbiAgICAgICAgICBtb2RhbGlkYWQ6IGVkaXRhck9mZXJ0YS5tb2RhbGlkYWQsXHJcbiAgICAgICAgICBleHBlcmllbmNpYTogZWRpdGFyT2ZlcnRhLmV4cGVyaWVuY2lhLFxyXG4gICAgICAgICAgZGVzY3JpcGNpb246IGVkaXRhck9mZXJ0YS5kZXNjcmlwY2lvbixcclxuICAgICAgICAgIHRpcG9EdXJhY2lvbjogU3RyaW5nKGVkaXRhck9mZXJ0YS5kaWFzX2R1cmFjaW9uIHx8ICcxMCcpXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgdGhpcy5za2lsbHNTZWxlY2Npb25hZGFzSWRzID0gWy4uLihlZGl0YXJPZmVydGEuc2tpbGxzX2lkcyB8fCBbXSldO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHRoaXMucmVzZXRlYXJGb3JtdWxhcmlvKCk7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHRoaXMucmVzZXRlYXJGb3JtdWxhcmlvKCk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICB2ZXJQb3N0dWxhZG9zKGlkT2ZlcnRhOiBudW1iZXIpOiB2b2lkIHtcclxuICAgIGlmICghaWRPZmVydGEpIHJldHVybjtcclxuICAgIHRoaXMucm91dGVyLm5hdmlnYXRlKFsnL3Bvc3R1bGFjaW9uZXMnXSwgeyBxdWVyeVBhcmFtczogeyBvZmVydGE6IGlkT2ZlcnRhIH0gfSk7XHJcbiAgfVxyXG5cclxuICBlc09mZXJ0YUFiaWVydGEob2ZlcnRhOiBhbnkpOiBib29sZWFuIHtcclxuICAgIGlmICghb2ZlcnRhKSByZXR1cm4gZmFsc2U7XHJcblxyXG4gICAgaWYgKG9mZXJ0YS5lc3RhZG8gPT09ICdDZXJyYWRhJyB8fCBvZmVydGEuZXN0YWRvID09PSAnRmluYWxpemFkYScpIHJldHVybiBmYWxzZTtcclxuICAgIGlmIChvZmVydGEuZXN0YWRvID09PSAnQWJpZXJ0YScpIHJldHVybiB0cnVlO1xyXG5cclxuICAgIGlmICghb2ZlcnRhLmZlY2hhX3B1YmxpY2FjaW9uIHx8ICFvZmVydGEuZGlhc19kdXJhY2lvbikgcmV0dXJuIGZhbHNlO1xyXG5cclxuICAgIGNvbnN0IGZlY2hhTGltcGlhID0gU3RyaW5nKG9mZXJ0YS5mZWNoYV9wdWJsaWNhY2lvbikudHJpbSgpLnNwbGl0KCdUJylbMF0ucmVwbGFjZSgvXFwvL2csICctJyk7XHJcbiAgICBjb25zdCBwYXJ0ZXMgPSBmZWNoYUxpbXBpYS5zcGxpdCgnLScpO1xyXG5cclxuICAgIGlmIChwYXJ0ZXMubGVuZ3RoIDwgMykgcmV0dXJuIGZhbHNlO1xyXG5cclxuICAgIGNvbnN0IGFuaW8gPSBOdW1iZXIocGFydGVzWzBdKTtcclxuICAgIGNvbnN0IG1lcyA9IE51bWJlcihwYXJ0ZXNbMV0pIC0gMTtcclxuICAgIGNvbnN0IGRpYSA9IE51bWJlcihwYXJ0ZXNbMl0pO1xyXG5cclxuICAgIGNvbnN0IGZlY2hhSW5pY2lvID0gbmV3IERhdGUoYW5pbywgbWVzLCBkaWEpO1xyXG4gICAgaWYgKGlzTmFOKGZlY2hhSW5pY2lvLmdldFRpbWUoKSkpIHJldHVybiBmYWxzZTtcclxuXHJcbiAgICBjb25zdCBmZWNoYVZlbmNpbWllbnRvID0gbmV3IERhdGUoZmVjaGFJbmljaW8pO1xyXG4gICAgZmVjaGFWZW5jaW1pZW50by5zZXREYXRlKGZlY2hhVmVuY2ltaWVudG8uZ2V0RGF0ZSgpICsgTnVtYmVyKG9mZXJ0YS5kaWFzX2R1cmFjaW9uKSk7XHJcbiAgICBmZWNoYVZlbmNpbWllbnRvLnNldEhvdXJzKDIzLCA1OSwgNTksIDk5OSk7XHJcblxyXG4gICAgcmV0dXJuIG5ldyBEYXRlKCkgPD0gZmVjaGFWZW5jaW1pZW50bztcclxuICB9XHJcblxyXG4gIG9idGVuZXJGZWNoYVZlbmNpbWllbnRvKG9mZXJ0YTogYW55KTogRGF0ZSB8IG51bGwge1xyXG4gICAgaWYgKCFvZmVydGEgfHwgIW9mZXJ0YS5mZWNoYV9wdWJsaWNhY2lvbiB8fCAhb2ZlcnRhLmRpYXNfZHVyYWNpb24pIHJldHVybiBudWxsO1xyXG5cclxuICAgIGNvbnN0IGZlY2hhTGltcGlhID0gU3RyaW5nKG9mZXJ0YS5mZWNoYV9wdWJsaWNhY2lvbikudHJpbSgpLnNwbGl0KCdUJylbMF0ucmVwbGFjZSgvXFwvL2csICctJyk7XHJcbiAgICBjb25zdCBwYXJ0ZXMgPSBmZWNoYUxpbXBpYS5zcGxpdCgnLScpO1xyXG5cclxuICAgIGlmIChwYXJ0ZXMubGVuZ3RoIDwgMykgcmV0dXJuIG51bGw7XHJcblxyXG4gICAgY29uc3QgYW5pbyA9IE51bWJlcihwYXJ0ZXNbMF0pO1xyXG4gICAgY29uc3QgbWVzID0gTnVtYmVyKHBhcnRlc1sxXSkgLSAxO1xyXG4gICAgY29uc3QgZGlhID0gTnVtYmVyKHBhcnRlc1syXSk7XHJcblxyXG4gICAgY29uc3QgZmVjaGFJbmljaW8gPSBuZXcgRGF0ZShhbmlvLCBtZXMsIGRpYSk7XHJcbiAgICBpZiAoaXNOYU4oZmVjaGFJbmljaW8uZ2V0VGltZSgpKSkgcmV0dXJuIG51bGw7XHJcblxyXG4gICAgY29uc3QgZmVjaGFWZW5jaW1pZW50byA9IG5ldyBEYXRlKGZlY2hhSW5pY2lvKTtcclxuICAgIGZlY2hhVmVuY2ltaWVudG8uc2V0RGF0ZShmZWNoYVZlbmNpbWllbnRvLmdldERhdGUoKSArIE51bWJlcihvZmVydGEuZGlhc19kdXJhY2lvbikpO1xyXG4gICAgXHJcbiAgICByZXR1cm4gZmVjaGFWZW5jaW1pZW50bztcclxuICB9XHJcbiAgXHJcbiAgZmlsdHJhck9mZXJ0YXNMb2NhbCgpOiB2b2lkIHtcclxuICAgIHRoaXMub2ZlcnRhc0ZpbHRyYWRhcyA9IHRoaXMub2ZlcnRhc0RlQmFzZURlRGF0b3MuZmlsdGVyKG8gPT4ge1xyXG4gICAgICBjb25zdCBjb2luY2lkZUJ1c3F1ZWRhID0gXHJcbiAgICAgICAgby50aXR1bG8udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyh0aGlzLnNlYXJjaFF1ZXJ5LnRvTG93ZXJDYXNlKCkpIHx8XHJcbiAgICAgICAgKG8ucmF6b25Tb2NpYWwgJiYgby5yYXpvblNvY2lhbC50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHRoaXMuc2VhcmNoUXVlcnkudG9Mb3dlckNhc2UoKSkpIHx8XHJcbiAgICAgICAgKG8uc2tpbGxzX25vbWJyZXMgJiYgby5za2lsbHNfbm9tYnJlcy5zb21lKChzOiBzdHJpbmcpID0+IHMudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyh0aGlzLnNlYXJjaFF1ZXJ5LnRvTG93ZXJDYXNlKCkpKSk7XHJcblxyXG4gICAgICBjb25zdCBjb2luY2lkZU1vZGFsaWRhZCA9IHRoaXMuZmlsdHJvTW9kYWxpZGFkID09PSAndG9kb3MnIHx8IG8ubW9kYWxpZGFkID09PSB0aGlzLmZpbHRyb01vZGFsaWRhZDtcclxuXHJcbiAgICAgIGNvbnN0IGFiaWVydGEgPSB0aGlzLmVzT2ZlcnRhQWJpZXJ0YShvKTtcclxuXHJcbiAgICAgIGxldCBjb2luY2lkZUVzdGFkbyA9IHRydWU7XHJcbiAgICAgIGlmICh0aGlzLmZpbHRyb0VzdGFkbyA9PT0gJ2FiaWVydGFzJykgY29pbmNpZGVFc3RhZG8gPSBhYmllcnRhO1xyXG4gICAgICBpZiAodGhpcy5maWx0cm9Fc3RhZG8gPT09ICdjZXJyYWRhcycpIGNvaW5jaWRlRXN0YWRvID0gIWFiaWVydGE7XHJcblxyXG4gICAgICByZXR1cm4gY29pbmNpZGVCdXNxdWVkYSAmJiBjb2luY2lkZU1vZGFsaWRhZCAmJiBjb2luY2lkZUVzdGFkbztcclxuICAgIH0pO1xyXG5cclxuICAgIHRoaXMuc2luY3Jvbml6YXJTZWxlY2Npb25EZXJlY2hhKCk7XHJcbiAgfVxyXG5cclxuICBjYW1iaWFyRmlsdHJvRXN0YWRvKGVzdGFkbzogJ3RvZGFzJyB8ICdhYmllcnRhcycgfCAnY2VycmFkYXMnKTogdm9pZCB7XHJcbiAgICB0aGlzLmZpbHRyb0VzdGFkbyA9IGVzdGFkbztcclxuICAgIHRoaXMuZmlsdHJhck9mZXJ0YXNMb2NhbCgpO1xyXG4gIH1cclxuXHJcbiAgY2FtYmlhckZpbHRyb01vZGFsaWRhZChtb2RhbGlkYWQ6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgdGhpcy5maWx0cm9Nb2RhbGlkYWQgPSBtb2RhbGlkYWQ7XHJcbiAgICB0aGlzLmZpbHRyYXJPZmVydGFzTG9jYWwoKTtcclxuICB9XHJcblxyXG4gIHByaXZhdGUgc2luY3Jvbml6YXJTZWxlY2Npb25EZXJlY2hhKCk6IHZvaWQge1xyXG4gICAgaWYgKCF0aGlzLm9mZXJ0YVNlbGVjY2lvbmFkYSB8fCAhdGhpcy5vZmVydGFzRmlsdHJhZGFzLnNvbWUobyA9PiBvLmlkX29mZXJ0YSA9PT0gdGhpcy5vZmVydGFTZWxlY2Npb25hZGEuaWRfb2ZlcnRhKSkge1xyXG4gICAgICB0aGlzLnNlbGVjY2lvbmFyUHJpbWVyYURpc3BvbmlibGUodGhpcy5vZmVydGFzRmlsdHJhZGFzKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGd1YXJkYXJPZmVydGEoKTogdm9pZCB7XHJcbiAgICBpZiAodGhpcy5vZmVydGFGb3JtLmludmFsaWQgfHwgdGhpcy5za2lsbHNTZWxlY2Npb25hZGFzSWRzLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICB0aGlzLm9mZXJ0YUZvcm0ubWFya0FsbEFzVG91Y2hlZCgpO1xyXG4gICAgICBhbGVydCgnUG9yIGZhdm9yIGNvbXBsZXRhIGxvcyBjYW1wb3Mgb2JsaWdhdG9yaW9zIHkgc2VsZWNjaW9uYSBhbCBtZW5vcyB1bmEgaGFiaWxpZGFkLicpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgZlZhbHVlID0gdGhpcy5vZmVydGFGb3JtLnZhbHVlO1xyXG4gICAgY29uc3QgZGlhc0ZpbmFsZXMgPSBmVmFsdWUudGlwb0R1cmFjaW9uID09PSAncGVyc29uYWxpemFkbycgXHJcbiAgICAgID8gTnVtYmVyKGZWYWx1ZS5kaWFzUGVyc29uYWxpemFkb3MpIFxyXG4gICAgICA6IE51bWJlcihmVmFsdWUudGlwb0R1cmFjaW9uKTtcclxuXHJcbiAgICBjb25zdCBwYXlsb2FkID0ge1xyXG4gICAgICBpZF9lbXByZXNhOiBOdW1iZXIodGhpcy5pZFVzdWFyaW8gfHwgMCksXHJcbiAgICAgIHRpdHVsbzogZlZhbHVlLnRpdHVsbyxcclxuICAgICAgZGVzY3JpcGNpb246IGZWYWx1ZS5kZXNjcmlwY2lvbixcclxuICAgICAgbW9kYWxpZGFkOiBmVmFsdWUubW9kYWxpZGFkLFxyXG4gICAgICBleHBlcmllbmNpYTogZlZhbHVlLmV4cGVyaWVuY2lhLFxyXG4gICAgICBkaWFzX2R1cmFjaW9uOiBkaWFzRmluYWxlcyxcclxuICAgICAgc2tpbGw6IFsuLi50aGlzLnNraWxsc1NlbGVjY2lvbmFkYXNJZHNdXHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IHBldGljaW9uJCA9ICh0aGlzLm1vZG9FZGljaW9uICYmIHRoaXMuaWRPZmVydGFFbkVkaWNpb24pXHJcbiAgICAgID8gdGhpcy5vZmVydGFTZXJ2aWNlLmFjdHVhbGl6YXJPZmVydGEodGhpcy5pZE9mZXJ0YUVuRWRpY2lvbiwgcGF5bG9hZClcclxuICAgICAgOiB0aGlzLm9mZXJ0YVNlcnZpY2UucHVibGljYXJPZmVydGEocGF5bG9hZCk7XHJcblxyXG4gICAgcGV0aWNpb24kLnN1YnNjcmliZSh7XHJcbiAgICAgIG5leHQ6ICgpID0+IHtcclxuICAgICAgICBhbGVydCh0aGlzLm1vZG9FZGljaW9uID8gJ09mZXJ0YSBhY3R1YWxpemFkYSBjb24gw6l4aXRvLicgOiAnT2ZlcnRhIHB1YmxpY2FkYSBjb24gw6l4aXRvLicpO1xyXG4gICAgICAgIHRoaXMucmVzZXRlYXJGb3JtdWxhcmlvKCk7XHJcbiAgICAgICAgdGhpcy50b2dnbGVWaXN0YShmYWxzZSk7XHJcbiAgICAgICAgdGhpcy5jYXJnYXJPZmVydGFzRGVzZGVCYWNrZW5kKCk7XHJcbiAgICAgIH0sXHJcbiAgICAgIGVycm9yOiAoZXJyKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgYWwgZ3VhcmRhciBsYSBvZmVydGE6JywgZXJyKTtcclxuICAgICAgICBcclxuICAgICAgICBpZiAoZXJyLnN0YXR1cyA9PT0gNDAzKSB7XHJcbiAgICAgICAgICBhbGVydCgnQWNjZXNvIGRlbmVnYWRvICg0MDMpOiBUdSB1c3VhcmlvIG5vIGN1ZW50YSBjb24gZWwgcm9sIFwiRW1wcmVzYVwiIG8gbGEgc2VzacOzbiBleHBpcsOzLicpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBhbGVydChlcnIuZXJyb3I/LmVycm9yIHx8IGVyci5lcnJvcj8ubWVuc2FqZSB8fCAnRXJyb3IgYWwgcHJvY2VzYXIgbGEgc29saWNpdHVkIGVuIGVsIHNlcnZpZG9yLicpO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBjYW1iaWFyRXN0YWRvT2ZlcnRhKG9mZXJ0YUlkOiBudW1iZXIsIG51ZXZvRXN0YWRvOiAnQWJpZXJ0YScgfCAnQ2VycmFkYScpOiB2b2lkIHtcclxuICAgIGlmIChjb25maXJtKGDCv0NvbmZpcm1hIHF1ZSBkZXNlYSBtYXJjYXIgZXN0YSBvZmVydGEgY29tbyAke251ZXZvRXN0YWRvfT9gKSkge1xyXG4gICAgICB0aGlzLm9mZXJ0YVNlcnZpY2UuY2FtYmlhckVzdGFkbyhvZmVydGFJZCwgbnVldm9Fc3RhZG8pLnN1YnNjcmliZSh7XHJcbiAgICAgICAgbmV4dDogKCkgPT4ge1xyXG4gICAgICAgICAgaWYgKHRoaXMub2ZlcnRhU2VsZWNjaW9uYWRhICYmIHRoaXMub2ZlcnRhU2VsZWNjaW9uYWRhLmlkX29mZXJ0YSA9PT0gb2ZlcnRhSWQpIHtcclxuICAgICAgICAgICAgdGhpcy5vZmVydGFTZWxlY2Npb25hZGEuZXN0YWRvID0gbnVldm9Fc3RhZG87XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBjb25zdCBpdGVtID0gdGhpcy5vZmVydGFzRGVCYXNlRGVEYXRvcy5maW5kKG8gPT4gby5pZF9vZmVydGEgPT09IG9mZXJ0YUlkKTtcclxuICAgICAgICAgIGlmIChpdGVtKSBpdGVtLmVzdGFkbyA9IG51ZXZvRXN0YWRvO1xyXG4gICAgICAgICAgdGhpcy5maWx0cmFyT2ZlcnRhc0xvY2FsKCk7XHJcbiAgICAgICAgICBhbGVydChgTGEgb2ZlcnRhIGFob3JhIGVzdMOhICR7bnVldm9Fc3RhZG99LmApO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZXJyb3I6IChlcnIpID0+IGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGFsIGNhbWJpYXIgZXN0YWRvOicsIGVycilcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBhbXBsaWFyRHVyYWNpb24ob2ZlcnRhSWQ6IG51bWJlcik6IHZvaWQge1xyXG4gICAgY29uc3QgZGlhc1N0ciA9IHByb21wdCgnwr9DdcOhbnRvcyBkw61hcyBkZXNlYSBhZ3JlZ2FyIGFsIHBsYXpvIGRlIHZpZ2VuY2lhPycsICcxMCcpO1xyXG4gICAgY29uc3QgZGlhcyA9IE51bWJlcihkaWFzU3RyKTtcclxuXHJcbiAgICBpZiAoZGlhcyAmJiBkaWFzID4gMCkge1xyXG4gICAgICB0aGlzLm9mZXJ0YVNlcnZpY2UuYW1wbGlhclBsYXpvKG9mZXJ0YUlkLCBkaWFzKS5zdWJzY3JpYmUoe1xyXG4gICAgICAgIG5leHQ6ICgpID0+IHtcclxuICAgICAgICAgIGlmICh0aGlzLm9mZXJ0YVNlbGVjY2lvbmFkYSAmJiB0aGlzLm9mZXJ0YVNlbGVjY2lvbmFkYS5pZF9vZmVydGEgPT09IG9mZXJ0YUlkKSB7XHJcbiAgICAgICAgICAgIHRoaXMub2ZlcnRhU2VsZWNjaW9uYWRhLmRpYXNfZHVyYWNpb24gPSBOdW1iZXIodGhpcy5vZmVydGFTZWxlY2Npb25hZGEuZGlhc19kdXJhY2lvbikgKyBkaWFzO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgdGhpcy5jYXJnYXJPZmVydGFzRGVzZGVCYWNrZW5kKCk7XHJcbiAgICAgICAgICBhbGVydChgUGxhem8gYW1wbGlhZG8gZXhpdG9zYW1lbnRlIGVuICR7ZGlhc30gZMOtYXMuYCk7XHJcbiAgICAgICAgfSxcclxuICAgICAgICBlcnJvcjogKGVycikgPT4gY29uc29sZS5lcnJvcignRXJyb3IgYWwgYW1wbGlhciBwbGF6bzonLCBlcnIpXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgZ3VhcmRhclBvc3R1bGFjaW9uKG9mZXJ0YUlkOiBudW1iZXIpOiB2b2lkIHtcclxuICAgIGlmICghdGhpcy5pZFVzdWFyaW8pIHtcclxuICAgICAgYWxlcnQoJ0RlYmVzIGluaWNpYXIgc2VzacOzbiBwYXJhIHBvc3R1bGFydGUgYSB1bmEgb2ZlcnRhIGxhYm9yYWwuJyk7XHJcbiAgICAgIHRoaXMucm91dGVyLm5hdmlnYXRlKFsnL3Nlc2lvbiddKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICh0aGlzLnBvc3R1bGFjaW9uZXNSZWFsaXphZGFzLmhhcyhvZmVydGFJZCkpIHtcclxuICAgICAgYWxlcnQoJ1lhIHRlIGhhcyBwb3N0dWxhZG8gYSBlc3RhIG9mZXJ0YSBsYWJvcmFsLicpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgdGhpcy5wb3N0dWxhY2lvbmVzU2VydmljZS5jcmVhclBvc3R1bGFjaW9uKG9mZXJ0YUlkKS5zdWJzY3JpYmUoe1xyXG4gICAgICBuZXh0OiAoKSA9PiB7XHJcbiAgICAgICAgYWxlcnQoJ8KhUG9zdHVsYWNpw7NuIGVudmlhZGEgY29uIMOpeGl0byEnKTtcclxuICAgICAgICB0aGlzLnBvc3R1bGFjaW9uZXNSZWFsaXphZGFzLmFkZChvZmVydGFJZCk7XHJcbiAgICAgICAgdGhpcy5wb3N0dWxhY2lvbmVzUmVhbGl6YWRhcyA9IG5ldyBTZXQodGhpcy5wb3N0dWxhY2lvbmVzUmVhbGl6YWRhcyk7XHJcbiAgICAgICAgdGhpcy5jZHIuZGV0ZWN0Q2hhbmdlcygpO1xyXG4gICAgICB9LFxyXG4gICAgICBlcnJvcjogKGVycikgPT4gYWxlcnQoZXJyLmVycm9yPy5tZW5zYWplIHx8ICdFcnJvciBhbCBwcm9jZXNhciBsYSBwb3N0dWxhY2nDs24uJylcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgZXN0YVBvc3R1bGFkbyhvZmVydGFJZDogbnVtYmVyKTogYm9vbGVhbiB7XHJcbiAgICByZXR1cm4gdGhpcy5wb3N0dWxhY2lvbmVzUmVhbGl6YWRhcy5oYXMob2ZlcnRhSWQpO1xyXG4gIH1cclxuXHJcbiAgYmFqYU9mZXJ0YUFkbWluKG9mZXJ0YUlkOiBudW1iZXIpOiB2b2lkIHtcclxuICAgIGlmIChjb25maXJtKCfCv0VzdMOhIHNlZ3VybyBkZSBxdWUgZGVzZWEgZWxpbWluYXIgZXN0YSBvZmVydGEgZGUgbWFuZXJhIHBlcm1hbmVudGU/JykpIHtcclxuICAgICAgdGhpcy5vZmVydGFTZXJ2aWNlLmVsaW1pbmFyT2ZlcnRhKG9mZXJ0YUlkKS5zdWJzY3JpYmUoe1xyXG4gICAgICAgIG5leHQ6ICgpID0+IHtcclxuICAgICAgICAgIHRoaXMub2ZlcnRhc0RlQmFzZURlRGF0b3MgPSB0aGlzLm9mZXJ0YXNEZUJhc2VEZURhdG9zLmZpbHRlcihvID0+IG8uaWRfb2ZlcnRhICE9PSBvZmVydGFJZCk7XHJcbiAgICAgICAgICB0aGlzLmZpbHRyYXJPZmVydGFzTG9jYWwoKTtcclxuICAgICAgICAgIGFsZXJ0KGBPZmVydGEgTsKwICR7b2ZlcnRhSWR9IGVsaW1pbmFkYS5gKTtcclxuICAgICAgICB9LFxyXG4gICAgICAgIGVycm9yOiAoZXJyKSA9PiBjb25zb2xlLmVycm9yKCdFcnJvciBhbCBlbGltaW5hciBvZmVydGE6JywgZXJyKVxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9XHJcbn0iLCI8ZGl2IGNsYXNzPVwib2ZlcnRhcy1jb250YWluZXJcIj5cclxuXHJcbiAgPCEtLSA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gLS0+XHJcbiAgPCEtLSBWSVNUQSAxOiBGT1JNVUxBUklPIENSRUFSIC8gRURJVEFSIE9GRVJUQSAgLS0+XHJcbiAgPCEtLSA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gLS0+XHJcbiAgQGlmIChtb3N0cmFyRm9ybXVsYXJpbykge1xyXG4gICAgPGRpdiBjbGFzcz1cImZvcm11bGFyaW8tY2FyZFwiPlxyXG4gICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1oZWFkZXJcIj5cclxuICAgICAgICA8aDI+e3sgbW9kb0VkaWNpb24gPyAnRWRpdGFyIE9mZXJ0YSBMYWJvcmFsJyA6ICdQdWJsaWNhciBOdWV2YSBPZmVydGEgTGFib3JhbCcgfX08L2gyPlxyXG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzPVwiYnRuLWNhbmNlbGFyXCIgKGNsaWNrKT1cInRvZ2dsZVZpc3RhKGZhbHNlKVwiPlxyXG4gICAgICAgICAgPGkgY2xhc3M9XCJmYS1zb2xpZCBmYS14bWFya1wiPjwvaT4gQ2FuY2VsYXJcclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8Zm9ybSBbZm9ybUdyb3VwXT1cIm9mZXJ0YUZvcm1cIiAobmdTdWJtaXQpPVwiZ3VhcmRhck9mZXJ0YSgpXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgIDxsYWJlbCBmb3I9XCJ0aXR1bG9cIj5Uw610dWxvIGRlIGxhIE9mZXJ0YSAqPC9sYWJlbD5cclxuICAgICAgICAgIDxpbnB1dCBpZD1cInRpdHVsb1wiIG5hbWU9XCJ0aXR1bG9cIiB0eXBlPVwidGV4dFwiIGZvcm1Db250cm9sTmFtZT1cInRpdHVsb1wiIHBsYWNlaG9sZGVyPVwiRWo6IERlc2Fycm9sbGFkb3IgRnJvbnRlbmQgQW5ndWxhclwiIC8+XHJcbiAgICAgICAgICBAaWYgKGVzQ2FtcG9JbnZhbGlkbygndGl0dWxvJykpIHtcclxuICAgICAgICAgICAgPHNtYWxsIGNsYXNzPVwiZXJyb3ItdGV4dFwiPkVsIHTDrXR1bG8gZGViZSB0ZW5lciBhbCBtZW5vcyA1IGNhcmFjdGVyZXMuPC9zbWFsbD5cclxuICAgICAgICAgIH1cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tcm93XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICA8bGFiZWwgZm9yPVwibW9kYWxpZGFkXCI+TW9kYWxpZGFkICo8L2xhYmVsPlxyXG4gICAgICAgICAgICA8c2VsZWN0IGlkPVwibW9kYWxpZGFkXCIgbmFtZT1cIm1vZGFsaWRhZFwiIGZvcm1Db250cm9sTmFtZT1cIm1vZGFsaWRhZFwiPlxyXG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJQcmVzZW5jaWFsXCI+UHJlc2VuY2lhbDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJIw61icmlkb1wiPkjDrWJyaWRvPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlJlbW90b1wiPlJlbW90bzwvb3B0aW9uPlxyXG4gICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgIDxsYWJlbCBmb3I9XCJleHBlcmllbmNpYVwiPkV4cGVyaWVuY2lhICo8L2xhYmVsPlxyXG4gICAgICAgICAgICA8c2VsZWN0IGlkPVwiZXhwZXJpZW5jaWFcIiBuYW1lPVwiZXhwZXJpZW5jaWFcIiBmb3JtQ29udHJvbE5hbWU9XCJleHBlcmllbmNpYVwiPlxyXG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJUcmFpbmVlXCI+VHJhaW5lZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJKdW5pb3JcIj5KdW5pb3I8L29wdGlvbj5cclxuICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiU2VtaS1TZW5pb3JcIj5TZW1pLVNlbmlvcjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJTZW5pb3JcIj5TZW5pb3I8L29wdGlvbj5cclxuICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICA8bGFiZWwgZm9yPVwidGlwb0R1cmFjaW9uXCI+RHVyYWNpw7NuIGRlIGxhIENvbnZvY2F0b3JpYSAqPC9sYWJlbD5cclxuICAgICAgICAgICAgPHNlbGVjdCBpZD1cInRpcG9EdXJhY2lvblwiIG5hbWU9XCJ0aXBvRHVyYWNpb25cIiBmb3JtQ29udHJvbE5hbWU9XCJ0aXBvRHVyYWNpb25cIiAoY2hhbmdlKT1cIm9uVGlwb0R1cmFjaW9uQ2hhbmdlKClcIj5cclxuICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiMTBcIj4xMCBEw61hcyAoRXN0w6FuZGFyKTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCIzMFwiPjMwIETDrWFzPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cInBlcnNvbmFsaXphZG9cIj5QZXJzb25hbGl6YWRvPC9vcHRpb24+XHJcbiAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIEBpZiAob2ZlcnRhRm9ybS5nZXQoJ3RpcG9EdXJhY2lvbicpPy52YWx1ZSA9PT0gJ3BlcnNvbmFsaXphZG8nKSB7XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICA8bGFiZWwgZm9yPVwiZGlhc1BlcnNvbmFsaXphZG9zXCI+RMOtYXMgcGVyc29uYWxpemFkb3MgKDEgYSA5MCk6PC9sYWJlbD5cclxuICAgICAgICAgICAgPGlucHV0IGlkPVwiZGlhc1BlcnNvbmFsaXphZG9zXCIgbmFtZT1cImRpYXNQZXJzb25hbGl6YWRvc1wiIHR5cGU9XCJudW1iZXJcIiBmb3JtQ29udHJvbE5hbWU9XCJkaWFzUGVyc29uYWxpemFkb3NcIiBtaW49XCIxXCIgbWF4PVwiOTBcIiAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgPGxhYmVsIGZvcj1cImRlc2NyaXBjaW9uXCI+RGVzY3JpcGNpw7NuIGRlIGxhIELDunNxdWVkYSAqPC9sYWJlbD5cclxuICAgICAgICAgIDx0ZXh0YXJlYSBpZD1cImRlc2NyaXBjaW9uXCIgbmFtZT1cImRlc2NyaXBjaW9uXCIgZm9ybUNvbnRyb2xOYW1lPVwiZGVzY3JpcGNpb25cIiByb3dzPVwiNVwiIHBsYWNlaG9sZGVyPVwiRGV0YWxsYSBsb3MgcmVxdWlzaXRvcywgdGFyZWFzIHkgYmVuZWZpY2lvcy4uLlwiPjwvdGV4dGFyZWE+XHJcbiAgICAgICAgICBAaWYgKGVzQ2FtcG9JbnZhbGlkbygnZGVzY3JpcGNpb24nKSkge1xyXG4gICAgICAgICAgICA8c21hbGwgY2xhc3M9XCJlcnJvci10ZXh0XCI+TGEgZGVzY3JpcGNpw7NuIGRlYmUgdGVuZXIgYWwgbWVub3MgMjAgY2FyYWN0ZXJlcy48L3NtYWxsPlxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8IS0tIEhhYmlsaWRhZGVzIFJlcXVlcmlkYXMgLS0+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgIDxsYWJlbD5IYWJpbGlkYWRlcyAvIFJlcXVpc2l0b3MgKFNlbGVjY2lvbmFyKTwvbGFiZWw+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2F0ZWdvcmlhcy1jb250YWluZXJcIj5cclxuICAgICAgICAgICAgQGZvciAoY2F0IG9mIGNhdGVnb3JpYXNDb25Ta2lsbHM7IHRyYWNrIGNhdC5jYXRlZ29yaWFfaWQpIHtcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2F0ZWdvcmlhLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICA8aDQ+e3sgY2F0Lm5vbWJyZSB9fTwvaDQ+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2hpcHMtY29udGFpbmVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIEBmb3IgKHNraWxsIG9mIGNhdC5za2lsbHM7IHRyYWNrIHNraWxsLnNraWxsX2lkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImNoaXAtc2tpbGxcIiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtjbGFzcy5zZWxlY2Npb25hZGFdPVwic2tpbGxzU2VsZWNjaW9uYWRhc0lkcy5pbmNsdWRlcyhza2lsbC5za2lsbF9pZClcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKGNsaWNrKT1cImFsdGVybmFySGFiaWxpZGFkKHNraWxsLnNraWxsX2lkKVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3sgc2tpbGwubm9tYnJlIH19XHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tYWN0aW9uc1wiPlxyXG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3M9XCJidG4tc2VjdW5kYXJpb1wiIChjbGljayk9XCJ0b2dnbGVWaXN0YShmYWxzZSlcIj5DYW5jZWxhcjwvYnV0dG9uPlxyXG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgY2xhc3M9XCJidG4tcHJpbWFyaW9cIiBbZGlzYWJsZWRdPVwib2ZlcnRhRm9ybS5pbnZhbGlkIHx8IHNraWxsc1NlbGVjY2lvbmFkYXNJZHMubGVuZ3RoID09PSAwXCI+XHJcbiAgICAgICAgICAgIHt7IG1vZG9FZGljaW9uID8gJ0d1YXJkYXIgQ2FtYmlvcycgOiAnUHVibGljYXIgT2ZlcnRhJyB9fVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZm9ybT5cclxuICAgIDwvZGl2PlxyXG4gIH1cclxuXHJcbiAgPCEtLSA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gLS0+XHJcbiAgPCEtLSBWSVNUQSAyOiBMSVNUQURPIFkgREVUQUxMRSBQUklOQ0lQQUwgICAgICAgIC0tPlxyXG4gIDwhLS0gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IC0tPlxyXG4gIEBlbHNlIHtcclxuICAgIDwhLS0gSGVhZGVyIGRlIEZpbHRyb3MgeSBCw7pzcXVlZGEgLS0+XHJcbiAgICA8aGVhZGVyIGNsYXNzPVwiaGVhZGVyLW9mZXJ0YXNcIj5cclxuICAgICAgPGRpdiBjbGFzcz1cInRpdHVsby1zZWNjaW9uXCI+XHJcbiAgICAgICAgPGgyPkJvbHNhIGRlIFRyYWJham9zIElUQiBDb25lY3RhPC9oMj5cclxuICAgICAgICA8cCBjbGFzcz1cInN1YnRpdHVsb1wiPkV4cGxvcmEgb3BvcnR1bmlkYWRlcyBsYWJvcmFsZXMgbyBnZXN0aW9uYSB0dXMgYsO6c3F1ZWRhcyBwdWJsaWNhZGFzLjwvcD5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzPVwiYmFyLWFjY2lvbmVzXCI+XHJcbiAgICAgICAgPGlucHV0IGlkPVwic2VhcmNoUXVlcnlcIiBuYW1lPVwic2VhcmNoUXVlcnlcIiB0eXBlPVwidGV4dFwiIFsobmdNb2RlbCldPVwic2VhcmNoUXVlcnlcIiAoaW5wdXQpPVwiZmlsdHJhck9mZXJ0YXNMb2NhbCgpXCIgcGxhY2Vob2xkZXI9XCLwn5SNIEJ1c2NhciBwb3IgdMOtdHVsbywgZW1wcmVzYSBvIHRlY25vbG9nw61hLi4uXCIgY2xhc3M9XCJpbnB1dC1idXNxdWVkYVwiIC8+XHJcblxyXG4gICAgICAgIDxzZWxlY3QgaWQ9XCJmaWx0cm9Nb2RhbGlkYWRcIiBuYW1lPVwiZmlsdHJvTW9kYWxpZGFkXCIgWyhuZ01vZGVsKV09XCJmaWx0cm9Nb2RhbGlkYWRcIiAoY2hhbmdlKT1cImZpbHRyYXJPZmVydGFzTG9jYWwoKVwiIGNsYXNzPVwic2VsZWN0LWZpbHRyb1wiPlxyXG4gICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cInRvZG9zXCI+VG9kYXMgbGFzIG1vZGFsaWRhZGVzPC9vcHRpb24+XHJcbiAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiUHJlc2VuY2lhbFwiPlByZXNlbmNpYWw8L29wdGlvbj5cclxuICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJIw61icmlkb1wiPkjDrWJyaWRvPC9vcHRpb24+XHJcbiAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiUmVtb3RvXCI+UmVtb3RvPC9vcHRpb24+XHJcbiAgICAgICAgPC9zZWxlY3Q+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJidG4tZ3JvdXAtZXN0YWRvc1wiPlxyXG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgW2NsYXNzLmFjdGl2b109XCJmaWx0cm9Fc3RhZG8gPT09ICdhYmllcnRhcydcIiAoY2xpY2spPVwiY2FtYmlhckZpbHRyb0VzdGFkbygnYWJpZXJ0YXMnKVwiPkFiaWVydGFzPC9idXR0b24+XHJcbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBbY2xhc3MuYWN0aXZvXT1cImZpbHRyb0VzdGFkbyA9PT0gJ2NlcnJhZGFzJ1wiIChjbGljayk9XCJjYW1iaWFyRmlsdHJvRXN0YWRvKCdjZXJyYWRhcycpXCI+Q2VycmFkYXM8L2J1dHRvbj5cclxuICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIFtjbGFzcy5hY3Rpdm9dPVwiZmlsdHJvRXN0YWRvID09PSAndG9kYXMnXCIgKGNsaWNrKT1cImNhbWJpYXJGaWx0cm9Fc3RhZG8oJ3RvZGFzJylcIj5Ub2RhczwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICBAaWYgKHJvbFVzdWFyaW8gPT09ICdlbXByZXNhJyB8fCByb2xVc3VhcmlvID09PSAnYWRtaW4nKSB7XHJcbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzcz1cImJ0bi1jcmVhclwiIChjbGljayk9XCJ0b2dnbGVWaXN0YSh0cnVlKVwiPlxyXG4gICAgICAgICAgICA8aSBjbGFzcz1cImZhLXNvbGlkIGZhLXBsdXNcIj48L2k+IE51ZXZhIE9mZXJ0YVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvaGVhZGVyPlxyXG5cclxuICAgIDwhLS0gUGFuZWwgRG9zIENvbHVtbmFzIChMaXN0YSAvIERldGFsbGUpIC0tPlxyXG4gICAgPGRpdiBjbGFzcz1cImxheW91dC1vZmVydGFzXCI+XHJcblxyXG4gICAgICA8IS0tIENPTFVNTkEgSVpRVUlFUkRBOiBMSVNUQSAtLT5cclxuICAgICAgPGFzaWRlIGNsYXNzPVwiY29sdW1uYS1saXN0YVwiPlxyXG4gICAgICAgIEBmb3IgKG9mZXJ0YSBvZiBvZmVydGFzRmlsdHJhZGFzOyB0cmFjayBvZmVydGEuaWRfb2ZlcnRhKSB7XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZC1vZmVydGFcIiBcclxuICAgICAgICAgICAgICAgW2NsYXNzLnNlbGVjY2lvbmFkYV09XCJvZmVydGFTZWxlY2Npb25hZGE/LmlkX29mZXJ0YSA9PT0gb2ZlcnRhLmlkX29mZXJ0YVwiXHJcbiAgICAgICAgICAgICAgIChjbGljayk9XCJzZWxlY2Npb25hck9mZXJ0YShvZmVydGEpXCI+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2FyZC1oZWFkZXJcIj5cclxuICAgICAgICAgICAgICA8aDM+e3sgb2ZlcnRhLnRpdHVsbyB9fTwvaDM+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJiYWRnZS1lc3RhZG9cIiBbY2xhc3MuYWJpZXJ0YV09XCJlc09mZXJ0YUFiaWVydGEob2ZlcnRhKVwiPlxyXG4gICAgICAgICAgICAgICAge3sgZXNPZmVydGFBYmllcnRhKG9mZXJ0YSkgPyAnQWJpZXJ0YScgOiAnQ2VycmFkYScgfX1cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPHAgY2xhc3M9XCJlbXByZXNhLW5vbWJyZVwiPjxpIGNsYXNzPVwiZmEtcmVndWxhciBmYS1idWlsZGluZ1wiPjwvaT4ge3sgb2ZlcnRhLnJhem9uU29jaWFsIHx8IG9mZXJ0YS5ub21icmVfZW1wcmVzYSB8fCAnRW1wcmVzYScgfX08L3A+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwidGFncy1pbmZvXCI+XHJcbiAgICAgICAgICAgICAgPHNwYW4+PGkgY2xhc3M9XCJmYS1zb2xpZCBmYS1sYXB0b3BcIj48L2k+IHt7IG9mZXJ0YS5tb2RhbGlkYWQgfX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgPHNwYW4+PGkgY2xhc3M9XCJmYS1zb2xpZCBmYS1icmllZmNhc2VcIj48L2k+IHt7IG9mZXJ0YS5leHBlcmllbmNpYSB9fTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8c3Bhbj48aSBjbGFzcz1cImZhLXJlZ3VsYXIgZmEtY2FsZW5kYXItZGF5c1wiPjwvaT4ge3sgb2ZlcnRhLmZlY2hhX3B1YmxpY2FjaW9uIHwgZGF0ZTonZGQvTU0veXl5eScgfX08L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgfSBAZW1wdHkge1xyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cInNpbi1yZXN1bHRhZG9zXCI+XHJcbiAgICAgICAgICAgIDxwPk5vIHNlIGVuY29udHJhcm9uIG9mZXJ0YXMgbGFib3JhbGVzIGNvbiBsb3MgZmlsdHJvcyBzZWxlY2Npb25hZG9zLjwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIH1cclxuICAgICAgPC9hc2lkZT5cclxuXHJcbiAgICAgIDwhLS0gQ09MVU1OQSBERVJFQ0hBOiBERVRBTExFIFNFTEVDQ0lPTkFETyAtLT5cclxuICAgICAgPG1haW4gY2xhc3M9XCJjb2x1bW5hLWRldGFsbGVcIj5cclxuICAgICAgICBAaWYgKG9mZXJ0YVNlbGVjY2lvbmFkYSkge1xyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImNhcmQtZGV0YWxsZS1jb21wbGV0b1wiPlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImRldGFsbGUtaGVhZGVyLXRvcFwiPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8aDI+e3sgb2ZlcnRhU2VsZWNjaW9uYWRhLnRpdHVsbyB9fTwvaDI+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzcz1cImVtcHJlc2EtZGV0YWxsZVwiPjxpIGNsYXNzPVwiZmEtcmVndWxhciBmYS1idWlsZGluZ1wiPjwvaT4ge3sgb2ZlcnRhU2VsZWNjaW9uYWRhLnJhem9uU29jaWFsIHx8IG9mZXJ0YVNlbGVjY2lvbmFkYS5ub21icmVfZW1wcmVzYSB8fCAnRW1wcmVzYSBJVEInIH19PC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiYmFkZ2UtbW9kYWxpZGFkXCI+e3sgb2ZlcnRhU2VsZWNjaW9uYWRhLm1vZGFsaWRhZCB9fTwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8aHIgLz5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJkZXRhbGxlLWJvZHlcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwibWV0YS1pdGVtXCI+XHJcbiAgICAgICAgICAgICAgICA8c3Ryb25nPk5pdmVsIGRlIGV4cGVyaWVuY2lhOjwvc3Ryb25nPiB7eyBvZmVydGFTZWxlY2Npb25hZGEuZXhwZXJpZW5jaWEgfX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm1ldGEtaXRlbVwiPlxyXG4gICAgICAgICAgICAgIDxzdHJvbmc+UHVibGljYWRvIGVsOjwvc3Ryb25nPiB7eyBvZmVydGFTZWxlY2Npb25hZGEuZmVjaGFfcHVibGljYWNpb24gfCBkYXRlOidkZC9NTS95eXl5JyB9fVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8IS0tIOKMmyBGZWNoYSBkZSBWZW5jaW1pZW50byBjYWxjdWxhZGEgLS0+XHJcbiAgICAgICAgICAgICAgQGlmIChvYnRlbmVyRmVjaGFWZW5jaW1pZW50byhvZmVydGFTZWxlY2Npb25hZGEpKSB7XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm1ldGEtaXRlbVwiPlxyXG4gICAgICAgICAgICAgIDxzdHJvbmc+VmVuY2UgZWw6PC9zdHJvbmc+IHt7IG9idGVuZXJGZWNoYVZlbmNpbWllbnRvKG9mZXJ0YVNlbGVjY2lvbmFkYSkgfCBkYXRlOidkZC9NTS95eXl5JyB9fSAoe3sgb2ZlcnRhU2VsZWNjaW9uYWRhLmRpYXNfZHVyYWNpb24gfX0gZMOtYXMpXHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIDxoND5EZXNjcmlwY2nDs24gZGVsIFB1ZXN0bzwvaDQ+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3M9XCJkZXNjcmlwY2lvbi10ZXh0b1wiPnt7IG9mZXJ0YVNlbGVjY2lvbmFkYS5kZXNjcmlwY2lvbiB9fTwvcD5cclxuXHJcbiAgICAgICAgICAgICAgQGlmIChvZmVydGFTZWxlY2Npb25hZGEuc2tpbGxzX25vbWJyZXMgJiYgb2ZlcnRhU2VsZWNjaW9uYWRhLnNraWxsc19ub21icmVzLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgICAgIDxoND5IYWJpbGlkYWRlcyBSZXF1ZXJpZGFzPC9oND5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjaGlwcy1jb250YWluZXJcIj5cclxuICAgICAgICAgICAgICAgICAgQGZvciAoc2tpbGwgb2Ygb2ZlcnRhU2VsZWNjaW9uYWRhLnNraWxsc19ub21icmVzOyB0cmFjayBza2lsbCkge1xyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiY2hpcC1za2lsbC12aWV3XCI+e3sgc2tpbGwgfX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8IS0tIEJMT1FVRSBERSBBQ0NJT05FUyBTRUfDmk4gRUwgUk9MIC0tPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZGV0YWxsZS1mb290ZXJcIj5cclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICA8IS0tIFJvbCBQT1NUVUxBTlRFIE8gVklTSVRBTlRFIC0tPlxyXG4gICAgICAgICAgICAgIEBpZiAocm9sVXN1YXJpbyA9PT0gJ3Bvc3R1bGFudGUnIHx8IHJvbFVzdWFyaW8gPT09ICd2aXNpdGFudGUnIHx8ICFyb2xVc3VhcmlvKSB7XHJcbiAgICAgICAgICAgICAgICBAaWYgKCFlc09mZXJ0YUFiaWVydGEob2ZlcnRhU2VsZWNjaW9uYWRhKSkge1xyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzcz1cImJ0bi1kZXNoYWJpbGl0YWRvXCIgZGlzYWJsZWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPGkgY2xhc3M9XCJmYS1zb2xpZCBmYS1sb2NrXCI+PC9pPiBDb252b2NhdG9yaWEgQ2VycmFkYVxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIH0gQGVsc2UgaWYgKGVzdGFQb3N0dWxhZG8ob2ZlcnRhU2VsZWNjaW9uYWRhLmlkX29mZXJ0YSkpIHtcclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3M9XCJidG4tcG9zdHVsYWRvXCIgZGlzYWJsZWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPGkgY2xhc3M9XCJmYS1zb2xpZCBmYS1jaGVjay1kb3VibGVcIj48L2k+IFlhIHRlIGhhcyBwb3N0dWxhZG9cclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICB9IEBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3M9XCJidG4tcG9zdHVsYXJzZVwiIChjbGljayk9XCJndWFyZGFyUG9zdHVsYWNpb24ob2ZlcnRhU2VsZWNjaW9uYWRhLmlkX29mZXJ0YSlcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aSBjbGFzcz1cImZhLXNvbGlkIGZhLXBhcGVyLXBsYW5lXCI+PC9pPiBQb3N0dWxhcm1lIGFob3JhXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgPCEtLSBSb2wgRU1QUkVTQSAoUHJvcGlldGFyaWEgZGUgbGEgb2ZlcnRhKSAtLT5cclxuICAgICAgICAgICAgICBAaWYgKHJvbFVzdWFyaW8gPT09ICdlbXByZXNhJyAmJiBpZFVzdWFyaW8gPT09IChvZmVydGFTZWxlY2Npb25hZGEuaWRfZW1wcmVzYSB8fCBvZmVydGFTZWxlY2Npb25hZGEuZW1wcmVzYV9pZCk/LnRvU3RyaW5nKCkpIHtcclxuICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzPVwiYnRuLWNhbmRpZGF0b3NcIiAoY2xpY2spPVwidmVyUG9zdHVsYWRvcyhvZmVydGFTZWxlY2Npb25hZGEuaWRfb2ZlcnRhKVwiPlxyXG4gICAgICAgICAgICAgICAgICA8aSBjbGFzcz1cImZhLXNvbGlkIGZhLXVzZXJzXCI+PC9pPiBWZXIgQ2FuZGlkYXRvc1xyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3M9XCJidG4tZWRpdGFyXCIgKGNsaWNrKT1cInRvZ2dsZVZpc3RhKHRydWUsIG9mZXJ0YVNlbGVjY2lvbmFkYSlcIj5cclxuICAgICAgICAgICAgICAgICAgPGkgY2xhc3M9XCJmYS1zb2xpZCBmYS1wZW4tdG8tc3F1YXJlXCI+PC9pPiBFZGl0YXIgUHVibGljYWNpw7NuXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzcz1cImJ0bi1kdXJhY2lvblwiIChjbGljayk9XCJhbXBsaWFyRHVyYWNpb24ob2ZlcnRhU2VsZWNjaW9uYWRhLmlkX29mZXJ0YSlcIj5cclxuICAgICAgICAgICAgICAgICAgPGkgY2xhc3M9XCJmYS1zb2xpZCBmYS1ob3VyZ2xhc3MtaGFsZlwiPjwvaT4gQW1wbGlhciBEw61hc1xyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgICAgQGlmIChlc09mZXJ0YUFiaWVydGEob2ZlcnRhU2VsZWNjaW9uYWRhKSkge1xyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzcz1cImJ0bi1jZXJyYXItb2ZlcnRhXCIgKGNsaWNrKT1cImNhbWJpYXJFc3RhZG9PZmVydGEob2ZlcnRhU2VsZWNjaW9uYWRhLmlkX29mZXJ0YSwgJ0NlcnJhZGEnKVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzPVwiZmEtc29saWQgZmEtZm9sZGVyLWNsb3NlZFwiPjwvaT4gQ2VycmFyIENvbnZvY2F0b3JpYVxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIH0gQGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzcz1cImJ0bi1yZWFicmlyLW9mZXJ0YVwiIChjbGljayk9XCJjYW1iaWFyRXN0YWRvT2ZlcnRhKG9mZXJ0YVNlbGVjY2lvbmFkYS5pZF9vZmVydGEsICdBYmllcnRhJylcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aSBjbGFzcz1cImZhLXNvbGlkIGZhLWZvbGRlci1vcGVuXCI+PC9pPiBSZWFicmlyIENvbnZvY2F0b3JpYVxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgIDwhLS0gUm9sIEFETUlOIC0tPlxyXG4gICAgICAgICAgICAgIEBpZiAocm9sVXN1YXJpbyA9PT0gJ2FkbWluJykge1xyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3M9XCJidG4tY2FuZGlkYXRvc1wiIChjbGljayk9XCJ2ZXJQb3N0dWxhZG9zKG9mZXJ0YVNlbGVjY2lvbmFkYS5pZF9vZmVydGEpXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxpIGNsYXNzPVwiZmEtc29saWQgZmEtdXNlcnNcIj48L2k+IFZlciBDYW5kaWRhdG9zXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzcz1cImJ0bi1lbGltaW5hci1hZG1pblwiIChjbGljayk9XCJiYWphT2ZlcnRhQWRtaW4ob2ZlcnRhU2VsZWNjaW9uYWRhLmlkX29mZXJ0YSlcIj5cclxuICAgICAgICAgICAgICAgICAgPGkgY2xhc3M9XCJmYS1zb2xpZCBmYS10cmFzaC1jYW5cIj48L2k+IEVsaW1pbmFyIChNb2RlcmFjacOzbiBBZG1pbilcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgfSBAZWxzZSB7XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwic2luLXNlbGVjY2lvblwiPlxyXG4gICAgICAgICAgICA8cD5TZWxlY2Npb25hIHVuYSBvZmVydGEgZGUgbGEgbGlzdGEgcGFyYSB2ZXIgc3VzIGRldGFsbGVzLjwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIH1cclxuICAgICAgPC9tYWluPlxyXG5cclxuICAgIDwvZGl2PlxyXG4gIH1cclxuXHJcbjwvZGl2PiIsImltcG9ydCB7IEluamVjdGFibGUsIGluamVjdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBIdHRwQ2xpZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIFNraWxsIHtcclxuICBza2lsbF9pZDogbnVtYmVyO1xyXG4gIG5vbWJyZTogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIENhdGVnb3JpYVNraWxsIHtcclxuICBjYXRlZ29yaWFfaWQ6IG51bWJlcjtcclxuICBub21icmU6IHN0cmluZztcclxuICBza2lsbHM6IFNraWxsW107XHJcbn1cclxuXHJcbmV4cG9ydCB0eXBlIE1vZGFsaWRhZE9mZXJ0YSA9ICdQcmVzZW5jaWFsJyB8ICdSZW1vdG8nIHwgJ0jDrWJyaWRvJztcclxuZXhwb3J0IHR5cGUgTml2ZWxFeHBlcmllbmNpYSA9ICdUcmFpbmVlJyB8ICdKdW5pb3InIHwgJ1NlbWktU2VuaW9yJyB8ICdTZW5pb3InO1xyXG5cclxuZXhwb3J0IGludGVyZmFjZSBPZmVydGEge1xyXG4gIGlkX29mZXJ0YT86IG51bWJlcjtcclxuICBpZF9lbXByZXNhPzogbnVtYmVyO1xyXG4gIHJhem9uU29jaWFsPzogc3RyaW5nO1xyXG4gIHRpdHVsbzogc3RyaW5nO1xyXG4gIGRlc2NyaXBjaW9uOiBzdHJpbmc7XHJcbiAgbW9kYWxpZGFkOiBNb2RhbGlkYWRPZmVydGE7XHJcbiAgZXhwZXJpZW5jaWE6IE5pdmVsRXhwZXJpZW5jaWE7IFxyXG4gIGRpYXNfZHVyYWNpb246IG51bWJlcjtcclxuICBmZWNoYV9wdWJsaWNhY2lvbj86IHN0cmluZztcclxuICBmZWNoYV92ZW5jaW1pZW50bz86IHN0cmluZztcclxuICBza2lsbHM/OiBudW1iZXJbXTtcclxuICBza2lsbD86IG51bWJlcltdO1xyXG4gIHNraWxsc19ub21icmVzPzogc3RyaW5nW107XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgUmVzcHVlc3RhQ3JlYXJPZmVydGEge1xyXG4gIE9LOiBib29sZWFuO1xyXG4gIG1lc3NhZ2U6IHN0cmluZztcclxuICBpZF9vZmVydGE/OiBudW1iZXI7XHJcbn1cclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuZXhwb3J0IGNsYXNzIE9mZXJ0YVNlcnZpY2Uge1xyXG4gIHByaXZhdGUgaHR0cCA9IGluamVjdChIdHRwQ2xpZW50KTtcclxuICBwcml2YXRlIGFwaVVybCA9ICdodHRwOi8vbG9jYWxob3N0OjMwMDAvYXBpL29mZXJ0YXMnO1xyXG5cclxuICAvKiogT2J0ZW5lciBlbCBsaXN0YWRvIGRlIGNhdGVnb3LDrWFzIGNvbiBzdXMgcmVzcGVjdGl2YXMgaGFiaWxpZGFkZXMgKi9cclxuICBnZXRDYXRlZ29yaWFzQ29uU2tpbGxzKCk6IE9ic2VydmFibGU8Q2F0ZWdvcmlhU2tpbGxbXT4ge1xyXG4gICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQ8Q2F0ZWdvcmlhU2tpbGxbXT4oYCR7dGhpcy5hcGlVcmx9L2NhdGVnb3JpYXMtc2tpbGxzYCk7XHJcbiAgfVxyXG5cclxuICAvKiogT2J0ZW5lciB0b2RhcyBsYXMgb2ZlcnRhcyBsYWJvcmFsZXMgdmlnZW50ZXMgKHBhcmEgcG9zdHVsYW50ZXMpICovXHJcbiAgZ2V0T2ZlcnRhc1ZpZ2VudGVzKCk6IE9ic2VydmFibGU8T2ZlcnRhW10+IHtcclxuICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PE9mZXJ0YVtdPihgJHt0aGlzLmFwaVVybH0vdmlnZW50ZXNgKTtcclxuICB9XHJcblxyXG4gIC8qKiBPYnRlbmVyIG9mZXJ0YXMgY3JlYWRhcyBwb3IgdW5hIGVtcHJlc2EgZXNwZWPDrWZpY2EgKi9cclxuICBnZXRPZmVydGFzUG9yRW1wcmVzYShlbXByZXNhSWQ6IG51bWJlcik6IE9ic2VydmFibGU8T2ZlcnRhW10+IHtcclxuICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PE9mZXJ0YVtdPihgJHt0aGlzLmFwaVVybH0vZW1wcmVzYS8ke2VtcHJlc2FJZH1gKTtcclxuICB9XHJcblxyXG4gIC8qKiBQdWJsaWNhciB1bmEgbnVldmEgb2ZlcnRhIGxhYm9yYWwgKEVtcHJlc2EgLyBBZG1pbikgKi9cclxuICBwdWJsaWNhck9mZXJ0YShvZmVydGE6IFBhcnRpYWw8T2ZlcnRhPik6IE9ic2VydmFibGU8UmVzcHVlc3RhQ3JlYXJPZmVydGE+IHtcclxuICAgIHJldHVybiB0aGlzLmh0dHAucG9zdDxSZXNwdWVzdGFDcmVhck9mZXJ0YT4oYCR7dGhpcy5hcGlVcmx9L2NyZWFyYCwgb2ZlcnRhKTtcclxuICB9XHJcblxyXG4gIC8qKiBBY3R1YWxpemFyIGxvcyBkYXRvcyBkZSB1bmEgb2ZlcnRhIGV4aXN0ZW50ZSAqL1xyXG4gIGFjdHVhbGl6YXJPZmVydGEoaWRPZmVydGE6IG51bWJlciwgb2ZlcnRhOiBQYXJ0aWFsPE9mZXJ0YT4pOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgcmV0dXJuIHRoaXMuaHR0cC5wdXQ8YW55PihgJHt0aGlzLmFwaVVybH0vJHtpZE9mZXJ0YX1gLCBvZmVydGEpO1xyXG4gIH1cclxuXHJcbiAgLyoqIENhbWJpYXIgZWwgZXN0YWRvIChBYmllcnRhIC8gQ2VycmFkYSkgKi9cclxuICBjYW1iaWFyRXN0YWRvKGlkT2ZlcnRhOiBudW1iZXIsIGVzdGFkbzogJ0FiaWVydGEnIHwgJ0NlcnJhZGEnKTogT2JzZXJ2YWJsZTxhbnk+IHtcclxuICAgIHJldHVybiB0aGlzLmh0dHAucGF0Y2g8YW55PihgJHt0aGlzLmFwaVVybH0vJHtpZE9mZXJ0YX0vZXN0YWRvYCwgeyBlc3RhZG8gfSk7XHJcbiAgfVxyXG5cclxuICAvKiogQW1wbGlhciBlbCBwbGF6byBkZSB2aWdlbmNpYSBlbiBkw61hcyAqL1xyXG4gIGFtcGxpYXJQbGF6byhpZE9mZXJ0YTogbnVtYmVyLCBkaWFzOiBudW1iZXIpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgcmV0dXJuIHRoaXMuaHR0cC5wYXRjaDxhbnk+KGAke3RoaXMuYXBpVXJsfS8ke2lkT2ZlcnRhfS9hbXBsaWFyYCwgeyBkaWFzIH0pO1xyXG4gIH1cclxuXHJcbiAgLyoqIEVsaW1pbmFyIHVuYSBvZmVydGEgZGUgbGEgYmFzZSBkZSBkYXRvcyAqL1xyXG4gIGVsaW1pbmFyT2ZlcnRhKGlkT2ZlcnRhOiBudW1iZXIpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgcmV0dXJuIHRoaXMuaHR0cC5kZWxldGU8YW55PihgJHt0aGlzLmFwaVVybH0vJHtpZE9mZXJ0YX1gKTtcclxuICB9XHJcbn0iLCJpbXBvcnQgeyBJbmplY3RhYmxlLCBpbmplY3QgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgSHR0cENsaWVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xyXG5cclxuZXhwb3J0IHR5cGUgRXN0YWRvUG9zdHVsYWNpb24gPSAnUGVuZGllbnRlJyB8ICdFbiBSZXZpc2lvbicgfCAnQWNlcHRhZG8nIHwgJ1JlY2hhemFkbyc7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIFBvc3R1bGFjaW9uIHtcclxuICBpZF9wb3N0dWxhY2lvbj86IG51bWJlcjsgXHJcbiAgaWRQb3N0dWxhY2lvbj86IG51bWJlcjsgLy8gUGVybWl0ZSBhbWJvcyBmb3JtYXRvcyAoc25ha2VfY2FzZSB5IGNhbWVsQ2FzZSlcclxuICBpZF9wb3N0dWxhbnRlOiBudW1iZXI7XHJcbiAgaWRfb2ZlcnRhOiBudW1iZXI7XHJcbiAgZmVjaGFfcG9zdHVsYWNpb24/OiBzdHJpbmc7XHJcbiAgZXN0YWRvPzogRXN0YWRvUG9zdHVsYWNpb247XHJcblxyXG4gIC8vIENhbXBvcyBtYXBlYWRvcyBkZXNkZSBKT0lOcyAoTXlTUUwpXHJcbiAgdGl0dWxvX29mZXJ0YT86IHN0cmluZztcclxuICByYXpvbl9zb2NpYWw/OiBzdHJpbmc7XHJcbiAgbm9tYnJlX3Bvc3R1bGFudGU/OiBzdHJpbmc7XHJcbiAgYXBlbGxpZG9fcG9zdHVsYW50ZT86IHN0cmluZztcclxuICBlbWFpbF9wb3N0dWxhbnRlPzogc3RyaW5nO1xyXG4gIGNhcnJlcmFfcG9zdHVsYW50ZT86IHN0cmluZztcclxuICBjdXJyaWN1bHVtX3VybD86IHN0cmluZztcclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBSZXNwdWVzdGFBcGkge1xyXG4gIE9LPzogYm9vbGVhbjtcclxuICBtZW5zYWplPzogc3RyaW5nO1xyXG4gIG1lc3NhZ2U/OiBzdHJpbmc7XHJcbiAgaWRfcG9zdHVsYWNpb24/OiBudW1iZXI7XHJcbiAgZXJyb3I/OiBzdHJpbmc7XHJcbn1cclxuXHJcbkBJbmplY3RhYmxlKHtcclxuICBwcm92aWRlZEluOiAncm9vdCdcclxufSlcclxuZXhwb3J0IGNsYXNzIFBvc3R1bGFjaW9uZXNTZXJ2aWNlIHtcclxuICBwcml2YXRlIGh0dHAgPSBpbmplY3QoSHR0cENsaWVudCk7XHJcbiAgcHJpdmF0ZSBhcGlVcmwgPSAnaHR0cDovL2xvY2FsaG9zdDozMDAwL2FwaS9wb3N0dWxhY2lvbmVzJztcclxuXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgLy8gMS4gQUNDSU9ORVMgREVMIFBPU1RVTEFOVEUgKEVzdHVkaWFudGUpXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgXHJcbiAgLyoqIFBvc3R1bGFyc2UgYSB1bmEgb2ZlcnRhICovXHJcbiAgY3JlYXJQb3N0dWxhY2lvbihpZF9vZmVydGE6IG51bWJlciwgaWRfcG9zdHVsYW50ZT86IG51bWJlcik6IE9ic2VydmFibGU8UmVzcHVlc3RhQXBpPiB7XHJcbiAgICBjb25zdCBib2R5ID0gaWRfcG9zdHVsYW50ZSA/IHsgaWRfb2ZlcnRhLCBpZF9wb3N0dWxhbnRlIH0gOiB7IGlkX29mZXJ0YSB9O1xyXG4gICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0PFJlc3B1ZXN0YUFwaT4odGhpcy5hcGlVcmwsIGJvZHkpO1xyXG4gIH1cclxuXHJcbiAgLyoqIE9idGVuZXIgcG9zdHVsYWNpb25lcyBkZWwgZXN0dWRpYW50ZSBsb2d1ZWFkbyAqL1xyXG4gIGdldEJ5UG9zdHVsYW50ZShpZFBvc3R1bGFudGU6IG51bWJlcik6IE9ic2VydmFibGU8UG9zdHVsYWNpb25bXT4ge1xyXG4gICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQ8UG9zdHVsYWNpb25bXT4oYCR7dGhpcy5hcGlVcmx9L3Bvc3R1bGFudGUvJHtpZFBvc3R1bGFudGV9YCk7XHJcbiAgfVxyXG5cclxuICAvKiogQ2FuY2VsYXIgcG9zdHVsYWNpw7NuIGFjdGl2YSAqL1xyXG4gIGNhbmNlbGFyUG9zdHVsYWNpb24oaWRQb3N0dWxhY2lvbjogbnVtYmVyKTogT2JzZXJ2YWJsZTxSZXNwdWVzdGFBcGk+IHtcclxuICAgIHJldHVybiB0aGlzLmh0dHAuZGVsZXRlPFJlc3B1ZXN0YUFwaT4oYCR7dGhpcy5hcGlVcmx9LyR7aWRQb3N0dWxhY2lvbn1gKTtcclxuICB9XHJcblxyXG4gIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gIC8vIDIuIEFDQ0lPTkVTIERFIExBIEVNUFJFU0FcclxuICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICBcclxuICAvKiogQ2FuZGlkYXRvcyBkZSB0b2RhcyBsYXMgYsO6c3F1ZWRhcyBkZSBsYSBlbXByZXNhICovXHJcbiAgZ2V0QnlFbXByZXNhKGlkRW1wcmVzYTogbnVtYmVyKTogT2JzZXJ2YWJsZTxQb3N0dWxhY2lvbltdPiB7XHJcbiAgICByZXR1cm4gdGhpcy5odHRwLmdldDxQb3N0dWxhY2lvbltdPihgJHt0aGlzLmFwaVVybH0vZW1wcmVzYS8ke2lkRW1wcmVzYX1gKTtcclxuICB9XHJcblxyXG4gIC8qKiBDYW5kaWRhdG9zIGRlIHVuYSBvZmVydGEgZW4gcGFydGljdWxhciAqL1xyXG4gIGdldEJ5T2ZlcnRhKGlkT2ZlcnRhOiBudW1iZXIpOiBPYnNlcnZhYmxlPFBvc3R1bGFjaW9uW10+IHtcclxuICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PFBvc3R1bGFjaW9uW10+KGAke3RoaXMuYXBpVXJsfS9vZmVydGEvJHtpZE9mZXJ0YX1gKTtcclxuICB9XHJcblxyXG4gIC8qKiBBY3R1YWxpemFyIGVzdGFkbyAoJ1BlbmRpZW50ZScgfCAnRW4gUmV2aXNpb24nIHwgJ0FjZXB0YWRvJyB8ICdSZWNoYXphZG8nKSAqL1xyXG4gIGFjdHVhbGl6YXJFc3RhZG8oaWRQb3N0dWxhY2lvbjogbnVtYmVyLCBlc3RhZG86IEVzdGFkb1Bvc3R1bGFjaW9uKTogT2JzZXJ2YWJsZTxSZXNwdWVzdGFBcGk+IHtcclxuICAgIHJldHVybiB0aGlzLmh0dHAucHV0PFJlc3B1ZXN0YUFwaT4oYCR7dGhpcy5hcGlVcmx9LyR7aWRQb3N0dWxhY2lvbn0vZXN0YWRvYCwgeyBlc3RhZG8gfSk7XHJcbiAgfVxyXG5cclxuICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAvLyAzLiBBQ0NJT05FUyBERUwgQURNSU5JU1RSQURPUiAoQXVkaXRvcsOtYSBJVEIpXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgXHJcbiAgLyoqIE9idGVuZXIgdG9kYXMgbGFzIHBvc3R1bGFjaW9uZXMgZGVsIHNpc3RlbWEgKi9cclxuICBnZXRUb2RhcygpOiBPYnNlcnZhYmxlPFBvc3R1bGFjaW9uW10+IHtcclxuICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PFBvc3R1bGFjaW9uW10+KGAke3RoaXMuYXBpVXJsfS90b2Rhc2ApO1xyXG4gIH1cclxuXHJcbiAgLyoqIEVsaW1pbmFyIHBvc3R1bGFjacOzbiBwb3IgbW9kZXJhY2nDs24gZGUgQWRtaW4gKi9cclxuICBlbGltaW5hclBvck1vZGVyYWNpb24oaWRQb3N0dWxhY2lvbjogbnVtYmVyKTogT2JzZXJ2YWJsZTxSZXNwdWVzdGFBcGk+IHtcclxuICAgIHJldHVybiB0aGlzLmh0dHAuZGVsZXRlPFJlc3B1ZXN0YUFwaT4oYCR7dGhpcy5hcGlVcmx9L2FkbWluLyR7aWRQb3N0dWxhY2lvbn1gKTtcclxuICB9XHJcbn0iLCJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCwgaW5qZWN0LCBDaGFuZ2VEZXRlY3RvclJlZiwgRGVzdHJveVJlZiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBDb21tb25Nb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xyXG5pbXBvcnQgeyBBY3RpdmF0ZWRSb3V0ZSwgUm91dGVyIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcclxuaW1wb3J0IHsgdGFrZVVudGlsRGVzdHJveWVkIH0gZnJvbSAnQGFuZ3VsYXIvY29yZS9yeGpzLWludGVyb3AnO1xyXG5pbXBvcnQgeyBFc3RhZG9Qb3N0dWxhY2lvbiwgUG9zdHVsYWNpb24sIFBvc3R1bGFjaW9uZXNTZXJ2aWNlIH0gZnJvbSAnLi4vLi4vc2VydmljZXMvcG9zdHVsYWNpb25lcy5zZXJ2aWNlJztcclxuaW1wb3J0IHsgQXV0aFNlcnZpY2UgfSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9hdXRoLnNlcnZpY2UnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdhcHAtcG9zdHVsYWNpb25lcycsXHJcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcclxuICBpbXBvcnRzOiBbQ29tbW9uTW9kdWxlXSxcclxuICB0ZW1wbGF0ZVVybDogJy4vcG9zdHVsYWNpb25lcy5odG1sJyxcclxuICBzdHlsZVVybDogJy4vcG9zdHVsYWNpb25lcy5zY3NzJ1xyXG59KVxyXG5leHBvcnQgY2xhc3MgUG9zdHVsYWNpb25lc0NvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgLy8gLS0tIElueWVjY2nDs24gZGUgU2VydmljaW9zIC0tLVxyXG4gIHByaXZhdGUgcG9zdHVsYWNpb25lc1NlcnZpY2UgPSBpbmplY3QoUG9zdHVsYWNpb25lc1NlcnZpY2UpO1xyXG4gIHByaXZhdGUgYXV0aFNlcnZpY2UgPSBpbmplY3QoQXV0aFNlcnZpY2UpO1xyXG4gIHByaXZhdGUgY2RyID0gaW5qZWN0KENoYW5nZURldGVjdG9yUmVmKTtcclxuICBwcml2YXRlIGRlc3Ryb3lSZWYgPSBpbmplY3QoRGVzdHJveVJlZik7XHJcbiAgcHJpdmF0ZSByb3V0ZSA9IGluamVjdChBY3RpdmF0ZWRSb3V0ZSk7XHJcbiAgcHJpdmF0ZSByb3V0ZXIgPSBpbmplY3QoUm91dGVyKTtcclxuXHJcbiAgLy8gLS0tIEVzdGFkbyBkZWwgQ29tcG9uZW50ZSAtLS1cclxuICBwb3N0dWxhY2lvbmVzOiBQb3N0dWxhY2lvbltdID0gW107XHJcbiAgcm9sVXN1YXJpbzogc3RyaW5nID0gJyc7IFxyXG4gIGNhcmdhbmRvOiBib29sZWFuID0gdHJ1ZTtcclxuICBpZE9mZXJ0YUZpbHRybzogbnVtYmVyIHwgbnVsbCA9IG51bGw7XHJcblxyXG4gIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgY29uc3QgdXN1YXJpbyA9IHRoaXMuYXV0aFNlcnZpY2UuZ2V0VXN1YXJpb0FjdHVhbCgpOyBcclxuICAgIHRoaXMucm9sVXN1YXJpbyA9ICh1c3VhcmlvPy5yb2wgfHwgdGhpcy5hdXRoU2VydmljZS5nZXRUaXBvVXN1YXJpbygpIHx8ICdwb3N0dWxhbnRlJykudG9Mb3dlckNhc2UoKTtcclxuXHJcbiAgICAvLyBFc2N1Y2hhIGRlIHBhcsOhbWV0cm9zIGVuIFVSTCBjb24gbGltcGllemEgYXV0b23DoXRpY2EgZGUgbWVtb3JpYVxyXG4gICAgdGhpcy5yb3V0ZS5xdWVyeVBhcmFtc1xyXG4gICAgICAucGlwZSh0YWtlVW50aWxEZXN0cm95ZWQodGhpcy5kZXN0cm95UmVmKSlcclxuICAgICAgLnN1YnNjcmliZShwYXJhbXMgPT4ge1xyXG4gICAgICAgIHRoaXMuaWRPZmVydGFGaWx0cm8gPSBwYXJhbXNbJ29mZXJ0YSddID8gTnVtYmVyKHBhcmFtc1snb2ZlcnRhJ10pIDogbnVsbDtcclxuICAgICAgICB0aGlzLmNhcmdhclBvc3R1bGFjaW9uZXModXN1YXJpbyk7XHJcbiAgICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgLy8gLS0tIENhcmdhIGRlIERhdG9zIHNlZ8O6biBSb2wgLS0tXHJcbiAgY2FyZ2FyUG9zdHVsYWNpb25lcyh1c3VhcmlvOiBhbnkpOiB2b2lkIHtcclxuICAgIGlmICghdXN1YXJpbykge1xyXG4gICAgICB0aGlzLmNhcmdhbmRvID0gZmFsc2U7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICB0aGlzLmNhcmdhbmRvID0gdHJ1ZTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVTdWNjZXNzID0gKGRhdGE6IFBvc3R1bGFjaW9uW10pID0+IHRoaXMuc2V0RGF0b3MoZGF0YSk7XHJcbiAgICBjb25zdCBoYW5kbGVFcnJvciA9IChlcnI6IHVua25vd24pID0+IHtcclxuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgYWwgY2FyZ2FyIHBvc3R1bGFjaW9uZXM6JywgZXJyKTtcclxuICAgICAgdGhpcy5jYXJnYW5kbyA9IGZhbHNlO1xyXG4gICAgICB0aGlzLmNkci5kZXRlY3RDaGFuZ2VzKCk7XHJcbiAgICB9O1xyXG5cclxuICAgIHN3aXRjaCAodGhpcy5yb2xVc3VhcmlvKSB7XHJcbiAgICAgIGNhc2UgJ3Bvc3R1bGFudGUnOiB7XHJcbiAgICAgICAgY29uc3QgaWRQb3N0dWxhbnRlID0gdXN1YXJpby5pZF9wb3N0dWxhbnRlIHx8IHVzdWFyaW8uaWQ7XHJcbiAgICAgICAgdGhpcy5wb3N0dWxhY2lvbmVzU2VydmljZS5nZXRCeVBvc3R1bGFudGUoaWRQb3N0dWxhbnRlKS5zdWJzY3JpYmUoe1xyXG4gICAgICAgICAgbmV4dDogaGFuZGxlU3VjY2VzcyxcclxuICAgICAgICAgIGVycm9yOiBoYW5kbGVFcnJvclxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICB9XHJcbiAgICAgIGNhc2UgJ2VtcHJlc2EnOiB7XHJcbiAgICAgICAgaWYgKHRoaXMuaWRPZmVydGFGaWx0cm8pIHtcclxuICAgICAgICAgIHRoaXMucG9zdHVsYWNpb25lc1NlcnZpY2UuZ2V0QnlPZmVydGEodGhpcy5pZE9mZXJ0YUZpbHRybykuc3Vic2NyaWJlKHtcclxuICAgICAgICAgICAgbmV4dDogaGFuZGxlU3VjY2VzcyxcclxuICAgICAgICAgICAgZXJyb3I6IGhhbmRsZUVycm9yXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgY29uc3QgaWRFbXByZXNhID0gdXN1YXJpby5pZF9lbXByZXNhIHx8IHVzdWFyaW8uaWQ7XHJcbiAgICAgICAgICB0aGlzLnBvc3R1bGFjaW9uZXNTZXJ2aWNlLmdldEJ5RW1wcmVzYShpZEVtcHJlc2EpLnN1YnNjcmliZSh7XHJcbiAgICAgICAgICAgIG5leHQ6IGhhbmRsZVN1Y2Nlc3MsXHJcbiAgICAgICAgICAgIGVycm9yOiBoYW5kbGVFcnJvclxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICB9XHJcbiAgICAgIGNhc2UgJ2FkbWluJzoge1xyXG4gICAgICAgIHRoaXMucG9zdHVsYWNpb25lc1NlcnZpY2UuZ2V0VG9kYXMoKS5zdWJzY3JpYmUoe1xyXG4gICAgICAgICAgbmV4dDogaGFuZGxlU3VjY2VzcyxcclxuICAgICAgICAgIGVycm9yOiBoYW5kbGVFcnJvclxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICB9XHJcbiAgICAgIGRlZmF1bHQ6IHtcclxuICAgICAgICB0aGlzLmNhcmdhbmRvID0gZmFsc2U7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8vIC0tLSBBY2Npb25lcyAtLS1cclxuICBhY3R1YWxpemFyRXN0YWRvKGlkX3Bvc3R1bGFjaW9uOiBudW1iZXIgfCB1bmRlZmluZWQsIGV2ZW50OiBFdmVudCk6IHZvaWQge1xyXG4gICAgaWYgKCFpZF9wb3N0dWxhY2lvbikgcmV0dXJuO1xyXG4gICAgICBcclxuICAgIGNvbnN0IHNlbGVjdEVsZW1lbnQgPSBldmVudC50YXJnZXQgYXMgSFRNTFNlbGVjdEVsZW1lbnQ7XHJcbiAgICBjb25zdCBudWV2b0VzdGFkbyA9IHNlbGVjdEVsZW1lbnQudmFsdWUgYXMgRXN0YWRvUG9zdHVsYWNpb247XHJcblxyXG4gICAgdGhpcy5wb3N0dWxhY2lvbmVzU2VydmljZS5hY3R1YWxpemFyRXN0YWRvKGlkX3Bvc3R1bGFjaW9uLCBudWV2b0VzdGFkbykuc3Vic2NyaWJlKHtcclxuICAgICAgbmV4dDogKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGl0ZW0gPSB0aGlzLnBvc3R1bGFjaW9uZXMuZmluZChwID0+IHRoaXMub2J0ZW5lcklkKHApID09PSBpZF9wb3N0dWxhY2lvbik7XHJcbiAgICAgICAgaWYgKGl0ZW0pIHtcclxuICAgICAgICAgIGl0ZW0uZXN0YWRvID0gbnVldm9Fc3RhZG87XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuY2RyLmRldGVjdENoYW5nZXMoKTtcclxuICAgICAgfSxcclxuICAgICAgZXJyb3I6IChlcnIpID0+IGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGFsIGFjdHVhbGl6YXIgZWwgZXN0YWRvOicsIGVycilcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgY2FuY2VsYXJQb3N0dWxhY2lvbihpZF9wb3N0dWxhY2lvbjogbnVtYmVyIHwgdW5kZWZpbmVkKTogdm9pZCB7XHJcbiAgICBpZiAoIWlkX3Bvc3R1bGFjaW9uKSByZXR1cm47XHJcbiAgICBpZiAoIWNvbmZpcm0oJ8K/RXN0w6FzIHNlZ3VybyBkZSBxdWUgZGVzZWFzIHJldGlyYXIgdHUgcG9zdHVsYWNpw7NuIGEgZXN0YSBvZmVydGE/JykpIHJldHVybjtcclxuXHJcbiAgICB0aGlzLnBvc3R1bGFjaW9uZXNTZXJ2aWNlLmNhbmNlbGFyUG9zdHVsYWNpb24oaWRfcG9zdHVsYWNpb24pLnN1YnNjcmliZSh7XHJcbiAgICAgIG5leHQ6ICgpID0+IHtcclxuICAgICAgICB0aGlzLnBvc3R1bGFjaW9uZXMgPSB0aGlzLnBvc3R1bGFjaW9uZXMuZmlsdGVyKHAgPT4gdGhpcy5vYnRlbmVySWQocCkgIT09IGlkX3Bvc3R1bGFjaW9uKTtcclxuICAgICAgICB0aGlzLmNkci5kZXRlY3RDaGFuZ2VzKCk7XHJcbiAgICAgIH0sXHJcbiAgICAgIGVycm9yOiAoZXJyKSA9PiBjb25zb2xlLmVycm9yKCdFcnJvciBhbCBjYW5jZWxhciBwb3N0dWxhY2nDs246JywgZXJyKVxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBlbGltaW5hclBvck1vZGVyYWNpb24oaWRfcG9zdHVsYWNpb246IG51bWJlciB8IHVuZGVmaW5lZCk6IHZvaWQge1xyXG4gICAgaWYgKCFpZF9wb3N0dWxhY2lvbikgcmV0dXJuO1xyXG4gICAgaWYgKCFjb25maXJtKCfCv0VsaW1pbmFyIGVzdGEgcG9zdHVsYWNpw7NuIGRlbCByZWdpc3RybyBkZWwgc2lzdGVtYT8nKSkgcmV0dXJuO1xyXG5cclxuICAgIHRoaXMucG9zdHVsYWNpb25lc1NlcnZpY2UuZWxpbWluYXJQb3JNb2RlcmFjaW9uKGlkX3Bvc3R1bGFjaW9uKS5zdWJzY3JpYmUoe1xyXG4gICAgICBuZXh0OiAoKSA9PiB7XHJcbiAgICAgICAgdGhpcy5wb3N0dWxhY2lvbmVzID0gdGhpcy5wb3N0dWxhY2lvbmVzLmZpbHRlcihwID0+IHRoaXMub2J0ZW5lcklkKHApICE9PSBpZF9wb3N0dWxhY2lvbik7XHJcbiAgICAgICAgdGhpcy5jZHIuZGV0ZWN0Q2hhbmdlcygpO1xyXG4gICAgICB9LFxyXG4gICAgICBlcnJvcjogKGVycikgPT4gY29uc29sZS5lcnJvcignRXJyb3IgYWwgZWxpbWluYXIgcG9zdHVsYWNpw7NuOicsIGVycilcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgdmVyUGVyZmlsUG9zdHVsYW50ZShpZFBvc3R1bGFudGU/OiBudW1iZXIpOiB2b2lkIHtcclxuICAgIGlmIChpZFBvc3R1bGFudGUpIHtcclxuICAgICAgdGhpcy5yb3V0ZXIubmF2aWdhdGUoWycvcG9zdHVsYW50ZScsIGlkUG9zdHVsYW50ZV0pO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLy8gLS0tIE3DqXRvZG9zIEF1eGlsaWFyZXMgLS0tXHJcbiAgXHJcbiAgLyoqXHJcbiAgICogT2J0aWVuZSBlbCBJRCBzb3BvcnRhbmRvIHRhbnRvIHNuYWtlX2Nhc2UgY29tbyBjYW1lbENhc2UgZGUgbGEgQVBJXHJcbiAgICovXHJcbiAgb2J0ZW5lcklkKGl0ZW06IFBvc3R1bGFjaW9uKTogbnVtYmVyIHwgdW5kZWZpbmVkIHtcclxuICAgIHJldHVybiBpdGVtLmlkX3Bvc3R1bGFjaW9uID8/IChpdGVtIGFzIGFueSkuaWRQb3N0dWxhY2lvbjtcclxuICB9XHJcblxyXG4gIG9idGVuZXJDbGFzZUJhZGdlKGVzdGFkbz86IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgICBzd2l0Y2ggKGVzdGFkbykge1xyXG4gICAgICBjYXNlICdBY2VwdGFkbyc6IHJldHVybiAnYmFkZ2Utc3VjY2Vzcyc7XHJcbiAgICAgIGNhc2UgJ1JlY2hhemFkbyc6IHJldHVybiAnYmFkZ2UtZGFuZ2VyJztcclxuICAgICAgY2FzZSAnRW4gUmV2aXNpb24nOiByZXR1cm4gJ2JhZGdlLXdhcm5pbmcnO1xyXG4gICAgICBkZWZhdWx0OiByZXR1cm4gJ2JhZGdlLWluZm8nO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcHJpdmF0ZSBzZXREYXRvcyhkYXRhOiBQb3N0dWxhY2lvbltdKTogdm9pZCB7XHJcbiAgICB0aGlzLnBvc3R1bGFjaW9uZXMgPSAoZGF0YSB8fCBbXSkubWFwKGl0ZW0gPT4gKHtcclxuICAgICAgLi4uaXRlbSxcclxuICAgICAgZXN0YWRvOiBpdGVtLmVzdGFkbyB8fCAnUGVuZGllbnRlJ1xyXG4gICAgfSkpO1xyXG4gICAgdGhpcy5jYXJnYW5kbyA9IGZhbHNlO1xyXG4gICAgdGhpcy5jZHIuZGV0ZWN0Q2hhbmdlcygpO1xyXG4gIH1cclxufSIsIjxkaXYgY2xhc3M9XCJwb3N0dWxhY2lvbmVzLWNvbnRhaW5lclwiPlxyXG4gIDxoZWFkZXIgY2xhc3M9XCJoZWFkZXJcIj5cclxuICAgIDxkaXYgY2xhc3M9XCJoZWFkZXItaW5mb1wiPlxyXG4gICAgICA8aDI+XHJcbiAgICAgICAgQGlmIChyb2xVc3VhcmlvID09PSAncG9zdHVsYW50ZScpIHsgTWlzIFBvc3R1bGFjaW9uZXMgfVxyXG4gICAgICAgIEBlbHNlIGlmIChyb2xVc3VhcmlvID09PSAnZW1wcmVzYScpIHsgUG9zdHVsYWNpb25lcyBSZWNpYmlkYXMgfVxyXG4gICAgICAgIEBlbHNlIHsgR2VzdGnDs24gR2VuZXJhbCBkZSBQb3N0dWxhY2lvbmVzIH1cclxuICAgICAgPC9oMj5cclxuICAgICAgPHAgY2xhc3M9XCJzdWJ0aXRsZVwiPlxyXG4gICAgICAgIEBpZiAocm9sVXN1YXJpbyA9PT0gJ3Bvc3R1bGFudGUnKSB7IFNlZ3VpbWllbnRvIGVuIHRpZW1wbyByZWFsIGRlIHR1cyBwb3N0dWxhY2lvbmVzIGxhYm9yYWxlcy4gfVxyXG4gICAgICAgIEBlbHNlIGlmIChyb2xVc3VhcmlvID09PSAnZW1wcmVzYScpIHsgUmV2aXNhIHkgZ2VzdGlvbmEgbG9zIGNhbmRpZGF0b3MgcG9zdHVsYWRvcyBhIHR1cyBvZmVydGFzLiB9XHJcbiAgICAgICAgQGVsc2UgeyBMaXN0YWRvIGdlbmVyYWwgeSBjb250cm9sIGRlIHBvc3R1bGFjaW9uZXMgcmVnaXN0cmFkYXMgZW4gSVRCIENvbmVjdGEuIH1cclxuICAgICAgPC9wPlxyXG4gICAgPC9kaXY+XHJcblxyXG4gICAgQGlmIChpZE9mZXJ0YUZpbHRybykge1xyXG4gICAgICA8ZGl2IGNsYXNzPVwiZmlsdHJvLWFjdGl2by1iYWRnZVwiPlxyXG4gICAgICAgIPCfk4wgRmlsdHJhZG8gcG9yIE9mZXJ0YSAje3sgaWRPZmVydGFGaWx0cm8gfX1cclxuICAgICAgPC9kaXY+XHJcbiAgICB9XHJcbiAgPC9oZWFkZXI+XHJcblxyXG4gIDwhLS0gRXN0YWRvIGRlIENhcmdhIC0tPlxyXG4gIEBpZiAoY2FyZ2FuZG8pIHtcclxuICAgIDxkaXYgY2xhc3M9XCJzdGF0ZS1ib3ggbG9hZGluZ1wiPlxyXG4gICAgICA8ZGl2IGNsYXNzPVwic3Bpbm5lclwiPjwvZGl2PlxyXG4gICAgICA8cD5DYXJnYW5kbyBwb3N0dWxhY2lvbmVzLi4uPC9wPlxyXG4gICAgPC9kaXY+XHJcbiAgfSBcclxuXHJcbiAgPCEtLSBFc3RhZG8gVmFjw61vIC0tPlxyXG4gIEBlbHNlIGlmIChwb3N0dWxhY2lvbmVzLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgPGRpdiBjbGFzcz1cInN0YXRlLWJveCBlbXB0eVwiPlxyXG4gICAgICA8cD5ObyBzZSBlbmNvbnRyYXJvbiBwb3N0dWxhY2lvbmVzIHJlZ2lzdHJhZGFzLjwvcD5cclxuICAgIDwvZGl2PlxyXG4gIH0gXHJcblxyXG4gIDwhLS0gTGlzdGFkbyBUYWJ1bGFyIGRlIFBvc3R1bGFjaW9uZXMgLS0+XHJcbiAgQGVsc2Uge1xyXG4gICAgPGRpdiBjbGFzcz1cInRhYmxlLXJlc3BvbnNpdmVcIj5cclxuICAgICAgPHRhYmxlIGNsYXNzPVwidGFibGEtcG9zdHVsYWNpb25lc1wiPlxyXG4gICAgICAgIDx0aGVhZD5cclxuICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgPHRoPk9mZXJ0YTwvdGg+XHJcblxyXG4gICAgICAgICAgICBAaWYgKHJvbFVzdWFyaW8gIT09ICdlbXByZXNhJykge1xyXG4gICAgICAgICAgICAgIDx0aD5FbXByZXNhPC90aD5cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgQGlmIChyb2xVc3VhcmlvICE9PSAncG9zdHVsYW50ZScpIHtcclxuICAgICAgICAgICAgICA8dGg+Q2FuZGlkYXRvPC90aD5cclxuICAgICAgICAgICAgICA8dGg+Q29udGFjdG88L3RoPlxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICA8dGg+RmVjaGE8L3RoPlxyXG4gICAgICAgICAgICA8dGg+RXN0YWRvPC90aD5cclxuICAgICAgICAgICAgPHRoIGNsYXNzPVwidGV4dC1jZW50ZXJcIj5BY2Npb25lczwvdGg+XHJcbiAgICAgICAgICA8L3RyPlxyXG4gICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgPHRib2R5PlxyXG4gICAgICAgICAgQGZvciAoaXRlbSBvZiBwb3N0dWxhY2lvbmVzOyB0cmFjayBvYnRlbmVySWQoaXRlbSkpIHtcclxuICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgIDwhLS0gT2ZlcnRhIC0tPlxyXG4gICAgICAgICAgICAgIDx0ZCBjbGFzcz1cImNvbC1vZmVydGFcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwidGl0dWxvLW9mZXJ0YVwiPnt7IGl0ZW0udGl0dWxvX29mZXJ0YSB9fTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L3RkPlxyXG5cclxuICAgICAgICAgICAgICA8IS0tIEVtcHJlc2EgKHZpc2libGUgcGFyYSBwb3N0dWxhbnRlIHkgYWRtaW4pIC0tPlxyXG4gICAgICAgICAgICAgIEBpZiAocm9sVXN1YXJpbyAhPT0gJ2VtcHJlc2EnKSB7XHJcbiAgICAgICAgICAgICAgICA8dGQgY2xhc3M9XCJjb2wtZW1wcmVzYVwiPlxyXG4gICAgICAgICAgICAgICAgICB7eyBpdGVtLnJhem9uX3NvY2lhbCB8fCAnTi9BJyB9fVxyXG4gICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgIDwhLS0gQ2FuZGlkYXRvIHkgQ29udGFjdG8gKHZpc2libGUgcGFyYSBlbXByZXNhIHkgYWRtaW4pIC0tPlxyXG4gICAgICAgICAgICAgIEBpZiAocm9sVXN1YXJpbyAhPT0gJ3Bvc3R1bGFudGUnKSB7XHJcbiAgICAgICAgICAgICAgICA8dGQgY2xhc3M9XCJjb2wtY2FuZGlkYXRvXCI+XHJcbiAgICAgICAgICAgICAgICAgIHt7IGl0ZW0ubm9tYnJlX3Bvc3R1bGFudGUgfX0ge3sgaXRlbS5hcGVsbGlkb19wb3N0dWxhbnRlIH19XHJcbiAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgPHRkIGNsYXNzPVwiY29sLWNvbnRhY3RvXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxhIFtocmVmXT1cIidtYWlsdG86JyArIGl0ZW0uZW1haWxfcG9zdHVsYW50ZVwiIGNsYXNzPVwibGluay1lbWFpbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHt7IGl0ZW0uZW1haWxfcG9zdHVsYW50ZSB9fVxyXG4gICAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgPCEtLSBGZWNoYSAtLT5cclxuICAgICAgICAgICAgICA8dGQgY2xhc3M9XCJjb2wtZmVjaGFcIj5cclxuICAgICAgICAgICAgICAgIHt7IGl0ZW0uZmVjaGFfcG9zdHVsYWNpb24gfCBkYXRlOidkZC9NTS95eXl5JyB9fVxyXG4gICAgICAgICAgICAgIDwvdGQ+XHJcblxyXG4gICAgICAgICAgICAgIDwhLS0gRXN0YWRvIC0tPlxyXG4gICAgICAgICAgICAgIDx0ZCBjbGFzcz1cImNvbC1lc3RhZG9cIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiYmFkZ2VcIiBbbmdDbGFzc109XCIoaXRlbS5lc3RhZG8gfHwgJ3BlbmRpZW50ZScpLnRvTG93ZXJDYXNlKCkucmVwbGFjZUFsbCgnICcsICctJylcIj5cclxuICAgICAgICAgICAgICAgICAge3sgaXRlbS5lc3RhZG8gfX1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L3RkPlxyXG5cclxuICAgICAgICAgICAgICA8IS0tIEFjY2lvbmVzIC0tPlxyXG4gICAgICAgICAgICAgIDx0ZCBjbGFzcz1cImNvbC1hY2Npb25lc1wiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImFjdGlvbnMtd3JhcHBlclwiPlxyXG4gICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgPCEtLSBWZXIgcGVyZmlsIHkgQ2FtYmlhciBFc3RhZG8gKEVtcHJlc2EgLyBBZG1pbikgLS0+XHJcbiAgICAgICAgICAgICAgICAgIEBpZiAocm9sVXN1YXJpbyA9PT0gJ2VtcHJlc2EnIHx8IHJvbFVzdWFyaW8gPT09ICdhZG1pbicpIHtcclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiIFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJidG4tdmVyLXBlcmZpbFwiIFxyXG4gICAgICAgICAgICAgICAgICAgICAgKGNsaWNrKT1cInZlclBlcmZpbFBvc3R1bGFudGUoaXRlbS5pZF9wb3N0dWxhbnRlKVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlZlciBQZXJmaWwgZGVsIENhbmRpZGF0b1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAg8J+RpCBQZXJmaWxcclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInNlbGVjdC1lc3RhZG8td3JhcHBlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgW2lkXT1cIidlc3RhZG8tJyArIG9idGVuZXJJZChpdGVtKVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFt2YWx1ZV09XCJpdGVtPy5lc3RhZG8gfHwgJ1BlbmRpZW50ZSdcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAoY2hhbmdlKT1cImFjdHVhbGl6YXJFc3RhZG8ob2J0ZW5lcklkKGl0ZW0pLCAkZXZlbnQpXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJzZWxlY3QtZXN0YWRvXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJQZW5kaWVudGVcIj5QZW5kaWVudGU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkVuIFJldmlzaW9uXCI+RW4gUmV2aXNpw7NuPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJBY2VwdGFkb1wiPkFjZXB0YWRvPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJSZWNoYXphZG9cIj5SZWNoYXphZG88L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICA8IS0tIE1vZGVyYWNpw7NuIChBZG1pbikgLS0+XHJcbiAgICAgICAgICAgICAgICAgIEBpZiAocm9sVXN1YXJpbyA9PT0gJ2FkbWluJykge1xyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gXHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzcz1cImJ0bi1lbGltaW5hci1hZG1pblwiIFxyXG4gICAgICAgICAgICAgICAgICAgICAgKGNsaWNrKT1cImVsaW1pbmFyUG9yTW9kZXJhY2lvbihvYnRlbmVySWQoaXRlbSkpXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiRWxpbWluYXIgUG9zdHVsYWNpw7NuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICDwn5eR77iPXHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgIDwhLS0gQWNjaW9uZXMgcGFyYSBlbCBQb3N0dWxhbnRlIChBbnVsYXIgcG9zdHVsYWNpw7NuKSAtLT5cclxuICAgICAgICAgICAgICAgICAgQGlmIChyb2xVc3VhcmlvID09PSAncG9zdHVsYW50ZScpIHtcclxuICAgICAgICAgICAgICAgICAgICBAaWYgKChpdGVtLmVzdGFkbyB8fCAnJykudG9Mb3dlckNhc2UoKSA9PT0gJ3BlbmRpZW50ZScgfHwgKGl0ZW0uZXN0YWRvIHx8ICcnKS50b0xvd2VyQ2FzZSgpID09PSAnZW4gcmV2aXNpb24nKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzPVwiYnRuLWNhbmNlbGFyXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIChjbGljayk9XCJjYW5jZWxhclBvc3R1bGFjaW9uKG9idGVuZXJJZChpdGVtKSlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkFudWxhciBwb3N0dWxhY2nDs25cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAg8J+aqyBBbnVsYXJcclxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIH0gQGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJzaW4tYWNjaW9uZXNcIiB0aXRsZT1cIlBvc3R1bGFjacOzbiBlbiBlc3RhZG8gZmluYWxpemFkb1wiPuKAlDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIDwvdGJvZHk+XHJcbiAgICAgIDwvdGFibGU+XHJcbiAgICA8L2Rpdj5cclxuICB9XHJcbjwvZGl2PiIsImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0LCBpbmplY3QsIENoYW5nZURldGVjdG9yUmVmIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBDb21tb25Nb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHsgUm91dGVyIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcbmltcG9ydCB7IEF1dGhTZXJ2aWNlIH0gZnJvbSAnLi4vLi4vc2VydmljZXMvYXV0aC5zZXJ2aWNlJztcbmltcG9ydCB7IFNraWxscyB9IGZyb20gJy4vc2tpbGxzL3NraWxscyc7XG5pbXBvcnQge1Bvc3R1bGFudGVQcm9maWxlfSBmcm9tICcuLi9wZXJmaWxlcy9wb3N0dWxhbnRlLXByb2ZpbGUvcG9zdHVsYW50ZS1wcm9maWxlJztcbmltcG9ydCB7RW1wcmVzYVByb2ZpbGUgIH0gZnJvbSAnLi4vcGVyZmlsZXMvZW1wcmVzYS1wcm9maWxlL2VtcHJlc2EtcHJvZmlsZSc7XG5pbXBvcnQgeyBQb3N0dWxhY2lvbmVzQ29tcG9uZW50IH0gZnJvbSAnLi4vcG9zdHVsYWNpb25lcy9wb3N0dWxhY2lvbmVzJztcbmltcG9ydCB7IFxuICBBZG1pblNlcnZpY2UsIFxuICBFbXByZXNhQWRtaW4sIFxuICBPZmVydGFBZG1pbixcbiAgUG9zdHVsYW50ZUFkbWluLFxuICBNZXRyaWNhc0FkbWluLCBcbiAgUmVzcHVlc3RhQXBpIFxufSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9hZG1pbic7XG5cbmV4cG9ydCB0eXBlIFBlc3RhbmFBZG1pbiA9ICdlbXByZXNhcycgfCAnb2ZlcnRhcycgfCAncG9zdHVsYW50ZXMnIHwgJ3Bvc3R1bGFjaW9uZXMnIHwgJ3NraWxscyc7XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ2FwcC1wYW5lbC1hZG1pbicsXG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIGltcG9ydHM6IFtDb21tb25Nb2R1bGUsIFNraWxscywgUG9zdHVsYW50ZVByb2ZpbGUsIEVtcHJlc2FQcm9maWxlLCBQb3N0dWxhY2lvbmVzQ29tcG9uZW50XSxcbiAgdGVtcGxhdGVVcmw6ICcuL3BhbmVsLWFkbWluLmh0bWwnLFxuICBzdHlsZVVybDogJy4vcGFuZWwtYWRtaW4uc2Nzcydcbn0pXG5leHBvcnQgY2xhc3MgUGFuZWxBZG1pbiBpbXBsZW1lbnRzIE9uSW5pdCB7XG4gIHByaXZhdGUgYWRtaW5TZXJ2aWNlID0gaW5qZWN0KEFkbWluU2VydmljZSk7XG4gIHByaXZhdGUgY2RyID0gaW5qZWN0KENoYW5nZURldGVjdG9yUmVmKTtcbiAgcHJpdmF0ZSByb3V0ZXIgPSBpbmplY3QoUm91dGVyKTtcbiAgcHVibGljIGF1dGhTZXJ2aWNlID0gaW5qZWN0KEF1dGhTZXJ2aWNlKTtcblxuICAvLyBDb250cm9sIGRlIFZpc3Rhc1xuICBtb3N0cmFyU2tpbGxzOiBib29sZWFuID0gZmFsc2U7XG4gIHBlc3RhbmFBY3RpdmE6IFBlc3RhbmFBZG1pbiA9ICdlbXByZXNhcyc7XG5cbiAgLy8gQ29udHJvbCBkZSBDYXJnYXMgw5puaWNhcyAoRXZpdGEgcmUtcGV0aWNpb25lcyBhIGxhIEFQSSlcbiAgY2FyZ2Fkb0VtcHJlc2FzOiBib29sZWFuID0gZmFsc2U7XG4gIGNhcmdhZG9PZmVydGFzOiBib29sZWFuID0gZmFsc2U7XG4gIGNhcmdhZG9Qb3N0dWxhbnRlczogYm9vbGVhbiA9IGZhbHNlO1xuXG4gIC8vIEVzdGFkbyBHbG9iYWwgeSBNw6l0cmljYXNcbiAgY2FyZ2FuZG86IGJvb2xlYW4gPSBmYWxzZTtcbiAgbWV0cmljYXM6IE1ldHJpY2FzQWRtaW4gPSB7IFxuICAgIHRvdGFsT2ZlcnRhczogMCwgXG4gICAgdG90YWxFbXByZXNhczogMCxcbiAgICB0b3RhbFBvc3R1bGFudGVzOiAwLCBcbiAgICB0b3RhbFBvc3R1bGFjaW9uZXM6IDAgXG4gIH07XG4gIFxuICAvLyBBcnJlZ2xvcyBkZSBEYXRvc1xuICBlbXByZXNhczogRW1wcmVzYUFkbWluW10gPSBbXTtcbiAgb2ZlcnRhczogT2ZlcnRhQWRtaW5bXSA9IFtdO1xuICBwb3N0dWxhbnRlczogUG9zdHVsYW50ZUFkbWluW10gPSBbXTtcblxuICAvLyBNb2RhbGVzXG4gIGVtcHJlc2FTZWxlY2Npb25hZGE6IEVtcHJlc2FBZG1pbiB8IG51bGwgPSBudWxsO1xuICBtb3N0cmFyTW9kYWw6IGJvb2xlYW4gPSBmYWxzZTtcbi8vIPCfkYggTW9kYWwgUGVyZmlsIGRlIEVtcHJlc2EgKEVtcHJlc2FQcm9maWxlKVxuICBlbXByZXNhUGVyZmlsSWQ6IG51bWJlciB8IG51bGwgPSBudWxsO1xuXG4gIHBvc3R1bGFudGVTZWxlY2Npb25hZG86IFBvc3R1bGFudGVBZG1pbiB8IG51bGwgPSBudWxsO1xuICBtb3N0cmFyTW9kYWxQb3N0dWxhbnRlOiBib29sZWFuID0gZmFsc2U7XG4gIFxuICBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICB0aGlzLmNhcmdhckRhdG9zKCk7XG4gIH1cblxuICB0b2dnbGVTa2lsbHMoKTogdm9pZCB7XG4gICAgdGhpcy5tb3N0cmFyU2tpbGxzID0gIXRoaXMubW9zdHJhclNraWxscztcbiAgfVxuXG4gIC8vIENhbWJpYXIgZGUgcGVzdGHDsWFcbiAgY2FtYmlhclBlc3RhbmEobnVldmFQZXN0YW5hOiBQZXN0YW5hQWRtaW4pOiB2b2lkIHtcbiAgICB0aGlzLm1vc3RyYXJTa2lsbHMgPSBmYWxzZTtcbiAgICB0aGlzLnBlc3RhbmFBY3RpdmEgPSBudWV2YVBlc3RhbmE7XG4gICAgXG4gICAgLy8gQ2FyZ2EgcGVyZXpvc2EgKExhenkgbG9hZGluZyk6IHNvbG8gcGlkZSBsb3MgZGF0b3MgbGEgcHJpbWVyYSB2ZXogcXVlIHNlIGVudHJhIGEgbGEgcGVzdGHDsWFcbiAgICBpZiAobnVldmFQZXN0YW5hID09PSAnZW1wcmVzYXMnICYmICF0aGlzLmNhcmdhZG9FbXByZXNhcykge1xuICAgICAgdGhpcy5jYXJnYXJFbXByZXNhcygpO1xuICAgIH0gZWxzZSBpZiAobnVldmFQZXN0YW5hID09PSAnb2ZlcnRhcycgJiYgIXRoaXMuY2FyZ2Fkb09mZXJ0YXMpIHtcbiAgICAgIHRoaXMuY2FyZ2FyT2ZlcnRhcygpO1xuICAgIH0gZWxzZSBpZiAobnVldmFQZXN0YW5hID09PSAncG9zdHVsYW50ZXMnICYmICF0aGlzLmNhcmdhZG9Qb3N0dWxhbnRlcykge1xuICAgICAgdGhpcy5jYXJnYXJQb3N0dWxhbnRlcygpO1xuICAgIH1cbiAgfVxuXG4gIGNhcmdhckRhdG9zKCk6IHZvaWQge1xuICAgIHRoaXMuY2FyZ2FyTWV0cmljYXMoKTtcbiAgICB0aGlzLmNhcmdhckVtcHJlc2FzKCk7XG4gIH1cblxuICAvLyBNw6l0cmljYXMgR2VuZXJhbGVzXG4gIGNhcmdhck1ldHJpY2FzKCk6IHZvaWQge1xuICAgIHRoaXMuYWRtaW5TZXJ2aWNlLmdldE1ldHJpY2FzKCkuc3Vic2NyaWJlKHtcbiAgICAgIG5leHQ6IChyZXM6IGFueSkgPT4ge1xuICAgICAgICBpZiAocmVzICYmIHJlcy5zdWNjZXNzICYmIHJlcy5tZXRyaWNhcykge1xuICAgICAgICAgIHRoaXMubWV0cmljYXMgPSByZXMubWV0cmljYXM7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBlcnJvcjogKGVycikgPT4gY29uc29sZS5lcnJvcignRXJyb3IgYWwgY2FyZ2FyIG3DqXRyaWNhczonLCBlcnIpXG4gICAgfSk7XG4gIH1cblxuICAvLyBDYXJnYSBkZSBFbXByZXNhc1xuICBjYXJnYXJFbXByZXNhcygpOiB2b2lkIHtcbiAgICB0aGlzLmNhcmdhbmRvID0gdHJ1ZTtcbiAgICB0aGlzLmFkbWluU2VydmljZS5nZXRFbXByZXNhcygpLnN1YnNjcmliZSh7XG4gICAgICBuZXh0OiAocmVzOiBhbnkpID0+IHtcbiAgICAgICAgaWYgKHJlcyAmJiByZXMuc3VjY2VzcyAmJiByZXMuZW1wcmVzYXMpIHtcbiAgICAgICAgICB0aGlzLmVtcHJlc2FzID0gcmVzLmVtcHJlc2FzO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuY2FyZ2Fkb0VtcHJlc2FzID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5jYXJnYW5kbyA9IGZhbHNlO1xuICAgICAgfSxcbiAgICAgIGVycm9yOiAoZXJyKSA9PiB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGFsIGNhcmdhciBlbXByZXNhczonLCBlcnIpO1xuICAgICAgICB0aGlzLmNhcmdhZG9FbXByZXNhcyA9IHRydWU7XG4gICAgICAgIHRoaXMuY2FyZ2FuZG8gPSBmYWxzZTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuXG4gIC8vIENhcmdhIGRlIE9mZXJ0YXNcbiAgY2FyZ2FyT2ZlcnRhcygpOiB2b2lkIHtcbiAgICB0aGlzLmNhcmdhbmRvID0gdHJ1ZTtcbiAgICB0aGlzLmFkbWluU2VydmljZS5nZXRPZmVydGFzKCkuc3Vic2NyaWJlKHtcbiAgICAgIG5leHQ6IChyZXM6IGFueSkgPT4ge1xuICAgICAgICBpZiAocmVzICYmIHJlcy5zdWNjZXNzICYmIHJlcy5vZmVydGFzKSB7XG4gICAgICAgICAgdGhpcy5vZmVydGFzID0gcmVzLm9mZXJ0YXM7XG4gICAgICAgIH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheShyZXMpKSB7XG4gICAgICAgICAgdGhpcy5vZmVydGFzID0gcmVzO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuY2FyZ2Fkb09mZXJ0YXMgPSB0cnVlO1xuICAgICAgICB0aGlzLmNhcmdhbmRvID0gZmFsc2U7XG4gICAgICB9LFxuICAgICAgZXJyb3I6IChlcnIpID0+IHtcbiAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgYWwgY2FyZ2FyIG9mZXJ0YXMgZW4gZWwgYWRtaW46JywgZXJyKTtcbiAgICAgICAgdGhpcy5jYXJnYWRvT2ZlcnRhcyA9IHRydWU7XG4gICAgICAgIHRoaXMuY2FyZ2FuZG8gPSBmYWxzZTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuXG4gIC8vIENhcmdhIGRlIFBvc3R1bGFudGVzXG4gIGNhcmdhclBvc3R1bGFudGVzKCk6IHZvaWQge1xuICAgIHRoaXMuY2FyZ2FuZG8gPSB0cnVlO1xuICAgIHRoaXMuYWRtaW5TZXJ2aWNlLmdldFBvc3R1bGFudGVzKCkuc3Vic2NyaWJlKHtcbiAgICAgIG5leHQ6IChyZXM6IGFueSkgPT4ge1xuICAgICAgICBpZiAocmVzICYmIHJlcy5zdWNjZXNzICYmIHJlcy5wb3N0dWxhbnRlcykge1xuICAgICAgICAgIHRoaXMucG9zdHVsYW50ZXMgPSByZXMucG9zdHVsYW50ZXM7XG4gICAgICAgIH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheShyZXMpKSB7XG4gICAgICAgICAgdGhpcy5wb3N0dWxhbnRlcyA9IHJlcztcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmNhcmdhZG9Qb3N0dWxhbnRlcyA9IHRydWU7XG4gICAgICAgIHRoaXMuY2FyZ2FuZG8gPSBmYWxzZTtcbiAgICAgIH0sXG4gICAgICBlcnJvcjogKGVycikgPT4ge1xuICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBhbCBjYXJnYXIgcG9zdHVsYW50ZXMgZW4gZWwgYWRtaW46JywgZXJyKTtcbiAgICAgICAgdGhpcy5jYXJnYWRvUG9zdHVsYW50ZXMgPSB0cnVlO1xuICAgICAgICB0aGlzLmNhcmdhbmRvID0gZmFsc2U7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICAvLyBNb2RlcmFjacOzbiBkZSBPZmVydGFzXG4gIGJhamFPZmVydGFBZG1pbihpZE9mZXJ0YTogbnVtYmVyKTogdm9pZCB7XG4gICAgaWYgKGNvbmZpcm0oYMK/RXN0w6Egc2VndXJvIGRlIHF1ZSBkZXNlYSBlbGltaW5hciBsYSBvZmVydGEgIyR7aWRPZmVydGF9IGRlIG1hbmVyYSBwZXJtYW5lbnRlP2ApKSB7XG4gICAgICB0aGlzLmFkbWluU2VydmljZS5lbGltaW5hck9mZXJ0YShpZE9mZXJ0YSkuc3Vic2NyaWJlKHtcbiAgICAgICAgbmV4dDogKHJlczogUmVzcHVlc3RhQXBpKSA9PiB7XG4gICAgICAgICAgaWYgKHJlcy5zdWNjZXNzKSB7XG4gICAgICAgICAgICBhbGVydChgT2ZlcnRhICMke2lkT2ZlcnRhfSBlbGltaW5hZGEgY29uIMOpeGl0by5gKTtcbiAgICAgICAgICAgIHRoaXMub2ZlcnRhcyA9IHRoaXMub2ZlcnRhcy5maWx0ZXIobyA9PiBvLmlkX29mZXJ0YSAhPT0gaWRPZmVydGEpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgZXJyb3I6IChlcnIpID0+IGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGFsIGVsaW1pbmFyIG9mZXJ0YTonLCBlcnIpXG4gICAgICB9KTtcbiAgICB9XG4gIH1cblxuICAvLyBIZWxwZXJzIGRlIEZlY2hhc1xuICBmb3JtYXRlYXJGZWNoYShmZWNoYVJhdzogc3RyaW5nIHwgRGF0ZSB8IG51bGwgfCB1bmRlZmluZWQpOiBzdHJpbmcge1xuICAgIGlmICghZmVjaGFSYXcpIHJldHVybiAnU2luIGZlY2hhJztcbiAgICBjb25zdCBmZWNoYSA9IG5ldyBEYXRlKGZlY2hhUmF3KTtcbiAgICBpZiAoaXNOYU4oZmVjaGEuZ2V0VGltZSgpKSkgcmV0dXJuICdTaW4gZmVjaGEnO1xuXG4gICAgcmV0dXJuIGZlY2hhLnRvTG9jYWxlRGF0ZVN0cmluZygnZXMtQVInLCB7XG4gICAgICBkYXk6ICcyLWRpZ2l0JyxcbiAgICAgIG1vbnRoOiAnMi1kaWdpdCcsXG4gICAgICB5ZWFyOiAnbnVtZXJpYydcbiAgICB9KTtcbiAgfVxuXG4gIG9idGVuZXJFc3RhZG9ZQ29udGVvKGZlY2hhUHViOiBzdHJpbmcgfCBEYXRlIHwgbnVsbCB8IHVuZGVmaW5lZCwgZGlhc0R1cmFjaW9uOiBudW1iZXIgPSAxMCkge1xuICAgIGlmICghZmVjaGFQdWIpIHJldHVybiB7IGVzdGFkb1RleHQ6ICdTaW4gRmVjaGEnLCBkaWFzOiAwLCBmaW5hbGl6YWRhOiB0cnVlIH07XG5cbiAgICBjb25zdCBpbmljaW8gPSBuZXcgRGF0ZShmZWNoYVB1Yik7XG4gICAgaWYgKGlzTmFOKGluaWNpby5nZXRUaW1lKCkpKSByZXR1cm4geyBlc3RhZG9UZXh0OiAnU2luIEZlY2hhJywgZGlhczogMCwgZmluYWxpemFkYTogdHJ1ZSB9O1xuXG4gICAgY29uc3QgZmluID0gbmV3IERhdGUoaW5pY2lvKTtcbiAgICBmaW4uc2V0RGF0ZShpbmljaW8uZ2V0RGF0ZSgpICsgTnVtYmVyKGRpYXNEdXJhY2lvbikpO1xuXG4gICAgY29uc3QgaG95ID0gbmV3IERhdGUoKTtcbiAgICBjb25zdCBkaWZlcmVuY2lhTXMgPSBmaW4uZ2V0VGltZSgpIC0gaG95LmdldFRpbWUoKTtcbiAgICBjb25zdCBkaWFzUmVzdGFudGVzID0gTWF0aC5jZWlsKGRpZmVyZW5jaWFNcyAvICgxMDAwICogNjAgKiA2MCAqIDI0KSk7XG5cbiAgICBpZiAoZGlhc1Jlc3RhbnRlcyA8PSAwKSB7XG4gICAgICByZXR1cm4geyBlc3RhZG9UZXh0OiAnRmluYWxpemFkYScsIGRpYXM6IDAsIGZpbmFsaXphZGE6IHRydWUgfTtcbiAgICB9XG5cbiAgICByZXR1cm4geyBcbiAgICAgIGVzdGFkb1RleHQ6ICdWaWdlbnRlJywgXG4gICAgICBkaWFzOiBkaWFzUmVzdGFudGVzLCBcbiAgICAgIGZpbmFsaXphZGE6IGZhbHNlIFxuICAgIH07XG4gIH1cblxuLy8gTW9kYWxlcyB5IEFjY2lvbmVzIChFbXByZXNhcylcbmNhbWJpYXJFc3RhZG8oaWRFbXByZXNhOiBudW1iZXIsIGVzdGFkb0FjdHVhbDogc3RyaW5nKTogdm9pZCB7XG4gIC8vIDEuIE5vcm1hbGl6YW1vcyBsYSBjYWRlbmEgYSBtaW7DunNjdWxhcyB5IHNpbiBlc3BhY2lvcyBwYXJhIGV2aXRhciBmYWxsb3MgZGUgZm9ybWF0b1xuICBjb25zdCBlc0FjdGl2byA9IGVzdGFkb0FjdHVhbD8udG9TdHJpbmcoKS50cmltKCkudG9Mb3dlckNhc2UoKSA9PT0gJ2FjdGl2byc7XG4gIGNvbnN0IG51ZXZvRXN0YWRvID0gZXNBY3Rpdm8gPyAnSW5hY3Rpdm8nIDogJ0FjdGl2byc7XG5cbiAgdGhpcy5hZG1pblNlcnZpY2UuY2FtYmlhckVzdGFkb0VtcHJlc2EoaWRFbXByZXNhLCBudWV2b0VzdGFkbykuc3Vic2NyaWJlKHtcbiAgICBuZXh0OiAocmVzOiBSZXNwdWVzdGFBcGkpID0+IHtcbiAgICAgIGlmIChyZXMuc3VjY2Vzcykge1xuICAgICAgICAvLyAyLiBBY3R1YWxpemFyIG9iamV0byBlbiBsYSBsaXN0YSBwcmluY2lwYWwgZGUgZW1wcmVzYXNcbiAgICAgICAgY29uc3QgZW1wID0gdGhpcy5lbXByZXNhcy5maW5kKGUgPT4gZS5pZF9lbXByZXNhID09PSBpZEVtcHJlc2EpO1xuICAgICAgICBpZiAoZW1wKSB7XG4gICAgICAgICAgZW1wLmVzdGFkbyA9IG51ZXZvRXN0YWRvO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gMy4gQWN0dWFsaXphciBvYmpldG8gc2kgZXN0w6Egc2VsZWNjaW9uYWRvIGVuIHVuIG1vZGFsIGRlIGRldGFsbGVcbiAgICAgICAgaWYgKHRoaXMuZW1wcmVzYVNlbGVjY2lvbmFkYSAmJiB0aGlzLmVtcHJlc2FTZWxlY2Npb25hZGEuaWRfZW1wcmVzYSA9PT0gaWRFbXByZXNhKSB7XG4gICAgICAgICAgdGhpcy5lbXByZXNhU2VsZWNjaW9uYWRhLmVzdGFkbyA9IG51ZXZvRXN0YWRvO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gNC4gRm9yemFyIGxhIGFjdHVhbGl6YWNpw7NuIHZpc3VhbCBkZSBsYSB0YWJsYSB5IGxvcyBib3RvbmVzXG4gICAgICAgIHRoaXMuY2RyLmRldGVjdENoYW5nZXMoKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIFNpIGVsIGJhY2tlbmQgZGV2b2x2acOzIHN1Y2Nlc3M6IGZhbHNlLCBtb3N0cmFtb3MgZWwgbWVuc2FqZVxuICAgICAgICBhbGVydChyZXMubWVuc2FqZSB8fCAnTm8gc2UgcHVkbyBjYW1iaWFyIGVsIGVzdGFkbyBkZSBsYSBlbXByZXNhLicpO1xuICAgICAgfVxuICAgIH0sXG4gICAgZXJyb3I6IChlcnIpID0+IHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGFsIGNhbWJpYXIgZXN0YWRvOicsIGVycik7XG4gICAgICBhbGVydCgnT2N1cnJpw7MgdW4gZXJyb3IgYWwgY29tdW5pY2Fyc2UgY29uIGVsIHNlcnZpZG9yLicpO1xuICAgIH1cbiAgfSk7XG59XG4gIHZlckRldGFsbGUoZW1wcmVzYTogRW1wcmVzYUFkbWluKTogdm9pZCB7XG4gICAgdGhpcy5lbXByZXNhU2VsZWNjaW9uYWRhID0gZW1wcmVzYTtcbiAgICB0aGlzLm1vc3RyYXJNb2RhbCA9IHRydWU7XG4gIH1cblxuICBjZXJyYXJNb2RhbCgpOiB2b2lkIHtcbiAgICB0aGlzLm1vc3RyYXJNb2RhbCA9IGZhbHNlO1xuICAgIHRoaXMuZW1wcmVzYVNlbGVjY2lvbmFkYSA9IG51bGw7XG4gIH1cbi8vIPCfkYggIE1PREFMIDIgUEVSRklMIENPTVBMRVRPIChFbXByZXNhUHJvZmlsZSlcbiAgYWJyaXJQZXJmaWxFbXByZXNhKGlkRW1wcmVzYTogbnVtYmVyKTogdm9pZCB7XG4gICAgdGhpcy5lbXByZXNhUGVyZmlsSWQgPSBpZEVtcHJlc2E7XG4gIH1cblxuICBjZXJyYXJNb2RhbFBlcmZpbCgpOiB2b2lkIHtcbiAgdGhpcy5lbXByZXNhUGVyZmlsSWQgPSBudWxsO1xufVxuXG4gIC8vIE1vZGFsZXMgeSBBY2Npb25lcyAoUG9zdHVsYW50ZXMpXG4gIHZlckRldGFsbGVQb3N0dWxhbnRlKHBvc3R1bGFudGU6IFBvc3R1bGFudGVBZG1pbik6IHZvaWQge1xuICAgIHRoaXMucG9zdHVsYW50ZVNlbGVjY2lvbmFkbyA9IHBvc3R1bGFudGU7XG4gICAgdGhpcy5tb3N0cmFyTW9kYWxQb3N0dWxhbnRlID0gdHJ1ZTtcbiAgfVxuXG4gIGNlcnJhck1vZGFsUG9zdHVsYW50ZSgpOiB2b2lkIHtcbiAgICB0aGlzLm1vc3RyYXJNb2RhbFBvc3R1bGFudGUgPSBmYWxzZTtcbiAgICB0aGlzLnBvc3R1bGFudGVTZWxlY2Npb25hZG8gPSBudWxsO1xuICB9XG5cbiAgLy8gQ2llcnJlIGRlIFNlc2nDs24gQ2VudHJhbGl6YWRvXG4gIGNlcnJhclNlc2lvbigpOiB2b2lkIHtcbiAgICB0aGlzLmF1dGhTZXJ2aWNlLmxvZ291dCgpO1xuICAgIHRoaXMucm91dGVyLm5hdmlnYXRlKFsnL3Nlc2lvbiddKTtcbiAgfVxuICBcbiAgLy8gS2V5VmFsdWVQaXBlIEhlbHBlcnNcbiAgbm9ybWFsaXphckNsYXZlKGNsYXZlOiBzdHJpbmcgfCBudW1iZXIgfCBzeW1ib2wpOiBzdHJpbmcge1xuICAgIHJldHVybiBjbGF2ZS50b1N0cmluZygpO1xuICB9XG5cbiAgZXNDYW1wb1Zpc2libGUoY2xhdmU6IHN0cmluZyB8IG51bWJlciB8IHN5bWJvbCk6IGJvb2xlYW4ge1xuICAgIGNvbnN0IHZhbG9yID0gdGhpcy5ub3JtYWxpemFyQ2xhdmUoY2xhdmUpLnRvTG93ZXJDYXNlKCk7XG4gICAgY29uc3QgY2FtcG9zT2N1bHRvcyA9IFsncGFzc3dvcmQnLCAnY29udHJhc2VuYScsICdjbGF2ZScsICdwYXNzJywgJ3Rva2VuJ107XG4gICAgcmV0dXJuICFjYW1wb3NPY3VsdG9zLmluY2x1ZGVzKHZhbG9yKTtcbiAgfVxuXG4gIGZvcm1hdGVhckNsYXZlKGNsYXZlOiBzdHJpbmcgfCBudW1iZXIgfCBzeW1ib2wpOiBzdHJpbmcge1xuICAgIHJldHVybiB0aGlzLm5vcm1hbGl6YXJDbGF2ZShjbGF2ZSkucmVwbGFjZSgvXy9nLCAnICcpLnRvVXBwZXJDYXNlKCk7XG4gIH1cbn0iLCI8ZGl2IGNsYXNzPVwiZGFzaGJvYXJkLWxheW91dFwiPlxuICA8IS0tIFNpZGViYXIgZGUgbmF2ZWdhY2nDs24gLS0+XG4gIDxhc2lkZSBjbGFzcz1cInNpZGViYXJcIj5cbiAgICA8bmF2PlxuICAgICAgPGEgKGNsaWNrKT1cIm1vc3RyYXJTa2lsbHMgPSB0cnVlXCIgW2NsYXNzLmFjdGl2ZV09XCJtb3N0cmFyU2tpbGxzXCIgc3R5bGU9XCJjdXJzb3I6IHBvaW50ZXI7XCI+8J+boO+4jyBTa2lsbHMgeSBDYXRlZ29yw61hczwvYT5cbiAgICAgIDxhIChjbGljayk9XCJtb3N0cmFyU2tpbGxzID0gZmFsc2U7IGNhbWJpYXJQZXN0YW5hKCdwb3N0dWxhbnRlcycpXCIgW2NsYXNzLmFjdGl2ZV09XCJwZXN0YW5hQWN0aXZhID09PSAncG9zdHVsYW50ZXMnICYmICFtb3N0cmFyU2tpbGxzXCIgc3R5bGU9XCJjdXJzb3I6IHBvaW50ZXI7XCI+8J+RpSBQb3N0dWxhbnRlczwvYT5cbiAgICAgIDxhIChjbGljayk9XCJtb3N0cmFyU2tpbGxzID0gZmFsc2U7IGNhbWJpYXJQZXN0YW5hKCdlbXByZXNhcycpXCIgW2NsYXNzLmFjdGl2ZV09XCJwZXN0YW5hQWN0aXZhID09PSAnZW1wcmVzYXMnICYmICFtb3N0cmFyU2tpbGxzXCIgc3R5bGU9XCJjdXJzb3I6IHBvaW50ZXI7XCI+8J+PoiBFbXByZXNhczwvYT5cbiAgICAgIDxhIChjbGljayk9XCJtb3N0cmFyU2tpbGxzID0gZmFsc2U7IGNhbWJpYXJQZXN0YW5hKCdvZmVydGFzJylcIiBbY2xhc3MuYWN0aXZlXT1cInBlc3RhbmFBY3RpdmEgPT09ICdvZmVydGFzJyAmJiAhbW9zdHJhclNraWxsc1wiIHN0eWxlPVwiY3Vyc29yOiBwb2ludGVyO1wiPvCfkrwgT2ZlcnRhczwvYT5cbiAgICAgIDxhIChjbGljayk9XCJtb3N0cmFyU2tpbGxzID0gZmFsc2U7IGNhbWJpYXJQZXN0YW5hKCdwb3N0dWxhY2lvbmVzJylcIiBbY2xhc3MuYWN0aXZlXT1cInBlc3RhbmFBY3RpdmEgPT09ICdwb3N0dWxhY2lvbmVzJyAmJiAhbW9zdHJhclNraWxsc1wiIHN0eWxlPVwiY3Vyc29yOiBwb2ludGVyO1wiPvCfk4QgUG9zdHVsYWNpb25lczwvYT5cbiAgICA8L25hdj5cblxuICA8YnV0dG9uIGNsYXNzPVwibG9nb3V0XCIgKGNsaWNrKT1cImNlcnJhclNlc2lvbigpXCI+Q2VycmFyIFNlc2nDs248L2J1dHRvbj5cbiAgICBcbiAgPC9hc2lkZT5cblxuICA8ZGl2IGNsYXNzPVwiYWRtaW4tY29udGFpbmVyXCI+XG4gICAgPGgyPvCfm6DvuI8gUGFuZWwgZGUgQ29udHJvbCBJbnN0aXR1Y2lvbmFsIElUQkNPTkVDVEE8L2gyPlxuICAgIDxwIGNsYXNzPVwic3VidGl0dWxvXCI+R2VzdGnDs24gZGUgdXN1YXJpb3MsIGVtcHJlc2FzIHkgbW9kZXJhY2nDs24gZGUgbGEgcGxhdGFmb3JtYTwvcD5cblxuICAgIDwhLS0gVEFSSkVUQVMgREUgTcOJVFJJQ0FTIC0tPlxuICAgIDxkaXYgY2xhc3M9XCJtZXRyaWNhcy1ncmlkXCI+XG4gICAgICA8ZGl2IFxuICAgICAgICBjbGFzcz1cImNhcmQta3BpXCIgXG4gICAgICAgIFtjbGFzcy5hY3RpdmFdPVwicGVzdGFuYUFjdGl2YSA9PT0gJ2VtcHJlc2FzJ1wiIFxuICAgICAgICAoY2xpY2spPVwiY2FtYmlhclBlc3RhbmEoJ2VtcHJlc2FzJylcIj5cbiAgICAgICAgPHNwYW4gY2xhc3M9XCJudW1lcm9cIj57eyBtZXRyaWNhcy50b3RhbEVtcHJlc2FzIH19PC9zcGFuPlxuICAgICAgICA8c3BhbiBjbGFzcz1cImxhYmVsXCI+RW1wcmVzYXMgUmVnaXN0cmFkYXM8L3NwYW4+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBcbiAgICAgICAgY2xhc3M9XCJjYXJkLWtwaVwiIFxuICAgICAgICBbY2xhc3MuYWN0aXZhXT1cInBlc3RhbmFBY3RpdmEgPT09ICdvZmVydGFzJ1wiIFxuICAgICAgICAoY2xpY2spPVwiY2FtYmlhclBlc3RhbmEoJ29mZXJ0YXMnKVwiPlxuICAgICAgICA8c3BhbiBjbGFzcz1cIm51bWVyb1wiPnt7IG1ldHJpY2FzLnRvdGFsT2ZlcnRhcyB9fTwvc3Bhbj5cbiAgICAgICAgPHNwYW4gY2xhc3M9XCJsYWJlbFwiPk9mZXJ0YXMgUHVibGljYWRhczwvc3Bhbj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2IFxuICAgICAgICBjbGFzcz1cImNhcmQta3BpXCIgXG4gICAgICAgIFtjbGFzcy5hY3RpdmFdPVwicGVzdGFuYUFjdGl2YSA9PT0gJ3Bvc3R1bGFudGVzJ1wiIFxuICAgICAgICAoY2xpY2spPVwiY2FtYmlhclBlc3RhbmEoJ3Bvc3R1bGFudGVzJylcIj5cbiAgICAgICAgPHNwYW4gY2xhc3M9XCJudW1lcm9cIj57eyBtZXRyaWNhcy50b3RhbFBvc3R1bGFudGVzIH19PC9zcGFuPlxuICAgICAgICA8c3BhbiBjbGFzcz1cImxhYmVsXCI+UG9zdHVsYW50ZXMgUmVnaXN0cmFkb3M8L3NwYW4+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBcbiAgICAgICAgY2xhc3M9XCJjYXJkLWtwaSBoaWdobGlnaHRcIiBcbiAgICAgICAgW2NsYXNzLmFjdGl2YV09XCJwZXN0YW5hQWN0aXZhID09PSAncG9zdHVsYWNpb25lcydcIiBcbiAgICAgICAgKGNsaWNrKT1cIm1vc3RyYXJTa2lsbHMgPSBmYWxzZTsgY2FtYmlhclBlc3RhbmEoJ3Bvc3R1bGFjaW9uZXMnKVwiXG4gICAgICAgIHN0eWxlPVwiY3Vyc29yOiBwb2ludGVyO1wiPlxuICAgICAgICA8c3BhbiBjbGFzcz1cIm51bWVyb1wiPnt7IG1ldHJpY2FzLnRvdGFsUG9zdHVsYWNpb25lcyB9fTwvc3Bhbj5cbiAgICAgICAgPHNwYW4gY2xhc3M9XCJsYWJlbFwiPlBvc3R1bGFjaW9uZXMgVG90YWxlczwvc3Bhbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuXG4gICAgPCEtLSBTRUNDScOTTiBESU7DgU1JQ0EgREUgQ09OVEVOSURPIC0tPlxuICAgIDxkaXYgY2xhc3M9XCJ0YWJsYS1zZWNjaW9uXCI+XG5cbiAgICAgIDwhLS0gVklTVEEgMTogRU1QUkVTQVMgLS0+XG4gICAgICBAaWYgKHBlc3RhbmFBY3RpdmEgPT09ICdlbXByZXNhcycpIHtcbiAgICAgICAgPGgzPvCfj6IgRW1wcmVzYXMgUmVnaXN0cmFkYXM8L2gzPlxuXG4gICAgICAgIEBpZiAoY2FyZ2FuZG8pIHtcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwibG9hZGluZ1wiPuKPsyBDYXJnYW5kbyBlbXByZXNhcyBkZXNkZSBlbCBzZXJ2aWRvci4uLjwvZGl2PlxuICAgICAgICB9IEBlbHNlIGlmIChlbXByZXNhcy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgPHRhYmxlIGNsYXNzPVwidGFibGEtYWRtaW5cIj5cbiAgICAgICAgICAgIDx0aGVhZD5cbiAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgIDx0aD5JRDwvdGg+XG4gICAgICAgICAgICAgICAgPHRoPlJhesOzbiBTb2NpYWw8L3RoPlxuICAgICAgICAgICAgICAgIDx0aD5DVUlUPC90aD5cbiAgICAgICAgICAgICAgICA8dGg+RW1haWw8L3RoPlxuICAgICAgICAgICAgICAgIDx0aD5Fc3RhZG88L3RoPlxuICAgICAgICAgICAgICAgIDx0aD5BY2Npb25lczwvdGg+XG4gICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgPHRib2R5PlxuICAgICAgICAgICAgICBAZm9yIChlbXAgb2YgZW1wcmVzYXM7IHRyYWNrIGVtcC5pZF9lbXByZXNhKSB7XG4gICAgPHRyPlxuICAgICAgPHRkPiN7eyBlbXAuaWRfZW1wcmVzYSB9fTwvdGQ+XG4gICAgICA8dGQ+PHN0cm9uZz57eyBlbXAucmF6b25Tb2NpYWwgfX08L3N0cm9uZz48L3RkPlxuICAgICAgPHRkPnt7IGVtcC5jdWl0IH19PC90ZD5cbiAgICAgIDx0ZD57eyBlbXAuZW1haWwgfX08L3RkPlxuICAgICAgPHRkPlxuICAgICAgICA8c3BhbiBjbGFzcz1cImJhZGdlXCIgXG4gICAgICAgICAgICAgIFtjbGFzcy5hY3Rpdm9dPVwiZW1wLmVzdGFkbyA9PT0gJ0FjdGl2bydcIiBcbiAgICAgICAgICAgICAgW2NsYXNzLmluYWN0aXZvXT1cImVtcC5lc3RhZG8gPT09ICdJbmFjdGl2bydcIlxuICAgICAgICAgICAgICBbY2xhc3MucGVuZGllbnRlXT1cImVtcC5lc3RhZG8gPT09ICdQZW5kaWVudGUnXCI+XG4gICAgICAgICAge3sgZW1wLmVzdGFkbyB9fVxuICAgICAgICA8L3NwYW4+XG4gICAgICA8L3RkPlxuICAgICAgPHRkIGNsYXNzPVwiYWNjaW9uZXMtY2VsbFwiPlxuICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuLWluZm9cIiAoY2xpY2spPVwidmVyRGV0YWxsZShlbXApXCIgdGl0bGU9XCJWZXIgZGV0YWxsZSBmaXNjYWxcIj5cbiAgICAgICAgICDwn5SNIERldGFsbGVcbiAgICAgICAgPC9idXR0b24+XG4gICAgICAgIFxuICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuLWluZm9cIiAoY2xpY2spPVwiYWJyaXJQZXJmaWxFbXByZXNhKGVtcC5pZF9lbXByZXNhKVwiIHRpdGxlPVwiVmVyIHBlcmZpbCBww7pibGljb1wiPlxuICAgICAgICAgIPCfj6IgUGVyZmlsXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgICBcbiAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICBjbGFzcz1cImJ0bi1lc3RhZG9cIiBcbiAgICAgICAgICBbY2xhc3MuYnRuLWRlc2FjdGl2YXJdPVwiZW1wLmVzdGFkbyA9PT0gJ0FjdGl2bydcIlxuICAgICAgICAgIFtjbGFzcy5idG4tYWN0aXZhcl09XCJlbXAuZXN0YWRvICE9PSAnQWN0aXZvJ1wiXG4gICAgICAgICAgKGNsaWNrKT1cImNhbWJpYXJFc3RhZG8oZW1wLmlkX2VtcHJlc2EsIGVtcC5lc3RhZG8pXCI+XG4gICAgICAgICAge3sgZW1wLmVzdGFkbyA9PT0gJ0FjdGl2bycgPyAnRGVzYWN0aXZhcicgOiAnQWN0aXZhcicgfX1cbiAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvdGQ+XG4gICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICB9IEBlbHNlIHtcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwibm8tZGF0b3NcIj7imqDvuI8gTm8gc2UgZW5jb250cmFyb24gZW1wcmVzYXMgZW4gbGEgYmFzZSBkZSBkYXRvcy48L2Rpdj5cbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICA8IS0tIFZJU1RBIDI6IE9GRVJUQVMgLS0+XG4gICAgICBAaWYgKHBlc3RhbmFBY3RpdmEgPT09ICdvZmVydGFzJykge1xuICAgICAgICA8aDM+8J+SvCBNb2RlcmFjacOzbiBkZSBPZmVydGFzIGRlIEVtcGxlbzwvaDM+XG4gICAgICAgIEBpZiAoY2FyZ2FuZG8pIHtcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwibG9hZGluZ1wiPuKPsyBDYXJnYW5kbyBvZmVydGFzIGRlc2RlIGVsIHNlcnZpZG9yLi4uPC9kaXY+XG4gICAgICAgIH0gQGVsc2UgaWYgKG9mZXJ0YXMubGVuZ3RoID4gMCkge1xuICAgICAgICAgIDx0YWJsZSBjbGFzcz1cInRhYmxhLWFkbWluXCI+XG4gICAgICAgICAgICA8dGhlYWQ+XG4gICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICA8dGg+SUQ8L3RoPlxuICAgICAgICAgICAgICAgIDx0aD5Uw610dWxvIC8gRW1wcmVzYTwvdGg+XG4gICAgICAgICAgICAgICAgPHRoPkZlY2hhIFB1YmxpY2FjacOzbjwvdGg+XG4gICAgICAgICAgICAgICAgPHRoPlZlbmNpbWllbnRvIC8gRHVyYWNpw7NuPC90aD5cbiAgICAgICAgICAgICAgICA8dGg+TW9kYWxpZGFkPC90aD5cbiAgICAgICAgICAgICAgICA8dGg+RXN0YWRvPC90aD5cbiAgICAgICAgICAgICAgICA8dGg+QWNjacOzbjwvdGg+XG4gICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgPHRib2R5PlxuICAgICAgICAgICAgICBAZm9yIChvZmVydGEgb2Ygb2ZlcnRhczsgdHJhY2sgKG9mZXJ0YS5pZF9vZmVydGEgfHwgJGluZGV4KSkge1xuICAgICAgICAgICAgICAgIEBsZXQgaW5mb0VzdGFkbyA9IG9idGVuZXJFc3RhZG9ZQ29udGVvKG9mZXJ0YS5mZWNoYV9wdWJsaWNhY2lvbiwgb2ZlcnRhLmRpYXNfZHVyYWNpb24pO1xuICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgIDx0ZD4je3sgb2ZlcnRhLmlkX29mZXJ0YSB9fTwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQ+XG4gICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+e3sgb2ZlcnRhLnRpdHVsbyB9fTwvc3Ryb25nPjxicj5cbiAgICAgICAgICAgICAgICAgICAgPHNtYWxsIGNsYXNzPVwidGV4dC1tdXRlZFwiPnt7IG9mZXJ0YS5yYXpvblNvY2lhbCB8fCAnRW1wcmVzYSAjJyArIG9mZXJ0YS5pZF9lbXByZXNhIH19PC9zbWFsbD5cbiAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQ+e3sgZm9ybWF0ZWFyRmVjaGEob2ZlcnRhLmZlY2hhX3B1YmxpY2FjaW9uKSB9fTwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQ+XG4gICAgICAgICAgICAgICAgICAgIEBpZiAoaW5mb0VzdGFkby5maW5hbGl6YWRhKSB7XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJiYWRnZSBpbmFjdGl2b1wiPkV4cGlyw7MgKHt7IG9mZXJ0YS5kaWFzX2R1cmFjaW9uIHx8IDEwIH19ZCk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIH0gQGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiYmFkZ2UgYWN0aXZvXCI+4oybIFF1ZWRhbiB7eyBpbmZvRXN0YWRvLmRpYXMgfX0gZMOtYXM8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQ+e3sgb2ZlcnRhLm1vZGFsaWRhZCB9fSAoe3sgb2ZlcnRhLmV4cGVyaWVuY2lhIH19KTwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQ+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiYmFkZ2VcIiBbY2xhc3MuYWN0aXZvXT1cIiFpbmZvRXN0YWRvLmZpbmFsaXphZGFcIiBbY2xhc3MuaW5hY3Rpdm9dPVwiaW5mb0VzdGFkby5maW5hbGl6YWRhXCI+XG4gICAgICAgICAgICAgICAgICAgICAge3sgaW5mb0VzdGFkby5lc3RhZG9UZXh0IH19XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQ+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJidG4tZXN0YWRvIGJ0bi1kZXNhY3RpdmFyXCIgKGNsaWNrKT1cImJhamFPZmVydGFBZG1pbihvZmVydGEuaWRfb2ZlcnRhKVwiPlxuICAgICAgICAgICAgICAgICAgICAgIPCfl5HvuI8gRWxpbWluYXJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgfSBAZWxzZSB7XG4gICAgICAgICAgPGRpdiBjbGFzcz1cIm5vLWRhdG9zXCI+4pqg77iPIE5vIHNlIGVuY29udHJhcm9uIG9mZXJ0YXMgZGUgZW1wbGVvIHJlZ2lzdHJhZGFzIGVuIGVsIHNpc3RlbWEuPC9kaXY+XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgPCEtLSBWSVNUQSAzOiBQT1NUVUxBTlRFUyAtLT5cbiAgICAgIEBpZiAocGVzdGFuYUFjdGl2YSA9PT0gJ3Bvc3R1bGFudGVzJykge1xuICAgICAgICA8aDM+8J+OkyBQYWRyw7NuIGRlIFBvc3R1bGFudGVzIChBbHVtbm9zIHkgRWdyZXNhZG9zKTwvaDM+XG5cbiAgICAgICAgQGlmIChjYXJnYW5kbykge1xuICAgICAgICAgIDxkaXYgY2xhc3M9XCJsb2FkaW5nXCI+4o+zIENhcmdhbmRvIHBvc3R1bGFudGVzIGRlc2RlIGVsIHNlcnZpZG9yLi4uPC9kaXY+XG4gICAgICAgIH0gQGVsc2UgaWYgKHBvc3R1bGFudGVzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICA8dGFibGUgY2xhc3M9XCJ0YWJsYS1hZG1pblwiPlxuICAgICAgICAgICAgPHRoZWFkPlxuICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgPHRoPklEPC90aD5cbiAgICAgICAgICAgICAgICA8dGg+Tm9tYnJlIHkgQXBlbGxpZG88L3RoPlxuICAgICAgICAgICAgICAgIDx0aD5ETkk8L3RoPlxuICAgICAgICAgICAgICAgIDx0aD5MZWdham88L3RoPlxuICAgICAgICAgICAgICAgIDx0aD5DYXJyZXJhPC90aD5cbiAgICAgICAgICAgICAgICA8dGg+RW1haWw8L3RoPlxuICAgICAgICAgICAgICAgIDx0aD5Fc3RhZG88L3RoPlxuICAgICAgICAgICAgICAgIDx0aD5BY2Npw7NuPC90aD5cbiAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICA8dGJvZHk+XG4gICAgICAgICAgICAgIEBmb3IgKHBvc3Qgb2YgcG9zdHVsYW50ZXM7IHRyYWNrIChwb3N0LmlkX3Bvc3R1bGFudGUgfHwgcG9zdC5pZCB8fCAkaW5kZXgpKSB7XG4gICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgPHRkPiN7eyBwb3N0LmlkX3Bvc3R1bGFudGUgfHwgcG9zdC5pZCB9fTwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQ+PHN0cm9uZz57eyBwb3N0Lm5vbWJyZXMgfHwgcG9zdC5ub21icmUgfX0ge3sgcG9zdC5hcGVsbGlkb3MgfHwgcG9zdC5hcGVsbGlkbyB9fTwvc3Ryb25nPjwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQ+e3sgcG9zdC5kbmkgfHwgJ1MvRCcgfX08L3RkPlxuICAgICAgICAgICAgICAgICAgPHRkPnt7IHBvc3QubGVnYWpvIHx8ICdTL0wnIH19PC90ZD5cbiAgICAgICAgICAgICAgICAgIDx0ZD57eyBwb3N0LmNhcnJlcmEgfHwgJ0FuYWxpc3RhIGRlIFNpc3RlbWFzIC8gSUEnIH19PC90ZD5cbiAgICAgICAgICAgICAgICAgIDx0ZD57eyBwb3N0LmVtYWlsIH19PC90ZD5cbiAgICAgICAgICAgICAgICAgIDx0ZD5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJiYWRnZVwiIFtjbGFzcy5hY3Rpdm9dPVwicG9zdC5lc3RhZG8gIT09ICdJbmFjdGl2bydcIiBbY2xhc3MuaW5hY3Rpdm9dPVwicG9zdC5lc3RhZG8gPT09ICdJbmFjdGl2bydcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7eyBwb3N0LmVzdGFkbyB8fCAnQWN0aXZvJyB9fVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgPHRkPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuLWluZm9cIiAoY2xpY2spPVwidmVyRGV0YWxsZVBvc3R1bGFudGUocG9zdClcIj5cbiAgICAgICAgICAgICAgICAgICAgICDwn5SNIFZlciBQZXJmaWwvQ1ZcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIDwvdGJvZHk+XG4gICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgfSBAZWxzZSB7XG4gICAgICAgICAgPGRpdiBjbGFzcz1cIm5vLWRhdG9zXCI+4pqg77iPIE5vIHNlIGVuY29udHJhcm9uIHBvc3R1bGFudGVzIHJlZ2lzdHJhZG9zIGVuIGxhIGJhc2UgZGUgZGF0b3MuPC9kaXY+XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgPCEtLSBWSVNUQSA0OiBHRVNUScOTTiBERSBQT1NUVUxBQ0lPTkVTIENPTVBMRVRBIC0tPlxuICAgICAgQGlmIChwZXN0YW5hQWN0aXZhID09PSAncG9zdHVsYWNpb25lcycpIHtcbiAgICAgICAgPGFwcC1wb3N0dWxhY2lvbmVzIC8+XG4gICAgICB9XG5cbiAgICA8L2Rpdj5cblxuICAgIDwhLS0gQk9Uw5NOIFRPR0dMRSBZIENPTVBPTkVOVEUgSU5ERVBFTkRJRU5URSBERSBTS0lMTFMgLS0+XG4gICAgPGRpdiBjbGFzcz1cImNvbnRlbmVkb3ItdG9nZ2xlLXNraWxsc1wiIHN0eWxlPVwibWFyZ2luLXRvcDogMnJlbTtcIj5cbiAgICAgIDxidXR0b24gY2xhc3M9XCJidG4tdG9nZ2xlLXNraWxsc1wiIChjbGljayk9XCJ0b2dnbGVTa2lsbHMoKVwiPlxuICAgICAgICB7eyBtb3N0cmFyU2tpbGxzID8gJ+KWsiBPY3VsdGFyIEdlc3Rpw7NuIGRlIFNraWxscycgOiAn4pa8IFZlciAvIEFkbWluaXN0cmFyIFNraWxscycgfX1cbiAgICAgIDwvYnV0dG9uPlxuICAgIDwvZGl2PlxuXG4gICAgPCEtLSBDT01QT05FTlRFIFNLSUxMUyBDT05ESUNJT05BTCAtLT5cbiAgICBAaWYgKG1vc3RyYXJTa2lsbHMpIHtcbiAgICAgIDxhcHAtc2tpbGxzIC8+XG4gICAgfVxuICA8L2Rpdj5cblxuICA8IS0tIE1PREFMIERJTsOBTUlDTyBERSBERVRBTExFIERFIEVNUFJFU0EgLS0+XG4gIEBpZiAobW9zdHJhck1vZGFsICYmIGVtcHJlc2FTZWxlY2Npb25hZGEpIHtcbiAgICA8ZGl2IGNsYXNzPVwibW9kYWwtb3ZlcmxheVwiIChjbGljayk9XCJjZXJyYXJNb2RhbCgpXCI+XG4gICAgICA8ZGl2IGNsYXNzPVwibW9kYWwtY29udGVudFwiIChjbGljayk9XCIkZXZlbnQuc3RvcFByb3BhZ2F0aW9uKClcIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cIm1vZGFsLWhlYWRlclwiPlxuICAgICAgICAgIDxoMz7wn4+iIEZpY2hhIGRlIFJlZ2lzdHJvIGRlIEVtcHJlc2E8L2gzPlxuICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJidG4tY2VycmFyXCIgKGNsaWNrKT1cImNlcnJhck1vZGFsKClcIj7inJU8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIFxuICAgICAgICA8ZGl2IGNsYXNzPVwibW9kYWwtYm9keVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJncmlkLWRhdG9zXCI+XG4gICAgICAgICAgICBAZm9yIChpdGVtIG9mIGVtcHJlc2FTZWxlY2Npb25hZGEgfCBrZXl2YWx1ZTsgdHJhY2sgaXRlbS5rZXkpIHtcbiAgICAgICAgICAgICAgQGlmIChlc0NhbXBvVmlzaWJsZShub3JtYWxpemFyQ2xhdmUoaXRlbS5rZXkudG9TdHJpbmcoKSkpKSB7XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cImRhdG8taXRlbVwiPlxuICAgICAgICAgICAgICAgICAgPGxhYmVsPnt7IGZvcm1hdGVhckNsYXZlKG5vcm1hbGl6YXJDbGF2ZShpdGVtLmtleS50b1N0cmluZygpKSkgfX06PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPnt7IGl0ZW0udmFsdWUgIT09IG51bGwgJiYgaXRlbS52YWx1ZSAhPT0gJycgPyBpdGVtLnZhbHVlIDogJ05vIGVzcGVjaWZpY2FkbycgfX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzcz1cIm1vZGFsLWZvb3RlclwiPlxuICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICBjbGFzcz1cImJ0bi1lc3RhZG9cIiBcbiAgICAgICAgICAgIFtjbGFzcy5idG4tZGVzYWN0aXZhcl09XCJlbXByZXNhU2VsZWNjaW9uYWRhLmVzdGFkbyA9PT0gJ0FjdGl2bydcIlxuICAgICAgICAgICAgW2NsYXNzLmJ0bi1hY3RpdmFyXT1cImVtcHJlc2FTZWxlY2Npb25hZGEuZXN0YWRvICE9PSAnQWN0aXZvJ1wiXG4gICAgICAgICAgICAoY2xpY2spPVwiY2FtYmlhckVzdGFkbyhlbXByZXNhU2VsZWNjaW9uYWRhLmlkX2VtcHJlc2EsIGVtcHJlc2FTZWxlY2Npb25hZGEuZXN0YWRvKVwiPlxuICAgICAgICAgICAge3sgZW1wcmVzYVNlbGVjY2lvbmFkYS5lc3RhZG8gPT09ICdBY3Rpdm8nID8gJ0Rlc2FjdGl2YXIgRW1wcmVzYScgOiAnQWN0aXZhciBFbXByZXNhJyB9fVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJidG4tc2VjdW5kYXJpb1wiIChjbGljayk9XCJjZXJyYXJNb2RhbCgpXCI+Q2VycmFyPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIH1cbjwhLS0gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IC0tPlxuPCEtLSAyLiBNT0RBTCBERSBQRVJGSUwgRU1QUkVTQSAtLT5cbjwhLS0gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09IC0tPlxuQGlmIChlbXByZXNhUGVyZmlsSWQpIHtcbiAgPGRpdiBjbGFzcz1cIm1vZGFsLW92ZXJsYXlcIiAoY2xpY2spPVwiY2VycmFyTW9kYWxQZXJmaWwoKVwiPlxuICAgIDxkaXYgY2xhc3M9XCJtb2RhbC1jb250ZW50IG1vZGFsLXBlcmZpbC1hbmNob1wiIChjbGljayk9XCIkZXZlbnQuc3RvcFByb3BhZ2F0aW9uKClcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJtb2RhbC1oZWFkZXJcIj5cbiAgICAgICAgPGgzPvCfj6IgUGVyZmlsIGRlIGxhIEVtcHJlc2E8L2gzPlxuICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuLWNlcnJhclwiIChjbGljayk9XCJjZXJyYXJNb2RhbFBlcmZpbCgpXCI+4pyVPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICAgIFxuICAgICAgPGRpdiBjbGFzcz1cIm1vZGFsLWJvZHlcIj5cbiAgICAgICAgPGFwcC1lbXByZXNhLXByb2ZpbGUgXG4gICAgICAgICAgW2lkRW1wcmVzYUlucHV0XT1cImVtcHJlc2FQZXJmaWxJZFwiIFxuICAgICAgICAgIFtlc01vZG9BZG1pbl09XCJ0cnVlXCJcbiAgICAgICAgICAoY2VycmFyTW9kYWwpPVwiY2VycmFyTW9kYWxQZXJmaWwoKVwiPlxuICAgICAgICA8L2FwcC1lbXByZXNhLXByb2ZpbGU+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgPC9kaXY+XG59XG5cbiAgPCEtLSBNT0RBTCBGTE9UQU5URTogVkVSIFBFUkZJTCBZIENWIERFTCBQT1NUVUxBTlRFIC0tPlxuQGlmIChtb3N0cmFyTW9kYWxQb3N0dWxhbnRlICYmIHBvc3R1bGFudGVTZWxlY2Npb25hZG8pIHtcbiAgPGRpdiBjbGFzcz1cIm1vZGFsLW92ZXJsYXlcIiAoY2xpY2spPVwiY2VycmFyTW9kYWxQb3N0dWxhbnRlKClcIj5cbiAgICA8ZGl2IGNsYXNzPVwibW9kYWwtY29udGVudFwiIChjbGljayk9XCIkZXZlbnQuc3RvcFByb3BhZ2F0aW9uKClcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJtb2RhbC1oZWFkZXJcIj5cbiAgICAgICAgPGgzPvCfjpMgRmljaGEgZGVsIFBvc3R1bGFudGU8L2gzPlxuICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuLWNlcnJhclwiIChjbGljayk9XCJjZXJyYXJNb2RhbFBvc3R1bGFudGUoKVwiPuKclTwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgICBcbiAgICAgIDxkaXYgY2xhc3M9XCJtb2RhbC1ib2R5XCI+XG4gICAgICAgIDwhLS0gRWwgY29tcG9uZW50ZSByZXN1ZWx2ZSBzb2xvIGxhIGLDunNxdWVkYSBkZSBwZXJmaWwsIGRhdG9zIHBlcnNvbmFsZXMgeSBwcmV2aXN1YWxpemFjacOzbi9kZXNjYXJnYSBkZSBDViAtLT5cbiAgICAgICAgPGFwcC1wb3N0dWxhbnRlLXByb2ZpbGUgXG4gICAgICAgICAgW2lkUG9zdHVsYW50ZUlucHV0XT1cInBvc3R1bGFudGVTZWxlY2Npb25hZG8uaWRfcG9zdHVsYW50ZSB8fCBwb3N0dWxhbnRlU2VsZWNjaW9uYWRvLmlkXCJcbiAgICAgICAgICBbZXNNb2RvQWRtaW5dPVwidHJ1ZVwiPlxuICAgICAgICA8L2FwcC1wb3N0dWxhbnRlLXByb2ZpbGU+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzcz1cIm1vZGFsLWZvb3RlclwiPlxuICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuLXNlY3VuZGFyaW9cIiAoY2xpY2spPVwiY2VycmFyTW9kYWxQb3N0dWxhbnRlKClcIj5DZXJyYXI8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICA8L2Rpdj5cbn1cbjwvZGl2PiIsImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0LCBpbmplY3QgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENvbW1vbk1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5pbXBvcnQgeyBGb3JtQnVpbGRlciwgRm9ybUdyb3VwLCBSZWFjdGl2ZUZvcm1zTW9kdWxlLCBWYWxpZGF0b3JzLCBGb3Jtc01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcbmltcG9ydCB7IEFkbWluU2VydmljZSwgQ2F0ZWdvcmlhQWRtaW4sIFNraWxsQWRtaW4gfSBmcm9tICcuLi8uLi8uLi9zZXJ2aWNlcy9hZG1pbic7XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ2FwcC1za2lsbHMnLFxuICBzdGFuZGFsb25lOiB0cnVlLFxuICBpbXBvcnRzOiBbQ29tbW9uTW9kdWxlLCBSZWFjdGl2ZUZvcm1zTW9kdWxlLCBGb3Jtc01vZHVsZV0sXG4gIHRlbXBsYXRlVXJsOiAnLi9za2lsbHMuaHRtbCcsXG4gIHN0eWxlVXJsOiAnLi9za2lsbHMuc2Nzcydcbn0pXG5leHBvcnQgY2xhc3MgU2tpbGxzIGltcGxlbWVudHMgT25Jbml0IHtcbiAgcHJpdmF0ZSByZWFkb25seSBmYiA9IGluamVjdChGb3JtQnVpbGRlcik7XG4gIHByaXZhdGUgcmVhZG9ubHkgYWRtaW5TZXJ2aWNlID0gaW5qZWN0KEFkbWluU2VydmljZSk7XG5cbiAgY2F0ZWdvcmlhczogQ2F0ZWdvcmlhQWRtaW5bXSA9IFtdO1xuICBza2lsbHM6IFNraWxsQWRtaW5bXSA9IFtdO1xuICBza2lsbHNGaWx0cmFkYXM6IFNraWxsQWRtaW5bXSA9IFtdO1xuXG4gIGNhdGVnb3JpYVNlbGVjY2lvbmFkYUlkOiBudW1iZXIgfCAndG9kYXMnID0gJ3RvZGFzJztcbiAgdGV4dG9CdXNxdWVkYTogc3RyaW5nID0gJyc7XG5cbiAgbW9kYWxBYmllcnRvID0gZmFsc2U7XG4gIG1vZG9FZGljaW9uID0gZmFsc2U7XG4gIGlkU2tpbGxFbkVkaWNpb246IG51bWJlciB8IG51bGwgPSBudWxsO1xuICBjYXJnYW5kbyA9IGZhbHNlO1xuXG4gIHNraWxsRm9ybTogRm9ybUdyb3VwID0gdGhpcy5mYi5ncm91cCh7XG4gICAgbm9tYnJlOiBbJycsIFtWYWxpZGF0b3JzLnJlcXVpcmVkLCBWYWxpZGF0b3JzLm1pbkxlbmd0aCgyKV1dLFxuICAgIGNhdGVnb3JpYV9pZDogWycnLCBbVmFsaWRhdG9ycy5yZXF1aXJlZF1dXG4gIH0pO1xuXG4gIG5nT25Jbml0KCk6IHZvaWQge1xuICAgIHRoaXMuY2FyZ2FyQ2F0ZWdvcmlhcygpO1xuICAgIHRoaXMuY2FyZ2FyU2tpbGxzKCk7XG4gIH1cblxuICBjYXJnYXJDYXRlZ29yaWFzKCk6IHZvaWQge1xuICAgIHRoaXMuYWRtaW5TZXJ2aWNlLmdldENhdGVnb3JpYXNTa2lsbHMoKS5zdWJzY3JpYmUoe1xuICAgICAgbmV4dDogKGRhdGEpID0+ICh0aGlzLmNhdGVnb3JpYXMgPWRhdGEpLFxuICAgICAgZXJyb3I6IChlcnIpID0+IGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGFsIGNhcmdhciBjYXRlZ29yw61hcycsIGVycilcbiAgICB9KTtcbiAgfVxuICBvYnRlbmVyTm9tYnJlQ2F0ZWdvcmlhKGNhdGVnb3JpYUlkOiBudW1iZXIpOiBzdHJpbmcge1xuICBpZiAoIWNhdGVnb3JpYUlkIHx8IHRoaXMuY2F0ZWdvcmlhcy5sZW5ndGggPT09IDApIHJldHVybiAnU2luIGNhdGVnb3LDrWEnO1xuICBjb25zdCBjYXQgPSB0aGlzLmNhdGVnb3JpYXMuZmluZChjID0+IE51bWJlcihjLmlkKSA9PT0gTnVtYmVyKGNhdGVnb3JpYUlkKSk7XG4gIHJldHVybiBjYXQgPyBjYXQubm9tYnJlIDogJ1NpbiBjYXRlZ29yw61hJztcbn1cblxuICBjYXJnYXJTa2lsbHMoKTogdm9pZCB7XG4gICAgdGhpcy5jYXJnYW5kbyA9IHRydWU7XG4gICAgdGhpcy5hZG1pblNlcnZpY2UuZ2V0U2tpbGxzKCkuc3Vic2NyaWJlKHtcbiAgICAgIG5leHQ6IChkYXRhKSA9PiB7XG4gICAgICAgIHRoaXMuc2tpbGxzID0gZGF0YTtcbiAgICAgICAgdGhpcy5hcGxpY2FyRmlsdHJvcygpO1xuICAgICAgICB0aGlzLmNhcmdhbmRvID0gZmFsc2U7XG4gICAgICB9LFxuICAgICAgZXJyb3I6IChlcnIpID0+IHtcbiAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgYWwgY2FyZ2FyIHNraWxscycsIGVycik7XG4gICAgICAgIHRoaXMuY2FyZ2FuZG8gPSBmYWxzZTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuXG4gIGFwbGljYXJGaWx0cm9zKCk6IHZvaWQge1xuICAgIHRoaXMuc2tpbGxzRmlsdHJhZGFzID0gdGhpcy5za2lsbHMuZmlsdGVyKChzKSA9PiB7XG4gICAgICBjb25zdCBjb2luY2lkZUNhdGVnb3JpYSA9XG4gICAgICAgIHRoaXMuY2F0ZWdvcmlhU2VsZWNjaW9uYWRhSWQgPT09ICd0b2RhcycgfHxcbiAgICAgICAgcy5jYXRlZ29yaWFfaWQgPT09IE51bWJlcih0aGlzLmNhdGVnb3JpYVNlbGVjY2lvbmFkYUlkKTtcblxuICAgICAgY29uc3QgY29pbmNpZGVUZXh0byA9IHMubm9tYnJlXG4gICAgICAgIC50b0xvd2VyQ2FzZSgpXG4gICAgICAgIC5pbmNsdWRlcyh0aGlzLnRleHRvQnVzcXVlZGEudG9Mb3dlckNhc2UoKS50cmltKCkpO1xuXG4gICAgICByZXR1cm4gY29pbmNpZGVDYXRlZ29yaWEgJiYgY29pbmNpZGVUZXh0bztcbiAgICB9KTtcbiAgfVxuXG4gIG9uQnVzY2FyVGV4dG8oZXZlbnQ6IEV2ZW50KTogdm9pZCB7XG4gICAgdGhpcy50ZXh0b0J1c3F1ZWRhID0gKGV2ZW50LnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50KS52YWx1ZTtcbiAgICB0aGlzLmFwbGljYXJGaWx0cm9zKCk7XG4gIH1cblxuICBvblNlbGVjY2lvbmFyQ2F0ZWdvcmlhKGV2ZW50OiBFdmVudCk6IHZvaWQge1xuICAgIGNvbnN0IHZhbG9yID0gKGV2ZW50LnRhcmdldCBhcyBIVE1MU2VsZWN0RWxlbWVudCkudmFsdWU7XG4gICAgdGhpcy5jYXRlZ29yaWFTZWxlY2Npb25hZGFJZCA9IHZhbG9yID09PSAndG9kYXMnID8gJ3RvZGFzJyA6IE51bWJlcih2YWxvcik7XG4gICAgdGhpcy5hcGxpY2FyRmlsdHJvcygpO1xuICB9XG5cbiAgYWJyaXJNb2RhbENyZWFyKCk6IHZvaWQge1xuICAgIHRoaXMubW9kb0VkaWNpb24gPSBmYWxzZTtcbiAgICB0aGlzLmlkU2tpbGxFbkVkaWNpb24gPSBudWxsO1xuICAgIHRoaXMuc2tpbGxGb3JtLnJlc2V0KCk7XG4gICAgdGhpcy5tb2RhbEFiaWVydG8gPSB0cnVlO1xuICB9XG5cbiAgcHJlcGFyYXJFZGljaW9uKHNraWxsOiBTa2lsbEFkbWluKTogdm9pZCB7XG4gICAgdGhpcy5tb2RvRWRpY2lvbiA9IHRydWU7XG4gICAgdGhpcy5pZFNraWxsRW5FZGljaW9uID0gc2tpbGwuaWQ7XG4gICAgdGhpcy5za2lsbEZvcm0ucGF0Y2hWYWx1ZSh7XG4gICAgICBub21icmU6IHNraWxsLm5vbWJyZSxcbiAgICAgIGNhdGVnb3JpYV9pZDogc2tpbGwuY2F0ZWdvcmlhX2lkXG4gICAgfSk7XG4gICAgdGhpcy5tb2RhbEFiaWVydG8gPSB0cnVlO1xuICB9XG5cbiAgY2VycmFyTW9kYWwoKTogdm9pZCB7XG4gICAgdGhpcy5tb2RhbEFiaWVydG8gPSBmYWxzZTtcbiAgICB0aGlzLm1vZG9FZGljaW9uID0gZmFsc2U7XG4gICAgdGhpcy5pZFNraWxsRW5FZGljaW9uID0gbnVsbDtcbiAgICB0aGlzLnNraWxsRm9ybS5yZXNldCgpO1xuICB9XG5cbiAgZ3VhcmRhclNraWxsKCk6IHZvaWQge1xuICAgIGlmICh0aGlzLnNraWxsRm9ybS5pbnZhbGlkKSB7XG4gICAgICB0aGlzLnNraWxsRm9ybS5tYXJrQWxsQXNUb3VjaGVkKCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgcGF5bG9hZCA9IHtcbiAgICAgIG5vbWJyZTogdGhpcy5za2lsbEZvcm0udmFsdWUubm9tYnJlLFxuICAgICAgY2F0ZWdvcmlhX2lkOiBOdW1iZXIodGhpcy5za2lsbEZvcm0udmFsdWUuY2F0ZWdvcmlhX2lkKVxuICAgIH07XG5cbiAgICBpZiAodGhpcy5tb2RvRWRpY2lvbiAmJiB0aGlzLmlkU2tpbGxFbkVkaWNpb24pIHtcbiAgICAgIHRoaXMuYWRtaW5TZXJ2aWNlLmFjdHVhbGl6YXJTa2lsbCh0aGlzLmlkU2tpbGxFbkVkaWNpb24sIHBheWxvYWQpLnN1YnNjcmliZSh7XG4gICAgICAgIG5leHQ6ICgpID0+IHtcbiAgICAgICAgICB0aGlzLmNhcmdhclNraWxscygpO1xuICAgICAgICAgIHRoaXMuY2VycmFyTW9kYWwoKTtcbiAgICAgICAgfSxcbiAgICAgICAgZXJyb3I6IChlcnIpID0+IGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGFsIGFjdHVhbGl6YXIgc2tpbGw6JywgZXJyKVxuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuYWRtaW5TZXJ2aWNlLmNyZWFyU2tpbGwocGF5bG9hZCkuc3Vic2NyaWJlKHtcbiAgICAgICAgbmV4dDogKCkgPT4ge1xuICAgICAgICAgIHRoaXMuY2FyZ2FyU2tpbGxzKCk7XG4gICAgICAgICAgdGhpcy5jZXJyYXJNb2RhbCgpO1xuICAgICAgICB9LFxuICAgICAgICBlcnJvcjogKGVycikgPT4gY29uc29sZS5lcnJvcignRXJyb3IgYWwgY3JlYXIgc2tpbGw6JywgZXJyKVxuICAgICAgfSk7XG4gICAgfVxuICB9XG5cbiAgZWxpbWluYXJTa2lsbChpZDogbnVtYmVyKTogdm9pZCB7XG4gICAgaWYgKGNvbmZpcm0oJ8K/RXN0w6FzIHNlZ3VybyBkZSBlbGltaW5hciBlc3RhIGhhYmlsaWRhZD8nKSkge1xuICAgICAgdGhpcy5hZG1pblNlcnZpY2UuZWxpbWluYXJTa2lsbChpZCkuc3Vic2NyaWJlKHtcbiAgICAgICAgbmV4dDogKCkgPT4gdGhpcy5jYXJnYXJTa2lsbHMoKSxcbiAgICAgICAgZXJyb3I6IChlcnIpID0+IGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGFsIGVsaW1pbmFyIHNraWxsOicsIGVycilcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuXG59IiwiPGRpdiBjbGFzcz1cInNraWxscy1jb250YWluZXJcIj5cbiAgPGhlYWRlciBjbGFzcz1cImhlYWRlci1zZWN0aW9uXCI+XG4gICAgPGRpdj5cbiAgICAgIDxoMz7wn5ug77iPIEdlc3Rpw7NuIGRlIEhhYmlsaWRhZGVzIChTa2lsbHMpPC9oMz5cbiAgICAgIDxwPkNhdMOhbG9nbyBnbG9iYWwgZGUgY29ub2NpbWllbnRvcyB0w6ljbmljb3MgZSBpbnN0aXR1Y2lvbmFsZXMuPC9wPlxuICAgIDwvZGl2PlxuICAgIDxidXR0b24gY2xhc3M9XCJidG4tcHJpbWFyeVwiIChjbGljayk9XCJhYnJpck1vZGFsQ3JlYXIoKVwiPlxuICAgICAg4p6VIE51ZXZhIEhhYmlsaWRhZFxuICAgIDwvYnV0dG9uPlxuICA8L2hlYWRlcj5cblxuICA8IS0tIFRhYmxhIFByaW5jaXBhbCBkZSBBbmNobyBDb21wbGV0byAtLT5cbiAgPHNlY3Rpb24gY2xhc3M9XCJjYXJkLWxpc3RcIj5cbiAgICA8ZGl2IGNsYXNzPVwibGlzdC1oZWFkZXJcIj5cbiAgICAgIDxoND5MaXN0YWRvIGRlIEhhYmlsaWRhZGVzICh7eyBza2lsbHNGaWx0cmFkYXMubGVuZ3RoIH19KTwvaDQ+XG5cbiAgICAgIDxkaXYgY2xhc3M9XCJjb250cm9sZXMtYnVzcXVlZGFcIj5cbiAgICAgICAgPGlucHV0XG4gICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgIGNsYXNzPVwiaW5wdXQtc2VhcmNoXCJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIvCflI0gQnVzY2FyIHNraWxsLi4uXCJcbiAgICAgICAgICAoaW5wdXQpPVwib25CdXNjYXJUZXh0bygkZXZlbnQpXCJcbiAgICAgICAgLz5cblxuICAgICAgICA8c2VsZWN0IGNsYXNzPVwic2VsZWN0LWNhdFwiIChjaGFuZ2UpPVwib25TZWxlY2Npb25hckNhdGVnb3JpYSgkZXZlbnQpXCI+XG4gICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cInRvZGFzXCI+VG9kYXMgbGFzIGNhdGVnb3LDrWFzPC9vcHRpb24+XG4gICAgICAgICAgQGZvciAoY2F0IG9mIGNhdGVnb3JpYXM7IHRyYWNrIGNhdC5pZCkge1xuICAgICAgICAgICAgPG9wdGlvbiBbdmFsdWVdPVwiY2F0LmlkXCI+e3sgY2F0Lm5vbWJyZSB9fTwvb3B0aW9uPlxuICAgICAgICAgIH1cbiAgICAgICAgPC9zZWxlY3Q+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cblxuICAgIDxkaXYgY2xhc3M9XCJ0YWJsZS1yZXNwb25zaXZlXCI+XG4gICAgICA8dGFibGU+XG4gICAgICAgIDx0aGVhZD5cbiAgICAgICAgICA8dHI+XG4gICAgICAgICAgICA8dGg+SUQ8L3RoPlxuICAgICAgICAgICAgPHRoPkhhYmlsaWRhZDwvdGg+XG4gICAgICAgICAgICA8dGg+Q2F0ZWdvcsOtYTwvdGg+XG4gICAgICAgICAgICA8dGggY2xhc3M9XCJ0ZXh0LXJpZ2h0XCI+QWNjaW9uZXM8L3RoPlxuICAgICAgICAgIDwvdHI+XG4gICAgICAgIDwvdGhlYWQ+XG4gICAgICAgIDx0Ym9keT5cbiAgICAgICAgICBAZm9yIChza2lsbCBvZiBza2lsbHNGaWx0cmFkYXM7IHRyYWNrIHNraWxsLmlkKSB7XG4gICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgIDx0ZD4je3sgc2tpbGwuaWQgfX08L3RkPlxuICAgICAgICAgICAgICA8dGQ+PHN0cm9uZz57eyBza2lsbC5ub21icmUgfX08L3N0cm9uZz48L3RkPlxuICAgICAgICAgICAgICA8dGQ+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJiYWRnZS1jYXRcIj57eyBvYnRlbmVyTm9tYnJlQ2F0ZWdvcmlhKHNraWxsLmNhdGVnb3JpYV9pZCkgfX08L3NwYW4+XG4gICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgIDx0ZCBjbGFzcz1cInRleHQtcmlnaHRcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuLWljb24gZWRpdFwiIChjbGljayk9XCJwcmVwYXJhckVkaWNpb24oc2tpbGwpXCIgdGl0bGU9XCJFZGl0YXJcIj5cbiAgICAgICAgICAgICAgICAgIOKcj++4j1xuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJidG4taWNvbiBkZWxldGVcIiAoY2xpY2spPVwiZWxpbWluYXJTa2lsbChza2lsbC5pZClcIiB0aXRsZT1cIkVsaW1pbmFyXCI+XG4gICAgICAgICAgICAgICAgICDwn5eR77iPXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICA8L3RyPlxuICAgICAgICAgIH0gQGVtcHR5IHtcbiAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgPHRkIGNvbHNwYW49XCI0XCIgY2xhc3M9XCJlbXB0eS1zdGF0ZVwiPlxuICAgICAgICAgICAgICAgIHt7IGNhcmdhbmRvID8gJ0NhcmdhbmRvIGhhYmlsaWRhZGVzLi4uJyA6ICdObyBzZSBlbmNvbnRyYXJvbiBoYWJpbGlkYWRlcy4nIH19XG4gICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICA8L3RyPlxuICAgICAgICAgIH1cbiAgICAgICAgPC90Ym9keT5cbiAgICAgIDwvdGFibGU+XG4gICAgPC9kaXY+XG4gIDwvc2VjdGlvbj5cblxuICA8IS0tIE1PREFMIEZMT1RBTlRFIERFIFJFR0lTVFJPIC8gRURJQ0nDk04gLS0+XG4gIEBpZiAobW9kYWxBYmllcnRvKSB7XG4gICAgPGRpdiBjbGFzcz1cIm1vZGFsLWJhY2tkcm9wXCIgKGNsaWNrKT1cImNlcnJhck1vZGFsKClcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJtb2RhbC1jb250ZW50IGNhcmQtZm9ybVwiIChjbGljayk9XCIkZXZlbnQuc3RvcFByb3BhZ2F0aW9uKClcIj5cbiAgICAgICAgPGhlYWRlciBjbGFzcz1cIm1vZGFsLWhlYWRlclwiPlxuICAgICAgICAgIDxoND57eyBtb2RvRWRpY2lvbiA/ICfinI/vuI8gRWRpdGFyIEhhYmlsaWRhZCcgOiAn4p6VIE51ZXZhIEhhYmlsaWRhZCcgfX08L2g0PlxuICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzPVwiYnRuLWNsb3NlXCIgKGNsaWNrKT1cImNlcnJhck1vZGFsKClcIj7inJU8L2J1dHRvbj5cbiAgICAgICAgPC9oZWFkZXI+XG5cbiAgICAgICAgPGZvcm0gW2Zvcm1Hcm91cF09XCJza2lsbEZvcm1cIiAobmdTdWJtaXQpPVwiZ3VhcmRhclNraWxsKClcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxuICAgICAgICAgICAgPGxhYmVsIGZvcj1cIm5vbWJyZVwiPk5vbWJyZSBkZSBsYSBIYWJpbGlkYWQ8L2xhYmVsPlxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgaWQ9XCJub21icmVcIlxuICAgICAgICAgICAgICBmb3JtQ29udHJvbE5hbWU9XCJub21icmVcIlxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVqOiBBbmd1bGFyLCBQeXRob24sIFNRTC4uLlwiXG4gICAgICAgICAgICAgIFtjbGFzcy5pcy1pbnZhbGlkXT1cInNraWxsRm9ybS5nZXQoJ25vbWJyZScpPy5pbnZhbGlkICYmIHNraWxsRm9ybS5nZXQoJ25vbWJyZScpPy50b3VjaGVkXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICBAaWYgKHNraWxsRm9ybS5nZXQoJ25vbWJyZScpPy5pbnZhbGlkICYmIHNraWxsRm9ybS5nZXQoJ25vbWJyZScpPy50b3VjaGVkKSB7XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVwiZXJyb3ItbXNnXCI+RWwgbm9tYnJlIGVzIG9ibGlnYXRvcmlvIChtw61uaW1vIDIgY2FyYWN0ZXJlcykuPC9zcGFuPlxuICAgICAgICAgICAgfVxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cbiAgICAgICAgICAgIDxsYWJlbCBmb3I9XCJjYXRlZ29yaWFfaWRcIj5DYXRlZ29yw61hPC9sYWJlbD5cbiAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgaWQ9XCJjYXRlZ29yaWFfaWRcIlxuICAgICAgICAgICAgICBmb3JtQ29udHJvbE5hbWU9XCJjYXRlZ29yaWFfaWRcIlxuICAgICAgICAgICAgICBbY2xhc3MuaXMtaW52YWxpZF09XCJza2lsbEZvcm0uZ2V0KCdjYXRlZ29yaWFfaWQnKT8uaW52YWxpZCAmJiBza2lsbEZvcm0uZ2V0KCdjYXRlZ29yaWFfaWQnKT8udG91Y2hlZFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIiBkaXNhYmxlZCBzZWxlY3RlZD5TZWxlY2Npb27DoSB1bmEgY2F0ZWdvcsOtYTwvb3B0aW9uPlxuICAgICAgICAgICAgICBAZm9yIChjYXQgb2YgY2F0ZWdvcmlhczsgdHJhY2sgY2F0LmlkKSB7XG4gICAgICAgICAgICAgICAgPG9wdGlvbiBbdmFsdWVdPVwiY2F0LmlkXCI+e3sgY2F0Lm5vbWJyZSB9fTwvb3B0aW9uPlxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgIEBpZiAoc2tpbGxGb3JtLmdldCgnY2F0ZWdvcmlhX2lkJyk/LmludmFsaWQgJiYgc2tpbGxGb3JtLmdldCgnY2F0ZWdvcmlhX2lkJyk/LnRvdWNoZWQpIHtcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJlcnJvci1tc2dcIj5TZWxlY2Npb27DoSB1bmEgY2F0ZWdvcsOtYSB2w6FsaWRhLjwvc3Bhbj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWFjdGlvbnNcIj5cbiAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzPVwiYnRuLXNlY29uZGFyeVwiIChjbGljayk9XCJjZXJyYXJNb2RhbCgpXCI+XG4gICAgICAgICAgICAgIENhbmNlbGFyXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGNsYXNzPVwiYnRuLXByaW1hcnlcIiBbZGlzYWJsZWRdPVwic2tpbGxGb3JtLmludmFsaWRcIj5cbiAgICAgICAgICAgICAge3sgbW9kb0VkaWNpb24gPyAnR3VhcmRhciBDYW1iaW9zJyA6ICdDcmVhciBIYWJpbGlkYWQnIH19XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9mb3JtPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIH1cbjwvZGl2PiIsImltcG9ydCB7IEluamVjdGFibGUsIGluamVjdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSHR0cENsaWVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcbmltcG9ydCB7IE9ic2VydmFibGUgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7bWFwfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XG5cbi8vIDEuIE1PREVMT1MgREUgREFUT1MgKEFqdXN0YSBsb3Mgbm9tYnJlcyBzZWfDum4gdHUgQkQgZGUgTm9kZS5qcylcbmV4cG9ydCBpbnRlcmZhY2UgTWV0cmljYXNBZG1pbiB7XG4gIHRvdGFsT2ZlcnRhczogbnVtYmVyO1xuICB0b3RhbEVtcHJlc2FzOiBudW1iZXI7XG4gIHRvdGFsUG9zdHVsYW50ZXM6IG51bWJlcjtcbiAgdG90YWxQb3N0dWxhY2lvbmVzOiBudW1iZXI7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgRW1wcmVzYUFkbWluIHtcbiAgaWRfZW1wcmVzYTogbnVtYmVyO1xuICByYXpvblNvY2lhbDogc3RyaW5nO1xuICBjdWl0OiBzdHJpbmc7XG4gIGVtYWlsOiBzdHJpbmc7XG4gIHRlbGVmb25vPzogc3RyaW5nO1xuICBzZWN0b3I/OiBzdHJpbmc7XG4gIGVzdGFkbzogc3RyaW5nO1xuICBba2V5OiBzdHJpbmddOiBhbnk7IC8vIFBhcmEgcGVybWl0aXIgY2FtcG9zIGFkaWNpb25hbGVzIGRpbsOhbWljb3Ncbn1cbmV4cG9ydCBpbnRlcmZhY2UgT2ZlcnRhQWRtaW4ge1xuICBpZF9vZmVydGE6IG51bWJlcjtcbiAgaWRfZW1wcmVzYTogbnVtYmVyO1xuICB0aXR1bG86IHN0cmluZztcbiAgZGVzY3JpcGNpb24/OiBzdHJpbmc7XG4gIG1vZGFsaWRhZDogc3RyaW5nO1xuICBleHBlcmllbmNpYTogc3RyaW5nO1xuICBmZWNoYV9wdWJsaWNhY2lvbjogc3RyaW5nO1xuICBkaWFzX2R1cmFjaW9uOiBudW1iZXI7XG4gIHJhem9uU29jaWFsPzogc3RyaW5nO1xuICBlc3RhZG8/OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgUG9zdHVsYW50ZUFkbWluIHtcbiAgaWRfcG9zdHVsYW50ZT86IG51bWJlcjtcbiAgaWQ/OiBudW1iZXI7XG4gIG5vbWJyZXM/OiBzdHJpbmc7ICAgICAgLy8g8J+RiCBDYW1wbyBkZSB0dSBCRCAocGx1cmFsKVxuICBhcGVsbGlkb3M/OiBzdHJpbmc7ICAgIC8vIPCfkYggQ2FtcG8gZGUgdHUgQkQgKHBsdXJhbClcbiAgbm9tYnJlPzogc3RyaW5nOyAgICAgICAvLyBPcGNpb25hbCBwYXJhIGNvbXBhdGliaWxpZGFkXG4gIGFwZWxsaWRvPzogc3RyaW5nOyAgICAgLy8gT3BjaW9uYWwgcGFyYSBjb21wYXRpYmlsaWRhZFxuICBkbmk/OiBzdHJpbmc7XG4gIGxlZ2Fqbz86IHN0cmluZzsgICAgICAgLy8g8J+RiCBDYW1wbyBhZ3JlZ2Fkb1xuICBlbWFpbD86IHN0cmluZztcbiAgY2FycmVyYT86IHN0cmluZztcbiAgZXN0YWRvPzogc3RyaW5nO1xuICBba2V5OiBzdHJpbmddOiBhbnk7ICAgIC8vIFBlcm1pdGUgY2FtcG9zIGRpbsOhbWljb3MgZXh0cmFcbn1cbmV4cG9ydCBpbnRlcmZhY2UgQ2F0ZWdvcmlhQWRtaW4ge1xuICBpZDogbnVtYmVyO1xuICBub21icmU6IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBTa2lsbEFkbWluIHtcbiAgaWQ6IG51bWJlcjtcbiAgbm9tYnJlOiBzdHJpbmc7XG4gIGNhdGVnb3JpYV9pZDogbnVtYmVyO1xuICBjYXRlZ29yaWFfbm9tYnJlPzogc3RyaW5nOyAvLyBOb21icmUgZGUgbGEgY2F0ZWdvcsOtYSBwYXJhIG1vc3RyYXJcbn1cblxuZXhwb3J0IGludGVyZmFjZSBSZXNwdWVzdGFBcGkge1xuICBzdWNjZXNzOiBib29sZWFuO1xuICBtZXRyaWNhcz86IE1ldHJpY2FzQWRtaW47XG4gIGVtcHJlc2FzPzogRW1wcmVzYUFkbWluW107XG4gIG1lbnNhamU/OiBzdHJpbmc7XG4gIGNhdGVnb3JpYXM/OiBDYXRlZ29yaWFBZG1pbltdO1xuICBza2lsbHM/OiBTa2lsbEFkbWluW107XG4gIG9mZXJ0YXM/OiBPZmVydGFBZG1pbltdO1xuICBwb3N0dWxhbnRlcz86IFBvc3R1bGFudGVBZG1pbltdO1xuICBba2V5OiBzdHJpbmddOiBhbnk7IC8vIFBlcm1pdGUgY2FtcG9zIGFkaWNpb25hbGVzIGRpbsOhbWljb3Ncbn1cblxuXG4vLyAyLiBTRVJWSUNJT1xuQEluamVjdGFibGUoe1xuICBwcm92aWRlZEluOiAncm9vdCdcbn0pXG5leHBvcnQgY2xhc3MgQWRtaW5TZXJ2aWNlIHtcbiAgcHJpdmF0ZSByZWFkb25seSBodHRwID0gaW5qZWN0KEh0dHBDbGllbnQpO1xuICBwcml2YXRlIHJlYWRvbmx5IEFQSV9VUkwgPSAnaHR0cDovL2xvY2FsaG9zdDozMDAwL2FwaS9hZG1pbic7XG5cbiAgZ2V0TWV0cmljYXMoKTogT2JzZXJ2YWJsZTxNZXRyaWNhc0FkbWluPiB7XG4gICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQ8TWV0cmljYXNBZG1pbj4oYCR7dGhpcy5BUElfVVJMfS9tZXRyaWNhc2ApO1xuICB9XG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gQi4gR0VTVEnDk04gREUgRU1QUkVTQVNcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbiAgZ2V0RW1wcmVzYXMoKTogT2JzZXJ2YWJsZTxFbXByZXNhQWRtaW5bXT4ge1xuICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PEVtcHJlc2FBZG1pbltdPihgJHt0aGlzLkFQSV9VUkx9L2VtcHJlc2FzYCk7XG4gIH1cblxuICBjYW1iaWFyRXN0YWRvRW1wcmVzYShpZF9lbXByZXNhOiBudW1iZXIsIGVzdGFkbzogc3RyaW5nKTogT2JzZXJ2YWJsZTxSZXNwdWVzdGFBcGk+IHtcbiAgICByZXR1cm4gdGhpcy5odHRwLnB1dDxSZXNwdWVzdGFBcGk+KGAke3RoaXMuQVBJX1VSTH0vZW1wcmVzYS9lc3RhZG9gLCB7IGlkX2VtcHJlc2EsIGVzdGFkbyB9KTtcbiAgfVxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gQy4gR0VTVEnDk04gREUgT0ZFUlRBU1xuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgZ2V0T2ZlcnRhcygpOiBPYnNlcnZhYmxlPE9mZXJ0YUFkbWluW10+IHtcbiAgICByZXR1cm4gdGhpcy5odHRwLmdldDxPZmVydGFBZG1pbltdPihgJHt0aGlzLkFQSV9VUkx9L29mZXJ0YXNgKTtcbiAgfVxuXG4gIGVsaW1pbmFyT2ZlcnRhKGlkX29mZXJ0YTogbnVtYmVyKTogT2JzZXJ2YWJsZTxSZXNwdWVzdGFBcGk+IHtcbiAgICByZXR1cm4gdGhpcy5odHRwLmRlbGV0ZTxSZXNwdWVzdGFBcGk+KGAke3RoaXMuQVBJX1VSTH0vb2ZlcnRhLyR7aWRfb2ZlcnRhfWApO1xuICB9XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIEQuIEdFU1RJw5NOIERFIFBPU1RVTEFOVEVTXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICBnZXRQb3N0dWxhbnRlcygpOiBPYnNlcnZhYmxlPFBvc3R1bGFudGVBZG1pbltdPiB7XG4gICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQ8UG9zdHVsYW50ZUFkbWluW10+KGAke3RoaXMuQVBJX1VSTH0vcG9zdHVsYW50ZXNgKTtcbiAgfVxuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyBFLiBDQVTDgUxPR09TIFkgVEFCTEFTIE1BRVNUUkFTIChDYXRlZ29yw61hcyB5IFNraWxscylcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIGdldENhdGVnb3JpYXNTa2lsbHMoKTogT2JzZXJ2YWJsZTxDYXRlZ29yaWFBZG1pbltdPiB7XG4gICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQ8UmVzcHVlc3RhQXBpPihgJHt0aGlzLkFQSV9VUkx9L2NhdGVnb3JpYXMtc2tpbGxzYCkucGlwZShcbiAgICAgIG1hcChyZXMgPT4gcmVzLmNhdGVnb3JpYXMgfHwgW10pXG4gICAgKTtcbiAgfVxuXG4gIGdldFNraWxscygpOiBPYnNlcnZhYmxlPFNraWxsQWRtaW5bXT4ge1xuICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PFJlc3B1ZXN0YUFwaT4oYCR7dGhpcy5BUElfVVJMfS9za2lsbHNgKS5waXBlKFxuICAgICAgbWFwKHJlcyA9PiByZXMuc2tpbGxzIHx8IFtdKVxuICAgICk7XG4gIH1cblxuICAvLyBPcGNpb25hbDogc2kgbmVjZXNpdMOhcyBvYnRlbmVyIHNraWxscyBmaWx0cmFkYXMgcG9yIHVuYSBjYXRlZ29yw61hIGVuIHBhcnRpY3VsYXJcbiAgZ2V0U2tpbGxzUG9yQ2F0ZWdvcmlhKGlkQ2F0ZWdvcmlhOiBudW1iZXIpOiBPYnNlcnZhYmxlPFNraWxsQWRtaW5bXT4ge1xuICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0PFJlc3B1ZXN0YUFwaT4oYCR7dGhpcy5BUElfVVJMfS9jYXRlZ29yaWFzLyR7aWRDYXRlZ29yaWF9L3NraWxsc2ApLnBpcGUoXG4gICAgICBtYXAocmVzID0+IHJlcy5za2lsbHMgfHwgW10pXG4gICAgKTtcbiAgfVxuXG5cbiAgY3JlYXJTa2lsbChwYXlsb2FkOiB7IG5vbWJyZTogc3RyaW5nOyBjYXRlZ29yaWFfaWQ6IG51bWJlciB9KTogT2JzZXJ2YWJsZTxSZXNwdWVzdGFBcGk+IHtcbiAgICByZXR1cm4gdGhpcy5odHRwLnBvc3Q8UmVzcHVlc3RhQXBpPihgJHt0aGlzLkFQSV9VUkx9L3NraWxsc2AsIHBheWxvYWQpO1xuICB9XG5cbiAgYWN0dWFsaXphclNraWxsKGlkOiBudW1iZXIsIHBheWxvYWQ6IHsgbm9tYnJlOiBzdHJpbmc7IGNhdGVnb3JpYV9pZDogbnVtYmVyIH0pOiBPYnNlcnZhYmxlPFJlc3B1ZXN0YUFwaT4ge1xuICAgIHJldHVybiB0aGlzLmh0dHAucHV0PFJlc3B1ZXN0YUFwaT4oYCR7dGhpcy5BUElfVVJMfS9za2lsbHMvJHtpZH1gLCBwYXlsb2FkKTtcbiAgfVxuXG4gIGVsaW1pbmFyU2tpbGwoaWQ6IG51bWJlcik6IE9ic2VydmFibGU8UmVzcHVlc3RhQXBpPiB7XG4gICAgcmV0dXJuIHRoaXMuaHR0cC5kZWxldGU8UmVzcHVlc3RhQXBpPihgJHt0aGlzLkFQSV9VUkx9L3NraWxscy8ke2lkfWApO1xuICB9XG59IiwiaW1wb3J0IHsgaW5qZWN0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IENhbkFjdGl2YXRlRm4sIFJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XHJcbmltcG9ydCB7IEF1dGhTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvYXV0aC5zZXJ2aWNlJztcclxuXHJcbmV4cG9ydCBjb25zdCBhdXRoR3VhcmQ6IENhbkFjdGl2YXRlRm4gPSAocm91dGUsIHN0YXRlKSA9PiB7XHJcbiAgY29uc3QgYXV0aFNlcnZpY2UgPSBpbmplY3QoQXV0aFNlcnZpY2UpO1xyXG4gIGNvbnN0IHJvdXRlciA9IGluamVjdChSb3V0ZXIpO1xyXG5cclxuICBpZiAoYXV0aFNlcnZpY2UuaXNMb2dnZWRJbigpKSB7XHJcbiAgICByZXR1cm4gdHJ1ZTtcclxuICB9XHJcblxyXG4gIHJldHVybiByb3V0ZXIuY3JlYXRlVXJsVHJlZShbJy9zZXNpb24nXSk7XHJcbn07IiwiaW1wb3J0IHsgaW5qZWN0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IENhbkFjdGl2YXRlRm4sIFJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XHJcbmltcG9ydCB7IEF1dGhTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvYXV0aC5zZXJ2aWNlJztcclxuXHJcbmV4cG9ydCBjb25zdCBhZG1pbkd1YXJkOiBDYW5BY3RpdmF0ZUZuID0gKHJvdXRlLCBzdGF0ZSkgPT4ge1xyXG4gIGNvbnN0IGF1dGhTZXJ2aWNlID0gaW5qZWN0KEF1dGhTZXJ2aWNlKTtcclxuICBjb25zdCByb3V0ZXIgPSBpbmplY3QoUm91dGVyKTtcclxuXHJcbiAgLy8gMS4gU2kgbm8gaGF5IHNlc2nDs24gYWN0aXZhIC0+IFJlZGlyaWdpciBhIC9zZXNpb25cclxuICBpZiAoIWF1dGhTZXJ2aWNlLmlzTG9nZ2VkSW4oKSkge1xyXG4gICAgcmV0dXJuIHJvdXRlci5jcmVhdGVVcmxUcmVlKFsnL3Nlc2lvbiddKTtcclxuICB9XHJcblxyXG4gIC8vIDIuIFNpIGhheSBzZXNpw7NuIHkgZXMgQWRtaW4gLT4gUGVybWl0aXIgYWNjZXNvXHJcbiAgaWYgKGF1dGhTZXJ2aWNlLmdldFRpcG9Vc3VhcmlvKCkgPT09ICdhZG1pbicpIHtcclxuICAgIHJldHVybiB0cnVlO1xyXG4gIH1cclxuXHJcbiAgLy8gMy4gU2kgaGF5IHNlc2nDs24gcGVybyBubyBlcyBBZG1pbiAtPiBSZWRpcmlnaXIgc2Vnw7puIGVsIHJvbFxyXG4gIGNvbnN0IHJvbCA9IGF1dGhTZXJ2aWNlLmdldFRpcG9Vc3VhcmlvKCk7XHJcbiAgaWYgKHJvbCA9PT0gJ2VtcHJlc2EnKSB7XHJcbiAgICByZXR1cm4gcm91dGVyLmNyZWF0ZVVybFRyZWUoWycvZW1wcmVzYS9taXMtY2FuZGlkYXRvcyddKTtcclxuICB9XHJcblxyXG4gIHJldHVybiByb3V0ZXIuY3JlYXRlVXJsVHJlZShbJy9taXMtcG9zdHVsYWNpb25lcyddKTtcclxufTsiLCJpbXBvcnQgeyBpbmplY3QgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgQ2FuQWN0aXZhdGVGbiwgUm91dGVyIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcclxuaW1wb3J0IHsgQXV0aFNlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcy9hdXRoLnNlcnZpY2UnO1xyXG5cclxuZXhwb3J0IGNvbnN0IHBvc3R1bGFudGVHdWFyZDogQ2FuQWN0aXZhdGVGbiA9ICgpID0+IHtcclxuICBjb25zdCBhdXRoU2VydmljZSA9IGluamVjdChBdXRoU2VydmljZSk7XHJcbiAgY29uc3Qgcm91dGVyID0gaW5qZWN0KFJvdXRlcik7XHJcblxyXG4gIGlmIChhdXRoU2VydmljZS5pc0xvZ2dlZEluKCkgJiYgYXV0aFNlcnZpY2UuZ2V0VGlwb1VzdWFyaW8oKSA9PT0gJ3Bvc3R1bGFudGUnKSB7XHJcbiAgICByZXR1cm4gdHJ1ZTtcclxuICB9XHJcbiAgcmV0dXJuIHJvdXRlci5jcmVhdGVVcmxUcmVlKFsnL3Nlc2lvbiddKTtcclxufTsiLCJpbXBvcnQgeyBpbmplY3QgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgQ2FuQWN0aXZhdGVGbiwgUm91dGVyIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcclxuaW1wb3J0IHsgQXV0aFNlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcy9hdXRoLnNlcnZpY2UnO1xyXG5cclxuZXhwb3J0IGNvbnN0IGVtcHJlc2FHdWFyZDogQ2FuQWN0aXZhdGVGbiA9ICgpID0+IHtcclxuICBjb25zdCBhdXRoU2VydmljZSA9IGluamVjdChBdXRoU2VydmljZSk7XHJcbiAgY29uc3Qgcm91dGVyID0gaW5qZWN0KFJvdXRlcik7XHJcblxyXG4gIGlmIChhdXRoU2VydmljZS5pc0xvZ2dlZEluKCkgJiYgYXV0aFNlcnZpY2UuZ2V0VGlwb1VzdWFyaW8oKSA9PT0gJ2VtcHJlc2EnKSB7XHJcbiAgICByZXR1cm4gdHJ1ZTtcclxuICB9XHJcbiAgcmV0dXJuIHJvdXRlci5jcmVhdGVVcmxUcmVlKFsnL3Nlc2lvbiddKTtcclxufTsiLCJpbXBvcnQgeyBSb3V0ZXMgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xyXG5cclxuLy8gQ29tcG9uZW50ZXMgZGUgQ2FyZ2EgRGlyZWN0YSAoRWFnZXIpXHJcbmltcG9ydCB7IFByaW5jaXBhbCB9IGZyb20gJy4vcGFnaW5hL3ByaW5jaXBhbC9wcmluY2lwYWwnO1xyXG5pbXBvcnQgeyBTZXNpb24gfSBmcm9tICcuL3BhZ2luYS9zZXNpb24vc2VzaW9uJztcclxuaW1wb3J0IHsgUmVnaXN0cmFySG9tZSB9IGZyb20gJy4vcGFnaW5hL3JlZ2lzdHJhci9yZWdpc3RyYXItaG9tZS9yZWdpc3RyYXItaG9tZSc7XHJcbmltcG9ydCB7IFJlZ2lzdHJhclBvc3R1bGFudGUgfSBmcm9tICcuL3BhZ2luYS9yZWdpc3RyYXIvcmVnaXN0cmFyLXBvc3R1bGFudGUvcmVnaXN0cmFyLXBvc3R1bGFudGUnO1xyXG5pbXBvcnQgeyBSZWdpc3RyYXJFbXByZXNhIH0gZnJvbSAnLi9wYWdpbmEvcmVnaXN0cmFyL3JlZ2lzdHJhci1lbXByZXNhL3JlZ2lzdHJhci1lbXByZXNhJztcclxuaW1wb3J0IHsgT2ZlcnRhcyB9IGZyb20gJy4vcGFnaW5hL29mZXJ0YXMvb2ZlcnRhcyc7XHJcbmltcG9ydCB7IFBvc3R1bGFjaW9uZXNDb21wb25lbnQgfSBmcm9tICcuL3BhZ2luYS9wb3N0dWxhY2lvbmVzL3Bvc3R1bGFjaW9uZXMnO1xyXG5pbXBvcnQgeyBQYW5lbEFkbWluIH0gZnJvbSAnLi9wYWdpbmEvcGFuZWwtYWRtaW4vcGFuZWwtYWRtaW4nO1xyXG5cclxuLy8gR3VhcmRzIGRlIFNlZ3VyaWRhZCB5IFJvbGVzXHJcbmltcG9ydCB7IGF1dGhHdWFyZCB9IGZyb20gJy4vZ3VhcmRzL2F1dGguZ3VhcmQnO1xyXG5pbXBvcnQgeyBhZG1pbkd1YXJkIH0gZnJvbSAnLi9ndWFyZHMvYWRtaW4uZ3VhcmQnO1xyXG5pbXBvcnQgeyBwb3N0dWxhbnRlR3VhcmQgfSBmcm9tICcuL2d1YXJkcy9wb3N0dWxhbnRlLmd1YXJkJztcclxuaW1wb3J0IHsgZW1wcmVzYUd1YXJkIH0gZnJvbSAnLi9ndWFyZHMvZW1wcmVzYS5ndWFyZCc7XHJcblxyXG5leHBvcnQgY29uc3Qgcm91dGVzOiBSb3V0ZXMgPSBbXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgLy8gMS4gUlVUQVMgUMOaQkxJQ0FTIFkgQVVURU5USUNBQ0nDk05cclxuICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICB7IHBhdGg6ICcnLCBjb21wb25lbnQ6IFByaW5jaXBhbCB9LFxyXG4gIHsgcGF0aDogJ3Nlc2lvbicsIGNvbXBvbmVudDogU2VzaW9uIH0sXHJcbiAgeyBwYXRoOiAncmVnaXN0cmFyJywgY29tcG9uZW50OiBSZWdpc3RyYXJIb21lIH0sXHJcbiAgeyBwYXRoOiAncmVnaXN0cmFyLXBvc3R1bGFudGUnLCBjb21wb25lbnQ6IFJlZ2lzdHJhclBvc3R1bGFudGUgfSxcclxuICB7IHBhdGg6ICdyZWdpc3RyYXItZW1wcmVzYScsIGNvbXBvbmVudDogUmVnaXN0cmFyRW1wcmVzYSB9LFxyXG5cclxuICAvLyBDYXJ0ZWxlcmEgcMO6YmxpY2EgKGxlY3R1cmEgcGFyYSB0b2RvcylcclxuICB7IHBhdGg6ICdvZmVydGFzJywgY29tcG9uZW50OiBPZmVydGFzIH0sXHJcblxyXG5cclxuLy8gTWlzIHB1YmxpY2FjaW9uZXMgKFJldXRpbGl6YSBPZmVydGFzIGZpbHRyYW5kbyBwb3IgbGEgZW1wcmVzYSBsb2d1ZWFkYSlcclxuICB7IFxyXG4gICAgcGF0aDogJ21pcy1vZmVydGFzJywgXHJcbiAgICBjb21wb25lbnQ6IE9mZXJ0YXMsIFxyXG4gICAgY2FuQWN0aXZhdGU6IFtlbXByZXNhR3VhcmRdIFxyXG4gIH0sXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgLy8gMi4gVklTVEFTIFBST1RFR0lEQVMgREUgUEVSRklMRVMgSU5ESVZJRFVBTEVTXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAge1xyXG4gICAgcGF0aDogJ2VtcHJlc2EvOmlkJyxcclxuICAgIGxvYWRDb21wb25lbnQ6ICgpID0+XHJcbiAgICAgIGltcG9ydCgnLi9wYWdpbmEvcGVyZmlsZXMvZW1wcmVzYS1wcm9maWxlL2VtcHJlc2EtcHJvZmlsZScpLnRoZW4obSA9PiBtLkVtcHJlc2FQcm9maWxlKSxcclxuICAgIGNhbkFjdGl2YXRlOiBbYXV0aEd1YXJkXVxyXG4gIH0sXHJcbiAge1xyXG4gICAgcGF0aDogJ3Bvc3R1bGFudGUvOmlkJyxcclxuICAgIGxvYWRDb21wb25lbnQ6ICgpID0+XHJcbiAgICAgIGltcG9ydCgnLi9wYWdpbmEvcGVyZmlsZXMvcG9zdHVsYW50ZS1wcm9maWxlL3Bvc3R1bGFudGUtcHJvZmlsZScpLnRoZW4obSA9PiBtLlBvc3R1bGFudGVQcm9maWxlKSxcclxuICAgIGNhbkFjdGl2YXRlOiBbYXV0aEd1YXJkXSBcclxuICB9LFxyXG5cclxuICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAvLyAzLiBSVVRBUyBQT1IgUk9MIEVTUEVDw41GSUNPXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAgLy8gVmlzdGEgcGFyYSBlbCBQb3N0dWxhbnRlIChcIk1pcyBQb3N0dWxhY2lvbmVzXCIpXHJcbiAgeyBcclxuICAgIHBhdGg6ICdwb3N0dWxhY2lvbmVzJywgXHJcbiAgICBjb21wb25lbnQ6IFBvc3R1bGFjaW9uZXNDb21wb25lbnQsIFxyXG4gICAgY2FuQWN0aXZhdGU6IFthdXRoR3VhcmRdXHJcbiAgfSxcclxuXHJcbiAgLy8gVmlzdGEgcGFyYSBsYSBFbXByZXNhIChcIkNhbmRpZGF0b3MgZGUgdW5hIE9mZXJ0YSBjb25jcmV0YVwiKVxyXG4gIHsgXHJcbiAgICBwYXRoOiAncG9zdHVsYWNpb25lcy9vZmVydGEvOmlkT2ZlcnRhJywgXHJcbiAgICBjb21wb25lbnQ6IFBvc3R1bGFjaW9uZXNDb21wb25lbnQsIFxyXG4gICAgY2FuQWN0aXZhdGU6IFthdXRoR3VhcmRdXHJcbiAgfSxcclxuICBcclxuICB7IFxyXG4gICAgcGF0aDogJ3BhbmVsLWFkbWluJywgXHJcbiAgICBjb21wb25lbnQ6IFBhbmVsQWRtaW4sIFxyXG4gICAgY2FuQWN0aXZhdGU6IFthZG1pbkd1YXJkXSBcclxuICB9LFxyXG5cclxuICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAvLyA0LiBFRElDScOTTiBERSBQRVJGSUxFUyBZIFBBTkVMIChMYXlvdXQgY29uIFNpZGViYXIpXHJcbiAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcbiAge1xyXG4gICAgcGF0aDogJ3BlcmZpbCcsXHJcbiAgICBsb2FkQ29tcG9uZW50OiAoKSA9PiBcclxuICAgICAgaW1wb3J0KCcuL3BhZ2luYS9wZXJmaWxlcy9zaWRlYmFyL3NpZGViYXInKS50aGVuKG0gPT4gbS5TaWRlYmFyKSxcclxuICAgIGNhbkFjdGl2YXRlOiBbYXV0aEd1YXJkXSxcclxuICAgIGNoaWxkcmVuOiBbXHJcbiAgICAgIHtcclxuICAgICAgICBwYXRoOiAncG9zdHVsYW50ZScsXHJcbiAgICAgICAgbG9hZENvbXBvbmVudDogKCkgPT4gXHJcbiAgICAgICAgICBpbXBvcnQoJy4vcGFnaW5hL3BlcmZpbGVzL3Bvc3R1bGFudGUtcHJvZmlsZS9wb3N0dWxhbnRlLXByb2ZpbGUnKS50aGVuKG0gPT4gbS5Qb3N0dWxhbnRlUHJvZmlsZSksXHJcbiAgICAgICAgY2FuQWN0aXZhdGU6IFtwb3N0dWxhbnRlR3VhcmRdXHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICBwYXRoOiAnY3VycmljdWx1bScsXHJcbiAgICAgICAgbG9hZENvbXBvbmVudDogKCkgPT4gXHJcbiAgICAgICAgICBpbXBvcnQoJy4vcGFnaW5hL3BlcmZpbGVzL2N1cnJpY3VsdW0vY3VycmljdWx1bScpLnRoZW4obSA9PiBtLkN1cnJpY3VsdW0pLFxyXG4gICAgICAgIGNhbkFjdGl2YXRlOiBbcG9zdHVsYW50ZUd1YXJkXVxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgcGF0aDogJ2VtcHJlc2EnLFxyXG4gICAgICAgIGxvYWRDb21wb25lbnQ6ICgpID0+IFxyXG4gICAgICAgICAgaW1wb3J0KCcuL3BhZ2luYS9wZXJmaWxlcy9lbXByZXNhLXByb2ZpbGUvZW1wcmVzYS1wcm9maWxlJykudGhlbihtID0+IG0uRW1wcmVzYVByb2ZpbGUpLFxyXG4gICAgICAgIGNhbkFjdGl2YXRlOiBbZW1wcmVzYUd1YXJkXVxyXG4gICAgICB9LFxyXG5cclxuICAgICAgLy8g8J+RiCBSVVRBUyBERUwgQlVTQ0FET1IgSU5URUdSQURBUyBBTCBTSURFQkFSXHJcbiAgICAgIHtcclxuICAgICAgICBwYXRoOiAnZW1wcmVzYXMnLFxyXG4gICAgICAgIGxvYWRDb21wb25lbnQ6ICgpID0+IFxyXG4gICAgICAgICAgaW1wb3J0KCcuL3BhZ2luYS9idXNjYWRvci9idXNjYWRvcicpLnRoZW4obSA9PiBtLkJ1c2NhZG9yKVxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgcGF0aDogJ3Bvc3R1bGFudGVzJyxcclxuICAgICAgICBsb2FkQ29tcG9uZW50OiAoKSA9PiBcclxuICAgICAgICAgIGltcG9ydCgnLi9wYWdpbmEvYnVzY2Fkb3IvYnVzY2Fkb3InKS50aGVuKG0gPT4gbS5CdXNjYWRvcilcclxuICAgICAgfVxyXG4gICAgXVxyXG4gIH0sXHJcblxyXG4gIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gIC8vIDUuIFJFRElSRUNDScOTTiBQT1IgREVGRUNUT1xyXG4gIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gIHsgcGF0aDogJyoqJywgcmVkaXJlY3RUbzogJycgfVxyXG5dOyIsImltcG9ydCB7IEh0dHBJbnRlcmNlcHRvckZuLCBIdHRwRXJyb3JSZXNwb25zZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbi9odHRwJztcclxuaW1wb3J0IHsgaW5qZWN0LCBQTEFURk9STV9JRCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBpc1BsYXRmb3JtQnJvd3NlciB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XHJcbmltcG9ydCB7IFJvdXRlciB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XHJcbmltcG9ydCB7IGNhdGNoRXJyb3IsIHRocm93RXJyb3IgfSBmcm9tICdyeGpzJztcclxuXHJcbmV4cG9ydCBjb25zdCBhdXRoSW50ZXJjZXB0b3I6IEh0dHBJbnRlcmNlcHRvckZuID0gKHJlcSwgbmV4dCkgPT4ge1xyXG4gIGNvbnN0IHBsYXRmb3JtSWQgPSBpbmplY3QoUExBVEZPUk1fSUQpO1xyXG4gIGNvbnN0IHJvdXRlciA9IGluamVjdChSb3V0ZXIpO1xyXG5cclxuICBsZXQgdG9rZW46IHN0cmluZyB8IG51bGwgPSBudWxsO1xyXG5cclxuICBpZiAoaXNQbGF0Zm9ybUJyb3dzZXIocGxhdGZvcm1JZCkpIHtcclxuICAgIGNvbnN0IHJhd1Rva2VuID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3Rva2VuJyk7XHJcblxyXG4gICAgaWYgKHJhd1Rva2VuKSB7XHJcbiAgICAgIHRva2VuID0gcmF3VG9rZW47XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zdCB1c3VhcmlvU2VzaW9uID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3VzdWFyaW8nKTtcclxuICAgICAgaWYgKHVzdWFyaW9TZXNpb24pIHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgY29uc3QgdXNlck9iaiA9IEpTT04ucGFyc2UodXN1YXJpb1Nlc2lvbik7XHJcbiAgICAgICAgICB0b2tlbiA9IHVzZXJPYmoudG9rZW4gfHwgdXNlck9iai5qd3QgfHwgbnVsbDtcclxuICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBwYXJzZWFuZG8gdXN1YXJpbyBlbiBlbCBpbnRlcmNlcHRvcjonLCBlKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLyDwn6e5IExpbXBpZXphIGRlZmVuc2l2YTogRWxpbWluYSBjb21pbGxhcyBleHRyYSBzaSBlbCB0b2tlbiBzZSBndWFyZMOzIGNvbiBKU09OLnN0cmluZ2lmeVxyXG4gICAgaWYgKHRva2VuKSB7XHJcbiAgICAgIHRva2VuID0gdG9rZW4ucmVwbGFjZSgvXlwifFwiJC9nLCAnJykudHJpbSgpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLy8gQ2xvbmEgbGEgcGV0aWNpw7NuIGlueWVjdGFuZG8gZWwgaGVhZGVyIEF1dGhvcml6YXRpb24gc2kgZXhpc3RlIHRva2VuXHJcbiAgY29uc3QgYXV0aFJlcSA9IHRva2VuXHJcbiAgICA/IHJlcS5jbG9uZSh7XHJcbiAgICAgICAgc2V0SGVhZGVyczoge1xyXG4gICAgICAgICAgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Rva2VufWBcclxuICAgICAgICB9XHJcbiAgICAgIH0pXHJcbiAgICA6IHJlcTtcclxuXHJcbiAgcmV0dXJuIG5leHQoYXV0aFJlcSkucGlwZShcclxuICAgIGNhdGNoRXJyb3IoKGVycm9yOiBIdHRwRXJyb3JSZXNwb25zZSkgPT4ge1xyXG4gICAgICBpZiAoaXNQbGF0Zm9ybUJyb3dzZXIocGxhdGZvcm1JZCkpIHtcclxuICAgICAgICAvLyDwn5qoIDQwMTogU2VzacOzbiBleHBpcmFkYSBvIHRva2VuIG5vIHbDoWxpZG9cclxuICAgICAgICBpZiAoZXJyb3Iuc3RhdHVzID09PSA0MDEpIHtcclxuICAgICAgICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCd0b2tlbicpO1xyXG4gICAgICAgICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oJ3VzdWFyaW8nKTtcclxuXHJcbiAgICAgICAgICBpZiAocm91dGVyLnVybCAhPT0gJy9zZXNpb24nKSB7XHJcbiAgICAgICAgICAgIHJvdXRlci5uYXZpZ2F0ZShbJy9zZXNpb24nXSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBcclxuICAgICAgICAvLyDwn5SSIDQwMzogQXV0ZW50aWNhZG8gcGVybyBzaW4gbG9zIHBlcm1pc29zIHN1ZmljaWVudGVzXHJcbiAgICAgICAgZWxzZSBpZiAoZXJyb3Iuc3RhdHVzID09PSA0MDMpIHtcclxuICAgICAgICAgIGNvbnNvbGUud2FybignQWNjZXNvIGRlbmVnYWRvICg0MDMpOiBObyBjdWVudGFzIGNvbiBlbCByb2wgbmVjZXNhcmlvIHBhcmEgZXN0YSBhY2Npw7NuLicpO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgcmV0dXJuIHRocm93RXJyb3IoKCkgPT4gZXJyb3IpO1xyXG4gICAgfSlcclxuICApO1xyXG59OyIsImltcG9ydCB7IENvbXBvbmVudCwgc2lnbmFsIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IFJvdXRlck91dGxldCB9IGZyb20gJ0Bhbmd1bGFyL3JvdXRlcic7XHJcbmltcG9ydCB7IEhlYWRlciB9IGZyb20gJy4vY29tcG9uZW50ZXMvaGVhZGVyL2hlYWRlcic7XHJcbmltcG9ydCB7IEZvb3RlciB9IGZyb20gJy4vY29tcG9uZW50ZXMvZm9vdGVyL2Zvb3Rlcic7XHJcbmltcG9ydCB7IHByb3ZpZGVIdHRwQ2xpZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uL2h0dHAnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcclxuICBzZWxlY3RvcjogJ2FwcC1yb290JyxcclxuICBpbXBvcnRzOiBbUm91dGVyT3V0bGV0LCBIZWFkZXIsIEZvb3Rlcl0sXHJcbiAgdGVtcGxhdGVVcmw6ICcuL2FwcC5odG1sJyxcclxuICBzdHlsZVVybDogJy4vYXBwLnNjc3MnXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBBcHAge1xyXG4gIHByb3RlY3RlZCByZWFkb25seSB0aXRsZSA9IHNpZ25hbCgnQ29uZWN0YScpO1xyXG59XHJcbiIsIjxhcHAtaGVhZGVyPjwvYXBwLWhlYWRlcj5cclxuPG1haW4+XHJcbiAgPHJvdXRlci1vdXRsZXQ+PC9yb3V0ZXItb3V0bGV0PlxyXG48L21haW4+XHJcblxyXG48YXBwLWZvb3Rlcj48L2FwcC1mb290ZXI+IiwiaW1wb3J0IHsgQ29tcG9uZW50LCBpbmplY3QgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgUm91dGVyTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcclxuaW1wb3J0IHsgUm91dGVyTGluaywgUm91dGVyIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcclxuaW1wb3J0IHsgQXV0aFNlcnZpY2UgfSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9hdXRoLnNlcnZpY2UnO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6ICdhcHAtaGVhZGVyJyxcclxuICBzdGFuZGFsb25lOiB0cnVlLFxyXG4gIGltcG9ydHM6IFtSb3V0ZXJMaW5rXSxcclxuICB0ZW1wbGF0ZVVybDogJy4vaGVhZGVyLmh0bWwnLFxyXG4gIHN0eWxlVXJsOiAnLi9oZWFkZXIuc2NzcycsXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBIZWFkZXIge1xyXG4gIHB1YmxpYyBhdXRoU2VydmljZSA9IGluamVjdChBdXRoU2VydmljZSk7XHJcbiAgcHJpdmF0ZSByb3V0ZXI9IGluamVjdChSb3V0ZXIpO1xyXG5cclxuICBjZXJyYXJTZXNpb24oKSB7XHJcbiAgICB0aGlzLmF1dGhTZXJ2aWNlLmxvZ291dCgpO1xyXG4gICAgdGhpcy5yb3V0ZXIubmF2aWdhdGUoWycvc2VzaW9uJ10pO1xyXG4gIH1cclxuXHJcblxyXG5pclBlcmZpbCgpe1xyXG5cclxuICBjb25zdCB0aXBvID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3RpcG8nKTtcclxuXHJcbiAgaWYodGlwbyA9PT0gJ2VtcHJlc2EnKXtcclxuXHJcbiAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbJy9wZXJmaWwtZW1wcmVzYSddKTtcclxuXHJcbiAgfWVsc2UgaWYodGlwbyA9PT0gJ3Bvc3R1bGFudGUnKXtcclxuXHJcbiAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbJy9wZXJmaWwtcG9zdHVsYW50ZSddKTtcclxuXHJcbiAgfWVsc2V7XHJcblxyXG4gICAgdGhpcy5yb3V0ZXIubmF2aWdhdGUoWycvc2VzaW9uJ10pO1xyXG5cclxuICB9XHJcblxyXG59XHJcbn1cclxuIiwiPGhlYWRlcj5cclxuICAgIFxyXG48bmF2PlxyXG4gICAgPCEtLSBMb2dvIGUgSW5pY2lvIChzaWVtcHJlIHZpc2libGVzKSAtLT5cclxuICAgIDxhIHJvdXRlckxpbms9XCIvcHJpbmNpcGFsXCI+XHJcbiAgICAgIDxpbWcgc3JjPVwiTG9nb3RyYW5zLnBuZ1wiIGFsdD1cIkxvZ28gSVRCXCIgY2xhc3M9XCJsb2dvLWhlYWRlclwiPlxyXG4gICAgPC9hPiAgXHJcbiAgICA8YSByb3V0ZXJMaW5rPVwiL3ByaW5jaXBhbFwiPkluaWNpbzwvYT4gXHJcbiAgICA8YSByb3V0ZXJMaW5rPVwiL29mZXJ0YXNcIj5PcG9ydHVuaWRhZGVzPC9hPlxyXG5cclxuICAgIDwhLS0gU0kgTk8gSEFZIFNFU0nDk04gQUNUSVZBIC0tPlxyXG4gICAgQGlmICghYXV0aFNlcnZpY2UuaXNMb2dnZWRJbigpKSB7XHJcbiAgICAgIDxhIHJvdXRlckxpbms9XCIvcmVnaXN0cmFyXCI+UmVnaXN0cmFyc2U8L2E+XHJcbiAgICAgIDxhIHJvdXRlckxpbms9XCIvc2VzaW9uXCI+SW5pY2lhciBzZXNpw7NuPC9hPlxyXG4gICAgfSBcclxuICAgIDwhLS0gU0kgSEFZIFNFU0nDk04gQUNUSVZBIC0tPlxyXG4gICAgQGVsc2Uge1xyXG4gICAgICA8IS0tIFNvbG8gc2kgZXMgQWRtaW4gLS0+XHJcbiAgICAgIEBpZiAoYXV0aFNlcnZpY2UuZ2V0VGlwb1VzdWFyaW8oKSA9PT0gJ2FkbWluJykge1xyXG4gICAgICAgIDxhIHJvdXRlckxpbms9XCIvcGFuZWwtYWRtaW5cIj5QYW5lbCBBZG1pbjwvYT5cclxuICAgICAgfVxyXG5cclxuICAgICAgPCEtLSBTb2xvIHNpIGVzIFBvc3R1bGFudGUgbyBFbXByZXNhIC0tPlxyXG4gICAgICBAaWYgKGF1dGhTZXJ2aWNlLmdldFRpcG9Vc3VhcmlvKCkgPT09ICdwb3N0dWxhbnRlJyB8fCBhdXRoU2VydmljZS5nZXRUaXBvVXN1YXJpbygpID09PSAnZW1wcmVzYScpIHtcclxuICAgICAgICA8YSByb3V0ZXJMaW5rPVwiL3BlcmZpbFwiPklyIGFsIFBlcmZpbDwvYT5cclxuICAgICAgfVxyXG5cclxuICAgICAgPCEtLSBPcGNpw7NuIHBhcmEgc2FsaXIgLS0+XHJcbiAgICAgIDxhIChjbGljayk9XCJjZXJyYXJTZXNpb24oKVwiIHN0eWxlPVwiY3Vyc29yOiBwb2ludGVyO1wiPkNlcnJhciBzZXNpw7NuPC9hPlxyXG4gICAgfVxyXG4gIDwvbmF2PlxyXG5cclxuPC9oZWFkZXI+XHJcbiIsImltcG9ydCB7IENvbXBvbmVudCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdhcHAtZm9vdGVyJyxcbiAgaW1wb3J0czogW10sXG4gIHRlbXBsYXRlVXJsOiAnLi9mb290ZXIuaHRtbCcsXG4gIHN0eWxlVXJsOiAnLi9mb290ZXIuc2NzcycsXG59KVxuZXhwb3J0IGNsYXNzIEZvb3RlciB7fVxuIiwiPGZvb3Rlcj5cblxuPGg0PiZjb3B5OyAyMDI2IE51ZXN0cm8gU2lzdGVtYSBkZSBJbnRlcm1lZGlhY2nDs24gTGFib3JhbC4gVG9kb3MgbG9zIGRlcmVjaG9zIHJlc2VydmFkb3MuPC9oND5cbjxwPkNvbnRhY3RvOiA8YSBocmVmPVwibWFpbHRvOmluZm9AbnVlc3Ryb3Npc3RlbWEuY29tXCI+aW5mb0BudWVzdHJvc2lzdGVtYS5jb208L2E+PC9wPlxuXG48L2Zvb3Rlcj4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLFNBQVMsNEJBQTRCOzs7QUNBckMsU0FBNEIsb0NBQW9DLGlCQUFpQjtBQUNqRixTQUFTLHFCQUFxQjtBQUM5QixTQUFTLG1CQUFtQixXQUFXLHdCQUF3QjtBQUMvRCxTQUFTLDBCQUEwQjtBQUNuQyxPQUFPLGNBQWM7OztBQ0pyQixTQUFTLGlCQUFpQjtBQUMxQixTQUFTLGtCQUFrQjs7Ozs7Ozs7QUNzQ25CLElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUEsRUFBdUIsR0FBQSxPQUFBLEVBQUE7QUFDSSxJQUFBLG9CQUFBLENBQUE7QUFBZ0IsSUFBQSwwQkFBQTtBQUN6QyxJQUFBLDRCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQXdCLElBQUEsb0JBQUEsQ0FBQTtBQUFnQixJQUFBLDBCQUFBLEVBQU07Ozs7QUFEckIsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSxRQUFBLEtBQUE7QUFDRCxJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLFFBQUEsS0FBQTs7Ozs7QUFlMUIsSUFBQSw0QkFBQSxHQUFBLE9BQUEsRUFBQSxFQUF1QixHQUFBLE9BQUEsRUFBQTtBQUNJLElBQUEsb0JBQUEsQ0FBQTtBQUFnQixJQUFBLDBCQUFBO0FBQ3pDLElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDRSxJQUFBLHVCQUFBLEdBQUEsR0FBQTtBQUNGLElBQUEsMEJBQUE7QUFDQSxJQUFBLDRCQUFBLEdBQUEsSUFBQTtBQUFJLElBQUEsb0JBQUEsQ0FBQTtBQUFpQixJQUFBLDBCQUFBO0FBQ3JCLElBQUEsNEJBQUEsR0FBQSxHQUFBO0FBQUcsSUFBQSxvQkFBQSxDQUFBO0FBQXNCLElBQUEsMEJBQUEsRUFBSTs7Ozs7QUFMSixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLFlBQUEsQ0FBQTtBQUVwQixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLHdCQUFBLDRCQUFBLGFBQUEsUUFBQSxLQUFBLENBQWlDO0FBRWxDLElBQUEsdUJBQUEsQ0FBQTtBQUFBLElBQUEsK0JBQUEsUUFBQSxNQUFBO0FBQ0QsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSxRQUFBLFdBQUE7Ozs7O0FBc0JDLElBQUEsNEJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBc0IsSUFBQSxvQkFBQSxDQUFBO0FBQVMsSUFBQSwwQkFBQTs7OztBQUFULElBQUEsdUJBQUE7QUFBQSxJQUFBLCtCQUFBLE1BQUE7Ozs7O0FBUDVCLElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUEsRUFBbUMsR0FBQSxPQUFBLEVBQUEsRUFDTixHQUFBLElBQUE7QUFDckIsSUFBQSxvQkFBQSxDQUFBO0FBQW1CLElBQUEsMEJBQUE7QUFDdkIsSUFBQSw0QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUE2QixJQUFBLG9CQUFBLENBQUE7QUFBb0IsSUFBQSwwQkFBQSxFQUFPO0FBRTFELElBQUEsNEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFDRSxJQUFBLDhCQUFBLEdBQUEsaUNBQUEsR0FBQSxHQUFBLFFBQUEsSUFBQSxzQ0FBQTtBQUdGLElBQUEsMEJBQUE7QUFDQSxJQUFBLDRCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQ0UsSUFBQSxvQkFBQSxJQUFBLGVBQUE7QUFBWSxJQUFBLHVCQUFBLElBQUEsS0FBQSxFQUFBO0FBQ2QsSUFBQSwwQkFBQSxFQUFTOzs7O0FBVkgsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSxVQUFBLE1BQUE7QUFDeUIsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSxVQUFBLE9BQUE7QUFHN0IsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxVQUFBLFdBQUE7QUFJNkIsSUFBQSx1QkFBQSxDQUFBO0FBQUEsSUFBQSx3QkFBQSxjQUFBLDZCQUFBLEdBQUEsR0FBQSxDQUFBLEVBQTJCLGVBQUEsNkJBQUEsR0FBQSxLQUFBLFVBQUEsRUFBQSxDQUFBOzs7OztBQUs1RCxJQUFBLDRCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQXVCLElBQUEsb0JBQUEsR0FBQSwyRUFBQTtBQUEyRCxJQUFBLDBCQUFBOzs7OztBQTBFOUUsSUFBQSw0QkFBQSxHQUFBLE9BQUEsRUFBQSxFQUEyQixHQUFBLEdBQUE7QUFDdEIsSUFBQSxvQkFBQSxDQUFBO0FBQW1CLElBQUEsMEJBQUEsRUFBSTs7OztBQUF2QixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLE9BQUEsU0FBQTs7Ozs7O0FBVFQsSUFBQSw0QkFBQSxHQUFBLE9BQUEsRUFBQSxFQUF3RCxHQUFBLFVBQUEsRUFBQTtBQUV6QixJQUFBLHdCQUFBLFNBQUEsU0FBQSxxREFBQTtBQUFBLFlBQUEsWUFBQSwyQkFBQSxHQUFBLEVBQUE7QUFBQSxZQUFBLFNBQUEsMkJBQUE7QUFBQSxhQUFBLHlCQUFTLE9BQUEsVUFBQSxTQUFBLENBQWlCO0lBQUEsQ0FBQTtBQUNyRCxJQUFBLDRCQUFBLEdBQUEsTUFBQTtBQUFNLElBQUEsb0JBQUEsQ0FBQTtBQUFrQixJQUFBLDBCQUFBO0FBQ3hCLElBQUEsdUJBQUEsR0FBQSxLQUFBLEVBQUE7QUFDRixJQUFBLDBCQUFBO0FBRUEsSUFBQSxpQ0FBQSxHQUFBLDBDQUFBLEdBQUEsR0FBQSxPQUFBLEVBQUE7QUFNRixJQUFBLDBCQUFBOzs7O0FBYnNCLElBQUEseUJBQUEsZUFBQSxPQUFBLE9BQUE7QUFHWixJQUFBLHVCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLE9BQUEsUUFBQTtBQUNjLElBQUEsdUJBQUE7QUFBQSxJQUFBLHlCQUFBLG1CQUFBLENBQUEsT0FBQSxPQUFBLEVBQXNDLGlCQUFBLE9BQUEsT0FBQTtBQUc1RCxJQUFBLHVCQUFBO0FBQUEsSUFBQSwyQkFBQSxPQUFBLFVBQUEsSUFBQSxFQUFBOzs7QUR4SUosSUFBTyxZQUFQLE1BQU8sV0FBUzs7RUFFcEIsZUFBOEI7SUFDNUIsRUFBRSxPQUFPLE9BQU8sT0FBTyxxQkFBb0I7SUFDM0MsRUFBRSxPQUFPLE9BQU8sT0FBTyx1QkFBc0I7SUFDN0MsRUFBRSxPQUFPLFFBQVEsT0FBTyxzQkFBcUI7SUFDN0MsRUFBRSxPQUFPLE9BQU8sT0FBTyx5QkFBd0I7OztFQUlqRCxRQUFnQjtJQUNkO01BQ0UsT0FBTztNQUNQLFFBQVE7TUFDUixhQUFhOztJQUdmO01BQ0UsT0FBTztNQUNQLFFBQVE7TUFDUixhQUFhOztJQUdmO01BQ0UsT0FBTztNQUNQLFFBQVE7TUFDUixhQUFhOzs7OztFQU9qQixvQkFBdUM7SUFDckM7TUFDRSxJQUFJO01BQ0osUUFBUTtNQUNSLFNBQVM7TUFDVCxhQUFhLENBQUMsV0FBVyxjQUFjLEtBQUs7O0lBRTlDO01BQ0UsSUFBSTtNQUNKLFFBQVE7TUFDUixTQUFTO01BQ1QsYUFBYSxDQUFDLFFBQVEsWUFBWTs7OztFQUt0QyxPQUFPO0lBQ0w7TUFDRSxVQUFVO01BQ1YsV0FBVztNQUNYLFNBQVM7O0lBRVg7TUFDRSxVQUFVO01BQ1YsV0FBVztNQUNYLFNBQVM7O0lBRVg7TUFDRSxVQUFVO01BQ1YsV0FBVztNQUNYLFNBQVM7Ozs7RUFLYixVQUFVLE9BQWE7QUFDckIsU0FBSyxLQUFLLEtBQUssRUFBRSxVQUFVLENBQUMsS0FBSyxLQUFLLEtBQUssRUFBRTtFQUMvQzs7cUNBdEVXLFlBQVM7RUFBQTs0RUFBVCxZQUFTLFdBQUEsQ0FBQSxDQUFBLGVBQUEsQ0FBQSxHQUFBLE9BQUEsS0FBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxtQkFBQSxHQUFBLENBQUEsR0FBQSxjQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxjQUFBLEdBQUEsQ0FBQSxjQUFBLFlBQUEsR0FBQSxvQkFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxHQUFBLENBQUEsR0FBQSxhQUFBLEdBQUEsQ0FBQSxPQUFBLGlCQUFBLE9BQUEsZUFBQSxHQUFBLG9CQUFBLEdBQUEsQ0FBQSxHQUFBLGdCQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsbUJBQUEsR0FBQSxTQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSxlQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLDRCQUFBLEdBQUEsQ0FBQSxHQUFBLHlCQUFBLEdBQUEsQ0FBQSxHQUFBLHVCQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEsbUJBQUEsR0FBQSxDQUFBLGNBQUEsWUFBQSxHQUFBLGdCQUFBLEdBQUEsQ0FBQSxHQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsbUJBQUEsR0FBQSxDQUFBLEdBQUEsY0FBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsZ0JBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLHNCQUFBLEdBQUEsQ0FBQSxHQUFBLHNCQUFBLEdBQUEsQ0FBQSxjQUFBLGNBQUEsR0FBQSxzQkFBQSxrQkFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLGNBQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxHQUFBLENBQUEsR0FBQSxlQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsR0FBQSxhQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxhQUFBLEdBQUEsQ0FBQSxHQUFBLGVBQUEsR0FBQSxDQUFBLEdBQUEsZ0JBQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxHQUFBLENBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLGtCQUFBLEdBQUEsY0FBQSxhQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsZ0JBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxHQUFBLENBQUEsR0FBQSxnQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxHQUFBLENBQUEsR0FBQSxlQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsbUJBQUEsSUFBQSxLQUFBO0FBQUEsUUFBQSxLQUFBLEdBQUE7QUM3QnRCLE1BQUEsNEJBQUEsR0FBQSxPQUFBLENBQUEsRUFBK0IsR0FBQSxVQUFBLENBQUEsRUFFQSxHQUFBLE9BQUEsQ0FBQSxFQUNELEdBQUEsUUFBQSxDQUFBO0FBQ0MsTUFBQSxvQkFBQSxHQUFBLHlDQUFBO0FBQW9DLE1BQUEsMEJBQUE7QUFDN0QsTUFBQSw0QkFBQSxHQUFBLElBQUE7QUFBSSxNQUFBLG9CQUFBLEdBQUEsZ0NBQUE7QUFBMkIsTUFBQSwwQkFBQTtBQUUvQixNQUFBLDRCQUFBLEdBQUEsSUFBQTtBQUFJLE1BQUEsb0JBQUEsR0FBQSwyQ0FBQTtBQUF5QyxNQUFBLDBCQUFBO0FBRTdDLE1BQUEsNEJBQUEsR0FBQSxHQUFBO0FBQ0UsTUFBQSxvQkFBQSxJQUFBLHdFQUFBO0FBQ0EsTUFBQSw0QkFBQSxJQUFBLFFBQUE7QUFBUSxNQUFBLG9CQUFBLElBQUEseUJBQUE7QUFBb0IsTUFBQSwwQkFBQTtBQUFVLE1BQUEsb0JBQUEsSUFBQSxLQUFBO0FBQUUsTUFBQSw0QkFBQSxJQUFBLFFBQUE7QUFBUSxNQUFBLG9CQUFBLElBQUEseUJBQUE7QUFBdUIsTUFBQSwwQkFBQTtBQUN2RSxNQUFBLG9CQUFBLElBQUEsMEZBQUE7QUFDRixNQUFBLDBCQUFBO0FBRUEsTUFBQSw0QkFBQSxJQUFBLE9BQUEsQ0FBQSxFQUEwQixJQUFBLFVBQUEsQ0FBQTtBQUV0QixNQUFBLG9CQUFBLElBQUEsbUNBQUE7QUFBZ0MsTUFBQSx1QkFBQSxJQUFBLEtBQUEsQ0FBQTtBQUNsQyxNQUFBLDBCQUFBLEVBQVMsRUFDTDtBQUdSLE1BQUEsNEJBQUEsSUFBQSxPQUFBLENBQUEsRUFBeUIsSUFBQSxPQUFBLENBQUE7QUFFekIsTUFBQSx1QkFBQSxJQUFBLE9BQUEsQ0FBQTtBQUVBLE1BQUEsNEJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDRSxNQUFBLHVCQUFBLElBQUEsS0FBQSxFQUFBO0FBQ0EsTUFBQSw0QkFBQSxJQUFBLE1BQUE7QUFBTSxNQUFBLG9CQUFBLElBQUEscUJBQUE7QUFBZ0IsTUFBQSwwQkFBQSxFQUFPLEVBQ3pCLEVBRUYsRUFDRjtBQUlKLE1BQUEsNEJBQUEsSUFBQSxXQUFBLEVBQUEsRUFBK0IsSUFBQSxPQUFBLEVBQUE7QUFFM0IsTUFBQSw4QkFBQSxJQUFBLDJCQUFBLEdBQUEsR0FBQSxPQUFBLElBQUEsVUFBQTtBQU1GLE1BQUEsMEJBQUEsRUFBTTtBQUlSLE1BQUEsNEJBQUEsSUFBQSxXQUFBLEVBQUEsRUFBK0IsSUFBQSxPQUFBLEVBQUEsRUFDRixJQUFBLElBQUE7QUFDckIsTUFBQSxvQkFBQSxJQUFBLHVCQUFBO0FBQWUsTUFBQSwwQkFBQTtBQUNuQixNQUFBLDRCQUFBLElBQUEsS0FBQSxFQUFBO0FBQXFCLE1BQUEsb0JBQUEsSUFBQSw0REFBQTtBQUF1RCxNQUFBLDBCQUFBLEVBQUk7QUFHbEYsTUFBQSw0QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNFLE1BQUEsOEJBQUEsSUFBQSwyQkFBQSxHQUFBLEdBQUEsT0FBQSxJQUFBLG1DQUFBO0FBVUYsTUFBQSwwQkFBQSxFQUFNO0FBSVIsTUFBQSw0QkFBQSxJQUFBLFdBQUEsRUFBQSxFQUE0QyxJQUFBLE9BQUEsRUFBQSxFQUNmLElBQUEsSUFBQTtBQUNyQixNQUFBLG9CQUFBLElBQUEsMEJBQUE7QUFBd0IsTUFBQSwwQkFBQTtBQUM1QixNQUFBLDRCQUFBLElBQUEsS0FBQSxFQUFBO0FBQXFCLE1BQUEsb0JBQUEsSUFBQSwyRUFBQTtBQUFzRSxNQUFBLDBCQUFBLEVBQUk7QUFHakcsTUFBQSw0QkFBQSxJQUFBLE9BQUEsRUFBQTtBQUNFLE1BQUEsOEJBQUEsSUFBQSwyQkFBQSxJQUFBLEdBQUEsT0FBQSxJQUFBLFlBQUEsT0FBQSxnQ0FBQSxHQUFBLEdBQUEsS0FBQSxFQUFBO0FBa0JGLE1BQUEsMEJBQUE7QUFFQSxNQUFBLDRCQUFBLElBQUEsT0FBQSxFQUFBLEVBQStCLElBQUEsVUFBQSxFQUFBO0FBQ3dCLE1BQUEsb0JBQUEsSUFBQSx1QkFBQTtBQUFxQixNQUFBLDBCQUFBLEVBQVMsRUFDL0U7QUFHUixNQUFBLDRCQUFBLElBQUEsV0FBQSxFQUFBLEVBQWlDLElBQUEsT0FBQSxFQUFBLEVBQ0osSUFBQSxJQUFBO0FBQ3JCLE1BQUEsb0JBQUEsSUFBQSw0Q0FBQTtBQUFvQyxNQUFBLDBCQUFBO0FBQ3hDLE1BQUEsNEJBQUEsSUFBQSxLQUFBLEVBQUE7QUFBcUIsTUFBQSxvQkFBQSxJQUFBLDhFQUFBO0FBQXNFLE1BQUEsMEJBQUEsRUFBSTtBQUdqRyxNQUFBLDRCQUFBLElBQUEsT0FBQSxFQUFBLEVBQTBCLElBQUEsT0FBQSxFQUFBLEVBRUEsSUFBQSxPQUFBLEVBQUE7QUFFcEIsTUFBQSx1QkFBQSxJQUFBLEtBQUEsRUFBQTtBQUNGLE1BQUEsMEJBQUE7QUFDQSxNQUFBLDRCQUFBLElBQUEsSUFBQTtBQUFJLE1BQUEsb0JBQUEsSUFBQSxzQkFBQTtBQUFvQixNQUFBLDBCQUFBO0FBQ3hCLE1BQUEsNEJBQUEsSUFBQSxHQUFBO0FBQUcsTUFBQSxvQkFBQSxJQUFBLDBLQUFBO0FBQXNKLE1BQUEsMEJBQUEsRUFBSTtBQUcvSixNQUFBLDRCQUFBLElBQUEsT0FBQSxFQUFBLEVBQWtDLElBQUEsT0FBQSxFQUFBO0FBRTlCLE1BQUEsdUJBQUEsSUFBQSxLQUFBLEVBQUE7QUFDRixNQUFBLDBCQUFBO0FBQ0EsTUFBQSw0QkFBQSxJQUFBLElBQUE7QUFBSSxNQUFBLG9CQUFBLElBQUEsc0JBQUE7QUFBb0IsTUFBQSwwQkFBQTtBQUN4QixNQUFBLDRCQUFBLElBQUEsR0FBQTtBQUFHLE1BQUEsb0JBQUEsSUFBQSw4SkFBQTtBQUFnSixNQUFBLDBCQUFBLEVBQUk7QUFHekosTUFBQSw0QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUF3QixJQUFBLE9BQUEsRUFBQTtBQUVwQixNQUFBLHVCQUFBLElBQUEsS0FBQSxFQUFBO0FBQ0YsTUFBQSwwQkFBQTtBQUNBLE1BQUEsNEJBQUEsSUFBQSxJQUFBO0FBQUksTUFBQSxvQkFBQSxJQUFBLGtCQUFBO0FBQWdCLE1BQUEsMEJBQUE7QUFDcEIsTUFBQSw0QkFBQSxJQUFBLEdBQUE7QUFBRyxNQUFBLG9CQUFBLElBQUEsK0pBQUE7QUFBMEosTUFBQSwwQkFBQSxFQUFJLEVBQzdKLEVBRUY7QUFJUixNQUFBLDRCQUFBLElBQUEsV0FBQSxFQUFBLEVBQXNDLElBQUEsT0FBQSxFQUFBLEVBQ0YsSUFBQSxLQUFBLEVBQzNCLElBQUEsUUFBQSxDQUFBO0FBQ3NCLE1BQUEsb0JBQUEsSUFBQSxlQUFBO0FBQWEsTUFBQSwwQkFBQTtBQUN0QyxNQUFBLDRCQUFBLElBQUEsSUFBQTtBQUFJLE1BQUEsb0JBQUEsSUFBQSxrREFBQTtBQUF1QyxNQUFBLDBCQUFBO0FBQzNDLE1BQUEsNEJBQUEsSUFBQSxHQUFBO0FBQUcsTUFBQSxvQkFBQSxJQUFBLGtKQUFBO0FBQXVJLE1BQUEsMEJBQUEsRUFBSTtBQUVoSixNQUFBLDRCQUFBLElBQUEsVUFBQSxFQUFBO0FBQ0UsTUFBQSxvQkFBQSxJQUFBLHVCQUFBO0FBQW9CLE1BQUEsdUJBQUEsSUFBQSxLQUFBLEVBQUE7QUFDdEIsTUFBQSwwQkFBQSxFQUFTLEVBQ0w7QUFHUixNQUFBLDRCQUFBLElBQUEsV0FBQSxFQUFBLEVBQTZCLElBQUEsT0FBQSxFQUFBLEVBQ0EsSUFBQSxJQUFBO0FBQ3JCLE1BQUEsb0JBQUEsSUFBQSxzQkFBQTtBQUFvQixNQUFBLDBCQUFBO0FBQ3hCLE1BQUEsNEJBQUEsSUFBQSxLQUFBLEVBQUE7QUFBcUIsTUFBQSxvQkFBQSxJQUFBLGtEQUFBO0FBQTZDLE1BQUEsMEJBQUEsRUFBSTtBQUd4RSxNQUFBLDRCQUFBLEtBQUEsT0FBQSxFQUFBO0FBQ0UsTUFBQSw4QkFBQSxLQUFBLDRCQUFBLEdBQUEsR0FBQSxPQUFBLElBQUEsbUNBQUE7QUFnQkYsTUFBQSwwQkFBQSxFQUFNLEVBQ0U7OztBQXhJTixNQUFBLHVCQUFBLEVBQUE7QUFBQSxNQUFBLHdCQUFBLElBQUEsWUFBQTtBQWlCQSxNQUFBLHVCQUFBLENBQUE7QUFBQSxNQUFBLHdCQUFBLElBQUEsS0FBQTtBQXFCQSxNQUFBLHVCQUFBLENBQUE7QUFBQSxNQUFBLHdCQUFBLElBQUEsaUJBQUE7QUFpRkEsTUFBQSx1QkFBQSxFQUFBO0FBQUEsTUFBQSx3QkFBQSxJQUFBLElBQUE7O29CRHJJTSxVQUFVLEdBQUEsUUFBQSxDQUFBLHNtZUFBQSxFQUFBLENBQUE7OzsrRUFLVCxXQUFTLENBQUE7VUFSckI7dUJBQ1csaUJBQWUsWUFDYixNQUFJLFNBQ1AsQ0FBQyxVQUFVLEdBQUMsVUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7U0FBQSxRQUFBLENBQUEsdW1ZQUFBLEVBQUEsQ0FBQTs7OztnRkFLVixXQUFTLEVBQUEsV0FBQSxhQUFBLFVBQUEscUNBQUEsWUFBQSxHQUFBLENBQUE7QUFBQSxHQUFBOzs7Ozs7OzhEQUFULFdBQVMsRUFBQSxTQUFBLENBQUEsRUFBQSxHQUFBLENBQUEsWUFBQSxTQUFBLEdBQUEsYUFBQSxFQUFBLENBQUE7RUFBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsY0FBQSxrQkFBQSxLQUFBLElBQUEsQ0FBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsZUFBQSxZQUFBLE9BQUEsWUFBQSxJQUFBLEdBQUEsNEJBQUEsT0FBQSxFQUFBLE9BQUEsTUFBQSxrQkFBQSxFQUFBLFNBQUEsQ0FBQTtBQUFBLEdBQUE7OztBRTdCdEIsU0FBUyxhQUFBQSxZQUFXLGNBQWM7QUFDbEMsU0FBUyxXQUFXLGFBQWEsWUFBWSwyQkFBMkI7QUFDeEUsU0FBUyxjQUFBQyxhQUFZLGNBQWM7Ozs7O0FDd0R6QixJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQ0UsSUFBQSxxQkFBQSxHQUFBLGdDQUFBO0FBQ0EsSUFBQSx3QkFBQSxHQUFBLElBQUE7QUFDQSxJQUFBLHFCQUFBLEdBQUEsb0NBQUE7QUFDQSxJQUFBLHdCQUFBLEdBQUEsSUFBQTtBQUNBLElBQUEscUJBQUEsR0FBQSx1QkFBQTtBQUNBLElBQUEsd0JBQUEsR0FBQSxJQUFBO0FBQ0EsSUFBQSxxQkFBQSxHQUFBLGlDQUFBO0FBQ0YsSUFBQSwyQkFBQTs7O0FEdERKLElBQU8sU0FBUCxNQUFPLFFBQU07O0VBR1QsY0FBYyxPQUFPLFdBQVc7RUFDaEMsU0FBUyxPQUFPLE1BQU07O0VBRzlCLGtCQUFrQjtFQUVsQixpQkFBYztBQUNaLFNBQUssa0JBQWtCLENBQUMsS0FBSztFQUMvQjs7RUFHQSxZQUFZLElBQUksVUFBVTtJQUN4QixPQUFPLElBQUksWUFBWSxJQUFJO01BQ3pCLFdBQVc7TUFDWCxXQUFXO0tBQ1o7SUFDRCxVQUFVLElBQUksWUFBWSxJQUFJO01BQzVCLFdBQVc7TUFDWCxXQUFXLFVBQVUsQ0FBQztNQUN0QixXQUFXLFFBQVEseUJBQXlCO0tBQzdDO0dBQ0Y7O0VBR0QsV0FBUTtBQUNOLFFBQUksS0FBSyxVQUFVLE9BQU87QUFDeEIsWUFBTSxlQUFlLEtBQUssVUFBVTtBQUVwQyxjQUFRLElBQUksK0JBQStCLGFBQWEsS0FBSztBQUU3RCxXQUFLLFlBQVksTUFBTSxZQUFZLEVBQUUsVUFBVTtRQUM3QyxNQUFNLENBQUMsUUFBWTtBQUNqQixrQkFBUSxJQUFJLGtEQUE0QyxHQUFHO0FBRTNELGNBQUksSUFBSSxTQUFTO0FBRWYseUJBQWEsUUFBUSxTQUFTLElBQUksS0FBSztBQUN2Qyx5QkFBYSxRQUFRLFFBQVEsSUFBSSxJQUFJO0FBQ3JDLHlCQUFhLFFBQVEsUUFBUSxLQUFLLFVBQVUsSUFBSSxJQUFJLENBQUM7QUFHckQsZ0JBQUksSUFBSSxTQUFTLFNBQVM7QUFDeEIsb0JBQU0sbUNBQWdDO0FBQ3RDLG1CQUFLLE9BQU8sU0FBUyxDQUFDLGNBQWMsQ0FBQztZQUN2QyxXQUNTLElBQUksU0FBUyxXQUFXO0FBQy9CLG9CQUFNLHlCQUFzQjtBQUM1QixtQkFBSyxPQUFPLFNBQVMsQ0FBQywyQkFBMkIsQ0FBQztZQUNwRCxXQUNTLElBQUksU0FBUyxjQUFjO0FBQ2xDLG9CQUFNLDhCQUEyQjtBQUNqQyxtQkFBSyxPQUFPLFNBQVMsQ0FBQyxVQUFVLENBQUM7WUFDbkMsT0FDSztBQUNILG9CQUFNLG1CQUFnQjtBQUN0QixtQkFBSyxPQUFPLFNBQVMsQ0FBQyxHQUFHLENBQUM7WUFDNUI7VUFDRjtRQUNGO1FBRUEsT0FBTyxDQUFDLFFBQU87QUFDYixrQkFBUSxNQUFNLHNCQUFzQixHQUFHO0FBQ3ZDLGdCQUNFLGFBQ0MsSUFBSSxPQUFPLFdBQVcsK0JBQTRCO1FBRXZEO09BQ0Q7SUFDSCxPQUFPO0FBQ0wsV0FBSyxVQUFVLGlCQUFnQjtBQUMvQixZQUFNLCtDQUErQztJQUN2RDtFQUNGOztxQ0EzRVcsU0FBTTtFQUFBOzZFQUFOLFNBQU0sV0FBQSxDQUFBLENBQUEsWUFBQSxDQUFBLEdBQUEsT0FBQSxJQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLHNCQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEsY0FBQSxHQUFBLENBQUEsT0FBQSxzQkFBQSxPQUFBLGVBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxZQUFBLFdBQUEsR0FBQSxDQUFBLFFBQUEsU0FBQSxtQkFBQSxTQUFBLGVBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxvQkFBQSxHQUFBLENBQUEsbUJBQUEsWUFBQSxlQUFBLG9CQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxPQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxHQUFBLFVBQUEsR0FBQSxDQUFBLEdBQUEsbUJBQUEsR0FBQSxDQUFBLGNBQUEsY0FBQSxHQUFBLFdBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxnQkFBQSxJQUFBLEtBQUE7QUFBQSxRQUFBLEtBQUEsR0FBQTtBQ1puQixNQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBLEVBQWtDLEdBQUEsT0FBQSxDQUFBLEVBR1AsR0FBQSxPQUFBLENBQUEsRUFDRyxHQUFBLElBQUE7QUFFcEIsTUFBQSxxQkFBQSxHQUFBLG1CQUFBO0FBQWlCLE1BQUEsMkJBQUE7QUFFckIsTUFBQSw2QkFBQSxHQUFBLEdBQUE7QUFDRSxNQUFBLHFCQUFBLEdBQUEsMElBQUE7QUFFRixNQUFBLDJCQUFBO0FBRUEsTUFBQSx3QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUtGLE1BQUEsMkJBQUEsRUFBTTtBQUlSLE1BQUEsNkJBQUEsR0FBQSxPQUFBLENBQUEsRUFBeUIsR0FBQSxPQUFBLENBQUEsRUFFQSxJQUFBLFFBQUEsQ0FBQTtBQUVTLE1BQUEseUJBQUEsWUFBQSxTQUFBLDRDQUFBO0FBQUEsZUFBWSxJQUFBLFNBQUE7TUFBVSxDQUFBO0FBR2xELE1BQUEsd0JBQUEsSUFBQSxTQUFBLENBQUE7QUFNQSxNQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBO0FBRUUsTUFBQSx3QkFBQSxJQUFBLFNBQUEsQ0FBQTtBQU1BLE1BQUEsNkJBQUEsSUFBQSxRQUFBLEVBQUE7QUFBa0IsTUFBQSx5QkFBQSxTQUFBLFNBQUEseUNBQUE7QUFBQSxlQUFTLElBQUEsZUFBQTtNQUFnQixDQUFBO0FBRXpDLE1BQUEsd0JBQUEsSUFBQSxLQUFBLEVBQUE7QUFNRixNQUFBLDJCQUFBLEVBQU87QUFLVCxNQUFBLGtDQUFBLElBQUEsZ0NBQUEsR0FBQSxHQUFBLE9BQUEsRUFBQTtBQWNBLE1BQUEsNkJBQUEsSUFBQSxVQUFBLEVBQUE7QUFJRSxNQUFBLHFCQUFBLElBQUEscUJBQUE7QUFFRixNQUFBLDJCQUFBLEVBQVM7QUFLWCxNQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBLEVBQStCLElBQUEsR0FBQTtBQUczQixNQUFBLHFCQUFBLElBQUEsNEZBQUE7QUFDRixNQUFBLDJCQUFBO0FBRUEsTUFBQSw2QkFBQSxJQUFBLEtBQUEsRUFBQTtBQUNFLE1BQUEscUJBQUEsSUFBQSxvQkFBQTtBQUNGLE1BQUEsMkJBQUEsRUFBSSxFQUVBLEVBRUYsRUFFRjs7OztBQXJFSSxNQUFBLHdCQUFBLEVBQUE7QUFBQSxNQUFBLHlCQUFBLGFBQUEsSUFBQSxTQUFBO0FBWUEsTUFBQSx3QkFBQSxDQUFBO0FBQUEsTUFBQSx5QkFBQSxRQUFBLElBQUEsa0JBQUEsU0FBQSxVQUFBO0FBU0UsTUFBQSx3QkFBQSxDQUFBO0FBQUEsTUFBQSwwQkFBQSxVQUFBLElBQUEsZUFBQSxFQUFnQyxnQkFBQSxDQUFBLElBQUEsZUFBQTtBQVN0QyxNQUFBLHdCQUFBO0FBQUEsTUFBQSw4QkFBQSxVQUFBLElBQUEsVUFBQSxJQUFBLFVBQUEsTUFBQSxPQUFBLE9BQUEsUUFBQSxVQUFBLE9BQUEsT0FBQSxRQUFBLE9BQUEsU0FBQSxRQUFBLFVBQUEsSUFBQSxVQUFBLElBQUEsVUFBQSxNQUFBLE9BQUEsT0FBQSxRQUFBLFdBQUEsS0FBQSxFQUFBO0FBZ0JFLE1BQUEsd0JBQUE7QUFBQSxNQUFBLHlCQUFBLFlBQUEsSUFBQSxVQUFBLE9BQUE7O29CRGhFRUMsYUFBWSxxQkFBbUIsdUJBQUEsbUJBQUEsaUNBQUEseUJBQUEsd0JBQUEsdUJBQUEsaUNBQUEsK0JBQUEsdUNBQUEsOEJBQUEsb0JBQUEseUJBQUEsc0JBQUEsdUJBQUEsdUJBQUEscUJBQUEsOEJBQUEsbUJBQUEsaUJBQUEsaUJBQUEseUJBQUEsdUJBQUEsdUJBQUEsb0JBQUEsa0JBQUEsZ0JBQUEsR0FBQSxRQUFBLENBQUEsbTRKQUFBLEVBQUEsQ0FBQTs7O2dGQUk5QixRQUFNLENBQUE7VUFQbEJDO3VCQUNXLGNBQVksWUFDVixNQUFJLFNBQ1AsQ0FBQ0QsYUFBWSxtQkFBbUIsR0FBQyxVQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1NBQUEsUUFBQSxDQUFBLGcrSEFBQSxFQUFBLENBQUE7Ozs7aUZBSS9CLFFBQU0sRUFBQSxXQUFBLFVBQUEsVUFBQSwrQkFBQSxZQUFBLEdBQUEsQ0FBQTtBQUFBLEdBQUE7Ozs7Ozs7K0RBQU4sUUFBTSxFQUFBLFNBQUEsQ0FBQUUsS0FBQSxFQUFBLEdBQUEsQ0FBQUYsYUFBQSxxQkFBQUMsVUFBQSxHQUFBLGFBQUEsRUFBQSxDQUFBO0VBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGNBQUEsZUFBQSxLQUFBLElBQUEsQ0FBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsZUFBQSxZQUFBLE9BQUEsWUFBQSxJQUFBLEdBQUEsNEJBQUEsT0FBQSxFQUFBLE9BQUEsTUFBQSxlQUFBLEVBQUEsU0FBQSxDQUFBO0FBQUEsR0FBQTs7O0FFWm5CLFNBQVMsYUFBQUUsWUFBVyx5QkFBeUI7QUFDN0MsU0FBUyxvQkFBb0I7OztBQVl2QixJQUFPLGdCQUFQLE1BQU8sZUFBYTs7cUNBQWIsZ0JBQWE7RUFBQTs2RUFBYixnQkFBYSxXQUFBLENBQUEsQ0FBQSxvQkFBQSxDQUFBLEdBQUEsT0FBQSxJQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLHNCQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEsY0FBQSxHQUFBLENBQUEsT0FBQSx1QkFBQSxPQUFBLGVBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLG9CQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLGNBQUEseUJBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsY0FBQSxzQkFBQSxHQUFBLE1BQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSx1QkFBQSxJQUFBLEtBQUE7QUFBQSxRQUFBLEtBQUEsR0FBQTtBQ2IxQixNQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBLEVBQWtDLEdBQUEsT0FBQSxDQUFBLEVBRVAsR0FBQSxPQUFBLENBQUE7QUFFckIsTUFBQSx3QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNGLE1BQUEsMkJBQUEsRUFBTTtBQUdSLE1BQUEsNkJBQUEsR0FBQSxPQUFBLENBQUEsRUFBZ0MsR0FBQSxJQUFBO0FBQzFCLE1BQUEscUJBQUEsR0FBQSwyQ0FBQTtBQUFzQyxNQUFBLDJCQUFBO0FBQzFDLE1BQUEsNkJBQUEsR0FBQSxHQUFBO0FBQUcsTUFBQSxxQkFBQSxHQUFBLHNDQUFBO0FBQW9DLE1BQUEsMkJBQUE7QUFFdkMsTUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQSxFQUF3QixJQUFBLE9BQUEsQ0FBQSxFQUMrQixJQUFBLE9BQUEsQ0FBQTtBQUNqQyxNQUFBLHFCQUFBLElBQUEsV0FBQTtBQUFFLE1BQUEsMkJBQUE7QUFDcEIsTUFBQSw2QkFBQSxJQUFBLElBQUE7QUFBSSxNQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFVLE1BQUEsMkJBQUE7QUFDZCxNQUFBLDZCQUFBLElBQUEsR0FBQTtBQUFHLE1BQUEscUJBQUEsSUFBQSx3REFBQTtBQUFtRCxNQUFBLDJCQUFBO0FBQ3RELE1BQUEsNkJBQUEsSUFBQSxVQUFBLENBQUE7QUFBMkIsTUFBQSxxQkFBQSxJQUFBLHlCQUFBO0FBQXVCLE1BQUEsMkJBQUEsRUFBUztBQUc3RCxNQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBLEVBQWtELElBQUEsT0FBQSxDQUFBO0FBQzlCLE1BQUEscUJBQUEsSUFBQSxXQUFBO0FBQUUsTUFBQSwyQkFBQTtBQUNwQixNQUFBLDZCQUFBLElBQUEsSUFBQTtBQUFJLE1BQUEscUJBQUEsSUFBQSxTQUFBO0FBQU8sTUFBQSwyQkFBQTtBQUNYLE1BQUEsNkJBQUEsSUFBQSxHQUFBO0FBQUcsTUFBQSxxQkFBQSxJQUFBLHlFQUFBO0FBQWlFLE1BQUEsMkJBQUE7QUFDcEUsTUFBQSw2QkFBQSxJQUFBLFVBQUEsQ0FBQTtBQUEyQixNQUFBLHFCQUFBLElBQUEsYUFBQTtBQUFXLE1BQUEsMkJBQUEsRUFBUyxFQUMzQyxFQUNGLEVBRUY7O29CRHBCSSxjQUFZLGtCQUFBLGdCQUFBLHNCQUFBLDhCQUFBLEdBQUEsUUFBQSxDQUFBLHdpR0FBQSxHQUFBLGVBQUEsRUFBQSxDQUFBOzs7Z0ZBS1gsZUFBYSxDQUFBO1VBUnpCQTt1QkFDVyxzQkFBb0IsWUFDbEIsTUFBSSxTQUNQLENBQUMsWUFBWSxHQUFDLGVBR1Isa0JBQWtCLE1BQUksVUFBQSxnK0JBQUEsUUFBQSxDQUFBLHdpR0FBQSxFQUFBLENBQUE7Ozs7aUZBRTFCLGVBQWEsRUFBQSxXQUFBLGlCQUFBLFVBQUEseURBQUEsWUFBQSxHQUFBLENBQUE7QUFBQSxHQUFBOzs7Ozs7OytEQUFiLGVBQWEsRUFBQSxTQUFBLENBQUFDLEtBQUFDLEdBQUEsR0FBQSxDQUFBLGNBQUFGLFlBQUEsaUJBQUEsR0FBQSxhQUFBLEVBQUEsQ0FBQTtFQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxjQUFBLHNCQUFBLEtBQUEsSUFBQSxDQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxlQUFBLFlBQUEsT0FBQSxZQUFBLElBQUEsR0FBQSw0QkFBQSxPQUFBLEVBQUEsT0FBQSxNQUFBLHNCQUFBLEVBQUEsU0FBQSxDQUFBO0FBQUEsR0FBQTs7O0FFYjFCLFNBQVMsYUFBQUcsWUFBVyxVQUFBQyxlQUFjO0FBR2xDLFNBQ0UsZUFBQUMsY0FDQSxhQUFBQyxZQUNBLHVCQUFBQyxzQkFDQSxjQUFBQyxtQkFDSztBQUVQLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsVUFBQUMsU0FBUSxjQUFBQyxtQkFBa0I7Ozs7OztBQ3lDdkIsSUFBQSw2QkFBQSxHQUFBLE9BQUE7QUFBTyxJQUFBLHFCQUFBLEdBQUEsd0JBQUE7QUFBc0IsSUFBQSwyQkFBQTs7Ozs7QUFJN0IsSUFBQSw2QkFBQSxHQUFBLE9BQUE7QUFBTyxJQUFBLHFCQUFBLEdBQUEsOEJBQUE7QUFBeUIsSUFBQSwyQkFBQTs7Ozs7QUFQcEMsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUVFLElBQUEsa0NBQUEsR0FBQSwyREFBQSxHQUFBLEdBQUEsT0FBQTtBQUlBLElBQUEsa0NBQUEsR0FBQSwyREFBQSxHQUFBLEdBQUEsT0FBQTtBQUlGLElBQUEsMkJBQUE7Ozs7OztBQVJFLElBQUEsd0JBQUE7QUFBQSxJQUFBLDhCQUFBLFVBQUEsT0FBQSxhQUFBLElBQUEsS0FBQSxNQUFBLE9BQUEsT0FBQSxRQUFBLFVBQUEsT0FBQSxPQUFBLFFBQUEsT0FBQSxVQUFBLEtBQUEsSUFBQSxFQUFBO0FBSUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsOEJBQUEsVUFBQSxPQUFBLGFBQUEsSUFBQSxLQUFBLE1BQUEsT0FBQSxPQUFBLFFBQUEsVUFBQSxPQUFBLE9BQUEsUUFBQSxPQUFBLFNBQUEsS0FBQSxJQUFBLEVBQUE7Ozs7O0FBa0RFLElBQUEsNkJBQUEsR0FBQSxPQUFBO0FBQU8sSUFBQSxxQkFBQSxHQUFBLDJCQUFBO0FBQXlCLElBQUEsMkJBQUE7Ozs7O0FBSWhDLElBQUEsNkJBQUEsR0FBQSxPQUFBO0FBQU8sSUFBQSxxQkFBQSxHQUFBLGlDQUFBO0FBQTRCLElBQUEsMkJBQUE7Ozs7O0FBUHZDLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFFRSxJQUFBLGtDQUFBLEdBQUEsMkRBQUEsR0FBQSxHQUFBLE9BQUE7QUFJQSxJQUFBLGtDQUFBLEdBQUEsMkRBQUEsR0FBQSxHQUFBLE9BQUE7QUFJRixJQUFBLDJCQUFBOzs7Ozs7QUFSRSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw4QkFBQSxVQUFBLE9BQUEsYUFBQSxJQUFBLE9BQUEsTUFBQSxPQUFBLE9BQUEsUUFBQSxVQUFBLE9BQUEsT0FBQSxRQUFBLE9BQUEsVUFBQSxLQUFBLElBQUEsRUFBQTtBQUlBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDhCQUFBLFVBQUEsT0FBQSxhQUFBLElBQUEsT0FBQSxNQUFBLE9BQUEsT0FBQSxRQUFBLFVBQUEsT0FBQSxPQUFBLFFBQUEsT0FBQSxPQUFBLEtBQUEsSUFBQSxFQUFBOzs7OztBQXlDRSxJQUFBLDZCQUFBLEdBQUEsT0FBQTtBQUFPLElBQUEscUJBQUEsR0FBQSxrQ0FBQTtBQUE2QixJQUFBLDJCQUFBOzs7OztBQUlwQyxJQUFBLDZCQUFBLEdBQUEsT0FBQTtBQUFPLElBQUEscUJBQUEsR0FBQSxtQ0FBQTtBQUFpQyxJQUFBLDJCQUFBOzs7OztBQUl4QyxJQUFBLDZCQUFBLEdBQUEsT0FBQTtBQUNFLElBQUEscUJBQUEsR0FBQSwyREFBQTtBQUNGLElBQUEsMkJBQUE7Ozs7O0FBYkosSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUVFLElBQUEsa0NBQUEsR0FBQSwyREFBQSxHQUFBLEdBQUEsT0FBQTtBQUlBLElBQUEsa0NBQUEsR0FBQSwyREFBQSxHQUFBLEdBQUEsT0FBQTtBQUlBLElBQUEsa0NBQUEsR0FBQSwyREFBQSxHQUFBLEdBQUEsT0FBQTtBQU1GLElBQUEsMkJBQUE7Ozs7Ozs7QUFkRSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw4QkFBQSxVQUFBLE9BQUEsYUFBQSxJQUFBLFVBQUEsTUFBQSxPQUFBLE9BQUEsUUFBQSxVQUFBLE9BQUEsT0FBQSxRQUFBLE9BQUEsVUFBQSxLQUFBLElBQUEsRUFBQTtBQUlBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDhCQUFBLFVBQUEsT0FBQSxhQUFBLElBQUEsVUFBQSxNQUFBLE9BQUEsT0FBQSxRQUFBLFVBQUEsT0FBQSxPQUFBLFFBQUEsT0FBQSxXQUFBLEtBQUEsSUFBQSxFQUFBO0FBSUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsOEJBQUEsVUFBQSxPQUFBLGFBQUEsSUFBQSxVQUFBLE1BQUEsT0FBQSxPQUFBLFFBQUEsVUFBQSxPQUFBLE9BQUEsUUFBQSxPQUFBLFNBQUEsS0FBQSxJQUFBLEVBQUE7Ozs7O0FBMENOLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUEsRUFBdUIsR0FBQSxPQUFBO0FBQ2QsSUFBQSxxQkFBQSxHQUFBLGtDQUFBO0FBQTZCLElBQUEsMkJBQUEsRUFBUTs7O0FEOUs1QyxJQUFPLHNCQUFQLE1BQU8scUJBQW1CO0VBRXRCLGNBQWNDLFFBQU8sV0FBVztFQUNoQyxTQUFTQSxRQUFPRixPQUFNOztFQUc5QixrQkFBa0I7RUFFbEIsaUJBQWM7QUFDWixTQUFLLGtCQUFrQixDQUFDLEtBQUs7RUFDL0I7O0VBR0EsZUFBZSxJQUFJSCxXQUFVO0lBRTNCLFNBQVMsSUFBSUQsYUFBWSxJQUFJO01BQzNCRyxZQUFXO01BQ1hBLFlBQVcsVUFBVSxDQUFDO0tBQ3ZCO0lBRUQsV0FBVyxJQUFJSCxhQUFZLElBQUk7TUFDN0JHLFlBQVc7S0FDWjtJQUVELEtBQUssSUFBSUgsYUFBWSxJQUFJO01BQ3ZCRyxZQUFXO01BQ1hBLFlBQVcsUUFBUSxVQUFVO01BQzdCQSxZQUFXLFVBQVUsQ0FBQztNQUN0QkEsWUFBVyxVQUFVLENBQUM7S0FDdkI7SUFFRCxRQUFRLElBQUlILGFBQVksSUFBSTtNQUMxQkcsWUFBVztLQUNaO0lBRUQsU0FBUyxJQUFJSCxhQUFZLElBQUk7TUFDM0JHLFlBQVc7S0FDWjtJQUVELE9BQU8sSUFBSUgsYUFBWSxJQUFJO01BQ3pCRyxZQUFXO01BQ1hBLFlBQVc7S0FDWjtJQUVELFVBQVUsSUFBSUgsYUFBWSxJQUFJO01BQzVCRyxZQUFXO01BQ1hBLFlBQVcsVUFBVSxDQUFDO01BQ3RCQSxZQUFXLFFBQVEseUJBQXlCO0tBQzdDO0lBRUQsaUJBQWlCLElBQUlILGFBQVksSUFBSTtNQUNuQ0csWUFBVztLQUNaO0dBRUY7O0VBR0Qsc0JBQW1CO0FBRWpCLFFBQ0UsS0FBSyxhQUFhLE1BQU0sYUFDeEIsS0FBSyxhQUFhLE1BQU0saUJBQ3hCO0FBQ0EsWUFBTSxpQ0FBOEI7QUFDcEM7SUFDRjtBQUVBLFFBQUksS0FBSyxhQUFhLE9BQU87QUFFM0IsWUFBTSxRQUFRLEtBQUssYUFBYTtBQUVoQyxXQUFLLFlBQVksb0JBQW9CLEtBQUssRUFBRSxVQUFVO1FBRXBELE1BQU0sQ0FBQyxRQUFPO0FBRVosa0JBQVEsSUFBSSx1Q0FBaUMsR0FBRztBQUVoRCxnQkFBTSxtQkFBbUI7QUFFekIsZUFBSyxPQUFPLFNBQVMsQ0FBQyxTQUFTLENBQUM7UUFFbEM7UUFFQSxPQUFPLENBQUMsUUFBTztBQUViLGtCQUFRLE1BQU0sc0NBQXNDLEdBQUc7QUFFdkQsZ0JBQU0sZUFDSixJQUFJLE9BQU8sV0FDWDtBQUVGLGdCQUFNLFlBQVk7UUFFcEI7T0FFRDtJQUVILE9BRUs7QUFFSCxXQUFLLGFBQWEsaUJBQWdCO0FBRWxDLFlBQU0sa0VBQWtFO0lBRTFFO0VBRUY7O3FDQTNHVyxzQkFBbUI7RUFBQTs2RUFBbkIsc0JBQW1CLFdBQUEsQ0FBQSxDQUFBLDBCQUFBLENBQUEsR0FBQSxPQUFBLElBQUEsTUFBQSxJQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsb0JBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLFFBQUEsUUFBQSxtQkFBQSxXQUFBLGVBQUEsZ0JBQUEsR0FBQSxDQUFBLFFBQUEsUUFBQSxtQkFBQSxhQUFBLGVBQUEscUJBQUEsR0FBQSxDQUFBLFFBQUEsUUFBQSxtQkFBQSxPQUFBLGVBQUEsNkJBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsUUFBQSxRQUFBLG1CQUFBLFVBQUEsZUFBQSx3QkFBQSxHQUFBLENBQUEsUUFBQSxRQUFBLG1CQUFBLFdBQUEsZUFBQSwwQkFBQSxHQUFBLENBQUEsUUFBQSxTQUFBLG1CQUFBLFNBQUEsZUFBQSw2QkFBQSxHQUFBLENBQUEsR0FBQSxvQkFBQSxHQUFBLENBQUEsbUJBQUEsWUFBQSxlQUFBLDBCQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxPQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxVQUFBLEdBQUEsQ0FBQSxtQkFBQSxtQkFBQSxlQUFBLDhCQUFBLEdBQUEsTUFBQSxHQUFBLENBQUEsUUFBQSxRQUFBLEdBQUEsQ0FBQSxHQUFBLGdCQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsY0FBQSxjQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsUUFBQSxVQUFBLGNBQUEsV0FBQSxHQUFBLFdBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSw2QkFBQSxJQUFBLEtBQUE7QUFBQSxRQUFBLEtBQUEsR0FBQTtBQ3pCaEMsTUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQSxFQUFnQyxHQUFBLElBQUE7QUFFMUIsTUFBQSxxQkFBQSxHQUFBLDBDQUFBO0FBQXFDLE1BQUEsMkJBQUE7QUFFekMsTUFBQSw2QkFBQSxHQUFBLEdBQUE7QUFDRSxNQUFBLHFCQUFBLEdBQUEsMkVBQUE7QUFDRixNQUFBLDJCQUFBO0FBRUEsTUFBQSw2QkFBQSxHQUFBLFFBQUEsQ0FBQTtBQUVFLE1BQUEseUJBQUEsWUFBQSxTQUFBLHNEQUFBLFFBQUE7QUFBWSxZQUFBLG9CQUFBO0FBQXFCLGVBQUUsT0FBQSxlQUFBO01BQXVCLENBQUE7QUFHMUQsTUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQSxFQUF3QixHQUFBLE9BQUE7QUFFZixNQUFBLHFCQUFBLEdBQUEsVUFBQTtBQUFRLE1BQUEsMkJBQUE7QUFFZixNQUFBLHdCQUFBLEdBQUEsU0FBQSxDQUFBO0FBS0YsTUFBQSwyQkFBQTtBQUdBLE1BQUEsNkJBQUEsSUFBQSxPQUFBLENBQUEsRUFBd0IsSUFBQSxPQUFBO0FBRWYsTUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBVSxNQUFBLDJCQUFBO0FBRWpCLE1BQUEsd0JBQUEsSUFBQSxTQUFBLENBQUE7QUFLRixNQUFBLDJCQUFBO0FBR0EsTUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQSxFQUF3QixJQUFBLE9BQUE7QUFFZixNQUFBLHFCQUFBLElBQUEsTUFBQTtBQUFJLE1BQUEsMkJBQUE7QUFFWCxNQUFBLHdCQUFBLElBQUEsU0FBQSxDQUFBO0FBS0EsTUFBQSxrQ0FBQSxJQUFBLDZDQUFBLEdBQUEsR0FBQSxPQUFBLENBQUE7QUFpQkYsTUFBQSwyQkFBQTtBQUdBLE1BQUEsNkJBQUEsSUFBQSxPQUFBLENBQUEsRUFBd0IsSUFBQSxPQUFBO0FBRWYsTUFBQSxxQkFBQSxJQUFBLFNBQUE7QUFBTyxNQUFBLDJCQUFBO0FBRWQsTUFBQSx3QkFBQSxJQUFBLFNBQUEsQ0FBQTtBQUtGLE1BQUEsMkJBQUE7QUFHQSxNQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBLEVBQXdCLElBQUEsT0FBQTtBQUVmLE1BQUEscUJBQUEsSUFBQSxVQUFBO0FBQVEsTUFBQSwyQkFBQTtBQUVmLE1BQUEsd0JBQUEsSUFBQSxTQUFBLENBQUE7QUFLRixNQUFBLDJCQUFBO0FBR0EsTUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQSxFQUF3QixJQUFBLE9BQUE7QUFFZixNQUFBLHFCQUFBLElBQUEsd0JBQUE7QUFBbUIsTUFBQSwyQkFBQTtBQUUxQixNQUFBLHdCQUFBLElBQUEsU0FBQSxDQUFBO0FBS0EsTUFBQSxrQ0FBQSxJQUFBLDZDQUFBLEdBQUEsR0FBQSxPQUFBLENBQUE7QUFpQkYsTUFBQSwyQkFBQTtBQUdBLE1BQUEsNkJBQUEsSUFBQSxPQUFBLENBQUEsRUFBd0IsSUFBQSxPQUFBO0FBRWYsTUFBQSxxQkFBQSxJQUFBLGVBQUE7QUFBVSxNQUFBLDJCQUFBO0FBRWpCLE1BQUEsNkJBQUEsSUFBQSxPQUFBLEVBQUE7QUFFRSxNQUFBLHdCQUFBLElBQUEsU0FBQSxFQUFBO0FBTUEsTUFBQSw2QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUFrQixNQUFBLHlCQUFBLFNBQUEsU0FBQSxzREFBQTtBQUFBLGVBQVMsSUFBQSxlQUFBO01BQWdCLENBQUE7QUFFekMsTUFBQSx3QkFBQSxJQUFBLEtBQUEsRUFBQTtBQU1GLE1BQUEsMkJBQUEsRUFBTztBQUlULE1BQUEsa0NBQUEsSUFBQSw2Q0FBQSxHQUFBLEdBQUEsT0FBQSxDQUFBO0FBdUJGLE1BQUEsMkJBQUE7QUFFSixNQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBLEVBQXdCLElBQUEsT0FBQTtBQUVmLE1BQUEscUJBQUEsSUFBQSx5QkFBQTtBQUFvQixNQUFBLDJCQUFBO0FBRTNCLE1BQUEsNkJBQUEsSUFBQSxPQUFBLEVBQUE7QUFFRSxNQUFBLHdCQUFBLElBQUEsU0FBQSxFQUFBO0FBTUEsTUFBQSw2QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUFrQixNQUFBLHlCQUFBLFNBQUEsU0FBQSxzREFBQTtBQUFBLGVBQVMsSUFBQSxlQUFBO01BQWdCLENBQUE7QUFFekMsTUFBQSx3QkFBQSxJQUFBLEtBQUEsRUFBQTtBQU1GLE1BQUEsMkJBQUEsRUFBTztBQUlULE1BQUEsa0NBQUEsSUFBQSw2Q0FBQSxHQUFBLEdBQUEsT0FBQSxDQUFBO0FBWUYsTUFBQSwyQkFBQTtBQUdJLE1BQUEsNkJBQUEsSUFBQSxVQUFBLEVBQUE7QUFDRixNQUFBLHFCQUFBLElBQUEsaUJBQUE7QUFDRixNQUFBLDJCQUFBLEVBQVM7QUFHUCxNQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBLEVBQTRCLElBQUEsVUFBQSxFQUFBO0FBUTFCLE1BQUEscUJBQUEsSUFBQSxpQkFBQTtBQUVGLE1BQUEsMkJBQUE7QUFHQSxNQUFBLDZCQUFBLElBQUEsVUFBQSxFQUFBO0FBS0UsTUFBQSxxQkFBQSxJQUFBLG1CQUFBO0FBRUYsTUFBQSwyQkFBQSxFQUFTLEVBR0w7Ozs7Ozs7QUFsT0YsTUFBQSx3QkFBQSxDQUFBO0FBQUEsTUFBQSx5QkFBQSxhQUFBLElBQUEsWUFBQTtBQXFDRSxNQUFBLHdCQUFBLEVBQUE7QUFBQSxNQUFBLDhCQUFBLFVBQUEsSUFBQSxhQUFBLElBQUEsS0FBQSxNQUFBLE9BQUEsT0FBQSxRQUFBLGNBQUEsVUFBQSxJQUFBLGFBQUEsSUFBQSxLQUFBLE1BQUEsT0FBQSxPQUFBLFFBQUEsV0FBQSxLQUFBLEVBQUE7QUFxREEsTUFBQSx3QkFBQSxFQUFBO0FBQUEsTUFBQSw4QkFBQSxVQUFBLElBQUEsYUFBQSxJQUFBLE9BQUEsTUFBQSxPQUFBLE9BQUEsUUFBQSxjQUFBLFVBQUEsSUFBQSxhQUFBLElBQUEsT0FBQSxNQUFBLE9BQUEsT0FBQSxRQUFBLFdBQUEsS0FBQSxFQUFBO0FBMkJJLE1BQUEsd0JBQUEsQ0FBQTtBQUFBLE1BQUEseUJBQUEsUUFBQSxJQUFBLGtCQUFBLFNBQUEsVUFBQTtBQVNFLE1BQUEsd0JBQUEsQ0FBQTtBQUFBLE1BQUEsMEJBQUEsVUFBQSxJQUFBLGVBQUEsRUFBZ0MsZ0JBQUEsQ0FBQSxJQUFBLGVBQUE7QUFRdEMsTUFBQSx3QkFBQTtBQUFBLE1BQUEsOEJBQUEsVUFBQSxJQUFBLGFBQUEsSUFBQSxVQUFBLE1BQUEsT0FBQSxPQUFBLFFBQUEsY0FBQSxVQUFBLElBQUEsYUFBQSxJQUFBLFVBQUEsTUFBQSxPQUFBLE9BQUEsUUFBQSxXQUFBLEtBQUEsRUFBQTtBQWdDQSxNQUFBLHdCQUFBLENBQUE7QUFBQSxNQUFBLHlCQUFBLFFBQUEsSUFBQSxrQkFBQSxTQUFBLFVBQUE7QUFTRSxNQUFBLHdCQUFBLENBQUE7QUFBQSxNQUFBLDBCQUFBLFVBQUEsSUFBQSxlQUFBLEVBQWdDLGdCQUFBLENBQUEsSUFBQSxlQUFBO0FBUXRDLE1BQUEsd0JBQUE7QUFBQSxNQUFBLDhCQUFBLFdBQUEsSUFBQSxhQUFBLElBQUEsaUJBQUEsTUFBQSxPQUFBLE9BQUEsU0FBQSxjQUFBLFdBQUEsSUFBQSxhQUFBLElBQUEsVUFBQSxNQUFBLE9BQUEsT0FBQSxTQUFBLGFBQUEsV0FBQSxJQUFBLGFBQUEsSUFBQSxpQkFBQSxNQUFBLE9BQUEsT0FBQSxTQUFBLFNBQUEsS0FBQSxFQUFBOztvQkQvS0FELHNCQUFtQix3QkFBQSxvQkFBQSxrQ0FBQSwwQkFBQSx5QkFBQSx3QkFBQSxrQ0FBQSxnQ0FBQSx3Q0FBQSwrQkFBQSxxQkFBQSwwQkFBQSx1QkFBQSx3QkFBQSx3QkFBQSxzQkFBQSwrQkFBQSxvQkFBQSxrQkFBQSxrQkFBQSwwQkFBQSx3QkFBQSx3QkFBQSxxQkFBQSxtQkFBQSxtQkFDbkIsY0FBWSxZQUFBLHNCQUFBLFlBQUEsU0FBQSxxQkFBQSxZQUFBLGFBQUEsaUJBQUEsb0JBQUEsYUFBQSxpQkFDWkcsYUFBVSxjQUFBLGtCQUFBLGtCQUFBLGFBQUEsY0FBQSxnQkFBQSxnQkFBQSxrQkFBQSxpQkFBQSxhQUFBLG1CQUFBLG1CQUFBLGVBQUEsR0FBQSxRQUFBLENBQUEsd29KQUFBLEVBQUEsQ0FBQTs7O2dGQU1DLHFCQUFtQixDQUFBO1VBWi9CRTt1QkFDVyw0QkFBMEIsWUFDeEIsTUFBSSxTQUNQO01BQ1RMO01BQ0E7TUFDQUc7T0FDRCxVQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1NBQUEsUUFBQSxDQUFBLDhnSUFBQSxFQUFBLENBQUE7Ozs7aUZBS1kscUJBQW1CLEVBQUEsV0FBQSx1QkFBQSxVQUFBLHFFQUFBLFlBQUEsR0FBQSxDQUFBO0FBQUEsR0FBQTs7Ozs7OzsrREFBbkIscUJBQW1CLEVBQUEsU0FBQSxDQUFBRyxLQUFBQyxLQUFBLEVBQUEsR0FBQSxDQUFBUCxzQkFBQSxjQUFBRyxhQUFBRSxVQUFBLEdBQUEsYUFBQSxFQUFBLENBQUE7RUFBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsY0FBQSw0QkFBQSxLQUFBLElBQUEsQ0FBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsZUFBQSxZQUFBLE9BQUEsWUFBQSxJQUFBLEdBQUEsNEJBQUEsT0FBQSxFQUFBLE9BQUEsTUFBQSw0QkFBQSxFQUFBLFNBQUEsQ0FBQTtBQUFBLEdBQUE7OztBRXpCaEMsU0FBUyxhQUFBRyxZQUFXLFVBQUFDLGVBQWM7QUFHbEMsU0FDRSxlQUFBQyxjQUNBLGFBQUFDLFlBQ0EsdUJBQUFDLHNCQUNBLGNBQUFDLG1CQUNLO0FBRVAsU0FBUyxnQkFBQUMscUJBQW9CO0FBQzdCLFNBQVMsVUFBQUMsU0FBUSxjQUFBQyxtQkFBa0I7Ozs7OztBQytDdkIsSUFBQSw2QkFBQSxHQUFBLE9BQUE7QUFBTyxJQUFBLHFCQUFBLEdBQUEseUJBQUE7QUFBdUIsSUFBQSwyQkFBQTs7Ozs7QUFJOUIsSUFBQSw2QkFBQSxHQUFBLE9BQUE7QUFBTyxJQUFBLHFCQUFBLEdBQUEsd0NBQUE7QUFBbUMsSUFBQSwyQkFBQTs7Ozs7QUFQOUMsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUVFLElBQUEsa0NBQUEsR0FBQSx3REFBQSxHQUFBLEdBQUEsT0FBQTtBQUlBLElBQUEsa0NBQUEsR0FBQSx3REFBQSxHQUFBLEdBQUEsT0FBQTtBQUlGLElBQUEsMkJBQUE7Ozs7OztBQVJFLElBQUEsd0JBQUE7QUFBQSxJQUFBLDhCQUFBLFVBQUEsT0FBQSxhQUFBLElBQUEsTUFBQSxNQUFBLE9BQUEsT0FBQSxRQUFBLFVBQUEsT0FBQSxPQUFBLFFBQUEsT0FBQSxVQUFBLEtBQUEsSUFBQSxFQUFBO0FBSUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsOEJBQUEsVUFBQSxPQUFBLGFBQUEsSUFBQSxNQUFBLE1BQUEsT0FBQSxPQUFBLFFBQUEsVUFBQSxPQUFBLE9BQUEsUUFBQSxPQUFBLFNBQUEsS0FBQSxJQUFBLEVBQUE7Ozs7O0FBb0hFLElBQUEsNkJBQUEsR0FBQSxPQUFBO0FBQU8sSUFBQSxxQkFBQSxHQUFBLDJCQUFBO0FBQXlCLElBQUEsMkJBQUE7Ozs7O0FBSWhDLElBQUEsNkJBQUEsR0FBQSxPQUFBO0FBQU8sSUFBQSxxQkFBQSxHQUFBLGlDQUFBO0FBQTRCLElBQUEsMkJBQUE7Ozs7O0FBUHZDLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUE7QUFFRSxJQUFBLGtDQUFBLEdBQUEsd0RBQUEsR0FBQSxHQUFBLE9BQUE7QUFJQSxJQUFBLGtDQUFBLEdBQUEsd0RBQUEsR0FBQSxHQUFBLE9BQUE7QUFJRixJQUFBLDJCQUFBOzs7Ozs7QUFSRSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw4QkFBQSxVQUFBLE9BQUEsYUFBQSxJQUFBLE9BQUEsTUFBQSxPQUFBLE9BQUEsUUFBQSxVQUFBLE9BQUEsT0FBQSxRQUFBLE9BQUEsVUFBQSxLQUFBLElBQUEsRUFBQTtBQUlBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDhCQUFBLFVBQUEsT0FBQSxhQUFBLElBQUEsT0FBQSxNQUFBLE9BQUEsT0FBQSxRQUFBLFVBQUEsT0FBQSxPQUFBLFFBQUEsT0FBQSxPQUFBLEtBQUEsSUFBQSxFQUFBOzs7OztBQXlFRSxJQUFBLDZCQUFBLEdBQUEsT0FBQTtBQUFPLElBQUEscUJBQUEsR0FBQSxrQ0FBQTtBQUE2QixJQUFBLDJCQUFBOzs7OztBQUlwQyxJQUFBLDZCQUFBLEdBQUEsT0FBQTtBQUFPLElBQUEscUJBQUEsR0FBQSxtQ0FBQTtBQUFpQyxJQUFBLDJCQUFBOzs7OztBQUl4QyxJQUFBLDZCQUFBLEdBQUEsT0FBQTtBQUNFLElBQUEscUJBQUEsR0FBQSwyREFBQTtBQUNGLElBQUEsMkJBQUE7Ozs7O0FBYkosSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUVFLElBQUEsa0NBQUEsR0FBQSx3REFBQSxHQUFBLEdBQUEsT0FBQTtBQUlBLElBQUEsa0NBQUEsR0FBQSx3REFBQSxHQUFBLEdBQUEsT0FBQTtBQUlBLElBQUEsa0NBQUEsR0FBQSx3REFBQSxHQUFBLEdBQUEsT0FBQTtBQU1GLElBQUEsMkJBQUE7Ozs7Ozs7QUFkRSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw4QkFBQSxVQUFBLE9BQUEsYUFBQSxJQUFBLFVBQUEsTUFBQSxPQUFBLE9BQUEsUUFBQSxVQUFBLE9BQUEsT0FBQSxRQUFBLE9BQUEsVUFBQSxLQUFBLElBQUEsRUFBQTtBQUlBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDhCQUFBLFVBQUEsT0FBQSxhQUFBLElBQUEsVUFBQSxNQUFBLE9BQUEsT0FBQSxRQUFBLFVBQUEsT0FBQSxPQUFBLFFBQUEsT0FBQSxXQUFBLEtBQUEsSUFBQSxFQUFBO0FBSUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsOEJBQUEsVUFBQSxPQUFBLGFBQUEsSUFBQSxVQUFBLE1BQUEsT0FBQSxPQUFBLFFBQUEsVUFBQSxPQUFBLE9BQUEsUUFBQSxPQUFBLFNBQUEsS0FBQSxJQUFBLEVBQUE7Ozs7O0FBMENOLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUEsRUFBdUIsR0FBQSxPQUFBO0FBQ2QsSUFBQSxxQkFBQSxHQUFBLGtDQUFBO0FBQTZCLElBQUEsMkJBQUEsRUFBUTs7O0FEdFI1QyxJQUFPLG1CQUFQLE1BQU8sa0JBQWdCO0VBRW5CLGNBQWNDLFFBQU8sV0FBVztFQUNoQyxTQUFTQSxRQUFPRixPQUFNOztFQUc5QixrQkFBa0I7RUFFbEIsaUJBQWM7QUFDWixTQUFLLGtCQUFrQixDQUFDLEtBQUs7RUFDL0I7O0VBR0EsZUFBZSxJQUFJSixXQUFVO0lBRTNCLGFBQWEsSUFBSUQsYUFBWSxJQUFJO01BQy9CRyxZQUFXO0tBQ1o7SUFFRCxVQUFVLElBQUlILGFBQVksRUFBRTtJQUU1QixjQUFjLElBQUlBLGFBQVksSUFBSTtNQUNoQ0csWUFBVztLQUNaO0lBRUQsTUFBTSxJQUFJSCxhQUFZLElBQUk7TUFDeEJHLFlBQVc7TUFDWEEsWUFBVyxRQUFRLDhCQUE4QjtLQUNsRDtJQUVELFFBQVEsSUFBSUgsYUFBWSxJQUFJO01BQzFCRyxZQUFXO0tBQ1o7SUFFRCxNQUFNLElBQUlILGFBQVksSUFBSTtNQUN4QkcsWUFBVztLQUNaO0lBRUQsV0FBVyxJQUFJSCxhQUFZLElBQUk7TUFDN0JHLFlBQVc7S0FDWjtJQUVELFFBQVEsSUFBSUgsYUFBWSxJQUFJO01BQzFCRyxZQUFXO0tBQ1o7SUFFRCxJQUFJLElBQUlILGFBQVksRUFBRTtJQUV0QixPQUFPLElBQUlBLGFBQVksSUFBSTtNQUN6QkcsWUFBVztLQUNaO0lBRUQsUUFBUSxJQUFJSCxhQUFZLEVBQUU7SUFFMUIsTUFBTSxJQUFJQSxhQUFZLEVBQUU7SUFFeEIsTUFBTSxJQUFJQSxhQUFZLEVBQUU7SUFFeEIsT0FBTyxJQUFJQSxhQUFZLElBQUk7TUFDekJHLFlBQVc7TUFDWEEsWUFBVztLQUNaO0lBRUQsS0FBSyxJQUFJSCxhQUFZLEVBQUU7SUFFdkIsVUFBVSxJQUFJQSxhQUFZLElBQUk7TUFDNUJHLFlBQVc7S0FDWjtJQUVELGFBQWEsSUFBSUgsYUFBWSxJQUFJO01BQy9CRyxZQUFXO0tBQ1o7SUFFRCxVQUFVLElBQUlILGFBQVksSUFBSTtNQUU1QkcsWUFBVztNQUVYQSxZQUFXLFVBQVUsQ0FBQzs7TUFHdEJBLFlBQVcsUUFBUSx5QkFBeUI7S0FFN0M7O0lBR0QsaUJBQWlCLElBQUlILGFBQVksSUFBSTtNQUNuQ0csWUFBVztLQUNaO0dBRUY7O0VBR0QsbUJBQWdCO0FBR2QsUUFDRSxLQUFLLGFBQWEsTUFBTSxhQUN4QixLQUFLLGFBQWEsTUFBTSxpQkFDeEI7QUFFQSxZQUFNLGlDQUE4QjtBQUNwQztJQUVGO0FBRUEsUUFBSSxLQUFLLGFBQWEsT0FBTztBQUUzQixZQUFNLFFBQVEsS0FBSyxhQUFhO0FBRWhDLFdBQUssWUFBWSxpQkFBaUIsS0FBSyxFQUFFLFVBQVU7UUFFakQsTUFBTSxDQUFDLFFBQU87QUFFWixrQkFBUSxJQUNOLHdDQUNBLEdBQUc7QUFHTCxnQkFDRSxxRUFBeUQ7QUFHM0QsZUFBSyxPQUFPLFNBQVMsQ0FBQyxTQUFTLENBQUM7UUFFbEM7UUFFQSxPQUFPLENBQUMsUUFBTztBQUViLGtCQUFRLE1BQ04sdUJBQ0EsR0FBRztBQUdMLGdCQUNFLGtDQUFrQztRQUd0QztPQUVEO0lBRUgsT0FFSztBQUVILFdBQUssYUFBYSxpQkFBZ0I7QUFFbEMsWUFDRSx3REFBcUQ7SUFHekQ7RUFFRjs7cUNBekpXLG1CQUFnQjtFQUFBOzZFQUFoQixtQkFBZ0IsV0FBQSxDQUFBLENBQUEsdUJBQUEsQ0FBQSxHQUFBLE9BQUEsSUFBQSxNQUFBLElBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxvQkFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsUUFBQSxRQUFBLG1CQUFBLGVBQUEsZUFBQSxrQkFBQSxHQUFBLENBQUEsUUFBQSxRQUFBLG1CQUFBLFlBQUEsZUFBQSxlQUFBLEdBQUEsQ0FBQSxRQUFBLFFBQUEsbUJBQUEsZ0JBQUEsZUFBQSx1QkFBQSxHQUFBLENBQUEsUUFBQSxRQUFBLG1CQUFBLFFBQUEsZUFBQSxtQkFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxRQUFBLFFBQUEsbUJBQUEsVUFBQSxlQUFBLDBCQUFBLEdBQUEsQ0FBQSxRQUFBLFFBQUEsbUJBQUEsUUFBQSxlQUFBLGVBQUEsR0FBQSxDQUFBLFFBQUEsUUFBQSxtQkFBQSxhQUFBLGVBQUEsa0JBQUEsR0FBQSxDQUFBLFFBQUEsUUFBQSxtQkFBQSxVQUFBLGVBQUEsbUJBQUEsR0FBQSxDQUFBLFFBQUEsUUFBQSxtQkFBQSxNQUFBLGVBQUEsVUFBQSxHQUFBLENBQUEsUUFBQSxRQUFBLG1CQUFBLFNBQUEsZUFBQSxvQkFBQSxHQUFBLENBQUEsUUFBQSxRQUFBLG1CQUFBLFVBQUEsZUFBQSxVQUFBLEdBQUEsQ0FBQSxRQUFBLFFBQUEsbUJBQUEsUUFBQSxlQUFBLE9BQUEsR0FBQSxDQUFBLFFBQUEsUUFBQSxtQkFBQSxRQUFBLGVBQUEsT0FBQSxHQUFBLENBQUEsUUFBQSxTQUFBLG1CQUFBLFNBQUEsZUFBQSwwQkFBQSxHQUFBLENBQUEsUUFBQSxRQUFBLG1CQUFBLE9BQUEsZUFBQSx1QkFBQSxHQUFBLENBQUEsUUFBQSxRQUFBLG1CQUFBLFlBQUEsZUFBQSxtQkFBQSxHQUFBLENBQUEsR0FBQSxjQUFBLFlBQUEsR0FBQSxDQUFBLFFBQUEsUUFBQSxtQkFBQSxlQUFBLGVBQUEsMEJBQUEsR0FBQSxDQUFBLEdBQUEsb0JBQUEsR0FBQSxDQUFBLG1CQUFBLFlBQUEsZUFBQSwwQkFBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLEdBQUEsT0FBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxHQUFBLENBQUEsbUJBQUEsbUJBQUEsZUFBQSw4QkFBQSxHQUFBLE1BQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxHQUFBLFVBQUEsR0FBQSxDQUFBLEdBQUEsZ0JBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxjQUFBLGNBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsY0FBQSxXQUFBLEdBQUEsV0FBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLDBCQUFBLElBQUEsS0FBQTtBQUFBLFFBQUEsS0FBQSxHQUFBO0FDekI3QixNQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBLEVBQWdDLEdBQUEsSUFBQTtBQUUxQixNQUFBLHFCQUFBLEdBQUEsNkJBQUE7QUFBd0IsTUFBQSwyQkFBQTtBQUU1QixNQUFBLDZCQUFBLEdBQUEsR0FBQTtBQUNFLE1BQUEscUJBQUEsR0FBQSwyRUFBQTtBQUNGLE1BQUEsMkJBQUE7QUFFQSxNQUFBLDZCQUFBLEdBQUEsUUFBQSxDQUFBO0FBRUUsTUFBQSx5QkFBQSxZQUFBLFNBQUEsbURBQUEsUUFBQTtBQUFZLFlBQUEsaUJBQUE7QUFBa0IsZUFBRSxPQUFBLGVBQUE7TUFBdUIsQ0FBQTtBQUd2RCxNQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBLEVBQXdCLEdBQUEsT0FBQTtBQUNmLE1BQUEscUJBQUEsR0FBQSxrQkFBQTtBQUFhLE1BQUEsMkJBQUE7QUFFcEIsTUFBQSx3QkFBQSxHQUFBLFNBQUEsQ0FBQTtBQUlGLE1BQUEsMkJBQUE7QUFHQSxNQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBLEVBQXdCLElBQUEsT0FBQTtBQUNmLE1BQUEscUJBQUEsSUFBQSx3QkFBQTtBQUFtQixNQUFBLDJCQUFBO0FBRTFCLE1BQUEsd0JBQUEsSUFBQSxTQUFBLENBQUE7QUFJRixNQUFBLDJCQUFBO0FBR0EsTUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQSxFQUF3QixJQUFBLE9BQUE7QUFDZixNQUFBLHFCQUFBLElBQUEsa0JBQUE7QUFBYSxNQUFBLDJCQUFBO0FBRXBCLE1BQUEsd0JBQUEsSUFBQSxTQUFBLENBQUE7QUFJRixNQUFBLDJCQUFBO0FBR0EsTUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQSxFQUF3QixJQUFBLE9BQUE7QUFFZixNQUFBLHFCQUFBLElBQUEsT0FBQTtBQUFLLE1BQUEsMkJBQUE7QUFFWixNQUFBLHdCQUFBLElBQUEsU0FBQSxDQUFBO0FBS0EsTUFBQSxrQ0FBQSxJQUFBLDBDQUFBLEdBQUEsR0FBQSxPQUFBLENBQUE7QUFpQkYsTUFBQSwyQkFBQTtBQUdBLE1BQUEsNkJBQUEsSUFBQSxPQUFBLENBQUEsRUFBd0IsSUFBQSxPQUFBO0FBQ2YsTUFBQSxxQkFBQSxJQUFBLFNBQUE7QUFBTyxNQUFBLDJCQUFBO0FBRWQsTUFBQSx3QkFBQSxJQUFBLFNBQUEsQ0FBQTtBQUlGLE1BQUEsMkJBQUE7QUFHQSxNQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBLEVBQXdCLElBQUEsT0FBQTtBQUNmLE1BQUEscUJBQUEsSUFBQSxVQUFBO0FBQUssTUFBQSwyQkFBQTtBQUVaLE1BQUEsd0JBQUEsSUFBQSxTQUFBLENBQUE7QUFJRixNQUFBLDJCQUFBO0FBR0EsTUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQSxFQUF3QixJQUFBLE9BQUE7QUFDZixNQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFVLE1BQUEsMkJBQUE7QUFFakIsTUFBQSx3QkFBQSxJQUFBLFNBQUEsRUFBQTtBQUlGLE1BQUEsMkJBQUE7QUFHQSxNQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBLEVBQXdCLElBQUEsT0FBQTtBQUNmLE1BQUEscUJBQUEsSUFBQSxTQUFBO0FBQU8sTUFBQSwyQkFBQTtBQUVkLE1BQUEsd0JBQUEsSUFBQSxTQUFBLEVBQUE7QUFJRixNQUFBLDJCQUFBO0FBR0EsTUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQSxFQUF3QixJQUFBLE9BQUE7QUFDZixNQUFBLHFCQUFBLElBQUEsbUJBQUE7QUFBYyxNQUFBLDJCQUFBO0FBRXJCLE1BQUEsd0JBQUEsSUFBQSxTQUFBLEVBQUE7QUFJRixNQUFBLDJCQUFBO0FBR0EsTUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQSxFQUF3QixJQUFBLE9BQUE7QUFDZixNQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFNLE1BQUEsMkJBQUE7QUFFYixNQUFBLHdCQUFBLElBQUEsU0FBQSxFQUFBO0FBSUYsTUFBQSwyQkFBQTtBQUdBLE1BQUEsNkJBQUEsSUFBQSxPQUFBLENBQUEsRUFBd0IsSUFBQSxPQUFBO0FBQ2YsTUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBRyxNQUFBLDJCQUFBO0FBRVYsTUFBQSx3QkFBQSxJQUFBLFNBQUEsRUFBQTtBQUlGLE1BQUEsMkJBQUE7QUFHQSxNQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBLEVBQXdCLElBQUEsT0FBQTtBQUNmLE1BQUEscUJBQUEsSUFBQSxPQUFBO0FBQUssTUFBQSwyQkFBQTtBQUVaLE1BQUEsd0JBQUEsSUFBQSxTQUFBLEVBQUE7QUFJRixNQUFBLDJCQUFBO0FBR0EsTUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQSxFQUF3QixJQUFBLE9BQUE7QUFDZixNQUFBLHFCQUFBLElBQUEsZUFBQTtBQUFhLE1BQUEsMkJBQUE7QUFFcEIsTUFBQSx3QkFBQSxJQUFBLFNBQUEsRUFBQTtBQUlGLE1BQUEsMkJBQUE7QUFHQSxNQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBLEVBQXdCLElBQUEsT0FBQTtBQUVmLE1BQUEscUJBQUEsSUFBQSxRQUFBO0FBQU0sTUFBQSwyQkFBQTtBQUViLE1BQUEsd0JBQUEsSUFBQSxTQUFBLEVBQUE7QUFLQSxNQUFBLGtDQUFBLElBQUEsMENBQUEsR0FBQSxHQUFBLE9BQUEsQ0FBQTtBQWlCRixNQUFBLDJCQUFBO0FBR0EsTUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQSxFQUF3QixJQUFBLE9BQUE7QUFDZixNQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFVLE1BQUEsMkJBQUE7QUFFakIsTUFBQSx3QkFBQSxJQUFBLFNBQUEsRUFBQTtBQUlGLE1BQUEsMkJBQUE7QUFHQSxNQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBLEVBQXdCLElBQUEsT0FBQTtBQUNmLE1BQUEscUJBQUEsSUFBQSwwQkFBQTtBQUFxQixNQUFBLDJCQUFBO0FBRTVCLE1BQUEsd0JBQUEsSUFBQSxTQUFBLEVBQUE7QUFJRixNQUFBLDJCQUFBO0FBR0EsTUFBQSw2QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUFtQyxJQUFBLE9BQUE7QUFFMUIsTUFBQSxxQkFBQSxJQUFBLHFDQUFBO0FBQWdDLE1BQUEsMkJBQUE7QUFFdkMsTUFBQSx3QkFBQSxJQUFBLFNBQUEsRUFBQTtBQUtGLE1BQUEsMkJBQUE7QUFHQSxNQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBLEVBQW1DLElBQUEsT0FBQTtBQUUxQixNQUFBLHFCQUFBLElBQUEsZ0JBQUE7QUFBVyxNQUFBLDJCQUFBO0FBRWxCLE1BQUEsNkJBQUEsSUFBQSxPQUFBLEVBQUE7QUFFRSxNQUFBLHdCQUFBLElBQUEsU0FBQSxFQUFBO0FBTUEsTUFBQSw2QkFBQSxJQUFBLFFBQUEsRUFBQTtBQUFrQixNQUFBLHlCQUFBLFNBQUEsU0FBQSxtREFBQTtBQUFBLGVBQVMsSUFBQSxlQUFBO01BQWdCLENBQUE7QUFFekMsTUFBQSx3QkFBQSxJQUFBLEtBQUEsRUFBQTtBQU1GLE1BQUEsMkJBQUEsRUFBTztBQUlULE1BQUEsa0NBQUEsSUFBQSwwQ0FBQSxHQUFBLEdBQUEsT0FBQSxDQUFBO0FBdUJGLE1BQUEsMkJBQUE7QUFFSixNQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBLEVBQW1DLElBQUEsT0FBQTtBQUUxQixNQUFBLHFCQUFBLElBQUEsMEJBQUE7QUFBcUIsTUFBQSwyQkFBQTtBQUU1QixNQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBO0FBRUUsTUFBQSx3QkFBQSxJQUFBLFNBQUEsRUFBQTtBQU1BLE1BQUEsNkJBQUEsSUFBQSxRQUFBLEVBQUE7QUFBa0IsTUFBQSx5QkFBQSxTQUFBLFNBQUEsbURBQUE7QUFBQSxlQUFTLElBQUEsZUFBQTtNQUFnQixDQUFBO0FBRXpDLE1BQUEsd0JBQUEsSUFBQSxLQUFBLEVBQUE7QUFNRixNQUFBLDJCQUFBLEVBQU87QUFJVCxNQUFBLGtDQUFBLElBQUEsMENBQUEsR0FBQSxHQUFBLE9BQUEsQ0FBQTtBQVlGLE1BQUEsMkJBQUE7QUFHSSxNQUFBLDZCQUFBLElBQUEsVUFBQSxFQUFBO0FBSUUsTUFBQSxxQkFBQSxJQUFBLGdCQUFBO0FBRUYsTUFBQSwyQkFBQSxFQUFTO0FBR2IsTUFBQSw2QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUE0QixJQUFBLFVBQUEsRUFBQTtBQVF4QixNQUFBLHFCQUFBLElBQUEsaUJBQUE7QUFFRixNQUFBLDJCQUFBO0FBR0EsTUFBQSw2QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUtFLE1BQUEscUJBQUEsSUFBQSxtQkFBQTtBQUVGLE1BQUEsMkJBQUEsRUFBUyxFQUdMOzs7Ozs7O0FBOVVGLE1BQUEsd0JBQUEsQ0FBQTtBQUFBLE1BQUEseUJBQUEsYUFBQSxJQUFBLFlBQUE7QUEyQ0UsTUFBQSx3QkFBQSxFQUFBO0FBQUEsTUFBQSw4QkFBQSxVQUFBLElBQUEsYUFBQSxJQUFBLE1BQUEsTUFBQSxPQUFBLE9BQUEsUUFBQSxjQUFBLFVBQUEsSUFBQSxhQUFBLElBQUEsTUFBQSxNQUFBLE9BQUEsT0FBQSxRQUFBLFdBQUEsS0FBQSxFQUFBO0FBdUhBLE1BQUEsd0JBQUEsRUFBQTtBQUFBLE1BQUEsOEJBQUEsVUFBQSxJQUFBLGFBQUEsSUFBQSxPQUFBLE1BQUEsT0FBQSxPQUFBLFFBQUEsY0FBQSxVQUFBLElBQUEsYUFBQSxJQUFBLE9BQUEsTUFBQSxPQUFBLE9BQUEsUUFBQSxXQUFBLEtBQUEsRUFBQTtBQTJESSxNQUFBLHdCQUFBLEVBQUE7QUFBQSxNQUFBLHlCQUFBLFFBQUEsSUFBQSxrQkFBQSxTQUFBLFVBQUE7QUFTRSxNQUFBLHdCQUFBLENBQUE7QUFBQSxNQUFBLDBCQUFBLFVBQUEsSUFBQSxlQUFBLEVBQWdDLGdCQUFBLENBQUEsSUFBQSxlQUFBO0FBUXRDLE1BQUEsd0JBQUE7QUFBQSxNQUFBLDhCQUFBLFVBQUEsSUFBQSxhQUFBLElBQUEsVUFBQSxNQUFBLE9BQUEsT0FBQSxRQUFBLGNBQUEsVUFBQSxJQUFBLGFBQUEsSUFBQSxVQUFBLE1BQUEsT0FBQSxPQUFBLFFBQUEsV0FBQSxLQUFBLEVBQUE7QUFnQ0EsTUFBQSx3QkFBQSxDQUFBO0FBQUEsTUFBQSx5QkFBQSxRQUFBLElBQUEsa0JBQUEsU0FBQSxVQUFBO0FBU0UsTUFBQSx3QkFBQSxDQUFBO0FBQUEsTUFBQSwwQkFBQSxVQUFBLElBQUEsZUFBQSxFQUFnQyxnQkFBQSxDQUFBLElBQUEsZUFBQTtBQVF0QyxNQUFBLHdCQUFBO0FBQUEsTUFBQSw4QkFBQSxXQUFBLElBQUEsYUFBQSxJQUFBLGlCQUFBLE1BQUEsT0FBQSxPQUFBLFNBQUEsY0FBQSxXQUFBLElBQUEsYUFBQSxJQUFBLFVBQUEsTUFBQSxPQUFBLE9BQUEsU0FBQSxhQUFBLFdBQUEsSUFBQSxhQUFBLElBQUEsaUJBQUEsTUFBQSxPQUFBLE9BQUEsU0FBQSxTQUFBLEtBQUEsRUFBQTtBQWlCSSxNQUFBLHdCQUFBO0FBQUEsTUFBQSx5QkFBQSxZQUFBLElBQUEsYUFBQSxPQUFBOztvQkR4U0pELHNCQUFtQix3QkFBQSxvQkFBQSxrQ0FBQSwwQkFBQSx5QkFBQSx3QkFBQSxrQ0FBQSxnQ0FBQSx3Q0FBQSwrQkFBQSxxQkFBQSwwQkFBQSx1QkFBQSx3QkFBQSx3QkFBQSxzQkFBQSwrQkFBQSxvQkFBQSxrQkFBQSxrQkFBQSwwQkFBQSx3QkFBQSx3QkFBQSxxQkFBQSxtQkFBQSxtQkFDbkJFLGVBQVksYUFBQSx1QkFBQSxhQUFBLFVBQUEsc0JBQUEsYUFBQSxjQUFBLGtCQUFBLHFCQUFBLGNBQUEsa0JBQ1pFLGFBQVUsZUFBQSxtQkFBQSxtQkFBQSxjQUFBLGVBQUEsaUJBQUEsaUJBQUEsbUJBQUEsa0JBQUEsY0FBQSxvQkFBQSxvQkFBQSxnQkFBQSxHQUFBLFFBQUEsQ0FBQSxxK0RBQUEsRUFBQSxDQUFBOzs7Z0ZBTUMsa0JBQWdCLENBQUE7VUFaNUJFO3VCQUNXLHlCQUF1QixZQUNyQixNQUFJLFNBQ1A7TUFDVE47TUFDQUU7TUFDQUU7T0FDRCxVQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1NBQUEsUUFBQSxDQUFBLDh4REFBQSxFQUFBLENBQUE7Ozs7aUZBS1ksa0JBQWdCLEVBQUEsV0FBQSxvQkFBQSxVQUFBLCtEQUFBLFlBQUEsR0FBQSxDQUFBO0FBQUEsR0FBQTs7Ozs7OzsrREFBaEIsa0JBQWdCLEVBQUEsU0FBQSxDQUFBRyxLQUFBQyxLQUFBQyxHQUFBLEdBQUEsQ0FBQVQsc0JBQUFFLGVBQUFFLGFBQUFFLFVBQUEsR0FBQSxhQUFBLEVBQUEsQ0FBQTtFQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxjQUFBLHlCQUFBLEtBQUEsSUFBQSxDQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxlQUFBLFlBQUEsT0FBQSxZQUFBLElBQUEsR0FBQSw0QkFBQSxPQUFBLEVBQUEsT0FBQSxNQUFBLHlCQUFBLEVBQUEsU0FBQSxDQUFBO0FBQUEsR0FBQTs7O0FFekI3QixTQUFTLGFBQUFJLGtCQUE0QztBQUNyRCxTQUFpQyxjQUFBQyxhQUFZLGFBQWEsdUJBQUFDLDRCQUEyQjtBQUNyRixTQUFTLGdCQUFBQyxxQkFBb0I7Ozs7O0FFRjdCOzs7O1NBQVMsWUFBWSxVQUFBQyxlQUFjO0FBQ25DLFNBQVMsa0JBQWtCOztBQTBDckIsSUFBTyxnQkFBUCxNQUFPLGVBQWE7RUFDaEIsT0FBT0EsUUFBTyxVQUFVO0VBQ3hCLFNBQVM7O0VBR2pCLHlCQUFzQjtBQUNwQixXQUFPLEtBQUssS0FBSyxJQUFzQixHQUFHLEtBQUssTUFBTSxvQkFBb0I7RUFDM0U7O0VBR0EscUJBQWtCO0FBQ2hCLFdBQU8sS0FBSyxLQUFLLElBQWMsR0FBRyxLQUFLLE1BQU0sV0FBVztFQUMxRDs7RUFHQSxxQkFBcUIsV0FBaUI7QUFDcEMsV0FBTyxLQUFLLEtBQUssSUFBYyxHQUFHLEtBQUssTUFBTSxZQUFZLFNBQVMsRUFBRTtFQUN0RTs7RUFHQSxlQUFlLFFBQXVCO0FBQ3BDLFdBQU8sS0FBSyxLQUFLLEtBQTJCLEdBQUcsS0FBSyxNQUFNLFVBQVUsTUFBTTtFQUM1RTs7RUFHQSxpQkFBaUIsVUFBa0IsUUFBdUI7QUFDeEQsV0FBTyxLQUFLLEtBQUssSUFBUyxHQUFHLEtBQUssTUFBTSxJQUFJLFFBQVEsSUFBSSxNQUFNO0VBQ2hFOztFQUdBLGNBQWMsVUFBa0IsUUFBNkI7QUFDM0QsV0FBTyxLQUFLLEtBQUssTUFBVyxHQUFHLEtBQUssTUFBTSxJQUFJLFFBQVEsV0FBVyxFQUFFLE9BQU0sQ0FBRTtFQUM3RTs7RUFHQSxhQUFhLFVBQWtCLE1BQVk7QUFDekMsV0FBTyxLQUFLLEtBQUssTUFBVyxHQUFHLEtBQUssTUFBTSxJQUFJLFFBQVEsWUFBWSxFQUFFLEtBQUksQ0FBRTtFQUM1RTs7RUFHQSxlQUFlLFVBQWdCO0FBQzdCLFdBQU8sS0FBSyxLQUFLLE9BQVksR0FBRyxLQUFLLE1BQU0sSUFBSSxRQUFRLEVBQUU7RUFDM0Q7O3FDQTFDVyxnQkFBYTtFQUFBO2dGQUFiLGdCQUFhLFNBQWIsZUFBYSxXQUFBLFlBRlosT0FBTSxDQUFBOzs7Z0ZBRVAsZUFBYSxDQUFBO1VBSHpCO1dBQVc7TUFDVixZQUFZO0tBQ2I7Ozs7O0FDMUNEOzs7O1NBQVMsY0FBQUMsYUFBWSxVQUFBQyxlQUFjO0FBQ25DLFNBQVMsY0FBQUMsbUJBQWtCOztBQWtDckIsSUFBTyx1QkFBUCxNQUFPLHNCQUFvQjtFQUN2QixPQUFPRCxRQUFPQyxXQUFVO0VBQ3hCLFNBQVM7Ozs7O0VBT2pCLGlCQUFpQixXQUFtQixlQUFzQjtBQUN4RCxVQUFNLE9BQU8sZ0JBQWdCLEVBQUUsV0FBVyxjQUFhLElBQUssRUFBRSxVQUFTO0FBQ3ZFLFdBQU8sS0FBSyxLQUFLLEtBQW1CLEtBQUssUUFBUSxJQUFJO0VBQ3ZEOztFQUdBLGdCQUFnQixjQUFvQjtBQUNsQyxXQUFPLEtBQUssS0FBSyxJQUFtQixHQUFHLEtBQUssTUFBTSxlQUFlLFlBQVksRUFBRTtFQUNqRjs7RUFHQSxvQkFBb0IsZUFBcUI7QUFDdkMsV0FBTyxLQUFLLEtBQUssT0FBcUIsR0FBRyxLQUFLLE1BQU0sSUFBSSxhQUFhLEVBQUU7RUFDekU7Ozs7O0VBT0EsYUFBYSxXQUFpQjtBQUM1QixXQUFPLEtBQUssS0FBSyxJQUFtQixHQUFHLEtBQUssTUFBTSxZQUFZLFNBQVMsRUFBRTtFQUMzRTs7RUFHQSxZQUFZLFVBQWdCO0FBQzFCLFdBQU8sS0FBSyxLQUFLLElBQW1CLEdBQUcsS0FBSyxNQUFNLFdBQVcsUUFBUSxFQUFFO0VBQ3pFOztFQUdBLGlCQUFpQixlQUF1QixRQUF5QjtBQUMvRCxXQUFPLEtBQUssS0FBSyxJQUFrQixHQUFHLEtBQUssTUFBTSxJQUFJLGFBQWEsV0FBVyxFQUFFLE9BQU0sQ0FBRTtFQUN6Rjs7Ozs7RUFPQSxXQUFRO0FBQ04sV0FBTyxLQUFLLEtBQUssSUFBbUIsR0FBRyxLQUFLLE1BQU0sUUFBUTtFQUM1RDs7RUFHQSxzQkFBc0IsZUFBcUI7QUFDekMsV0FBTyxLQUFLLEtBQUssT0FBcUIsR0FBRyxLQUFLLE1BQU0sVUFBVSxhQUFhLEVBQUU7RUFDL0U7O3FDQXZEVyx1QkFBb0I7RUFBQTtnRkFBcEIsdUJBQW9CLFNBQXBCLHNCQUFvQixXQUFBLFlBRm5CLE9BQU0sQ0FBQTs7O2dGQUVQLHNCQUFvQixDQUFBO1VBSGhDRjtXQUFXO01BQ1YsWUFBWTtLQUNiOzs7QTs7Ozs7Ozs7O0FGZlcsSUFBQSw2QkFBQSxHQUFBLFNBQUEsQ0FBQTtBQUEwQixJQUFBLHFCQUFBLEdBQUEsZ0RBQUE7QUFBMkMsSUFBQSwyQkFBQTs7Ozs7QUFtQ3ZFLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUEsRUFBd0IsR0FBQSxTQUFBLEVBQUE7QUFDVSxJQUFBLHFCQUFBLEdBQUEsa0NBQUE7QUFBNkIsSUFBQSwyQkFBQTtBQUM3RCxJQUFBLHdCQUFBLEdBQUEsU0FBQSxFQUFBO0FBQ0YsSUFBQSwyQkFBQTs7Ozs7QUFPRSxJQUFBLDZCQUFBLEdBQUEsU0FBQSxDQUFBO0FBQTBCLElBQUEscUJBQUEsR0FBQSxzREFBQTtBQUFpRCxJQUFBLDJCQUFBOzs7Ozs7QUFhbkUsSUFBQSw2QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUdRLElBQUEseUJBQUEsU0FBQSxTQUFBLHNFQUFBO0FBQUEsWUFBQSxXQUFBLDRCQUFBLEdBQUEsRUFBQTtBQUFBLFlBQUEsU0FBQSw0QkFBQSxDQUFBO0FBQUEsYUFBQSwwQkFBUyxPQUFBLGtCQUFBLFNBQUEsUUFBQSxDQUFpQztJQUFBLENBQUE7QUFDaEQsSUFBQSxxQkFBQSxDQUFBO0FBQ0YsSUFBQSwyQkFBQTs7Ozs7QUFIUSxJQUFBLDBCQUFBLGdCQUFBLE9BQUEsdUJBQUEsU0FBQSxTQUFBLFFBQUEsQ0FBQTtBQUVOLElBQUEsd0JBQUE7QUFBQSxJQUFBLGlDQUFBLEtBQUEsU0FBQSxRQUFBLEdBQUE7Ozs7O0FBUlIsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQSxFQUE2QixHQUFBLElBQUE7QUFDdkIsSUFBQSxxQkFBQSxDQUFBO0FBQWdCLElBQUEsMkJBQUE7QUFDcEIsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNFLElBQUEsK0JBQUEsR0FBQSw2Q0FBQSxHQUFBLEdBQUEsVUFBQSxJQUFBRyxXQUFBO0FBUUYsSUFBQSwyQkFBQSxFQUFNOzs7O0FBVkYsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxPQUFBLE1BQUE7QUFFRixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLE9BQUEsTUFBQTs7Ozs7O0FBdEVkLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUEsRUFBNkIsR0FBQSxPQUFBLENBQUEsRUFDRixHQUFBLElBQUE7QUFDbkIsSUFBQSxxQkFBQSxDQUFBO0FBQTZFLElBQUEsMkJBQUE7QUFDakYsSUFBQSw2QkFBQSxHQUFBLFVBQUEsQ0FBQTtBQUEyQyxJQUFBLHlCQUFBLFNBQUEsU0FBQSx5REFBQTtBQUFBLE1BQUEsNEJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSw0QkFBQTtBQUFBLGFBQUEsMEJBQVMsT0FBQSxZQUFZLEtBQUssQ0FBQztJQUFBLENBQUE7QUFDcEUsSUFBQSx3QkFBQSxHQUFBLEtBQUEsQ0FBQTtBQUFrQyxJQUFBLHFCQUFBLEdBQUEsWUFBQTtBQUNwQyxJQUFBLDJCQUFBLEVBQVM7QUFHWCxJQUFBLDZCQUFBLEdBQUEsUUFBQSxDQUFBO0FBQStCLElBQUEseUJBQUEsWUFBQSxTQUFBLDBEQUFBO0FBQUEsTUFBQSw0QkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBO0FBQUEsYUFBQSwwQkFBWSxPQUFBLGNBQUEsQ0FBZTtJQUFBLENBQUE7QUFDeEQsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQSxFQUF3QixHQUFBLFNBQUEsQ0FBQTtBQUNGLElBQUEscUJBQUEsSUFBQSwwQkFBQTtBQUFxQixJQUFBLDJCQUFBO0FBQ3pDLElBQUEsd0JBQUEsSUFBQSxTQUFBLENBQUE7QUFDQSxJQUFBLGtDQUFBLElBQUEsK0NBQUEsR0FBQSxHQUFBLFNBQUEsQ0FBQTtBQUdGLElBQUEsMkJBQUE7QUFFQSxJQUFBLDZCQUFBLElBQUEsT0FBQSxFQUFBLEVBQXNCLElBQUEsT0FBQSxDQUFBLEVBQ0ksSUFBQSxTQUFBLEVBQUE7QUFDQyxJQUFBLHFCQUFBLElBQUEsYUFBQTtBQUFXLElBQUEsMkJBQUE7QUFDbEMsSUFBQSw2QkFBQSxJQUFBLFVBQUEsRUFBQSxFQUFvRSxJQUFBLFVBQUEsRUFBQTtBQUN2QyxJQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFVLElBQUEsMkJBQUE7QUFDckMsSUFBQSw2QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUF3QixJQUFBLHFCQUFBLElBQUEsWUFBQTtBQUFPLElBQUEsMkJBQUE7QUFDL0IsSUFBQSw2QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUF1QixJQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFNLElBQUEsMkJBQUEsRUFBUyxFQUMvQjtBQUdYLElBQUEsNkJBQUEsSUFBQSxPQUFBLENBQUEsRUFBd0IsSUFBQSxTQUFBLEVBQUE7QUFDRyxJQUFBLHFCQUFBLElBQUEsZUFBQTtBQUFhLElBQUEsMkJBQUE7QUFDdEMsSUFBQSw2QkFBQSxJQUFBLFVBQUEsRUFBQSxFQUEwRSxJQUFBLFVBQUEsRUFBQTtBQUNoRCxJQUFBLHFCQUFBLElBQUEsU0FBQTtBQUFPLElBQUEsMkJBQUE7QUFDL0IsSUFBQSw2QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUF1QixJQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFNLElBQUEsMkJBQUE7QUFDN0IsSUFBQSw2QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUE0QixJQUFBLHFCQUFBLElBQUEsYUFBQTtBQUFXLElBQUEsMkJBQUE7QUFDdkMsSUFBQSw2QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUF1QixJQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFNLElBQUEsMkJBQUEsRUFBUyxFQUMvQjtBQUdYLElBQUEsNkJBQUEsSUFBQSxPQUFBLENBQUEsRUFBd0IsSUFBQSxTQUFBLEVBQUE7QUFDSSxJQUFBLHFCQUFBLElBQUEsa0NBQUE7QUFBNkIsSUFBQSwyQkFBQTtBQUN2RCxJQUFBLDZCQUFBLElBQUEsVUFBQSxFQUFBO0FBQTZFLElBQUEseUJBQUEsVUFBQSxTQUFBLDJEQUFBO0FBQUEsTUFBQSw0QkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBO0FBQUEsYUFBQSwwQkFBVSxPQUFBLHFCQUFBLENBQXNCO0lBQUEsQ0FBQTtBQUMzRyxJQUFBLDZCQUFBLElBQUEsVUFBQSxFQUFBO0FBQW1CLElBQUEscUJBQUEsSUFBQSwwQkFBQTtBQUFrQixJQUFBLDJCQUFBO0FBQ3JDLElBQUEsNkJBQUEsSUFBQSxVQUFBLEVBQUE7QUFBbUIsSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBTyxJQUFBLDJCQUFBO0FBQzFCLElBQUEsNkJBQUEsSUFBQSxVQUFBLEVBQUE7QUFBOEIsSUFBQSxxQkFBQSxJQUFBLGVBQUE7QUFBYSxJQUFBLDJCQUFBLEVBQVMsRUFDN0MsRUFDTDtBQUdSLElBQUEsa0NBQUEsSUFBQSwrQ0FBQSxHQUFBLEdBQUEsT0FBQSxDQUFBO0FBT0EsSUFBQSw2QkFBQSxJQUFBLE9BQUEsQ0FBQSxFQUF3QixJQUFBLFNBQUEsRUFBQTtBQUNHLElBQUEscUJBQUEsSUFBQSxvQ0FBQTtBQUE0QixJQUFBLDJCQUFBO0FBQ3JELElBQUEsd0JBQUEsSUFBQSxZQUFBLEVBQUE7QUFDQSxJQUFBLGtDQUFBLElBQUEsK0NBQUEsR0FBQSxHQUFBLFNBQUEsQ0FBQTtBQUdGLElBQUEsMkJBQUE7QUFHQSxJQUFBLDZCQUFBLElBQUEsT0FBQSxDQUFBLEVBQXdCLElBQUEsT0FBQTtBQUNmLElBQUEscUJBQUEsSUFBQSx3Q0FBQTtBQUFzQyxJQUFBLDJCQUFBO0FBQzdDLElBQUEsNkJBQUEsSUFBQSxPQUFBLEVBQUE7QUFDRSxJQUFBLCtCQUFBLElBQUEsdUNBQUEsR0FBQSxHQUFBLE9BQUEsSUFBQUMsV0FBQTtBQWVGLElBQUEsMkJBQUEsRUFBTTtBQUdSLElBQUEsNkJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBMEIsSUFBQSxVQUFBLEVBQUE7QUFDcUIsSUFBQSx5QkFBQSxTQUFBLFNBQUEsMERBQUE7QUFBQSxNQUFBLDRCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsNEJBQUE7QUFBQSxhQUFBLDBCQUFTLE9BQUEsWUFBWSxLQUFLLENBQUM7SUFBQSxDQUFBO0FBQUUsSUFBQSxxQkFBQSxJQUFBLFVBQUE7QUFBUSxJQUFBLDJCQUFBO0FBQ2xGLElBQUEsNkJBQUEsSUFBQSxVQUFBLEVBQUE7QUFDRSxJQUFBLHFCQUFBLEVBQUE7QUFDRixJQUFBLDJCQUFBLEVBQVMsRUFDTCxFQUNEOzs7OztBQXhGRCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLE9BQUEsY0FBQSwwQkFBQSwrQkFBQTtBQU1BLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsYUFBQSxPQUFBLFVBQUE7QUFJRixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLE9BQUEsZ0JBQUEsUUFBQSxJQUFBLEtBQUEsRUFBQTtBQW1DRixJQUFBLHdCQUFBLEVBQUE7QUFBQSxJQUFBLDhCQUFBLFVBQUEsT0FBQSxXQUFBLElBQUEsY0FBQSxNQUFBLE9BQUEsT0FBQSxRQUFBLFdBQUEsa0JBQUEsS0FBQSxFQUFBO0FBVUUsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxPQUFBLGdCQUFBLGFBQUEsSUFBQSxLQUFBLEVBQUE7QUFTRSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLE9BQUEsbUJBQUE7QUFvQnlDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsWUFBQSxPQUFBLFdBQUEsV0FBQSxPQUFBLHVCQUFBLFdBQUEsQ0FBQTtBQUN6QyxJQUFBLHdCQUFBO0FBQUEsSUFBQSxpQ0FBQSxLQUFBLE9BQUEsY0FBQSxvQkFBQSxtQkFBQSxHQUFBOzs7Ozs7QUFtQ0YsSUFBQSw2QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUF3QyxJQUFBLHlCQUFBLFNBQUEsU0FBQSx3RUFBQTtBQUFBLE1BQUEsNEJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSw0QkFBQSxDQUFBO0FBQUEsYUFBQSwwQkFBUyxPQUFBLFlBQVksSUFBSSxDQUFDO0lBQUEsQ0FBQTtBQUNoRSxJQUFBLHdCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQWlDLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUNuQyxJQUFBLDJCQUFBOzs7Ozs7QUFXQSxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBO0FBRUssSUFBQSx5QkFBQSxTQUFBLFNBQUEsNkRBQUE7QUFBQSxZQUFBLFlBQUEsNEJBQUEsR0FBQSxFQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFBLDBCQUFTLE9BQUEsa0JBQUEsU0FBQSxDQUF5QjtJQUFBLENBQUE7QUFFckMsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQSxFQUF5QixHQUFBLElBQUE7QUFDbkIsSUFBQSxxQkFBQSxDQUFBO0FBQW1CLElBQUEsMkJBQUE7QUFDdkIsSUFBQSw2QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUNFLElBQUEscUJBQUEsQ0FBQTtBQUNGLElBQUEsMkJBQUEsRUFBTztBQUdULElBQUEsNkJBQUEsR0FBQSxLQUFBLEVBQUE7QUFBMEIsSUFBQSx3QkFBQSxHQUFBLEtBQUEsRUFBQTtBQUF1QyxJQUFBLHFCQUFBLENBQUE7QUFBOEQsSUFBQSwyQkFBQTtBQUUvSCxJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBLEVBQXVCLElBQUEsTUFBQTtBQUNmLElBQUEsd0JBQUEsSUFBQSxLQUFBLEVBQUE7QUFBbUMsSUFBQSxxQkFBQSxFQUFBO0FBQXNCLElBQUEsMkJBQUE7QUFDL0QsSUFBQSw2QkFBQSxJQUFBLE1BQUE7QUFBTSxJQUFBLHdCQUFBLElBQUEsS0FBQSxFQUFBO0FBQXNDLElBQUEscUJBQUEsRUFBQTtBQUF3QixJQUFBLDJCQUFBO0FBQ3BFLElBQUEsNkJBQUEsSUFBQSxNQUFBO0FBQU0sSUFBQSx3QkFBQSxJQUFBLEtBQUEsRUFBQTtBQUE0QyxJQUFBLHFCQUFBLEVBQUE7O0FBQWtELElBQUEsMkJBQUEsRUFBTyxFQUN2Rzs7Ozs7QUFoQkgsSUFBQSwwQkFBQSxpQkFBQSxPQUFBLHNCQUFBLE9BQUEsT0FBQSxPQUFBLG1CQUFBLGVBQUEsVUFBQSxTQUFBO0FBSUcsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxnQ0FBQSxVQUFBLE1BQUE7QUFDdUIsSUFBQSx3QkFBQTtBQUFBLElBQUEsMEJBQUEsV0FBQSxPQUFBLGdCQUFBLFNBQUEsQ0FBQTtBQUN6QixJQUFBLHdCQUFBO0FBQUEsSUFBQSxpQ0FBQSxLQUFBLE9BQUEsZ0JBQUEsU0FBQSxJQUFBLFlBQUEsV0FBQSxHQUFBO0FBSTZELElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsS0FBQSxVQUFBLGVBQUEsVUFBQSxrQkFBQSxTQUFBO0FBR3RCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsS0FBQSxVQUFBLFNBQUE7QUFDRyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLEtBQUEsVUFBQSxXQUFBO0FBQ00sSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxLQUFBLDBCQUFBLElBQUEsSUFBQSxVQUFBLG1CQUFBLFlBQUEsQ0FBQTs7Ozs7QUFJdEQsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQSxFQUE0QixHQUFBLEdBQUE7QUFDdkIsSUFBQSxxQkFBQSxHQUFBLG9FQUFBO0FBQWtFLElBQUEsMkJBQUEsRUFBSTs7Ozs7QUFnQ3ZFLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUEsRUFBdUIsR0FBQSxRQUFBO0FBQ2YsSUFBQSxxQkFBQSxHQUFBLFdBQUE7QUFBUyxJQUFBLDJCQUFBO0FBQVUsSUFBQSxxQkFBQSxDQUFBOztBQUMzQixJQUFBLDJCQUFBOzs7O0FBRDJCLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsS0FBQSwwQkFBQSxHQUFBLEdBQUEsT0FBQSx3QkFBQSxPQUFBLGtCQUFBLEdBQUEsWUFBQSxHQUFBLE1BQUEsT0FBQSxtQkFBQSxlQUFBLFlBQUE7Ozs7O0FBV3JCLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBOEIsSUFBQSxxQkFBQSxDQUFBO0FBQVcsSUFBQSwyQkFBQTs7OztBQUFYLElBQUEsd0JBQUE7QUFBQSxJQUFBLGdDQUFBLFNBQUE7Ozs7O0FBSGxDLElBQUEsNkJBQUEsR0FBQSxJQUFBO0FBQUksSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQXNCLElBQUEsMkJBQUE7QUFDMUIsSUFBQSw2QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUNFLElBQUEsK0JBQUEsR0FBQSxvRUFBQSxHQUFBLEdBQUEsUUFBQSxJQUFBLHVDQUFBO0FBR0YsSUFBQSwyQkFBQTs7OztBQUhFLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsT0FBQSxtQkFBQSxjQUFBOzs7OztBQWFBLElBQUEsNkJBQUEsR0FBQSxVQUFBLEVBQUE7QUFDRSxJQUFBLHdCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQWlDLElBQUEscUJBQUEsR0FBQSx3QkFBQTtBQUNuQyxJQUFBLDJCQUFBOzs7OztBQUVBLElBQUEsNkJBQUEsR0FBQSxVQUFBLEVBQUE7QUFDRSxJQUFBLHdCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQXlDLElBQUEscUJBQUEsR0FBQSx1QkFBQTtBQUMzQyxJQUFBLDJCQUFBOzs7Ozs7QUFFQSxJQUFBLDZCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQTZDLElBQUEseUJBQUEsU0FBQSxTQUFBLHFHQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFBLDBCQUFTLE9BQUEsbUJBQUEsT0FBQSxtQkFBQSxTQUFBLENBQWdEO0lBQUEsQ0FBQTtBQUNwRyxJQUFBLHdCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQXdDLElBQUEscUJBQUEsR0FBQSxvQkFBQTtBQUMxQyxJQUFBLDJCQUFBOzs7OztBQVhGLElBQUEsa0NBQUEsR0FBQSw0RUFBQSxHQUFBLEdBQUEsVUFBQSxFQUFBLEVBQTRDLEdBQUEsNEVBQUEsR0FBQSxHQUFBLFVBQUEsRUFBQSxFQUljLEdBQUEsNEVBQUEsR0FBQSxHQUFBLFVBQUEsRUFBQTs7OztBQUoxRCxJQUFBLDRCQUFBLENBQUEsT0FBQSxnQkFBQSxPQUFBLGtCQUFBLElBQUEsSUFBQSxPQUFBLGNBQUEsT0FBQSxtQkFBQSxTQUFBLElBQUEsSUFBQSxDQUFBOzs7Ozs7QUE4QkUsSUFBQSw2QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUFnRCxJQUFBLHlCQUFBLFNBQUEsU0FBQSxxR0FBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSw0QkFBQSxDQUFBO0FBQUEsYUFBQSwwQkFBUyxPQUFBLG9CQUFBLE9BQUEsbUJBQUEsV0FBa0QsU0FBUyxDQUFDO0lBQUEsQ0FBQTtBQUNuSCxJQUFBLHdCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQTBDLElBQUEscUJBQUEsR0FBQSx1QkFBQTtBQUM1QyxJQUFBLDJCQUFBOzs7Ozs7QUFFQSxJQUFBLDZCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQWlELElBQUEseUJBQUEsU0FBQSxTQUFBLHNHQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFBLDBCQUFTLE9BQUEsb0JBQUEsT0FBQSxtQkFBQSxXQUFrRCxTQUFTLENBQUM7SUFBQSxDQUFBO0FBQ3BILElBQUEsd0JBQUEsR0FBQSxLQUFBLEVBQUE7QUFBd0MsSUFBQSxxQkFBQSxHQUFBLHdCQUFBO0FBQzFDLElBQUEsMkJBQUE7Ozs7OztBQW5CRixJQUFBLDZCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQTZDLElBQUEseUJBQUEsU0FBQSxTQUFBLHVGQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFBLDBCQUFTLE9BQUEsY0FBQSxPQUFBLG1CQUFBLFNBQUEsQ0FBMkM7SUFBQSxDQUFBO0FBQy9GLElBQUEsd0JBQUEsR0FBQSxLQUFBLEVBQUE7QUFBa0MsSUFBQSxxQkFBQSxHQUFBLGtCQUFBO0FBQ3BDLElBQUEsMkJBQUE7QUFFQSxJQUFBLDZCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQXlDLElBQUEseUJBQUEsU0FBQSxTQUFBLHVGQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFBLDBCQUFTLE9BQUEsWUFBWSxNQUFJLE9BQUEsa0JBQUEsQ0FBcUI7SUFBQSxDQUFBO0FBQ3JGLElBQUEsd0JBQUEsR0FBQSxLQUFBLEVBQUE7QUFBMEMsSUFBQSxxQkFBQSxHQUFBLHlCQUFBO0FBQzVDLElBQUEsMkJBQUE7QUFFQSxJQUFBLDZCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQTJDLElBQUEseUJBQUEsU0FBQSxTQUFBLHVGQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFBLDBCQUFTLE9BQUEsZ0JBQUEsT0FBQSxtQkFBQSxTQUFBLENBQTZDO0lBQUEsQ0FBQTtBQUMvRixJQUFBLHdCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQTJDLElBQUEscUJBQUEsR0FBQSxtQkFBQTtBQUM3QyxJQUFBLDJCQUFBO0FBRUEsSUFBQSxrQ0FBQSxHQUFBLDRFQUFBLEdBQUEsR0FBQSxVQUFBLEVBQUEsRUFBMkMsSUFBQSw2RUFBQSxHQUFBLEdBQUEsVUFBQSxFQUFBOzs7O0FBQTNDLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsT0FBQSxnQkFBQSxPQUFBLGtCQUFBLElBQUEsSUFBQSxFQUFBOzs7Ozs7QUFhQSxJQUFBLDZCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQTZDLElBQUEseUJBQUEsU0FBQSxTQUFBLHVGQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFBLDBCQUFTLE9BQUEsY0FBQSxPQUFBLG1CQUFBLFNBQUEsQ0FBMkM7SUFBQSxDQUFBO0FBQy9GLElBQUEsd0JBQUEsR0FBQSxLQUFBLEVBQUE7QUFBa0MsSUFBQSxxQkFBQSxHQUFBLGtCQUFBO0FBQ3BDLElBQUEsMkJBQUE7QUFFQSxJQUFBLDZCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQWlELElBQUEseUJBQUEsU0FBQSxTQUFBLHVGQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFBLDBCQUFTLE9BQUEsZ0JBQUEsT0FBQSxtQkFBQSxTQUFBLENBQTZDO0lBQUEsQ0FBQTtBQUNyRyxJQUFBLHdCQUFBLEdBQUEsS0FBQSxFQUFBO0FBQXNDLElBQUEscUJBQUEsR0FBQSxrQ0FBQTtBQUN4QyxJQUFBLDJCQUFBOzs7OztBQS9GTixJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBLEVBQW1DLEdBQUEsT0FBQSxFQUFBLEVBRUQsR0FBQSxLQUFBLEVBQ3pCLEdBQUEsSUFBQTtBQUNDLElBQUEscUJBQUEsQ0FBQTtBQUErQixJQUFBLDJCQUFBO0FBQ25DLElBQUEsNkJBQUEsR0FBQSxLQUFBLEVBQUE7QUFBMkIsSUFBQSx3QkFBQSxHQUFBLEtBQUEsRUFBQTtBQUF1QyxJQUFBLHFCQUFBLENBQUE7QUFBMEYsSUFBQSwyQkFBQSxFQUFJO0FBR2xLLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBOEIsSUFBQSxxQkFBQSxDQUFBO0FBQWtDLElBQUEsMkJBQUEsRUFBTztBQUd6RSxJQUFBLHdCQUFBLElBQUEsSUFBQTtBQUVBLElBQUEsNkJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBMEIsSUFBQSxPQUFBLEVBQUEsRUFDRCxJQUFBLFFBQUE7QUFDYixJQUFBLHFCQUFBLElBQUEsdUJBQUE7QUFBcUIsSUFBQSwyQkFBQTtBQUFVLElBQUEscUJBQUEsRUFBQTtBQUN6QyxJQUFBLDJCQUFBO0FBRUEsSUFBQSw2QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUF1QixJQUFBLFFBQUE7QUFDZixJQUFBLHFCQUFBLElBQUEsZUFBQTtBQUFhLElBQUEsMkJBQUE7QUFBVSxJQUFBLHFCQUFBLEVBQUE7O0FBQy9CLElBQUEsMkJBQUE7QUFHQSxJQUFBLGtDQUFBLElBQUEsOERBQUEsR0FBQSxHQUFBLE9BQUEsRUFBQTtBQU1BLElBQUEsNkJBQUEsSUFBQSxJQUFBO0FBQUksSUFBQSxxQkFBQSxJQUFBLDJCQUFBO0FBQXNCLElBQUEsMkJBQUE7QUFDMUIsSUFBQSw2QkFBQSxJQUFBLEtBQUEsRUFBQTtBQUE2QixJQUFBLHFCQUFBLEVBQUE7QUFBb0MsSUFBQSwyQkFBQTtBQUVqRSxJQUFBLGtDQUFBLElBQUEsOERBQUEsR0FBQSxDQUFBO0FBUUYsSUFBQSwyQkFBQTtBQUdBLElBQUEsNkJBQUEsSUFBQSxPQUFBLEVBQUE7QUFHRSxJQUFBLGtDQUFBLElBQUEsOERBQUEsR0FBQSxDQUFBO0FBaUJBLElBQUEsa0NBQUEsSUFBQSw4REFBQSxJQUFBLENBQUE7QUF5QkEsSUFBQSxrQ0FBQSxJQUFBLDhEQUFBLEdBQUEsQ0FBQTtBQVNGLElBQUEsMkJBQUEsRUFBTTs7OztBQTdGRSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLE9BQUEsbUJBQUEsTUFBQTtBQUM4RCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLEtBQUEsT0FBQSxtQkFBQSxlQUFBLE9BQUEsbUJBQUEsa0JBQUEsYUFBQTtBQUd0QyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLE9BQUEsbUJBQUEsU0FBQTtBQU9XLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsS0FBQSxPQUFBLG1CQUFBLGFBQUEsR0FBQTtBQUlWLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsS0FBQSwwQkFBQSxJQUFBLElBQUEsT0FBQSxtQkFBQSxtQkFBQSxZQUFBLEdBQUEsR0FBQTtBQUkvQixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLE9BQUEsd0JBQUEsT0FBQSxrQkFBQSxJQUFBLEtBQUEsRUFBQTtBQU82QixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLE9BQUEsbUJBQUEsV0FBQTtBQUU3QixJQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxPQUFBLG1CQUFBLGtCQUFBLE9BQUEsbUJBQUEsZUFBQSxTQUFBLElBQUEsS0FBQSxFQUFBO0FBY0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSw0QkFBQSxPQUFBLGVBQUEsZ0JBQUEsT0FBQSxlQUFBLGVBQUEsQ0FBQSxPQUFBLGFBQUEsS0FBQSxFQUFBO0FBaUJBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBLE9BQUEsZUFBQSxhQUFBLE9BQUEsZ0JBQUEsT0FBQSxtQkFBQSxjQUFBLE9BQUEsbUJBQUEsZUFBQSxPQUFBLFFBQUEsT0FBQSxtQkFBQSxjQUFBLE9BQUEsbUJBQUEsWUFBQSxTQUFBLEtBQUEsS0FBQSxFQUFBO0FBeUJBLElBQUEsd0JBQUE7QUFBQSxJQUFBLDRCQUFBLE9BQUEsZUFBQSxVQUFBLEtBQUEsRUFBQTs7Ozs7QUFhSixJQUFBLDZCQUFBLEdBQUEsT0FBQSxFQUFBLEVBQTJCLEdBQUEsR0FBQTtBQUN0QixJQUFBLHFCQUFBLEdBQUEsMERBQUE7QUFBd0QsSUFBQSwyQkFBQSxFQUFJOzs7Ozs7QUF2S3ZFLElBQUEsNkJBQUEsR0FBQSxVQUFBLEVBQUEsRUFBK0IsR0FBQSxPQUFBLEVBQUEsRUFDRCxHQUFBLElBQUE7QUFDdEIsSUFBQSxxQkFBQSxHQUFBLCtCQUFBO0FBQTZCLElBQUEsMkJBQUE7QUFDakMsSUFBQSw2QkFBQSxHQUFBLEtBQUEsRUFBQTtBQUFxQixJQUFBLHFCQUFBLEdBQUEseUVBQUE7QUFBb0UsSUFBQSwyQkFBQSxFQUFJO0FBRy9GLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUEsRUFBMEIsR0FBQSxTQUFBLEVBQUE7QUFDK0IsSUFBQSwrQkFBQSxpQkFBQSxTQUFBLDhEQUFBLFFBQUE7QUFBQSxNQUFBLDRCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsNEJBQUE7QUFBQSxNQUFBLGlDQUFBLE9BQUEsYUFBQSxNQUFBLE1BQUEsT0FBQSxjQUFBO0FBQUEsYUFBQSwwQkFBQSxNQUFBO0lBQUEsQ0FBQTtBQUEwQixJQUFBLHlCQUFBLFNBQUEsU0FBQSx3REFBQTtBQUFBLE1BQUEsNEJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSw0QkFBQTtBQUFBLGFBQUEsMEJBQVMsT0FBQSxvQkFBQSxDQUFxQjtJQUFBLENBQUE7QUFBL0csSUFBQSwyQkFBQTtBQUVBLElBQUEsNkJBQUEsR0FBQSxVQUFBLEVBQUE7QUFBb0QsSUFBQSwrQkFBQSxpQkFBQSxTQUFBLCtEQUFBLFFBQUE7QUFBQSxNQUFBLDRCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsNEJBQUE7QUFBQSxNQUFBLGlDQUFBLE9BQUEsaUJBQUEsTUFBQSxNQUFBLE9BQUEsa0JBQUE7QUFBQSxhQUFBLDBCQUFBLE1BQUE7SUFBQSxDQUFBO0FBQThCLElBQUEseUJBQUEsVUFBQSxTQUFBLDBEQUFBO0FBQUEsTUFBQSw0QkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBO0FBQUEsYUFBQSwwQkFBVSxPQUFBLG9CQUFBLENBQXFCO0lBQUEsQ0FBQTtBQUMvRyxJQUFBLDZCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQXNCLElBQUEscUJBQUEsSUFBQSx1QkFBQTtBQUFxQixJQUFBLDJCQUFBO0FBQzNDLElBQUEsNkJBQUEsSUFBQSxVQUFBLEVBQUE7QUFBMkIsSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBVSxJQUFBLDJCQUFBO0FBQ3JDLElBQUEsNkJBQUEsSUFBQSxVQUFBLEVBQUE7QUFBd0IsSUFBQSxxQkFBQSxJQUFBLFlBQUE7QUFBTyxJQUFBLDJCQUFBO0FBQy9CLElBQUEsNkJBQUEsSUFBQSxVQUFBLEVBQUE7QUFBdUIsSUFBQSxxQkFBQSxJQUFBLFFBQUE7QUFBTSxJQUFBLDJCQUFBLEVBQVM7QUFHeEMsSUFBQSw2QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUErQixJQUFBLFVBQUEsRUFBQTtBQUNzQyxJQUFBLHlCQUFBLFNBQUEsU0FBQSwwREFBQTtBQUFBLE1BQUEsNEJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSw0QkFBQTtBQUFBLGFBQUEsMEJBQVMsT0FBQSxvQkFBb0IsVUFBVSxDQUFDO0lBQUEsQ0FBQTtBQUFFLElBQUEscUJBQUEsSUFBQSxVQUFBO0FBQVEsSUFBQSwyQkFBQTtBQUNySCxJQUFBLDZCQUFBLElBQUEsVUFBQSxFQUFBO0FBQW1FLElBQUEseUJBQUEsU0FBQSxTQUFBLDBEQUFBO0FBQUEsTUFBQSw0QkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBO0FBQUEsYUFBQSwwQkFBUyxPQUFBLG9CQUFvQixVQUFVLENBQUM7SUFBQSxDQUFBO0FBQUUsSUFBQSxxQkFBQSxJQUFBLFVBQUE7QUFBUSxJQUFBLDJCQUFBO0FBQ3JILElBQUEsNkJBQUEsSUFBQSxVQUFBLEVBQUE7QUFBZ0UsSUFBQSx5QkFBQSxTQUFBLFNBQUEsMERBQUE7QUFBQSxNQUFBLDRCQUFBLEdBQUE7QUFBQSxZQUFBLFNBQUEsNEJBQUE7QUFBQSxhQUFBLDBCQUFTLE9BQUEsb0JBQW9CLE9BQU8sQ0FBQztJQUFBLENBQUE7QUFBRSxJQUFBLHFCQUFBLElBQUEsT0FBQTtBQUFLLElBQUEsMkJBQUEsRUFBUztBQUd2SCxJQUFBLGtDQUFBLElBQUEsK0NBQUEsR0FBQSxHQUFBLFVBQUEsRUFBQTtBQUtGLElBQUEsMkJBQUEsRUFBTTtBQUlSLElBQUEsNkJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBNEIsSUFBQSxTQUFBLEVBQUE7QUFJeEIsSUFBQSwrQkFBQSxJQUFBLHVDQUFBLElBQUEsSUFBQSxPQUFBLElBQUEsWUFBQSxPQUFBLDRDQUFBLEdBQUEsR0FBQSxPQUFBLEVBQUE7QUF5QkYsSUFBQSwyQkFBQTtBQUdBLElBQUEsNkJBQUEsSUFBQSxRQUFBLEVBQUE7QUFDRSxJQUFBLGtDQUFBLElBQUEsK0NBQUEsSUFBQSxJQUFBLE9BQUEsRUFBQSxFQUEwQixJQUFBLCtDQUFBLEdBQUEsR0FBQSxPQUFBLEVBQUE7QUEwRzVCLElBQUEsMkJBQUEsRUFBTzs7OztBQW5La0QsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSwrQkFBQSxXQUFBLE9BQUEsV0FBQTtBQUVILElBQUEsd0JBQUE7QUFBQSxJQUFBLCtCQUFBLFdBQUEsT0FBQSxlQUFBO0FBUTVCLElBQUEsd0JBQUEsRUFBQTtBQUFBLElBQUEsMEJBQUEsVUFBQSxPQUFBLGlCQUFBLFVBQUE7QUFDQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLFVBQUEsT0FBQSxpQkFBQSxVQUFBO0FBQ0EsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxVQUFBLE9BQUEsaUJBQUEsT0FBQTtBQUd4QixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLE9BQUEsZUFBQSxhQUFBLE9BQUEsZUFBQSxVQUFBLEtBQUEsRUFBQTtBQWFBLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEseUJBQUEsT0FBQSxnQkFBQTtBQTZCQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLE9BQUEscUJBQUEsS0FBQSxFQUFBOzs7QUQ5SUYsSUFBTyxVQUFQLE1BQU8sU0FBTztFQXdCUjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUE1QlYsYUFBcUI7RUFDckIsWUFBMkI7RUFDM0IsZ0JBQStCO0VBRS9CLG9CQUE2QjtFQUM3QixjQUF1QjtFQUN2QixvQkFBbUM7RUFDbkM7RUFFQSxzQkFBd0MsQ0FBQTtFQUN4Qyx5QkFBbUMsQ0FBQTtFQUVuQyx1QkFBOEIsQ0FBQTtFQUM5QixtQkFBMEIsQ0FBQTtFQUMxQixxQkFBMEI7RUFFMUIsMEJBQXVDLG9CQUFJLElBQUc7RUFFOUMsY0FBc0I7RUFDdEIsa0JBQTBCO0VBQzFCLGVBQWtEO0VBRWxELFlBQ1UsSUFDQSxlQUNBLHNCQUNBLGFBQ0EsS0FDQSxRQUFjO0FBTGQsU0FBQSxLQUFBO0FBQ0EsU0FBQSxnQkFBQTtBQUNBLFNBQUEsdUJBQUE7QUFDQSxTQUFBLGNBQUE7QUFDQSxTQUFBLE1BQUE7QUFDQSxTQUFBLFNBQUE7RUFDUDtFQUVILFdBQVE7QUFDTixVQUFNLGtCQUFrQixLQUFLLFlBQVksaUJBQWdCO0FBR3pELFVBQU0sU0FBUyxLQUFLLFlBQVksZUFBYyxLQUFNLGlCQUFpQixPQUFPO0FBQzVFLFNBQUssYUFBYSxPQUFPLE1BQU0sRUFBRSxZQUFXO0FBRTVDLFNBQUssWUFBWSxrQkFBa0IsT0FBTyxnQkFBZ0IsaUJBQWlCLGdCQUFnQixjQUFjLGdCQUFnQixFQUFFLElBQUk7QUFDL0gsU0FBSyxnQkFBZ0Isa0JBQWtCLGdCQUFnQixTQUFTO0FBRWhFLFNBQUssc0JBQXFCO0FBRzFCLFNBQUssMEJBQXlCO0FBRzlCLFFBQUksaUJBQWlCO0FBQ25CLFdBQUssNkJBQTRCO0FBRWpDLFVBQUksS0FBSyxlQUFlLGNBQWM7QUFDcEMsYUFBSyx1QkFBc0I7TUFDN0I7SUFDRjtFQUNGO0VBRUEsd0JBQXFCO0FBQ25CLFNBQUssYUFBYSxLQUFLLEdBQUcsTUFBTTtNQUM5QixRQUFRLENBQUMsSUFBSSxDQUFDQyxZQUFXLFVBQVVBLFlBQVcsVUFBVSxDQUFDLENBQUMsQ0FBQztNQUMzRCxXQUFXLENBQUMsY0FBV0EsWUFBVyxRQUFRO01BQzFDLGFBQWEsQ0FBQyxVQUFVQSxZQUFXLFFBQVE7TUFDM0MsYUFBYSxDQUFDLElBQUksQ0FBQ0EsWUFBVyxVQUFVQSxZQUFXLFVBQVUsRUFBRSxDQUFDLENBQUM7TUFDakUsY0FBYyxDQUFDLE1BQU1BLFlBQVcsUUFBUTtNQUN4QyxvQkFBb0IsQ0FBQyxJQUFJO0tBQzFCO0VBQ0g7RUFFQSxxQkFBa0I7QUFDaEIsU0FBSyxjQUFjO0FBQ25CLFNBQUssb0JBQW9CO0FBQ3pCLFNBQUsseUJBQXlCLENBQUE7QUFDOUIsU0FBSyxXQUFXLE1BQU07TUFDcEIsV0FBVztNQUNYLGFBQWE7TUFDYixjQUFjO0tBQ2Y7RUFDSDtFQUVBLElBQUksNkJBQTBCO0FBQzVCLFVBQU0sZ0JBQXlCLENBQUE7QUFDL0IsZUFBVyxPQUFPLEtBQUsscUJBQXFCO0FBQzFDLGlCQUFXLFNBQVMsSUFBSSxRQUFRO0FBQzlCLFlBQUksS0FBSyx1QkFBdUIsU0FBUyxNQUFNLFFBQVEsR0FBRztBQUN4RCx3QkFBYyxLQUFLLEtBQUs7UUFDMUI7TUFDRjtJQUNGO0FBQ0EsV0FBTztFQUNUO0VBRUEseUJBQXNCO0FBQ3BCLFFBQUksQ0FBQyxLQUFLO0FBQVc7QUFDckIsU0FBSyxxQkFBcUIsZ0JBQWdCLE9BQU8sS0FBSyxTQUFTLENBQUMsRUFBRSxVQUFVO01BQzFFLE1BQU0sQ0FBQyxrQkFBaUI7QUFDdEIsYUFBSywwQkFBMEIsSUFBSSxJQUFJLGNBQWMsSUFBSSxPQUFLLE9BQU8sRUFBRSxTQUFTLENBQUMsQ0FBQztBQUNsRixhQUFLLElBQUksY0FBYTtNQUN4QjtNQUNBLE9BQU8sQ0FBQyxRQUFRLFFBQVEsTUFBTSxtQ0FBbUMsR0FBRztLQUNyRTtFQUNIO0VBRUEsNEJBQXlCO0FBQ3ZCLFNBQUssY0FBYyxtQkFBa0IsRUFBRyxVQUFVO01BQ2hELE1BQU0sQ0FBQyxTQUFlO0FBQ3BCLGFBQUssd0JBQXdCLFFBQVEsQ0FBQSxHQUFJLElBQUksT0FBSTtBQUMvQyxnQkFBTSxpQkFDSixFQUFFLHFCQUNGLEVBQUUsb0JBQ0YsRUFBRSxjQUNGLEVBQUUsYUFDRixFQUFFLGtCQUNGLEVBQUU7QUFFSixpQkFBTyxpQ0FDRixJQURFO1lBRUwsZUFBZSxFQUFFLGlCQUFpQixFQUFFLGdCQUFnQjtZQUNwRCxtQkFBbUI7O1FBRXZCLENBQUM7QUFFRCxhQUFLLG9CQUFtQjtBQUN4QixhQUFLLElBQUksY0FBYTtNQUN4QjtNQUNBLE9BQU8sQ0FBQyxRQUFRLFFBQVEsTUFBTSw0QkFBNEIsR0FBRztLQUM5RDtFQUNIO0VBRUEsK0JBQTRCO0FBQzFCLFNBQUssY0FBYyx1QkFBc0IsRUFBRyxVQUFVO01BQ3BELE1BQU0sQ0FBQyxTQUFRO0FBQ2IsYUFBSyxzQkFBc0I7QUFDM0IsYUFBSyxJQUFJLGNBQWE7TUFDeEI7TUFDQSxPQUFPLENBQUMsUUFBUSxRQUFRLE1BQU0sZ0NBQWdDLEdBQUc7S0FDbEU7RUFDSDtFQUVBLHVCQUFvQjtBQUNsQixVQUFNLE9BQU8sS0FBSyxXQUFXLElBQUksY0FBYyxHQUFHO0FBQ2xELFVBQU0sY0FBYyxLQUFLLFdBQVcsSUFBSSxvQkFBb0I7QUFDNUQsUUFBSSxTQUFTLGlCQUFpQjtBQUM1QixtQkFBYSxjQUFjLENBQUNBLFlBQVcsVUFBVUEsWUFBVyxJQUFJLENBQUMsR0FBR0EsWUFBVyxJQUFJLEVBQUUsQ0FBQyxDQUFDO0lBQ3pGLE9BQU87QUFDTCxtQkFBYSxnQkFBZTtBQUM1QixtQkFBYSxTQUFTLElBQUk7SUFDNUI7QUFDQSxpQkFBYSx1QkFBc0I7RUFDckM7RUFFQSxrQkFBa0IsVUFBZ0I7QUFDaEMsVUFBTSxRQUFRLEtBQUssdUJBQXVCLFFBQVEsUUFBUTtBQUMxRCxRQUFJLFFBQVEsSUFBSTtBQUNkLFdBQUssdUJBQXVCLE9BQU8sT0FBTyxDQUFDO0lBQzdDLE9BQU87QUFDTCxXQUFLLHVCQUF1QixLQUFLLFFBQVE7SUFDM0M7RUFDRjtFQUVBLGtCQUFrQixRQUFXO0FBQzNCLFFBQUksQ0FBQztBQUFRO0FBQ2IsU0FBSyxxQkFBcUIsaUNBQ3JCLFNBRHFCO01BRXhCLFdBQVcsT0FBTyxhQUFhLE9BQU87TUFDdEMsZUFBZSxPQUFPLGlCQUFpQixPQUFPLGdCQUFnQjtNQUM5RCxnQkFBZ0IsT0FBTyxrQkFBa0IsQ0FBQTs7RUFFN0M7RUFFUSw2QkFBNkIsT0FBWTtBQUMvQyxRQUFJLE1BQU0sU0FBUyxHQUFHO0FBQ3BCLFdBQUssa0JBQWtCLE1BQU0sQ0FBQyxDQUFDO0lBQ2pDLE9BQU87QUFDTCxXQUFLLHFCQUFxQjtJQUM1QjtFQUNGO0VBRUEsZ0JBQWdCLE9BQWE7QUFDM0IsVUFBTSxVQUFVLEtBQUssV0FBVyxJQUFJLEtBQUs7QUFDekMsV0FBTyxDQUFDLEVBQUUsV0FBVyxRQUFRLFlBQVksUUFBUSxTQUFTLFFBQVE7RUFDcEU7RUFFQSxZQUFZLFNBQWtCLGVBQW9CLE1BQUk7QUFDcEQsU0FBSyxvQkFBb0I7QUFFekIsUUFBSSxTQUFTO0FBQ1gsVUFBSSxLQUFLLG9CQUFvQixXQUFXLEdBQUc7QUFDekMsYUFBSyw2QkFBNEI7TUFDbkM7QUFFQSxVQUFJLGNBQWM7QUFDaEIsYUFBSyxjQUFjO0FBQ25CLGFBQUssb0JBQW9CLGFBQWE7QUFDdEMsYUFBSyxXQUFXLFdBQVc7VUFDekIsUUFBUSxhQUFhO1VBQ3JCLFdBQVcsYUFBYTtVQUN4QixhQUFhLGFBQWE7VUFDMUIsYUFBYSxhQUFhO1VBQzFCLGNBQWMsT0FBTyxhQUFhLGlCQUFpQixJQUFJO1NBQ3hEO0FBQ0QsYUFBSyx5QkFBeUIsQ0FBQyxHQUFJLGFBQWEsY0FBYyxDQUFBLENBQUc7TUFDbkUsT0FBTztBQUNMLGFBQUssbUJBQWtCO01BQ3pCO0lBQ0YsT0FBTztBQUNMLFdBQUssbUJBQWtCO0lBQ3pCO0VBQ0Y7RUFFQSxjQUFjLFVBQWdCO0FBQzVCLFFBQUksQ0FBQztBQUFVO0FBQ2YsU0FBSyxPQUFPLFNBQVMsQ0FBQyxnQkFBZ0IsR0FBRyxFQUFFLGFBQWEsRUFBRSxRQUFRLFNBQVEsRUFBRSxDQUFFO0VBQ2hGO0VBRUEsZ0JBQWdCLFFBQVc7QUFDekIsUUFBSSxDQUFDO0FBQVEsYUFBTztBQUVwQixRQUFJLE9BQU8sV0FBVyxhQUFhLE9BQU8sV0FBVztBQUFjLGFBQU87QUFDMUUsUUFBSSxPQUFPLFdBQVc7QUFBVyxhQUFPO0FBRXhDLFFBQUksQ0FBQyxPQUFPLHFCQUFxQixDQUFDLE9BQU87QUFBZSxhQUFPO0FBRS9ELFVBQU0sY0FBYyxPQUFPLE9BQU8saUJBQWlCLEVBQUUsS0FBSSxFQUFHLE1BQU0sR0FBRyxFQUFFLENBQUMsRUFBRSxRQUFRLE9BQU8sR0FBRztBQUM1RixVQUFNLFNBQVMsWUFBWSxNQUFNLEdBQUc7QUFFcEMsUUFBSSxPQUFPLFNBQVM7QUFBRyxhQUFPO0FBRTlCLFVBQU0sT0FBTyxPQUFPLE9BQU8sQ0FBQyxDQUFDO0FBQzdCLFVBQU0sTUFBTSxPQUFPLE9BQU8sQ0FBQyxDQUFDLElBQUk7QUFDaEMsVUFBTSxNQUFNLE9BQU8sT0FBTyxDQUFDLENBQUM7QUFFNUIsVUFBTSxjQUFjLElBQUksS0FBSyxNQUFNLEtBQUssR0FBRztBQUMzQyxRQUFJLE1BQU0sWUFBWSxRQUFPLENBQUU7QUFBRyxhQUFPO0FBRXpDLFVBQU0sbUJBQW1CLElBQUksS0FBSyxXQUFXO0FBQzdDLHFCQUFpQixRQUFRLGlCQUFpQixRQUFPLElBQUssT0FBTyxPQUFPLGFBQWEsQ0FBQztBQUNsRixxQkFBaUIsU0FBUyxJQUFJLElBQUksSUFBSSxHQUFHO0FBRXpDLFdBQU8sb0JBQUksS0FBSSxLQUFNO0VBQ3ZCO0VBRUEsd0JBQXdCLFFBQVc7QUFDakMsUUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLHFCQUFxQixDQUFDLE9BQU87QUFBZSxhQUFPO0FBRTFFLFVBQU0sY0FBYyxPQUFPLE9BQU8saUJBQWlCLEVBQUUsS0FBSSxFQUFHLE1BQU0sR0FBRyxFQUFFLENBQUMsRUFBRSxRQUFRLE9BQU8sR0FBRztBQUM1RixVQUFNLFNBQVMsWUFBWSxNQUFNLEdBQUc7QUFFcEMsUUFBSSxPQUFPLFNBQVM7QUFBRyxhQUFPO0FBRTlCLFVBQU0sT0FBTyxPQUFPLE9BQU8sQ0FBQyxDQUFDO0FBQzdCLFVBQU0sTUFBTSxPQUFPLE9BQU8sQ0FBQyxDQUFDLElBQUk7QUFDaEMsVUFBTSxNQUFNLE9BQU8sT0FBTyxDQUFDLENBQUM7QUFFNUIsVUFBTSxjQUFjLElBQUksS0FBSyxNQUFNLEtBQUssR0FBRztBQUMzQyxRQUFJLE1BQU0sWUFBWSxRQUFPLENBQUU7QUFBRyxhQUFPO0FBRXpDLFVBQU0sbUJBQW1CLElBQUksS0FBSyxXQUFXO0FBQzdDLHFCQUFpQixRQUFRLGlCQUFpQixRQUFPLElBQUssT0FBTyxPQUFPLGFBQWEsQ0FBQztBQUVsRixXQUFPO0VBQ1Q7RUFFQSxzQkFBbUI7QUFDakIsU0FBSyxtQkFBbUIsS0FBSyxxQkFBcUIsT0FBTyxPQUFJO0FBQzNELFlBQU0sbUJBQ0osRUFBRSxPQUFPLFlBQVcsRUFBRyxTQUFTLEtBQUssWUFBWSxZQUFXLENBQUUsS0FDN0QsRUFBRSxlQUFlLEVBQUUsWUFBWSxZQUFXLEVBQUcsU0FBUyxLQUFLLFlBQVksWUFBVyxDQUFFLEtBQ3BGLEVBQUUsa0JBQWtCLEVBQUUsZUFBZSxLQUFLLENBQUMsTUFBYyxFQUFFLFlBQVcsRUFBRyxTQUFTLEtBQUssWUFBWSxZQUFXLENBQUUsQ0FBQztBQUVwSCxZQUFNLG9CQUFvQixLQUFLLG9CQUFvQixXQUFXLEVBQUUsY0FBYyxLQUFLO0FBRW5GLFlBQU0sVUFBVSxLQUFLLGdCQUFnQixDQUFDO0FBRXRDLFVBQUksaUJBQWlCO0FBQ3JCLFVBQUksS0FBSyxpQkFBaUI7QUFBWSx5QkFBaUI7QUFDdkQsVUFBSSxLQUFLLGlCQUFpQjtBQUFZLHlCQUFpQixDQUFDO0FBRXhELGFBQU8sb0JBQW9CLHFCQUFxQjtJQUNsRCxDQUFDO0FBRUQsU0FBSyw0QkFBMkI7RUFDbEM7RUFFQSxvQkFBb0IsUUFBeUM7QUFDM0QsU0FBSyxlQUFlO0FBQ3BCLFNBQUssb0JBQW1CO0VBQzFCO0VBRUEsdUJBQXVCLFdBQWlCO0FBQ3RDLFNBQUssa0JBQWtCO0FBQ3ZCLFNBQUssb0JBQW1CO0VBQzFCO0VBRVEsOEJBQTJCO0FBQ2pDLFFBQUksQ0FBQyxLQUFLLHNCQUFzQixDQUFDLEtBQUssaUJBQWlCLEtBQUssT0FBSyxFQUFFLGNBQWMsS0FBSyxtQkFBbUIsU0FBUyxHQUFHO0FBQ25ILFdBQUssNkJBQTZCLEtBQUssZ0JBQWdCO0lBQ3pEO0VBQ0Y7RUFFQSxnQkFBYTtBQUNYLFFBQUksS0FBSyxXQUFXLFdBQVcsS0FBSyx1QkFBdUIsV0FBVyxHQUFHO0FBQ3ZFLFdBQUssV0FBVyxpQkFBZ0I7QUFDaEMsWUFBTSxpRkFBaUY7QUFDdkY7SUFDRjtBQUVBLFVBQU0sU0FBUyxLQUFLLFdBQVc7QUFDL0IsVUFBTSxjQUFjLE9BQU8saUJBQWlCLGtCQUN4QyxPQUFPLE9BQU8sa0JBQWtCLElBQ2hDLE9BQU8sT0FBTyxZQUFZO0FBRTlCLFVBQU0sVUFBVTtNQUNkLFlBQVksT0FBTyxLQUFLLGFBQWEsQ0FBQztNQUN0QyxRQUFRLE9BQU87TUFDZixhQUFhLE9BQU87TUFDcEIsV0FBVyxPQUFPO01BQ2xCLGFBQWEsT0FBTztNQUNwQixlQUFlO01BQ2YsT0FBTyxDQUFDLEdBQUcsS0FBSyxzQkFBc0I7O0FBR3hDLFVBQU0sWUFBYSxLQUFLLGVBQWUsS0FBSyxvQkFDeEMsS0FBSyxjQUFjLGlCQUFpQixLQUFLLG1CQUFtQixPQUFPLElBQ25FLEtBQUssY0FBYyxlQUFlLE9BQU87QUFFN0MsY0FBVSxVQUFVO01BQ2xCLE1BQU0sTUFBSztBQUNULGNBQU0sS0FBSyxjQUFjLHFDQUFrQyxnQ0FBNkI7QUFDeEYsYUFBSyxtQkFBa0I7QUFDdkIsYUFBSyxZQUFZLEtBQUs7QUFDdEIsYUFBSywwQkFBeUI7TUFDaEM7TUFDQSxPQUFPLENBQUMsUUFBTztBQUNiLGdCQUFRLE1BQU0sK0JBQStCLEdBQUc7QUFFaEQsWUFBSSxJQUFJLFdBQVcsS0FBSztBQUN0QixnQkFBTSw0RkFBc0Y7UUFDOUYsT0FBTztBQUNMLGdCQUFNLElBQUksT0FBTyxTQUFTLElBQUksT0FBTyxXQUFXLGdEQUFnRDtRQUNsRztNQUNGO0tBQ0Q7RUFDSDtFQUVBLG9CQUFvQixVQUFrQixhQUFrQztBQUN0RSxRQUFJLFFBQVEsa0RBQStDLFdBQVcsR0FBRyxHQUFHO0FBQzFFLFdBQUssY0FBYyxjQUFjLFVBQVUsV0FBVyxFQUFFLFVBQVU7UUFDaEUsTUFBTSxNQUFLO0FBQ1QsY0FBSSxLQUFLLHNCQUFzQixLQUFLLG1CQUFtQixjQUFjLFVBQVU7QUFDN0UsaUJBQUssbUJBQW1CLFNBQVM7VUFDbkM7QUFDQSxnQkFBTSxPQUFPLEtBQUsscUJBQXFCLEtBQUssT0FBSyxFQUFFLGNBQWMsUUFBUTtBQUN6RSxjQUFJO0FBQU0saUJBQUssU0FBUztBQUN4QixlQUFLLG9CQUFtQjtBQUN4QixnQkFBTSwyQkFBd0IsV0FBVyxHQUFHO1FBQzlDO1FBQ0EsT0FBTyxDQUFDLFFBQVEsUUFBUSxNQUFNLDRCQUE0QixHQUFHO09BQzlEO0lBQ0g7RUFDRjtFQUVBLGdCQUFnQixVQUFnQjtBQUM5QixVQUFNLFVBQVUsT0FBTyw4REFBcUQsSUFBSTtBQUNoRixVQUFNLE9BQU8sT0FBTyxPQUFPO0FBRTNCLFFBQUksUUFBUSxPQUFPLEdBQUc7QUFDcEIsV0FBSyxjQUFjLGFBQWEsVUFBVSxJQUFJLEVBQUUsVUFBVTtRQUN4RCxNQUFNLE1BQUs7QUFDVCxjQUFJLEtBQUssc0JBQXNCLEtBQUssbUJBQW1CLGNBQWMsVUFBVTtBQUM3RSxpQkFBSyxtQkFBbUIsZ0JBQWdCLE9BQU8sS0FBSyxtQkFBbUIsYUFBYSxJQUFJO1VBQzFGO0FBQ0EsZUFBSywwQkFBeUI7QUFDOUIsZ0JBQU0sa0NBQWtDLElBQUksV0FBUTtRQUN0RDtRQUNBLE9BQU8sQ0FBQyxRQUFRLFFBQVEsTUFBTSwyQkFBMkIsR0FBRztPQUM3RDtJQUNIO0VBQ0Y7RUFFQSxtQkFBbUIsVUFBZ0I7QUFDakMsUUFBSSxDQUFDLEtBQUssV0FBVztBQUNuQixZQUFNLCtEQUE0RDtBQUNsRSxXQUFLLE9BQU8sU0FBUyxDQUFDLFNBQVMsQ0FBQztBQUNoQztJQUNGO0FBRUEsUUFBSSxLQUFLLHdCQUF3QixJQUFJLFFBQVEsR0FBRztBQUM5QyxZQUFNLDRDQUE0QztBQUNsRDtJQUNGO0FBRUEsU0FBSyxxQkFBcUIsaUJBQWlCLFFBQVEsRUFBRSxVQUFVO01BQzdELE1BQU0sTUFBSztBQUNULGNBQU0sMENBQWlDO0FBQ3ZDLGFBQUssd0JBQXdCLElBQUksUUFBUTtBQUN6QyxhQUFLLDBCQUEwQixJQUFJLElBQUksS0FBSyx1QkFBdUI7QUFDbkUsYUFBSyxJQUFJLGNBQWE7TUFDeEI7TUFDQSxPQUFPLENBQUMsUUFBUSxNQUFNLElBQUksT0FBTyxXQUFXLHNDQUFtQztLQUNoRjtFQUNIO0VBRUEsY0FBYyxVQUFnQjtBQUM1QixXQUFPLEtBQUssd0JBQXdCLElBQUksUUFBUTtFQUNsRDtFQUVBLGdCQUFnQixVQUFnQjtBQUM5QixRQUFJLFFBQVEsNEVBQXNFLEdBQUc7QUFDbkYsV0FBSyxjQUFjLGVBQWUsUUFBUSxFQUFFLFVBQVU7UUFDcEQsTUFBTSxNQUFLO0FBQ1QsZUFBSyx1QkFBdUIsS0FBSyxxQkFBcUIsT0FBTyxPQUFLLEVBQUUsY0FBYyxRQUFRO0FBQzFGLGVBQUssb0JBQW1CO0FBQ3hCLGdCQUFNLGdCQUFhLFFBQVEsYUFBYTtRQUMxQztRQUNBLE9BQU8sQ0FBQyxRQUFRLFFBQVEsTUFBTSw2QkFBNkIsR0FBRztPQUMvRDtJQUNIO0VBQ0Y7O3FDQWphVyxVQUFPLGdDQUFBLGVBQUEsR0FBQSxnQ0FBQSxhQUFBLEdBQUEsZ0NBQUEsb0JBQUEsR0FBQSxnQ0FBQSxXQUFBLEdBQUEsZ0NBQUEscUJBQUEsR0FBQSxnQ0FBQSxTQUFBLENBQUE7RUFBQTs2RUFBUCxVQUFPLFdBQUEsQ0FBQSxDQUFBLGFBQUEsQ0FBQSxHQUFBLE9BQUEsR0FBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsR0FBQSxtQkFBQSxHQUFBLENBQUEsR0FBQSxpQkFBQSxHQUFBLENBQUEsR0FBQSxhQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsR0FBQSxnQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxPQUFBLFFBQUEsR0FBQSxDQUFBLE1BQUEsVUFBQSxRQUFBLFVBQUEsUUFBQSxRQUFBLG1CQUFBLFVBQUEsZUFBQSxvQ0FBQSxHQUFBLENBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsR0FBQSxDQUFBLE9BQUEsV0FBQSxHQUFBLENBQUEsTUFBQSxhQUFBLFFBQUEsYUFBQSxtQkFBQSxXQUFBLEdBQUEsQ0FBQSxTQUFBLFlBQUEsR0FBQSxDQUFBLFNBQUEsWUFBQSxHQUFBLENBQUEsU0FBQSxRQUFBLEdBQUEsQ0FBQSxPQUFBLGFBQUEsR0FBQSxDQUFBLE1BQUEsZUFBQSxRQUFBLGVBQUEsbUJBQUEsYUFBQSxHQUFBLENBQUEsU0FBQSxTQUFBLEdBQUEsQ0FBQSxTQUFBLFFBQUEsR0FBQSxDQUFBLFNBQUEsYUFBQSxHQUFBLENBQUEsU0FBQSxRQUFBLEdBQUEsQ0FBQSxPQUFBLGNBQUEsR0FBQSxDQUFBLE1BQUEsZ0JBQUEsUUFBQSxnQkFBQSxtQkFBQSxnQkFBQSxHQUFBLFFBQUEsR0FBQSxDQUFBLFNBQUEsSUFBQSxHQUFBLENBQUEsU0FBQSxJQUFBLEdBQUEsQ0FBQSxTQUFBLGVBQUEsR0FBQSxDQUFBLE9BQUEsYUFBQSxHQUFBLENBQUEsTUFBQSxlQUFBLFFBQUEsZUFBQSxtQkFBQSxlQUFBLFFBQUEsS0FBQSxlQUFBLGdEQUFBLEdBQUEsQ0FBQSxHQUFBLHNCQUFBLEdBQUEsQ0FBQSxHQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxHQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsUUFBQSxVQUFBLEdBQUEsZ0JBQUEsR0FBQSxVQUFBLEdBQUEsQ0FBQSxPQUFBLG9CQUFBLEdBQUEsQ0FBQSxNQUFBLHNCQUFBLFFBQUEsc0JBQUEsUUFBQSxVQUFBLG1CQUFBLHNCQUFBLE9BQUEsS0FBQSxPQUFBLElBQUEsR0FBQSxDQUFBLEdBQUEsaUJBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxHQUFBLGNBQUEsR0FBQSxjQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsR0FBQSxjQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxnQkFBQSxHQUFBLENBQUEsR0FBQSxnQkFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsR0FBQSxDQUFBLE1BQUEsZUFBQSxRQUFBLGVBQUEsUUFBQSxRQUFBLGVBQUEsOERBQUEsR0FBQSxrQkFBQSxHQUFBLGlCQUFBLFNBQUEsU0FBQSxHQUFBLENBQUEsTUFBQSxtQkFBQSxRQUFBLG1CQUFBLEdBQUEsaUJBQUEsR0FBQSxpQkFBQSxVQUFBLFNBQUEsR0FBQSxDQUFBLFNBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxtQkFBQSxHQUFBLENBQUEsUUFBQSxVQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsUUFBQSxVQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxnQkFBQSxHQUFBLENBQUEsR0FBQSxlQUFBLEdBQUEsQ0FBQSxHQUFBLGVBQUEsR0FBQSxjQUFBLEdBQUEsQ0FBQSxHQUFBLGdCQUFBLEdBQUEsQ0FBQSxHQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLHVCQUFBLEdBQUEsQ0FBQSxHQUFBLGVBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxHQUFBLGFBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsU0FBQSxHQUFBLENBQUEsR0FBQSxlQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxhQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsR0FBQSxDQUFBLEdBQUEsZ0JBQUEsR0FBQSxDQUFBLEdBQUEsY0FBQSxhQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsY0FBQSxHQUFBLENBQUEsR0FBQSxjQUFBLGtCQUFBLEdBQUEsQ0FBQSxHQUFBLG9CQUFBLEdBQUEsQ0FBQSxHQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLGlCQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxtQkFBQSxHQUFBLENBQUEsR0FBQSxnQkFBQSxHQUFBLENBQUEsR0FBQSxpQkFBQSxHQUFBLENBQUEsUUFBQSxVQUFBLFlBQUEsSUFBQSxHQUFBLG1CQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsWUFBQSxJQUFBLEdBQUEsZUFBQSxHQUFBLENBQUEsUUFBQSxVQUFBLEdBQUEsZ0JBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsaUJBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxHQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxZQUFBLGdCQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsR0FBQSxrQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxVQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsR0FBQSxjQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxZQUFBLGtCQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsR0FBQSxnQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxtQkFBQSxHQUFBLENBQUEsUUFBQSxVQUFBLEdBQUEsbUJBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxHQUFBLG9CQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsR0FBQSxxQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxrQkFBQSxHQUFBLENBQUEsUUFBQSxVQUFBLEdBQUEsc0JBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsZ0JBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxHQUFBLHNCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxZQUFBLGNBQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxpQkFBQSxJQUFBLEtBQUE7QUFBQSxRQUFBLEtBQUEsR0FBQTtBQzNCcEIsTUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUtFLE1BQUEsa0NBQUEsR0FBQSxnQ0FBQSxJQUFBLEdBQUEsT0FBQSxDQUFBLEVBQXlCLEdBQUEsZ0NBQUEsSUFBQSxFQUFBO0FBbVIzQixNQUFBLDJCQUFBOzs7QUFuUkUsTUFBQSx3QkFBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQSxvQkFBQSxJQUFBLENBQUE7O29CRGtCVUMsc0JBQW1CLHdCQUFBLG9CQUFBLGtDQUFBLDBCQUFBLHlCQUFBLHdCQUFBLGtDQUFBLGdDQUFBLHdDQUFBLCtCQUFBLHFCQUFBLDBCQUFBLHVCQUFBLHdCQUFBLHdCQUFBLHNCQUFBLCtCQUFBLG9CQUFBLGtCQUFBLGtCQUFBLDBCQUFBLHdCQUFBLHdCQUFBLHFCQUFBLG1CQUFBLG1CQUFFLGFBQVcsYUFBQSxrQkFBQSxZQUFFQyxlQUFZLFlBQUEsc0JBQUEsWUFBQSxTQUFBLHFCQUFBLFlBQUEsYUFBQSxpQkFBQSxvQkFBQSxhQUFBLGlCQUFBLGNBQUEsa0JBQUEsa0JBQUEsYUFBQSxjQUFBLGdCQUFBLGdCQUFBLGtCQUFBLGlCQUFBLGFBQUEsbUJBQUEsbUJBQUEsZUFBQSxHQUFBLFFBQUEsQ0FBQSx5amtCQUFBLEVBQUEsQ0FBQTs7O2dGQUk3QyxTQUFPLENBQUE7VUFQbkJDO3VCQUNXLGVBQWEsWUFDWCxNQUFJLFNBQ1AsQ0FBQ0Ysc0JBQXFCLGFBQWFDLGFBQVksR0FBQyxVQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1NBQUEsUUFBQSxDQUFBLGk4YUFBQSxFQUFBLENBQUE7Ozs7aUZBSTlDLFNBQU8sRUFBQSxXQUFBLFdBQUEsVUFBQSxpQ0FBQSxZQUFBLEdBQUEsQ0FBQTtBQUFBLEdBQUE7Ozs7Ozs7K0RBQVAsU0FBTyxFQUFBLFNBQUEsQ0FBQUUsS0FBQUMsS0FBQSxJQUFBLHdCQUFBLCtCQUFBLHNCQUFBLEVBQUEsR0FBQSxDQUFBSixzQkFBQSxhQUFBQyxlQUFBQyxVQUFBLEdBQUEsYUFBQSxFQUFBLENBQUE7RUFBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsY0FBQSxnQkFBQSxLQUFBLElBQUEsQ0FBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsZUFBQSxZQUFBLE9BQUEsWUFBQSxJQUFBLEdBQUEsNEJBQUEsT0FBQSxFQUFBLE9BQUEsTUFBQSxnQkFBQSxFQUFBLFNBQUEsQ0FBQTtBQUFBLEdBQUE7OztBSTNCcEIsU0FBUyxhQUFBRyxZQUFtQixVQUFBQyxTQUFRLHFCQUFBQyxvQkFBbUIsa0JBQWtCO0FBQ3pFLFNBQVMsZ0JBQUFDLHFCQUFvQjtBQUM3QixTQUFTLGdCQUFnQixVQUFBQyxlQUFjO0FBQ3ZDLFNBQVMsMEJBQTBCO0E7OztTQ3lEekIsS0FBQSxVQUFBLEtBQUE7QUFBZTs7O0FBeERtQixJQUFBLHFCQUFBLEdBQUEscUJBQUE7Ozs7O0FBQ0UsSUFBQSxxQkFBQSxHQUFBLDJCQUFBOzs7OztBQUM5QixJQUFBLHFCQUFBLEdBQUEsdUNBQUE7Ozs7O0FBRzRCLElBQUEscUJBQUEsR0FBQSw4REFBQTs7Ozs7QUFDRSxJQUFBLHFCQUFBLEdBQUEsOERBQUE7Ozs7O0FBQzlCLElBQUEscUJBQUEsR0FBQSwwRUFBQTs7Ozs7QUFLVixJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0UsSUFBQSxxQkFBQSxDQUFBO0FBQ0YsSUFBQSwyQkFBQTs7OztBQURFLElBQUEsd0JBQUE7QUFBQSxJQUFBLGlDQUFBLG9DQUFBLE9BQUEsZ0JBQUEsR0FBQTs7Ozs7QUFPSixJQUFBLDZCQUFBLEdBQUEsT0FBQSxDQUFBO0FBQ0UsSUFBQSx3QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNBLElBQUEsNkJBQUEsR0FBQSxHQUFBO0FBQUcsSUFBQSxxQkFBQSxHQUFBLDJCQUFBO0FBQXlCLElBQUEsMkJBQUEsRUFBSTs7Ozs7QUFNbEMsSUFBQSw2QkFBQSxHQUFBLE9BQUEsQ0FBQSxFQUE2QixHQUFBLEdBQUE7QUFDeEIsSUFBQSxxQkFBQSxHQUFBLDhDQUFBO0FBQTRDLElBQUEsMkJBQUEsRUFBSTs7Ozs7QUFhM0MsSUFBQSw2QkFBQSxHQUFBLElBQUE7QUFBSSxJQUFBLHFCQUFBLEdBQUEsU0FBQTtBQUFPLElBQUEsMkJBQUE7Ozs7O0FBSVgsSUFBQSw2QkFBQSxHQUFBLElBQUE7QUFBSSxJQUFBLHFCQUFBLEdBQUEsV0FBQTtBQUFTLElBQUEsMkJBQUE7QUFDYixJQUFBLDZCQUFBLEdBQUEsSUFBQTtBQUFJLElBQUEscUJBQUEsR0FBQSxVQUFBO0FBQVEsSUFBQSwyQkFBQTs7Ozs7QUFrQlYsSUFBQSw2QkFBQSxHQUFBLE1BQUEsRUFBQTtBQUNFLElBQUEscUJBQUEsQ0FBQTtBQUNGLElBQUEsMkJBQUE7Ozs7QUFERSxJQUFBLHdCQUFBO0FBQUEsSUFBQSxpQ0FBQSxLQUFBLFFBQUEsZ0JBQUEsT0FBQSxHQUFBOzs7OztBQU1GLElBQUEsNkJBQUEsR0FBQSxNQUFBLEVBQUE7QUFDRSxJQUFBLHFCQUFBLENBQUE7QUFDRixJQUFBLDJCQUFBO0FBQ0EsSUFBQSw2QkFBQSxHQUFBLE1BQUEsRUFBQSxFQUF5QixHQUFBLEtBQUEsRUFBQTtBQUVyQixJQUFBLHFCQUFBLENBQUE7QUFDRixJQUFBLDJCQUFBLEVBQUk7Ozs7QUFMSixJQUFBLHdCQUFBO0FBQUEsSUFBQSxpQ0FBQSxLQUFBLFFBQUEsbUJBQUEsS0FBQSxRQUFBLHFCQUFBLEdBQUE7QUFHRyxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLFFBQUEsWUFBQSxRQUFBLGtCQUFBLDJCQUFBO0FBQ0QsSUFBQSx3QkFBQTtBQUFBLElBQUEsaUNBQUEsS0FBQSxRQUFBLGtCQUFBLEdBQUE7Ozs7OztBQXVCQSxJQUFBLDZCQUFBLEdBQUEsVUFBQSxFQUFBO0FBR0UsSUFBQSx5QkFBQSxTQUFBLFNBQUEsK0ZBQUE7QUFBQSxNQUFBLDRCQUFBLEdBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUEsRUFBQTtBQUFBLFlBQUEsU0FBQSw0QkFBQSxDQUFBO0FBQUEsYUFBQSwwQkFBUyxPQUFBLG9CQUFBLFFBQUEsYUFBQSxDQUF1QztJQUFBLENBQUE7QUFFaEQsSUFBQSxxQkFBQSxHQUFBLG9CQUFBO0FBQ0YsSUFBQSwyQkFBQTtBQUVBLElBQUEsNkJBQUEsR0FBQSxPQUFBLEVBQUEsRUFBbUMsR0FBQSxVQUFBLEVBQUE7QUFJL0IsSUFBQSx5QkFBQSxVQUFBLFNBQUEsOEZBQUEsUUFBQTtBQUFBLE1BQUEsNEJBQUEsR0FBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQSxFQUFBO0FBQUEsWUFBQSxTQUFBLDRCQUFBLENBQUE7QUFBQSxhQUFBLDBCQUFVLE9BQUEsaUJBQWlCLE9BQUEsVUFBQSxPQUFBLEdBQWUsTUFBQSxDQUFTO0lBQUEsQ0FBQTtBQUVuRCxJQUFBLDZCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQTBCLElBQUEscUJBQUEsR0FBQSxXQUFBO0FBQVMsSUFBQSwyQkFBQTtBQUNuQyxJQUFBLDZCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQTRCLElBQUEscUJBQUEsR0FBQSxnQkFBQTtBQUFXLElBQUEsMkJBQUE7QUFDdkMsSUFBQSw2QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUF5QixJQUFBLHFCQUFBLEdBQUEsVUFBQTtBQUFRLElBQUEsMkJBQUE7QUFDakMsSUFBQSw2QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUEwQixJQUFBLHFCQUFBLElBQUEsV0FBQTtBQUFTLElBQUEsMkJBQUEsRUFBUyxFQUNyQzs7Ozs7QUFSUCxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLHlCQUFBLE1BQUEsWUFBQSxPQUFBLFVBQUEsT0FBQSxDQUFBLEVBQWtDLFVBQUEsV0FBQSxPQUFBLE9BQUEsUUFBQSxXQUFBLFdBQUE7Ozs7OztBQWN0QyxJQUFBLDZCQUFBLEdBQUEsVUFBQSxFQUFBO0FBR0UsSUFBQSx5QkFBQSxTQUFBLFNBQUEsK0ZBQUE7QUFBQSxNQUFBLDRCQUFBLEdBQUE7QUFBQSxZQUFBLFVBQUEsNEJBQUEsRUFBQTtBQUFBLFlBQUEsU0FBQSw0QkFBQSxDQUFBO0FBQUEsYUFBQSwwQkFBUyxPQUFBLHNCQUFzQixPQUFBLFVBQUEsT0FBQSxDQUFlLENBQUM7SUFBQSxDQUFBO0FBRS9DLElBQUEscUJBQUEsR0FBQSxtQkFBQTtBQUNGLElBQUEsMkJBQUE7Ozs7OztBQU1FLElBQUEsNkJBQUEsR0FBQSxVQUFBLEVBQUE7QUFHRSxJQUFBLHlCQUFBLFNBQUEsU0FBQSw2R0FBQTtBQUFBLE1BQUEsNEJBQUEsR0FBQTtBQUFBLFlBQUEsVUFBQSw0QkFBQSxDQUFBLEVBQUE7QUFBQSxZQUFBLFNBQUEsNEJBQUEsQ0FBQTtBQUFBLGFBQUEsMEJBQVMsT0FBQSxvQkFBb0IsT0FBQSxVQUFBLE9BQUEsQ0FBZSxDQUFDO0lBQUEsQ0FBQTtBQUU3QyxJQUFBLHFCQUFBLEdBQUEsb0JBQUE7QUFDRixJQUFBLDJCQUFBOzs7OztBQUVBLElBQUEsNkJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBb0UsSUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBQyxJQUFBLDJCQUFBOzs7OztBQVR2RSxJQUFBLGtDQUFBLEdBQUEsb0ZBQUEsR0FBQSxHQUFBLFVBQUEsRUFBQSxFQUFnSCxHQUFBLG9GQUFBLEdBQUEsR0FBQSxRQUFBLEVBQUE7Ozs7QUFBaEgsSUFBQSw2QkFBQSxRQUFBLFVBQUEsSUFBQSxZQUFBLE1BQUEsZ0JBQUEsUUFBQSxVQUFBLElBQUEsWUFBQSxNQUFBLGdCQUFBLElBQUEsQ0FBQTs7Ozs7QUE5RVIsSUFBQSw2QkFBQSxHQUFBLElBQUEsRUFBSSxHQUFBLE1BQUEsRUFBQSxFQUVxQixHQUFBLFFBQUEsRUFBQTtBQUNPLElBQUEscUJBQUEsQ0FBQTtBQUF3QixJQUFBLDJCQUFBLEVBQU87QUFJN0QsSUFBQSxrQ0FBQSxHQUFBLHFFQUFBLEdBQUEsR0FBQSxNQUFBLEVBQUE7QUFPQSxJQUFBLGtDQUFBLEdBQUEscUVBQUEsR0FBQSxDQUFBO0FBWUEsSUFBQSw2QkFBQSxHQUFBLE1BQUEsRUFBQTtBQUNFLElBQUEscUJBQUEsQ0FBQTs7QUFDRixJQUFBLDJCQUFBO0FBR0EsSUFBQSw2QkFBQSxHQUFBLE1BQUEsRUFBQSxFQUF1QixJQUFBLFFBQUEsRUFBQTtBQUVuQixJQUFBLHFCQUFBLEVBQUE7QUFDRixJQUFBLDJCQUFBLEVBQU87QUFJVCxJQUFBLDZCQUFBLElBQUEsTUFBQSxFQUFBLEVBQXlCLElBQUEsT0FBQSxFQUFBO0FBSXJCLElBQUEsa0NBQUEsSUFBQSxzRUFBQSxJQUFBLENBQUE7QUF3QkEsSUFBQSxrQ0FBQSxJQUFBLHNFQUFBLEdBQUEsR0FBQSxVQUFBLEVBQUE7QUFXQSxJQUFBLGtDQUFBLElBQUEsc0VBQUEsR0FBQSxDQUFBO0FBY0YsSUFBQSwyQkFBQSxFQUFNLEVBQ0g7Ozs7O0FBekZ5QixJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGdDQUFBLFFBQUEsYUFBQTtBQUk5QixJQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxPQUFBLGVBQUEsWUFBQSxJQUFBLEVBQUE7QUFPQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxPQUFBLGVBQUEsZUFBQSxJQUFBLEVBQUE7QUFhRSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLEtBQUEsMEJBQUEsR0FBQSxHQUFBLFFBQUEsbUJBQUEsWUFBQSxHQUFBLEdBQUE7QUFLb0IsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxZQUFBLFFBQUEsVUFBQSxhQUFBLFlBQUEsRUFBQSxXQUFBLEtBQUEsR0FBQSxDQUFBO0FBQ2xCLElBQUEsd0JBQUE7QUFBQSxJQUFBLGlDQUFBLEtBQUEsUUFBQSxRQUFBLEdBQUE7QUFTQSxJQUFBLHdCQUFBLENBQUE7QUFBQSxJQUFBLDRCQUFBLE9BQUEsZUFBQSxhQUFBLE9BQUEsZUFBQSxVQUFBLEtBQUEsRUFBQTtBQXdCQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxPQUFBLGVBQUEsVUFBQSxLQUFBLEVBQUE7QUFXQSxJQUFBLHdCQUFBO0FBQUEsSUFBQSw0QkFBQSxPQUFBLGVBQUEsZUFBQSxLQUFBLEVBQUE7Ozs7O0FBbkdkLElBQUEsNkJBQUEsR0FBQSxPQUFBLENBQUEsRUFBOEIsR0FBQSxTQUFBLENBQUEsRUFDTyxHQUFBLE9BQUEsRUFDMUIsR0FBQSxJQUFBLEVBQ0QsR0FBQSxJQUFBO0FBQ0UsSUFBQSxxQkFBQSxHQUFBLFFBQUE7QUFBTSxJQUFBLDJCQUFBO0FBRVYsSUFBQSxrQ0FBQSxHQUFBLDhEQUFBLEdBQUEsR0FBQSxJQUFBO0FBSUEsSUFBQSxrQ0FBQSxHQUFBLDhEQUFBLEdBQUEsQ0FBQTtBQUtBLElBQUEsNkJBQUEsR0FBQSxJQUFBO0FBQUksSUFBQSxxQkFBQSxHQUFBLE9BQUE7QUFBSyxJQUFBLDJCQUFBO0FBQ1QsSUFBQSw2QkFBQSxJQUFBLElBQUE7QUFBSSxJQUFBLHFCQUFBLElBQUEsUUFBQTtBQUFNLElBQUEsMkJBQUE7QUFDVixJQUFBLDZCQUFBLElBQUEsTUFBQSxFQUFBO0FBQXdCLElBQUEscUJBQUEsSUFBQSxVQUFBO0FBQVEsSUFBQSwyQkFBQSxFQUFLLEVBQ2xDO0FBRVAsSUFBQSw2QkFBQSxJQUFBLE9BQUE7QUFDRSxJQUFBLCtCQUFBLElBQUEsdURBQUEsSUFBQSxJQUFBLE1BQUEsTUFBQUMsYUFBQSxJQUFBO0FBZ0dGLElBQUEsMkJBQUEsRUFBUSxFQUNGOzs7O0FBaEhGLElBQUEsd0JBQUEsQ0FBQTtBQUFBLElBQUEsNEJBQUEsT0FBQSxlQUFBLFlBQUEsSUFBQSxFQUFBO0FBSUEsSUFBQSx3QkFBQTtBQUFBLElBQUEsNEJBQUEsT0FBQSxlQUFBLGVBQUEsSUFBQSxFQUFBO0FBV0YsSUFBQSx3QkFBQSxDQUFBO0FBQUEsSUFBQSx5QkFBQSxPQUFBLGFBQUE7OztBRDlDSixJQUFPLHlCQUFQLE1BQU8sd0JBQXNCOztFQUV6Qix1QkFBdUJDLFFBQU8sb0JBQW9CO0VBQ2xELGNBQWNBLFFBQU8sV0FBVztFQUNoQyxNQUFNQSxRQUFPQyxrQkFBaUI7RUFDOUIsYUFBYUQsUUFBTyxVQUFVO0VBQzlCLFFBQVFBLFFBQU8sY0FBYztFQUM3QixTQUFTQSxRQUFPRSxPQUFNOztFQUc5QixnQkFBK0IsQ0FBQTtFQUMvQixhQUFxQjtFQUNyQixXQUFvQjtFQUNwQixpQkFBZ0M7RUFFaEMsV0FBUTtBQUNOLFVBQU0sVUFBVSxLQUFLLFlBQVksaUJBQWdCO0FBQ2pELFNBQUssY0FBYyxTQUFTLE9BQU8sS0FBSyxZQUFZLGVBQWMsS0FBTSxjQUFjLFlBQVc7QUFHakcsU0FBSyxNQUFNLFlBQ1IsS0FBSyxtQkFBbUIsS0FBSyxVQUFVLENBQUMsRUFDeEMsVUFBVSxZQUFTO0FBQ2xCLFdBQUssaUJBQWlCLE9BQU8sUUFBUSxJQUFJLE9BQU8sT0FBTyxRQUFRLENBQUMsSUFBSTtBQUNwRSxXQUFLLG9CQUFvQixPQUFPO0lBQ2xDLENBQUM7RUFDTDs7RUFHQSxvQkFBb0IsU0FBWTtBQUM5QixRQUFJLENBQUMsU0FBUztBQUNaLFdBQUssV0FBVztBQUNoQjtJQUNGO0FBRUEsU0FBSyxXQUFXO0FBRWhCLFVBQU0sZ0JBQWdCLENBQUMsU0FBd0IsS0FBSyxTQUFTLElBQUk7QUFDakUsVUFBTSxjQUFjLENBQUMsUUFBZ0I7QUFDbkMsY0FBUSxNQUFNLGtDQUFrQyxHQUFHO0FBQ25ELFdBQUssV0FBVztBQUNoQixXQUFLLElBQUksY0FBYTtJQUN4QjtBQUVBLFlBQVEsS0FBSyxZQUFZO01BQ3ZCLEtBQUssY0FBYztBQUNqQixjQUFNLGVBQWUsUUFBUSxpQkFBaUIsUUFBUTtBQUN0RCxhQUFLLHFCQUFxQixnQkFBZ0IsWUFBWSxFQUFFLFVBQVU7VUFDaEUsTUFBTTtVQUNOLE9BQU87U0FDUjtBQUNEO01BQ0Y7TUFDQSxLQUFLLFdBQVc7QUFDZCxZQUFJLEtBQUssZ0JBQWdCO0FBQ3ZCLGVBQUsscUJBQXFCLFlBQVksS0FBSyxjQUFjLEVBQUUsVUFBVTtZQUNuRSxNQUFNO1lBQ04sT0FBTztXQUNSO1FBQ0gsT0FBTztBQUNMLGdCQUFNLFlBQVksUUFBUSxjQUFjLFFBQVE7QUFDaEQsZUFBSyxxQkFBcUIsYUFBYSxTQUFTLEVBQUUsVUFBVTtZQUMxRCxNQUFNO1lBQ04sT0FBTztXQUNSO1FBQ0g7QUFDQTtNQUNGO01BQ0EsS0FBSyxTQUFTO0FBQ1osYUFBSyxxQkFBcUIsU0FBUSxFQUFHLFVBQVU7VUFDN0MsTUFBTTtVQUNOLE9BQU87U0FDUjtBQUNEO01BQ0Y7TUFDQSxTQUFTO0FBQ1AsYUFBSyxXQUFXO0FBQ2hCO01BQ0Y7SUFDRjtFQUNGOztFQUdBLGlCQUFpQixnQkFBb0MsT0FBWTtBQUMvRCxRQUFJLENBQUM7QUFBZ0I7QUFFckIsVUFBTSxnQkFBZ0IsTUFBTTtBQUM1QixVQUFNLGNBQWMsY0FBYztBQUVsQyxTQUFLLHFCQUFxQixpQkFBaUIsZ0JBQWdCLFdBQVcsRUFBRSxVQUFVO01BQ2hGLE1BQU0sTUFBSztBQUNULGNBQU0sT0FBTyxLQUFLLGNBQWMsS0FBSyxPQUFLLEtBQUssVUFBVSxDQUFDLE1BQU0sY0FBYztBQUM5RSxZQUFJLE1BQU07QUFDUixlQUFLLFNBQVM7UUFDaEI7QUFDQSxhQUFLLElBQUksY0FBYTtNQUN4QjtNQUNBLE9BQU8sQ0FBQyxRQUFRLFFBQVEsTUFBTSxrQ0FBa0MsR0FBRztLQUNwRTtFQUNIO0VBRUEsb0JBQW9CLGdCQUFrQztBQUNwRCxRQUFJLENBQUM7QUFBZ0I7QUFDckIsUUFBSSxDQUFDLFFBQVEsNEVBQW1FO0FBQUc7QUFFbkYsU0FBSyxxQkFBcUIsb0JBQW9CLGNBQWMsRUFBRSxVQUFVO01BQ3RFLE1BQU0sTUFBSztBQUNULGFBQUssZ0JBQWdCLEtBQUssY0FBYyxPQUFPLE9BQUssS0FBSyxVQUFVLENBQUMsTUFBTSxjQUFjO0FBQ3hGLGFBQUssSUFBSSxjQUFhO01BQ3hCO01BQ0EsT0FBTyxDQUFDLFFBQVEsUUFBUSxNQUFNLHFDQUFrQyxHQUFHO0tBQ3BFO0VBQ0g7RUFFQSxzQkFBc0IsZ0JBQWtDO0FBQ3RELFFBQUksQ0FBQztBQUFnQjtBQUNyQixRQUFJLENBQUMsUUFBUSw0REFBc0Q7QUFBRztBQUV0RSxTQUFLLHFCQUFxQixzQkFBc0IsY0FBYyxFQUFFLFVBQVU7TUFDeEUsTUFBTSxNQUFLO0FBQ1QsYUFBSyxnQkFBZ0IsS0FBSyxjQUFjLE9BQU8sT0FBSyxLQUFLLFVBQVUsQ0FBQyxNQUFNLGNBQWM7QUFDeEYsYUFBSyxJQUFJLGNBQWE7TUFDeEI7TUFDQSxPQUFPLENBQUMsUUFBUSxRQUFRLE1BQU0scUNBQWtDLEdBQUc7S0FDcEU7RUFDSDtFQUVBLG9CQUFvQixjQUFxQjtBQUN2QyxRQUFJLGNBQWM7QUFDaEIsV0FBSyxPQUFPLFNBQVMsQ0FBQyxlQUFlLFlBQVksQ0FBQztJQUNwRDtFQUNGOzs7OztFQU9BLFVBQVUsTUFBaUI7QUFDekIsV0FBTyxLQUFLLGtCQUFtQixLQUFhO0VBQzlDO0VBRUEsa0JBQWtCLFFBQWU7QUFDL0IsWUFBUSxRQUFRO01BQ2QsS0FBSztBQUFZLGVBQU87TUFDeEIsS0FBSztBQUFhLGVBQU87TUFDekIsS0FBSztBQUFlLGVBQU87TUFDM0I7QUFBUyxlQUFPO0lBQ2xCO0VBQ0Y7RUFFUSxTQUFTLE1BQW1CO0FBQ2xDLFNBQUssaUJBQWlCLFFBQVEsQ0FBQSxHQUFJLElBQUksVUFBUyxpQ0FDMUMsT0FEMEM7TUFFN0MsUUFBUSxLQUFLLFVBQVU7TUFDdkI7QUFDRixTQUFLLFdBQVc7QUFDaEIsU0FBSyxJQUFJLGNBQWE7RUFDeEI7O3FDQTlKVyx5QkFBc0I7RUFBQTs2RUFBdEIseUJBQXNCLFdBQUEsQ0FBQSxDQUFBLG1CQUFBLENBQUEsR0FBQSxPQUFBLElBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEseUJBQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxHQUFBLENBQUEsR0FBQSxhQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsR0FBQSxDQUFBLEdBQUEscUJBQUEsR0FBQSxDQUFBLEdBQUEsYUFBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxrQkFBQSxHQUFBLENBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLHFCQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxlQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsR0FBQSxDQUFBLEdBQUEsaUJBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxTQUFBLDJCQUFBLEdBQUEsb0JBQUEsR0FBQSxDQUFBLEdBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSxjQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsR0FBQSxNQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsU0FBQSw0QkFBQSxHQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSx1QkFBQSxHQUFBLENBQUEsR0FBQSxpQkFBQSxHQUFBLFVBQUEsTUFBQSxPQUFBLEdBQUEsQ0FBQSxTQUFBLFdBQUEsR0FBQSxDQUFBLFNBQUEsYUFBQSxHQUFBLENBQUEsU0FBQSxVQUFBLEdBQUEsQ0FBQSxTQUFBLFdBQUEsR0FBQSxDQUFBLFFBQUEsVUFBQSxTQUFBLDJCQUFBLEdBQUEsc0JBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsU0FBQSx5QkFBQSxHQUFBLGNBQUEsR0FBQSxDQUFBLFNBQUEsdUNBQUEsR0FBQSxjQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsU0FBQSx5QkFBQSxHQUFBLGdCQUFBLEdBQUEsT0FBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLGdDQUFBLElBQUEsS0FBQTtBQUFBLFFBQUEsS0FBQSxHQUFBO0FDZG5DLE1BQUEsNkJBQUEsR0FBQSxPQUFBLENBQUEsRUFBcUMsR0FBQSxVQUFBLENBQUEsRUFDWixHQUFBLE9BQUEsQ0FBQSxFQUNJLEdBQUEsSUFBQTtBQUVyQixNQUFBLGtDQUFBLEdBQUEsK0NBQUEsR0FBQSxDQUFBLEVBQW1DLEdBQUEsK0NBQUEsR0FBQSxDQUFBLEVBQ0UsR0FBQSwrQ0FBQSxHQUFBLENBQUE7QUFFdkMsTUFBQSwyQkFBQTtBQUNBLE1BQUEsNkJBQUEsR0FBQSxLQUFBLENBQUE7QUFDRSxNQUFBLGtDQUFBLEdBQUEsK0NBQUEsR0FBQSxDQUFBLEVBQW1DLEdBQUEsK0NBQUEsR0FBQSxDQUFBLEVBQ0UsSUFBQSxnREFBQSxHQUFBLENBQUE7QUFFdkMsTUFBQSwyQkFBQSxFQUFJO0FBR04sTUFBQSxrQ0FBQSxJQUFBLGdEQUFBLEdBQUEsR0FBQSxPQUFBLENBQUE7QUFLRixNQUFBLDJCQUFBO0FBR0EsTUFBQSxrQ0FBQSxJQUFBLGdEQUFBLEdBQUEsR0FBQSxPQUFBLENBQUEsRUFBZ0IsSUFBQSxnREFBQSxHQUFBLEdBQUEsT0FBQSxDQUFBLEVBUXVCLElBQUEsZ0RBQUEsSUFBQSxHQUFBLE9BQUEsQ0FBQTtBQWlJekMsTUFBQSwyQkFBQTs7O0FBNUpRLE1BQUEsd0JBQUEsQ0FBQTtBQUFBLE1BQUEsNEJBQUEsSUFBQSxlQUFBLGVBQUEsSUFBQSxJQUFBLGVBQUEsWUFBQSxJQUFBLENBQUE7QUFLQSxNQUFBLHdCQUFBLENBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUEsZUFBQSxlQUFBLElBQUEsSUFBQSxlQUFBLFlBQUEsSUFBQSxFQUFBO0FBTUosTUFBQSx3QkFBQSxDQUFBO0FBQUEsTUFBQSw0QkFBQSxJQUFBLGlCQUFBLEtBQUEsRUFBQTtBQVFGLE1BQUEsd0JBQUE7QUFBQSxNQUFBLDRCQUFBLElBQUEsV0FBQSxLQUFBLElBQUEsY0FBQSxXQUFBLElBQUEsS0FBQSxFQUFBOztvQkRiVUMsZUFBWSxhQUFBLHVCQUFBLGFBQUEsVUFBQSxzQkFBQSxhQUFBLGNBQUEsa0JBQUEscUJBQUEsY0FBQSxrQkFBQSxlQUFBLG1CQUFBLG1CQUFBLGNBQUEsZUFBQSxpQkFBQSxpQkFBQSxtQkFBQSxrQkFBQSxjQUFBLG9CQUFBLG9CQUFBLGdCQUFBLEdBQUEsUUFBQSxDQUFBLHNnTEFBQSxFQUFBLENBQUE7OztnRkFJWCx3QkFBc0IsQ0FBQTtVQVBsQ0M7dUJBQ1cscUJBQW1CLFlBQ2pCLE1BQUksU0FDUCxDQUFDRCxhQUFZLEdBQUMsVUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztTQUFBLFFBQUEsQ0FBQSxxMklBQUEsRUFBQSxDQUFBOzs7O2lGQUlaLHdCQUFzQixFQUFBLFdBQUEsMEJBQUEsVUFBQSw2Q0FBQSxZQUFBLEdBQUEsQ0FBQTtBQUFBLEdBQUE7Ozs7Ozs7K0RBQXRCLHdCQUFzQixFQUFBLFNBQUEsQ0FBQUUsS0FBQUMsR0FBQSxHQUFBLENBQUFILGVBQUFDLFVBQUEsR0FBQSxhQUFBLEVBQUEsQ0FBQTtFQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxjQUFBLCtCQUFBLEtBQUEsSUFBQSxDQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxlQUFBLFlBQUEsT0FBQSxZQUFBLElBQUEsR0FBQSw0QkFBQSxPQUFBLEVBQUEsT0FBQSxNQUFBLCtCQUFBLEVBQUEsU0FBQSxDQUFBO0FBQUEsR0FBQTs7O0FFZG5DLFNBQVMsYUFBQUcsWUFBbUIsVUFBQUMsU0FBUSxxQkFBQUMsMEJBQXlCO0FBQzdELFNBQVMsZ0JBQUFDLHFCQUFvQjtBQUM3QixTQUFTLFVBQUFDLGVBQWM7OztBRUZ2QixTQUFTLGFBQUFDLFlBQW1CLFVBQUFDLGVBQWM7QUFDMUMsU0FBUyxnQkFBQUMscUJBQW9CO0FBQzdCLFNBQVMsZUFBQUMsY0FBd0IsdUJBQUFDLHNCQUFxQixjQUFBQyxhQUFZLGVBQUFDLG9CQUFtQjs7O0FFRnJGLFNBQVMsY0FBQUMsYUFBWSxVQUFBQyxlQUFjO0FBQ25DLFNBQVMsY0FBQUMsbUJBQWtCO0FBRTNCLFNBQVEsV0FBVTs7QUE0RVosSUFBTyxlQUFQLE1BQU8sY0FBWTtFQUNOLE9BQU9ELFFBQU9DLFdBQVU7RUFDeEIsVUFBVTtFQUUzQixjQUFXO0FBQ1QsV0FBTyxLQUFLLEtBQUssSUFBbUIsR0FBRyxLQUFLLE9BQU8sV0FBVztFQUNoRTs7OztFQUtBLGNBQVc7QUFDVCxXQUFPLEtBQUssS0FBSyxJQUFvQixHQUFHLEtBQUssT0FBTyxXQUFXO0VBQ2pFO0VBRUEscUJBQXFCLFlBQW9CLFFBQWM7QUFDckQsV0FBTyxLQUFLLEtBQUssSUFBa0IsR0FBRyxLQUFLLE9BQU8sbUJBQW1CLEVBQUUsWUFBWSxPQUFNLENBQUU7RUFDN0Y7Ozs7RUFJQSxhQUFVO0FBQ1IsV0FBTyxLQUFLLEtBQUssSUFBbUIsR0FBRyxLQUFLLE9BQU8sVUFBVTtFQUMvRDtFQUVBLGVBQWUsV0FBaUI7QUFDOUIsV0FBTyxLQUFLLEtBQUssT0FBcUIsR0FBRyxLQUFLLE9BQU8sV0FBVyxTQUFTLEVBQUU7RUFDN0U7Ozs7RUFLQSxpQkFBYztBQUNaLFdBQU8sS0FBSyxLQUFLLElBQXVCLEdBQUcsS0FBSyxPQUFPLGNBQWM7RUFDdkU7Ozs7RUFLQSxzQkFBbUI7QUFDakIsV0FBTyxLQUFLLEtBQUssSUFBa0IsR0FBRyxLQUFLLE9BQU8sb0JBQW9CLEVBQUUsS0FDdEUsSUFBSSxTQUFPLElBQUksY0FBYyxDQUFBLENBQUUsQ0FBQztFQUVwQztFQUVBLFlBQVM7QUFDUCxXQUFPLEtBQUssS0FBSyxJQUFrQixHQUFHLEtBQUssT0FBTyxTQUFTLEVBQUUsS0FDM0QsSUFBSSxTQUFPLElBQUksVUFBVSxDQUFBLENBQUUsQ0FBQztFQUVoQzs7RUFHQSxzQkFBc0IsYUFBbUI7QUFDdkMsV0FBTyxLQUFLLEtBQUssSUFBa0IsR0FBRyxLQUFLLE9BQU8sZUFBZSxXQUFXLFNBQVMsRUFBRSxLQUNyRixJQUFJLFNBQU8sSUFBSSxVQUFVLENBQUEsQ0FBRSxDQUFDO0VBRWhDO0VBR0EsV0FBVyxTQUFpRDtBQUMxRCxXQUFPLEtBQUssS0FBSyxLQUFtQixHQUFHLEtBQUssT0FBTyxXQUFXLE9BQU87RUFDdkU7RUFFQSxnQkFBZ0IsSUFBWSxTQUFpRDtBQUMzRSxXQUFPLEtBQUssS0FBSyxJQUFrQixHQUFHLEtBQUssT0FBTyxXQUFXLEVBQUUsSUFBSSxPQUFPO0VBQzVFO0VBRUEsY0FBYyxJQUFVO0FBQ3RCLFdBQU8sS0FBSyxLQUFLLE9BQXFCLEdBQUcsS0FBSyxPQUFPLFdBQVcsRUFBRSxFQUFFO0VBQ3RFOztxQ0FyRVcsZUFBWTtFQUFBO2lGQUFaLGVBQVksU0FBWixjQUFZLFdBQUEsWUFGWCxPQUFNLENBQUE7OztpRkFFUCxjQUFZLENBQUE7VUFIeEJGO1dBQVc7TUFDVixZQUFZO0tBQ2I7Ozs7Ozs7Ozs7O0FEbkRXLElBQUEsOEJBQUEsR0FBQSxVQUFBLENBQUE7QUFBeUIsSUFBQSxzQkFBQSxDQUFBO0FBQWdCLElBQUEsNEJBQUE7Ozs7QUFBakMsSUFBQSwwQkFBQSxTQUFBLE9BQUEsRUFBQTtBQUFpQixJQUFBLHlCQUFBO0FBQUEsSUFBQSxpQ0FBQSxPQUFBLE1BQUE7Ozs7OztBQWtCekIsSUFBQSw4QkFBQSxHQUFBLElBQUEsRUFBSSxHQUFBLElBQUE7QUFDRSxJQUFBLHNCQUFBLENBQUE7QUFBZSxJQUFBLDRCQUFBO0FBQ25CLElBQUEsOEJBQUEsR0FBQSxJQUFBLEVBQUksR0FBQSxRQUFBO0FBQVEsSUFBQSxzQkFBQSxDQUFBO0FBQWtCLElBQUEsNEJBQUEsRUFBUztBQUN2QyxJQUFBLDhCQUFBLEdBQUEsSUFBQSxFQUFJLEdBQUEsUUFBQSxFQUFBO0FBQ3NCLElBQUEsc0JBQUEsQ0FBQTtBQUFnRCxJQUFBLDRCQUFBLEVBQU87QUFFakYsSUFBQSw4QkFBQSxHQUFBLE1BQUEsRUFBQSxFQUF1QixJQUFBLFVBQUEsRUFBQTtBQUNTLElBQUEsMEJBQUEsU0FBQSxTQUFBLGtEQUFBO0FBQUEsWUFBQSxXQUFBLDZCQUFBLEdBQUEsRUFBQTtBQUFBLFlBQUEsU0FBQSw2QkFBQTtBQUFBLGFBQUEsMkJBQVMsT0FBQSxnQkFBQSxRQUFBLENBQXNCO0lBQUEsQ0FBQTtBQUMzRCxJQUFBLHNCQUFBLElBQUEsZ0JBQUE7QUFDRixJQUFBLDRCQUFBO0FBQ0EsSUFBQSw4QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUFnQyxJQUFBLDBCQUFBLFNBQUEsU0FBQSxrREFBQTtBQUFBLFlBQUEsV0FBQSw2QkFBQSxHQUFBLEVBQUE7QUFBQSxZQUFBLFNBQUEsNkJBQUE7QUFBQSxhQUFBLDJCQUFTLE9BQUEsY0FBQSxTQUFBLEVBQUEsQ0FBdUI7SUFBQSxDQUFBO0FBQzlELElBQUEsc0JBQUEsSUFBQSxtQkFBQTtBQUNGLElBQUEsNEJBQUEsRUFBUyxFQUNOOzs7OztBQVpELElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsa0NBQUEsS0FBQSxTQUFBLEVBQUE7QUFDUSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLFNBQUEsTUFBQTtBQUVjLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsT0FBQSx1QkFBQSxTQUFBLFlBQUEsQ0FBQTs7Ozs7QUFZNUIsSUFBQSw4QkFBQSxHQUFBLElBQUEsRUFBSSxHQUFBLE1BQUEsRUFBQTtBQUVBLElBQUEsc0JBQUEsQ0FBQTtBQUNGLElBQUEsNEJBQUEsRUFBSzs7OztBQURILElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsa0NBQUEsS0FBQSxPQUFBLFdBQUEsNEJBQUEsa0NBQUEsR0FBQTs7Ozs7QUE2QkYsSUFBQSw4QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUF3QixJQUFBLHNCQUFBLEdBQUEsb0RBQUE7QUFBK0MsSUFBQSw0QkFBQTs7Ozs7QUFhckUsSUFBQSw4QkFBQSxHQUFBLFVBQUEsQ0FBQTtBQUF5QixJQUFBLHNCQUFBLENBQUE7QUFBZ0IsSUFBQSw0QkFBQTs7OztBQUFqQyxJQUFBLDBCQUFBLFNBQUEsT0FBQSxFQUFBO0FBQWlCLElBQUEseUJBQUE7QUFBQSxJQUFBLGlDQUFBLE9BQUEsTUFBQTs7Ozs7QUFJM0IsSUFBQSw4QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUF3QixJQUFBLHNCQUFBLEdBQUEsMkNBQUE7QUFBZ0MsSUFBQSw0QkFBQTs7Ozs7O0FBbkNsRSxJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQTRCLElBQUEsMEJBQUEsU0FBQSxTQUFBLHNEQUFBO0FBQUEsTUFBQSw2QkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDZCQUFBO0FBQUEsYUFBQSwyQkFBUyxPQUFBLFlBQUEsQ0FBYTtJQUFBLENBQUE7QUFDaEQsSUFBQSw4QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUFxQyxJQUFBLDBCQUFBLFNBQUEsU0FBQSxvREFBQSxRQUFBO0FBQUEsYUFBUyxPQUFBLGdCQUFBO0lBQXdCLENBQUE7QUFDcEUsSUFBQSw4QkFBQSxHQUFBLFVBQUEsRUFBQSxFQUE2QixHQUFBLElBQUE7QUFDdkIsSUFBQSxzQkFBQSxDQUFBO0FBQStELElBQUEsNEJBQUE7QUFDbkUsSUFBQSw4QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUF3QyxJQUFBLDBCQUFBLFNBQUEsU0FBQSx5REFBQTtBQUFBLE1BQUEsNkJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSw2QkFBQTtBQUFBLGFBQUEsMkJBQVMsT0FBQSxZQUFBLENBQWE7SUFBQSxDQUFBO0FBQUUsSUFBQSxzQkFBQSxHQUFBLFFBQUE7QUFBQyxJQUFBLDRCQUFBLEVBQVM7QUFHNUUsSUFBQSw4QkFBQSxHQUFBLFFBQUEsRUFBQTtBQUE4QixJQUFBLDBCQUFBLFlBQUEsU0FBQSwwREFBQTtBQUFBLE1BQUEsNkJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSw2QkFBQTtBQUFBLGFBQUEsMkJBQVksT0FBQSxhQUFBLENBQWM7SUFBQSxDQUFBO0FBQ3RELElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUEsRUFBd0IsR0FBQSxTQUFBLEVBQUE7QUFDRixJQUFBLHNCQUFBLElBQUEsd0JBQUE7QUFBc0IsSUFBQSw0QkFBQTtBQUMxQyxJQUFBLHlCQUFBLElBQUEsU0FBQSxFQUFBO0FBT0EsSUFBQSxtQ0FBQSxJQUFBLCtDQUFBLEdBQUEsR0FBQSxRQUFBLEVBQUE7QUFHRixJQUFBLDRCQUFBO0FBRUEsSUFBQSw4QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUF3QixJQUFBLFNBQUEsRUFBQTtBQUNJLElBQUEsc0JBQUEsSUFBQSxjQUFBO0FBQVMsSUFBQSw0QkFBQTtBQUNuQyxJQUFBLDhCQUFBLElBQUEsVUFBQSxFQUFBLEVBSUMsSUFBQSxVQUFBLEVBQUE7QUFDb0MsSUFBQSxzQkFBQSxJQUFBLGdDQUFBO0FBQXdCLElBQUEsNEJBQUE7QUFDM0QsSUFBQSxnQ0FBQSxJQUFBLHVDQUFBLEdBQUEsR0FBQSxVQUFBLEdBQUFHLFdBQUE7QUFHRixJQUFBLDRCQUFBO0FBQ0EsSUFBQSxtQ0FBQSxJQUFBLCtDQUFBLEdBQUEsR0FBQSxRQUFBLEVBQUE7QUFHRixJQUFBLDRCQUFBO0FBRUEsSUFBQSw4QkFBQSxJQUFBLE9BQUEsRUFBQSxFQUEwQixJQUFBLFVBQUEsRUFBQTtBQUNvQixJQUFBLDBCQUFBLFNBQUEsU0FBQSwwREFBQTtBQUFBLE1BQUEsNkJBQUEsR0FBQTtBQUFBLFlBQUEsU0FBQSw2QkFBQTtBQUFBLGFBQUEsMkJBQVMsT0FBQSxZQUFBLENBQWE7SUFBQSxDQUFBO0FBQ2hFLElBQUEsc0JBQUEsSUFBQSxZQUFBO0FBQ0YsSUFBQSw0QkFBQTtBQUNBLElBQUEsOEJBQUEsSUFBQSxVQUFBLEVBQUE7QUFDRSxJQUFBLHNCQUFBLEVBQUE7QUFDRixJQUFBLDRCQUFBLEVBQVMsRUFDTCxFQUNELEVBQ0g7Ozs7Ozs7O0FBN0NFLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsT0FBQSxjQUFBLGtDQUFBLHdCQUFBO0FBSUEsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxhQUFBLE9BQUEsU0FBQTtBQVFBLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMkJBQUEsZ0JBQUEsVUFBQSxPQUFBLFVBQUEsSUFBQSxRQUFBLE1BQUEsT0FBQSxPQUFBLFFBQUEsY0FBQSxVQUFBLE9BQUEsVUFBQSxJQUFBLFFBQUEsTUFBQSxPQUFBLE9BQUEsUUFBQSxRQUFBO0FBRUYsSUFBQSx5QkFBQTtBQUFBLElBQUEsK0JBQUEsVUFBQSxPQUFBLFVBQUEsSUFBQSxRQUFBLE1BQUEsT0FBQSxPQUFBLFFBQUEsY0FBQSxVQUFBLE9BQUEsVUFBQSxJQUFBLFFBQUEsTUFBQSxPQUFBLE9BQUEsUUFBQSxXQUFBLEtBQUEsRUFBQTtBQVVFLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMkJBQUEsZ0JBQUEsVUFBQSxPQUFBLFVBQUEsSUFBQSxjQUFBLE1BQUEsT0FBQSxPQUFBLFFBQUEsY0FBQSxVQUFBLE9BQUEsVUFBQSxJQUFBLGNBQUEsTUFBQSxPQUFBLE9BQUEsUUFBQSxRQUFBO0FBR0EsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxPQUFBLFVBQUE7QUFJRixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLCtCQUFBLFVBQUEsT0FBQSxVQUFBLElBQUEsY0FBQSxNQUFBLE9BQUEsT0FBQSxRQUFBLGNBQUEsVUFBQSxPQUFBLFVBQUEsSUFBQSxjQUFBLE1BQUEsT0FBQSxPQUFBLFFBQUEsV0FBQSxLQUFBLEVBQUE7QUFTMEMsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwwQkFBQSxZQUFBLE9BQUEsVUFBQSxPQUFBO0FBQ3hDLElBQUEseUJBQUE7QUFBQSxJQUFBLGtDQUFBLEtBQUEsT0FBQSxjQUFBLG9CQUFBLG1CQUFBLEdBQUE7OztBRDFHUixJQUFPLFNBQVAsTUFBTyxRQUFNO0VBQ0EsS0FBS0MsUUFBT0MsWUFBVztFQUN2QixlQUFlRCxRQUFPLFlBQVk7RUFFbkQsYUFBK0IsQ0FBQTtFQUMvQixTQUF1QixDQUFBO0VBQ3ZCLGtCQUFnQyxDQUFBO0VBRWhDLDBCQUE0QztFQUM1QyxnQkFBd0I7RUFFeEIsZUFBZTtFQUNmLGNBQWM7RUFDZCxtQkFBa0M7RUFDbEMsV0FBVztFQUVYLFlBQXVCLEtBQUssR0FBRyxNQUFNO0lBQ25DLFFBQVEsQ0FBQyxJQUFJLENBQUNFLFlBQVcsVUFBVUEsWUFBVyxVQUFVLENBQUMsQ0FBQyxDQUFDO0lBQzNELGNBQWMsQ0FBQyxJQUFJLENBQUNBLFlBQVcsUUFBUSxDQUFDO0dBQ3pDO0VBRUQsV0FBUTtBQUNOLFNBQUssaUJBQWdCO0FBQ3JCLFNBQUssYUFBWTtFQUNuQjtFQUVBLG1CQUFnQjtBQUNkLFNBQUssYUFBYSxvQkFBbUIsRUFBRyxVQUFVO01BQ2hELE1BQU0sQ0FBQyxTQUFVLEtBQUssYUFBWTtNQUNsQyxPQUFPLENBQUMsUUFBUSxRQUFRLE1BQU0saUNBQThCLEdBQUc7S0FDaEU7RUFDSDtFQUNBLHVCQUF1QixhQUFtQjtBQUMxQyxRQUFJLENBQUMsZUFBZSxLQUFLLFdBQVcsV0FBVztBQUFHLGFBQU87QUFDekQsVUFBTSxNQUFNLEtBQUssV0FBVyxLQUFLLE9BQUssT0FBTyxFQUFFLEVBQUUsTUFBTSxPQUFPLFdBQVcsQ0FBQztBQUMxRSxXQUFPLE1BQU0sSUFBSSxTQUFTO0VBQzVCO0VBRUUsZUFBWTtBQUNWLFNBQUssV0FBVztBQUNoQixTQUFLLGFBQWEsVUFBUyxFQUFHLFVBQVU7TUFDdEMsTUFBTSxDQUFDLFNBQVE7QUFDYixhQUFLLFNBQVM7QUFDZCxhQUFLLGVBQWM7QUFDbkIsYUFBSyxXQUFXO01BQ2xCO01BQ0EsT0FBTyxDQUFDLFFBQU87QUFDYixnQkFBUSxNQUFNLDBCQUEwQixHQUFHO0FBQzNDLGFBQUssV0FBVztNQUNsQjtLQUNEO0VBQ0g7RUFFQSxpQkFBYztBQUNaLFNBQUssa0JBQWtCLEtBQUssT0FBTyxPQUFPLENBQUMsTUFBSztBQUM5QyxZQUFNLG9CQUNKLEtBQUssNEJBQTRCLFdBQ2pDLEVBQUUsaUJBQWlCLE9BQU8sS0FBSyx1QkFBdUI7QUFFeEQsWUFBTSxnQkFBZ0IsRUFBRSxPQUNyQixZQUFXLEVBQ1gsU0FBUyxLQUFLLGNBQWMsWUFBVyxFQUFHLEtBQUksQ0FBRTtBQUVuRCxhQUFPLHFCQUFxQjtJQUM5QixDQUFDO0VBQ0g7RUFFQSxjQUFjLE9BQVk7QUFDeEIsU0FBSyxnQkFBaUIsTUFBTSxPQUE0QjtBQUN4RCxTQUFLLGVBQWM7RUFDckI7RUFFQSx1QkFBdUIsT0FBWTtBQUNqQyxVQUFNLFFBQVMsTUFBTSxPQUE2QjtBQUNsRCxTQUFLLDBCQUEwQixVQUFVLFVBQVUsVUFBVSxPQUFPLEtBQUs7QUFDekUsU0FBSyxlQUFjO0VBQ3JCO0VBRUEsa0JBQWU7QUFDYixTQUFLLGNBQWM7QUFDbkIsU0FBSyxtQkFBbUI7QUFDeEIsU0FBSyxVQUFVLE1BQUs7QUFDcEIsU0FBSyxlQUFlO0VBQ3RCO0VBRUEsZ0JBQWdCLE9BQWlCO0FBQy9CLFNBQUssY0FBYztBQUNuQixTQUFLLG1CQUFtQixNQUFNO0FBQzlCLFNBQUssVUFBVSxXQUFXO01BQ3hCLFFBQVEsTUFBTTtNQUNkLGNBQWMsTUFBTTtLQUNyQjtBQUNELFNBQUssZUFBZTtFQUN0QjtFQUVBLGNBQVc7QUFDVCxTQUFLLGVBQWU7QUFDcEIsU0FBSyxjQUFjO0FBQ25CLFNBQUssbUJBQW1CO0FBQ3hCLFNBQUssVUFBVSxNQUFLO0VBQ3RCO0VBRUEsZUFBWTtBQUNWLFFBQUksS0FBSyxVQUFVLFNBQVM7QUFDMUIsV0FBSyxVQUFVLGlCQUFnQjtBQUMvQjtJQUNGO0FBRUEsVUFBTSxVQUFVO01BQ2QsUUFBUSxLQUFLLFVBQVUsTUFBTTtNQUM3QixjQUFjLE9BQU8sS0FBSyxVQUFVLE1BQU0sWUFBWTs7QUFHeEQsUUFBSSxLQUFLLGVBQWUsS0FBSyxrQkFBa0I7QUFDN0MsV0FBSyxhQUFhLGdCQUFnQixLQUFLLGtCQUFrQixPQUFPLEVBQUUsVUFBVTtRQUMxRSxNQUFNLE1BQUs7QUFDVCxlQUFLLGFBQVk7QUFDakIsZUFBSyxZQUFXO1FBQ2xCO1FBQ0EsT0FBTyxDQUFDLFFBQVEsUUFBUSxNQUFNLDhCQUE4QixHQUFHO09BQ2hFO0lBQ0gsT0FBTztBQUNMLFdBQUssYUFBYSxXQUFXLE9BQU8sRUFBRSxVQUFVO1FBQzlDLE1BQU0sTUFBSztBQUNULGVBQUssYUFBWTtBQUNqQixlQUFLLFlBQVc7UUFDbEI7UUFDQSxPQUFPLENBQUMsUUFBUSxRQUFRLE1BQU0seUJBQXlCLEdBQUc7T0FDM0Q7SUFDSDtFQUNGO0VBRUEsY0FBYyxJQUFVO0FBQ3RCLFFBQUksUUFBUSxpREFBMkMsR0FBRztBQUN4RCxXQUFLLGFBQWEsY0FBYyxFQUFFLEVBQUUsVUFBVTtRQUM1QyxNQUFNLE1BQU0sS0FBSyxhQUFZO1FBQzdCLE9BQU8sQ0FBQyxRQUFRLFFBQVEsTUFBTSw0QkFBNEIsR0FBRztPQUM5RDtJQUNIO0VBQ0Y7O3FDQTNJVyxTQUFNO0VBQUE7OEVBQU4sU0FBTSxXQUFBLENBQUEsQ0FBQSxZQUFBLENBQUEsR0FBQSxPQUFBLElBQUEsTUFBQSxHQUFBLFFBQUEsQ0FBQSxDQUFBLEdBQUEsa0JBQUEsR0FBQSxDQUFBLEdBQUEsZ0JBQUEsR0FBQSxDQUFBLEdBQUEsZUFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsV0FBQSxHQUFBLENBQUEsR0FBQSxhQUFBLEdBQUEsQ0FBQSxHQUFBLG9CQUFBLEdBQUEsQ0FBQSxRQUFBLFFBQUEsZUFBQSw2QkFBQSxHQUFBLGdCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxjQUFBLEdBQUEsUUFBQSxHQUFBLENBQUEsU0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsa0JBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxnQkFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxTQUFBLFVBQUEsR0FBQSxZQUFBLFFBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxTQUFBLFlBQUEsR0FBQSxZQUFBLFVBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxXQUFBLEtBQUEsR0FBQSxhQUFBLEdBQUEsQ0FBQSxHQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxpQkFBQSxhQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxjQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsR0FBQSxhQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxZQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsT0FBQSxRQUFBLEdBQUEsQ0FBQSxRQUFBLFFBQUEsTUFBQSxVQUFBLG1CQUFBLFVBQUEsZUFBQSw2QkFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxPQUFBLGNBQUEsR0FBQSxDQUFBLE1BQUEsZ0JBQUEsbUJBQUEsY0FBQSxHQUFBLENBQUEsU0FBQSxJQUFBLFlBQUEsSUFBQSxZQUFBLEVBQUEsR0FBQSxDQUFBLEdBQUEsY0FBQSxHQUFBLENBQUEsUUFBQSxVQUFBLEdBQUEsaUJBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxRQUFBLFVBQUEsR0FBQSxlQUFBLEdBQUEsVUFBQSxDQUFBLEdBQUEsVUFBQSxTQUFBLGdCQUFBLElBQUEsS0FBQTtBQUFBLFFBQUEsS0FBQSxHQUFBO0FDWm5CLE1BQUEsOEJBQUEsR0FBQSxPQUFBLENBQUEsRUFBOEIsR0FBQSxVQUFBLENBQUEsRUFDRyxHQUFBLEtBQUEsRUFDeEIsR0FBQSxJQUFBO0FBQ0MsTUFBQSxzQkFBQSxHQUFBLG9EQUFBO0FBQW1DLE1BQUEsNEJBQUE7QUFDdkMsTUFBQSw4QkFBQSxHQUFBLEdBQUE7QUFBRyxNQUFBLHNCQUFBLEdBQUEsb0VBQUE7QUFBNEQsTUFBQSw0QkFBQSxFQUFJO0FBRXJFLE1BQUEsOEJBQUEsR0FBQSxVQUFBLENBQUE7QUFBNEIsTUFBQSwwQkFBQSxTQUFBLFNBQUEsMENBQUE7QUFBQSxlQUFTLElBQUEsZ0JBQUE7TUFBaUIsQ0FBQTtBQUNwRCxNQUFBLHNCQUFBLEdBQUEsMEJBQUE7QUFDRixNQUFBLDRCQUFBLEVBQVM7QUFJWCxNQUFBLDhCQUFBLEdBQUEsV0FBQSxDQUFBLEVBQTJCLElBQUEsT0FBQSxDQUFBLEVBQ0EsSUFBQSxJQUFBO0FBQ25CLE1BQUEsc0JBQUEsRUFBQTtBQUFxRCxNQUFBLDRCQUFBO0FBRXpELE1BQUEsOEJBQUEsSUFBQSxPQUFBLENBQUEsRUFBZ0MsSUFBQSxTQUFBLENBQUE7QUFLNUIsTUFBQSwwQkFBQSxTQUFBLFNBQUEsd0NBQUEsUUFBQTtBQUFBLGVBQVMsSUFBQSxjQUFBLE1BQUE7TUFBcUIsQ0FBQTtBQUpoQyxNQUFBLDRCQUFBO0FBT0EsTUFBQSw4QkFBQSxJQUFBLFVBQUEsQ0FBQTtBQUEyQixNQUFBLDBCQUFBLFVBQUEsU0FBQSwwQ0FBQSxRQUFBO0FBQUEsZUFBVSxJQUFBLHVCQUFBLE1BQUE7TUFBOEIsQ0FBQTtBQUNqRSxNQUFBLDhCQUFBLElBQUEsVUFBQSxDQUFBO0FBQXNCLE1BQUEsc0JBQUEsSUFBQSx5QkFBQTtBQUFvQixNQUFBLDRCQUFBO0FBQzFDLE1BQUEsZ0NBQUEsSUFBQSx3QkFBQSxHQUFBLEdBQUEsVUFBQSxHQUFBSCxXQUFBO0FBR0YsTUFBQSw0QkFBQSxFQUFTLEVBQ0w7QUFHUixNQUFBLDhCQUFBLElBQUEsT0FBQSxFQUFBLEVBQThCLElBQUEsT0FBQSxFQUNyQixJQUFBLE9BQUEsRUFDRSxJQUFBLElBQUEsRUFDRCxJQUFBLElBQUE7QUFDRSxNQUFBLHNCQUFBLElBQUEsSUFBQTtBQUFFLE1BQUEsNEJBQUE7QUFDTixNQUFBLDhCQUFBLElBQUEsSUFBQTtBQUFJLE1BQUEsc0JBQUEsSUFBQSxXQUFBO0FBQVMsTUFBQSw0QkFBQTtBQUNiLE1BQUEsOEJBQUEsSUFBQSxJQUFBO0FBQUksTUFBQSxzQkFBQSxJQUFBLGNBQUE7QUFBUyxNQUFBLDRCQUFBO0FBQ2IsTUFBQSw4QkFBQSxJQUFBLE1BQUEsRUFBQTtBQUF1QixNQUFBLHNCQUFBLElBQUEsVUFBQTtBQUFRLE1BQUEsNEJBQUEsRUFBSyxFQUNqQztBQUVQLE1BQUEsOEJBQUEsSUFBQSxPQUFBO0FBQ0UsTUFBQSxnQ0FBQSxJQUFBLHdCQUFBLElBQUEsR0FBQSxNQUFBLE1BQUFBLGFBQUEsT0FBQSw2QkFBQSxHQUFBLEdBQUEsSUFBQTtBQXVCRixNQUFBLDRCQUFBLEVBQVEsRUFDRixFQUNKO0FBSVIsTUFBQSxtQ0FBQSxJQUFBLGdDQUFBLElBQUEsSUFBQSxPQUFBLEVBQUE7QUFvREYsTUFBQSw0QkFBQTs7O0FBL0dVLE1BQUEseUJBQUEsRUFBQTtBQUFBLE1BQUEsa0NBQUEsNEJBQUEsSUFBQSxnQkFBQSxRQUFBLEdBQUE7QUFZQSxNQUFBLHlCQUFBLENBQUE7QUFBQSxNQUFBLDBCQUFBLElBQUEsVUFBQTtBQWtCQSxNQUFBLHlCQUFBLEVBQUE7QUFBQSxNQUFBLDBCQUFBLElBQUEsZUFBQTtBQTZCUixNQUFBLHlCQUFBLENBQUE7QUFBQSxNQUFBLDZCQUFBLElBQUEsZUFBQSxLQUFBLEVBQUE7O29CRGpFVUksZUFBWSxhQUFBLHVCQUFBLGFBQUEsVUFBQSxzQkFBQSxhQUFBLGNBQUEsa0JBQUEscUJBQUEsY0FBQSxrQkFBRUMsc0JBQW1CLHdCQUFBLG9CQUFBLGtDQUFBLDBCQUFBLHlCQUFBLHdCQUFBLGtDQUFBLGdDQUFBLHdDQUFBLCtCQUFBLHFCQUFBLDBCQUFBLHVCQUFBLHdCQUFBLHdCQUFBLHNCQUFBLCtCQUFBLG9CQUFBLGtCQUFBLGtCQUFBLDBCQUFBLHdCQUFBLHdCQUFBLHFCQUFBLG1CQUFBLG1CQUFFQyxjQUFXLGFBQUEsa0JBQUEsWUFBQSxlQUFBLG1CQUFBLG1CQUFBLGNBQUEsZUFBQSxpQkFBQSxpQkFBQSxtQkFBQSxrQkFBQSxjQUFBLG9CQUFBLG9CQUFBLGdCQUFBLEdBQUEsUUFBQSxDQUFBLDA4VEFBQSxFQUFBLENBQUE7OztpRkFJN0MsUUFBTSxDQUFBO1VBUGxCQzt1QkFDVyxjQUFZLFlBQ1YsTUFBSSxTQUNQLENBQUNILGVBQWNDLHNCQUFxQkMsWUFBVyxHQUFDLFVBQUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1NBQUEsUUFBQSxDQUFBLHkzTUFBQSxFQUFBLENBQUE7Ozs7a0ZBSTlDLFFBQU0sRUFBQSxXQUFBLFVBQUEsVUFBQSwyQ0FBQSxZQUFBLEdBQUEsQ0FBQTtBQUFBLEdBQUE7Ozs7Ozs7Z0VBQU4sUUFBTSxFQUFBLFNBQUEsQ0FBQUUsTUFBQUMsS0FBQUMsR0FBQSxHQUFBLENBQUFOLGVBQUFDLHNCQUFBQyxjQUFBQyxVQUFBLEdBQUEsYUFBQSxFQUFBLENBQUE7RUFBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsY0FBQSxlQUFBLEtBQUEsSUFBQSxDQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxlQUFBLFlBQUEsT0FBQSxZQUFBLElBQUEsR0FBQSw0QkFBQSxPQUFBLEVBQUEsT0FBQSxNQUFBLGVBQUEsRUFBQSxTQUFBLENBQUE7QUFBQSxHQUFBOzs7Ozs7Ozs7OztBRG1EVCxJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQXFCLElBQUEsc0JBQUEsR0FBQSwrQ0FBQTtBQUF3QyxJQUFBLDRCQUFBOzs7Ozs7QUFlbkUsSUFBQSw4QkFBQSxHQUFBLElBQUEsRUFBSSxHQUFBLElBQUE7QUFDRSxJQUFBLHNCQUFBLENBQUE7QUFBcUIsSUFBQSw0QkFBQTtBQUN6QixJQUFBLDhCQUFBLEdBQUEsSUFBQSxFQUFJLEdBQUEsUUFBQTtBQUFRLElBQUEsc0JBQUEsQ0FBQTtBQUFxQixJQUFBLDRCQUFBLEVBQVM7QUFDMUMsSUFBQSw4QkFBQSxHQUFBLElBQUE7QUFBSSxJQUFBLHNCQUFBLENBQUE7QUFBYyxJQUFBLDRCQUFBO0FBQ2xCLElBQUEsOEJBQUEsR0FBQSxJQUFBO0FBQUksSUFBQSxzQkFBQSxDQUFBO0FBQWUsSUFBQSw0QkFBQTtBQUNuQixJQUFBLDhCQUFBLElBQUEsSUFBQSxFQUFJLElBQUEsUUFBQSxFQUFBO0FBS0EsSUFBQSxzQkFBQSxFQUFBO0FBQ0YsSUFBQSw0QkFBQSxFQUFPO0FBRVQsSUFBQSw4QkFBQSxJQUFBLE1BQUEsRUFBQSxFQUEwQixJQUFBLFVBQUEsRUFBQTtBQUNDLElBQUEsMEJBQUEsU0FBQSxTQUFBLG1GQUFBO0FBQUEsWUFBQSxTQUFBLDZCQUFBLEdBQUEsRUFBQTtBQUFBLFlBQUEsU0FBQSw2QkFBQSxDQUFBO0FBQUEsYUFBQSwyQkFBUyxPQUFBLFdBQUEsTUFBQSxDQUFlO0lBQUEsQ0FBQTtBQUMvQyxJQUFBLHNCQUFBLElBQUEscUJBQUE7QUFDRixJQUFBLDRCQUFBO0FBRUEsSUFBQSw4QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUF5QixJQUFBLDBCQUFBLFNBQUEsU0FBQSxtRkFBQTtBQUFBLFlBQUEsU0FBQSw2QkFBQSxHQUFBLEVBQUE7QUFBQSxZQUFBLFNBQUEsNkJBQUEsQ0FBQTtBQUFBLGFBQUEsMkJBQVMsT0FBQSxtQkFBQSxPQUFBLFVBQUEsQ0FBa0M7SUFBQSxDQUFBO0FBQ2xFLElBQUEsc0JBQUEsSUFBQSxvQkFBQTtBQUNGLElBQUEsNEJBQUE7QUFFQSxJQUFBLDhCQUFBLElBQUEsVUFBQSxFQUFBO0FBSUUsSUFBQSwwQkFBQSxTQUFBLFNBQUEsbUZBQUE7QUFBQSxZQUFBLFNBQUEsNkJBQUEsR0FBQSxFQUFBO0FBQUEsWUFBQSxTQUFBLDZCQUFBLENBQUE7QUFBQSxhQUFBLDJCQUFTLE9BQUEsY0FBQSxPQUFBLFlBQUEsT0FBQSxNQUFBLENBQXlDO0lBQUEsQ0FBQTtBQUNsRCxJQUFBLHNCQUFBLEVBQUE7QUFDRixJQUFBLDRCQUFBLEVBQVMsRUFDSjs7OztBQTVCSCxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGtDQUFBLEtBQUEsT0FBQSxVQUFBO0FBQ1EsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxPQUFBLFdBQUE7QUFDUixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLE9BQUEsSUFBQTtBQUNBLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsT0FBQSxLQUFBO0FBR0ksSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxVQUFBLE9BQUEsV0FBQSxRQUFBLEVBQXdDLFlBQUEsT0FBQSxXQUFBLFVBQUEsRUFDSSxhQUFBLE9BQUEsV0FBQSxXQUFBO0FBRWhELElBQUEseUJBQUE7QUFBQSxJQUFBLGtDQUFBLEtBQUEsT0FBQSxRQUFBLEdBQUE7QUFjQSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDJCQUFBLGtCQUFBLE9BQUEsV0FBQSxRQUFBLEVBQWdELGVBQUEsT0FBQSxXQUFBLFFBQUE7QUFHaEQsSUFBQSx5QkFBQTtBQUFBLElBQUEsa0NBQUEsS0FBQSxPQUFBLFdBQUEsV0FBQSxlQUFBLFdBQUEsR0FBQTs7Ozs7QUF4Q0EsSUFBQSw4QkFBQSxHQUFBLFNBQUEsRUFBQSxFQUEyQixHQUFBLE9BQUEsRUFDbEIsR0FBQSxJQUFBLEVBQ0QsR0FBQSxJQUFBO0FBQ0UsSUFBQSxzQkFBQSxHQUFBLElBQUE7QUFBRSxJQUFBLDRCQUFBO0FBQ04sSUFBQSw4QkFBQSxHQUFBLElBQUE7QUFBSSxJQUFBLHNCQUFBLEdBQUEsaUJBQUE7QUFBWSxJQUFBLDRCQUFBO0FBQ2hCLElBQUEsOEJBQUEsR0FBQSxJQUFBO0FBQUksSUFBQSxzQkFBQSxHQUFBLE1BQUE7QUFBSSxJQUFBLDRCQUFBO0FBQ1IsSUFBQSw4QkFBQSxHQUFBLElBQUE7QUFBSSxJQUFBLHNCQUFBLElBQUEsT0FBQTtBQUFLLElBQUEsNEJBQUE7QUFDVCxJQUFBLDhCQUFBLElBQUEsSUFBQTtBQUFJLElBQUEsc0JBQUEsSUFBQSxRQUFBO0FBQU0sSUFBQSw0QkFBQTtBQUNWLElBQUEsOEJBQUEsSUFBQSxJQUFBO0FBQUksSUFBQSxzQkFBQSxJQUFBLFVBQUE7QUFBUSxJQUFBLDRCQUFBLEVBQUssRUFDZDtBQUVQLElBQUEsOEJBQUEsSUFBQSxPQUFBO0FBQ0UsSUFBQSxnQ0FBQSxJQUFBLHlEQUFBLElBQUEsSUFBQSxNQUFBLE1BQUFJLFdBQUE7QUFpQ04sSUFBQSw0QkFBQSxFQUFROzs7O0FBakNGLElBQUEseUJBQUEsRUFBQTtBQUFBLElBQUEsMEJBQUEsT0FBQSxRQUFBOzs7OztBQW9DSixJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQXNCLElBQUEsc0JBQUEsR0FBQSw4REFBQTtBQUFrRCxJQUFBLDRCQUFBOzs7OztBQXJEMUUsSUFBQSw4QkFBQSxHQUFBLElBQUE7QUFBSSxJQUFBLHNCQUFBLEdBQUEsZ0NBQUE7QUFBdUIsSUFBQSw0QkFBQTtBQUUzQixJQUFBLG1DQUFBLEdBQUEsa0RBQUEsR0FBQSxHQUFBLE9BQUEsRUFBQSxFQUFnQixHQUFBLGtEQUFBLElBQUEsR0FBQSxTQUFBLEVBQUEsRUFFa0IsR0FBQSxrREFBQSxHQUFBLEdBQUEsT0FBQSxFQUFBOzs7O0FBRmxDLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsNkJBQUEsT0FBQSxXQUFBLElBQUEsT0FBQSxTQUFBLFNBQUEsSUFBQSxJQUFBLENBQUE7Ozs7O0FBMkRFLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFBcUIsSUFBQSxzQkFBQSxHQUFBLDhDQUFBO0FBQXVDLElBQUEsNEJBQUE7Ozs7O0FBMEJoRCxJQUFBLDhCQUFBLEdBQUEsUUFBQSxFQUFBO0FBQTZCLElBQUEsc0JBQUEsQ0FBQTtBQUEwQyxJQUFBLDRCQUFBOzs7O0FBQTFDLElBQUEseUJBQUE7QUFBQSxJQUFBLGtDQUFBLGVBQUEsVUFBQSxpQkFBQSxJQUFBLElBQUE7Ozs7O0FBRTdCLElBQUEsOEJBQUEsR0FBQSxRQUFBLEVBQUE7QUFBMkIsSUFBQSxzQkFBQSxDQUFBO0FBQW1DLElBQUEsNEJBQUE7Ozs7O0FBQW5DLElBQUEseUJBQUE7QUFBQSxJQUFBLGtDQUFBLGtCQUFBLGNBQUEsTUFBQSxVQUFBOzs7Ozs7QUFaakMsSUFBQSw0QkFBQSxDQUFBO0FBQ0EsSUFBQSw4QkFBQSxHQUFBLElBQUEsRUFBSSxHQUFBLElBQUE7QUFDRSxJQUFBLHNCQUFBLENBQUE7QUFBdUIsSUFBQSw0QkFBQTtBQUMzQixJQUFBLDhCQUFBLEdBQUEsSUFBQSxFQUFJLEdBQUEsUUFBQTtBQUNNLElBQUEsc0JBQUEsQ0FBQTtBQUFtQixJQUFBLDRCQUFBO0FBQVMsSUFBQSx5QkFBQSxHQUFBLElBQUE7QUFDcEMsSUFBQSw4QkFBQSxHQUFBLFNBQUEsRUFBQTtBQUEwQixJQUFBLHNCQUFBLENBQUE7QUFBMkQsSUFBQSw0QkFBQSxFQUFRO0FBRS9GLElBQUEsOEJBQUEsSUFBQSxJQUFBO0FBQUksSUFBQSxzQkFBQSxFQUFBO0FBQThDLElBQUEsNEJBQUE7QUFDbEQsSUFBQSw4QkFBQSxJQUFBLElBQUE7QUFDRSxJQUFBLG1DQUFBLElBQUEsd0VBQUEsR0FBQSxHQUFBLFFBQUEsRUFBQSxFQUE2QixJQUFBLHdFQUFBLEdBQUEsR0FBQSxRQUFBLEVBQUE7QUFLL0IsSUFBQSw0QkFBQTtBQUNBLElBQUEsOEJBQUEsSUFBQSxJQUFBO0FBQUksSUFBQSxzQkFBQSxFQUFBO0FBQWlELElBQUEsNEJBQUE7QUFDckQsSUFBQSw4QkFBQSxJQUFBLElBQUEsRUFBSSxJQUFBLFFBQUEsRUFBQTtBQUVBLElBQUEsc0JBQUEsRUFBQTtBQUNGLElBQUEsNEJBQUEsRUFBTztBQUVULElBQUEsOEJBQUEsSUFBQSxJQUFBLEVBQUksSUFBQSxVQUFBLEVBQUE7QUFDd0MsSUFBQSwwQkFBQSxTQUFBLFNBQUEsbUZBQUE7QUFBQSxZQUFBLFlBQUEsNkJBQUEsR0FBQSxFQUFBO0FBQUEsWUFBQSxTQUFBLDZCQUFBLENBQUE7QUFBQSxhQUFBLDJCQUFTLE9BQUEsZ0JBQUEsVUFBQSxTQUFBLENBQWlDO0lBQUEsQ0FBQTtBQUNsRixJQUFBLHNCQUFBLElBQUEsNEJBQUE7QUFDRixJQUFBLDRCQUFBLEVBQVMsRUFDTjs7Ozs7MEJBekJQLDBCQUFrQixPQUFBLHFCQUFBLFVBQUEsbUJBQUEsVUFBQSxhQUFBLENBQW9FO0FBRWhGLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsa0NBQUEsS0FBQSxVQUFBLFNBQUE7QUFFTSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLFVBQUEsTUFBQTtBQUNrQixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLFVBQUEsZUFBQSxjQUFBLFVBQUEsVUFBQTtBQUV4QixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLE9BQUEsZUFBQSxVQUFBLGlCQUFBLENBQUE7QUFFRixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDZCQUFBLGNBQUEsYUFBQSxLQUFBLEVBQUE7QUFNRSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGtDQUFBLElBQUEsVUFBQSxXQUFBLE1BQUEsVUFBQSxhQUFBLEdBQUE7QUFFa0IsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxVQUFBLENBQUEsY0FBQSxVQUFBLEVBQXVDLFlBQUEsY0FBQSxVQUFBO0FBQ3pELElBQUEseUJBQUE7QUFBQSxJQUFBLGtDQUFBLEtBQUEsY0FBQSxZQUFBLEdBQUE7Ozs7O0FBaENaLElBQUEsOEJBQUEsR0FBQSxTQUFBLEVBQUEsRUFBMkIsR0FBQSxPQUFBLEVBQ2xCLEdBQUEsSUFBQSxFQUNELEdBQUEsSUFBQTtBQUNFLElBQUEsc0JBQUEsR0FBQSxJQUFBO0FBQUUsSUFBQSw0QkFBQTtBQUNOLElBQUEsOEJBQUEsR0FBQSxJQUFBO0FBQUksSUFBQSxzQkFBQSxHQUFBLHFCQUFBO0FBQWdCLElBQUEsNEJBQUE7QUFDcEIsSUFBQSw4QkFBQSxHQUFBLElBQUE7QUFBSSxJQUFBLHNCQUFBLEdBQUEsc0JBQUE7QUFBaUIsSUFBQSw0QkFBQTtBQUNyQixJQUFBLDhCQUFBLEdBQUEsSUFBQTtBQUFJLElBQUEsc0JBQUEsSUFBQSwyQkFBQTtBQUFzQixJQUFBLDRCQUFBO0FBQzFCLElBQUEsOEJBQUEsSUFBQSxJQUFBO0FBQUksSUFBQSxzQkFBQSxJQUFBLFdBQUE7QUFBUyxJQUFBLDRCQUFBO0FBQ2IsSUFBQSw4QkFBQSxJQUFBLElBQUE7QUFBSSxJQUFBLHNCQUFBLElBQUEsUUFBQTtBQUFNLElBQUEsNEJBQUE7QUFDVixJQUFBLDhCQUFBLElBQUEsSUFBQTtBQUFJLElBQUEsc0JBQUEsSUFBQSxXQUFBO0FBQU0sSUFBQSw0QkFBQSxFQUFLLEVBQ1o7QUFFUCxJQUFBLDhCQUFBLElBQUEsT0FBQTtBQUNFLElBQUEsZ0NBQUEsSUFBQSx5REFBQSxJQUFBLElBQUEsTUFBQSxNQUFBQyxXQUFBO0FBNkJGLElBQUEsNEJBQUEsRUFBUTs7OztBQTdCTixJQUFBLHlCQUFBLEVBQUE7QUFBQSxJQUFBLDBCQUFBLE9BQUEsT0FBQTs7Ozs7QUFnQ0osSUFBQSw4QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUFzQixJQUFBLHNCQUFBLEdBQUEsNkVBQUE7QUFBaUUsSUFBQSw0QkFBQTs7Ozs7QUFqRHpGLElBQUEsOEJBQUEsR0FBQSxJQUFBO0FBQUksSUFBQSxzQkFBQSxHQUFBLDhDQUFBO0FBQWtDLElBQUEsNEJBQUE7QUFDdEMsSUFBQSxtQ0FBQSxHQUFBLGtEQUFBLEdBQUEsR0FBQSxPQUFBLEVBQUEsRUFBZ0IsR0FBQSxrREFBQSxJQUFBLEdBQUEsU0FBQSxFQUFBLEVBRWlCLEdBQUEsa0RBQUEsR0FBQSxHQUFBLE9BQUEsRUFBQTs7OztBQUZqQyxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDZCQUFBLE9BQUEsV0FBQSxJQUFBLE9BQUEsUUFBQSxTQUFBLElBQUEsSUFBQSxDQUFBOzs7OztBQXlERSxJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQXFCLElBQUEsc0JBQUEsR0FBQSxrREFBQTtBQUEyQyxJQUFBLDRCQUFBOzs7Ozs7QUFpQjFELElBQUEsOEJBQUEsR0FBQSxJQUFBLEVBQUksR0FBQSxJQUFBO0FBQ0UsSUFBQSxzQkFBQSxDQUFBO0FBQW9DLElBQUEsNEJBQUE7QUFDeEMsSUFBQSw4QkFBQSxHQUFBLElBQUEsRUFBSSxHQUFBLFFBQUE7QUFBUSxJQUFBLHNCQUFBLENBQUE7QUFBdUUsSUFBQSw0QkFBQSxFQUFTO0FBQzVGLElBQUEsOEJBQUEsR0FBQSxJQUFBO0FBQUksSUFBQSxzQkFBQSxDQUFBO0FBQXVCLElBQUEsNEJBQUE7QUFDM0IsSUFBQSw4QkFBQSxHQUFBLElBQUE7QUFBSSxJQUFBLHNCQUFBLENBQUE7QUFBMEIsSUFBQSw0QkFBQTtBQUM5QixJQUFBLDhCQUFBLElBQUEsSUFBQTtBQUFJLElBQUEsc0JBQUEsRUFBQTtBQUFpRCxJQUFBLDRCQUFBO0FBQ3JELElBQUEsOEJBQUEsSUFBQSxJQUFBO0FBQUksSUFBQSxzQkFBQSxFQUFBO0FBQWdCLElBQUEsNEJBQUE7QUFDcEIsSUFBQSw4QkFBQSxJQUFBLElBQUEsRUFBSSxJQUFBLFFBQUEsRUFBQTtBQUVBLElBQUEsc0JBQUEsRUFBQTtBQUNGLElBQUEsNEJBQUEsRUFBTztBQUVULElBQUEsOEJBQUEsSUFBQSxJQUFBLEVBQUksSUFBQSxVQUFBLEVBQUE7QUFDdUIsSUFBQSwwQkFBQSxTQUFBLFNBQUEsbUZBQUE7QUFBQSxZQUFBLFVBQUEsNkJBQUEsR0FBQSxFQUFBO0FBQUEsWUFBQSxTQUFBLDZCQUFBLENBQUE7QUFBQSxhQUFBLDJCQUFTLE9BQUEscUJBQUEsT0FBQSxDQUEwQjtJQUFBLENBQUE7QUFDMUQsSUFBQSxzQkFBQSxJQUFBLDJCQUFBO0FBQ0YsSUFBQSw0QkFBQSxFQUFTLEVBQ047Ozs7QUFmRCxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGtDQUFBLEtBQUEsUUFBQSxpQkFBQSxRQUFBLEVBQUE7QUFDUSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGtDQUFBLElBQUEsUUFBQSxXQUFBLFFBQUEsUUFBQSxLQUFBLFFBQUEsYUFBQSxRQUFBLFFBQUE7QUFDUixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGlDQUFBLFFBQUEsT0FBQSxLQUFBO0FBQ0EsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxRQUFBLFVBQUEsS0FBQTtBQUNBLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsUUFBQSxXQUFBLDJCQUFBO0FBQ0EsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSxpQ0FBQSxRQUFBLEtBQUE7QUFFa0IsSUFBQSx5QkFBQSxDQUFBO0FBQUEsSUFBQSwyQkFBQSxVQUFBLFFBQUEsV0FBQSxVQUFBLEVBQTJDLFlBQUEsUUFBQSxXQUFBLFVBQUE7QUFDN0QsSUFBQSx5QkFBQTtBQUFBLElBQUEsa0NBQUEsS0FBQSxRQUFBLFVBQUEsVUFBQSxHQUFBOzs7OztBQXhCWixJQUFBLDhCQUFBLEdBQUEsU0FBQSxFQUFBLEVBQTJCLEdBQUEsT0FBQSxFQUNsQixHQUFBLElBQUEsRUFDRCxHQUFBLElBQUE7QUFDRSxJQUFBLHNCQUFBLEdBQUEsSUFBQTtBQUFFLElBQUEsNEJBQUE7QUFDTixJQUFBLDhCQUFBLEdBQUEsSUFBQTtBQUFJLElBQUEsc0JBQUEsR0FBQSxtQkFBQTtBQUFpQixJQUFBLDRCQUFBO0FBQ3JCLElBQUEsOEJBQUEsR0FBQSxJQUFBO0FBQUksSUFBQSxzQkFBQSxHQUFBLEtBQUE7QUFBRyxJQUFBLDRCQUFBO0FBQ1AsSUFBQSw4QkFBQSxHQUFBLElBQUE7QUFBSSxJQUFBLHNCQUFBLElBQUEsUUFBQTtBQUFNLElBQUEsNEJBQUE7QUFDVixJQUFBLDhCQUFBLElBQUEsSUFBQTtBQUFJLElBQUEsc0JBQUEsSUFBQSxTQUFBO0FBQU8sSUFBQSw0QkFBQTtBQUNYLElBQUEsOEJBQUEsSUFBQSxJQUFBO0FBQUksSUFBQSxzQkFBQSxJQUFBLE9BQUE7QUFBSyxJQUFBLDRCQUFBO0FBQ1QsSUFBQSw4QkFBQSxJQUFBLElBQUE7QUFBSSxJQUFBLHNCQUFBLElBQUEsUUFBQTtBQUFNLElBQUEsNEJBQUE7QUFDVixJQUFBLDhCQUFBLElBQUEsSUFBQTtBQUFJLElBQUEsc0JBQUEsSUFBQSxXQUFBO0FBQU0sSUFBQSw0QkFBQSxFQUFLLEVBQ1o7QUFFUCxJQUFBLDhCQUFBLElBQUEsT0FBQTtBQUNFLElBQUEsZ0NBQUEsSUFBQSx5REFBQSxJQUFBLElBQUEsTUFBQSxNQUFBQyxXQUFBO0FBb0JGLElBQUEsNEJBQUEsRUFBUTs7OztBQXBCTixJQUFBLHlCQUFBLEVBQUE7QUFBQSxJQUFBLDBCQUFBLE9BQUEsV0FBQTs7Ozs7QUF1QkosSUFBQSw4QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUFzQixJQUFBLHNCQUFBLEdBQUEsNkVBQUE7QUFBaUUsSUFBQSw0QkFBQTs7Ozs7QUExQ3pGLElBQUEsOEJBQUEsR0FBQSxJQUFBO0FBQUksSUFBQSxzQkFBQSxHQUFBLDBEQUFBO0FBQThDLElBQUEsNEJBQUE7QUFFbEQsSUFBQSxtQ0FBQSxHQUFBLGtEQUFBLEdBQUEsR0FBQSxPQUFBLEVBQUEsRUFBZ0IsR0FBQSxrREFBQSxJQUFBLEdBQUEsU0FBQSxFQUFBLEVBRXFCLEdBQUEsa0RBQUEsR0FBQSxHQUFBLE9BQUEsRUFBQTs7OztBQUZyQyxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDZCQUFBLE9BQUEsV0FBQSxJQUFBLE9BQUEsWUFBQSxTQUFBLElBQUEsSUFBQSxDQUFBOzs7OztBQThDQSxJQUFBLHlCQUFBLEdBQUEsbUJBQUE7Ozs7O0FBY0YsSUFBQSx5QkFBQSxHQUFBLFlBQUE7Ozs7O0FBaUJVLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUEsRUFBdUIsR0FBQSxPQUFBO0FBQ2QsSUFBQSxzQkFBQSxDQUFBO0FBQTJELElBQUEsNEJBQUE7QUFDbEUsSUFBQSw4QkFBQSxHQUFBLE1BQUE7QUFBTSxJQUFBLHNCQUFBLENBQUE7QUFBK0UsSUFBQSw0QkFBQSxFQUFPOzs7OztBQURyRixJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLGtDQUFBLElBQUEsT0FBQSxlQUFBLE9BQUEsZ0JBQUEsU0FBQSxJQUFBLFNBQUEsQ0FBQSxDQUFBLEdBQUEsR0FBQTtBQUNELElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsaUNBQUEsU0FBQSxVQUFBLFFBQUEsU0FBQSxVQUFBLEtBQUEsU0FBQSxRQUFBLGlCQUFBOzs7OztBQUhWLElBQUEsbUNBQUEsR0FBQSx5REFBQSxHQUFBLEdBQUEsT0FBQSxFQUFBOzs7OztBQUFBLElBQUEsNkJBQUEsT0FBQSxlQUFBLE9BQUEsZ0JBQUEsU0FBQSxJQUFBLFNBQUEsQ0FBQSxDQUFBLElBQUEsSUFBQSxFQUFBOzs7Ozs7QUFWVixJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQTJCLElBQUEsMEJBQUEsU0FBQSxTQUFBLDBEQUFBO0FBQUEsTUFBQSw2QkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDZCQUFBO0FBQUEsYUFBQSwyQkFBUyxPQUFBLFlBQUEsQ0FBYTtJQUFBLENBQUE7QUFDL0MsSUFBQSw4QkFBQSxHQUFBLE9BQUEsRUFBQTtBQUEyQixJQUFBLDBCQUFBLFNBQUEsU0FBQSx3REFBQSxRQUFBO0FBQUEsYUFBUyxPQUFBLGdCQUFBO0lBQXdCLENBQUE7QUFDMUQsSUFBQSw4QkFBQSxHQUFBLE9BQUEsRUFBQSxFQUEwQixHQUFBLElBQUE7QUFDcEIsSUFBQSxzQkFBQSxHQUFBLHdDQUFBO0FBQStCLElBQUEsNEJBQUE7QUFDbkMsSUFBQSw4QkFBQSxHQUFBLFVBQUEsRUFBQTtBQUEyQixJQUFBLDBCQUFBLFNBQUEsU0FBQSw2REFBQTtBQUFBLE1BQUEsNkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSw2QkFBQTtBQUFBLGFBQUEsMkJBQVMsT0FBQSxZQUFBLENBQWE7SUFBQSxDQUFBO0FBQUUsSUFBQSxzQkFBQSxHQUFBLFFBQUE7QUFBQyxJQUFBLDRCQUFBLEVBQVM7QUFHL0QsSUFBQSw4QkFBQSxHQUFBLE9BQUEsRUFBQSxFQUF3QixHQUFBLE9BQUEsRUFBQTtBQUVwQixJQUFBLGdDQUFBLEdBQUEsMkNBQUEsR0FBQSxHQUFBLE1BQUEsTUFBQSxVQUFBOztBQVFGLElBQUEsNEJBQUEsRUFBTTtBQUdSLElBQUEsOEJBQUEsSUFBQSxPQUFBLEVBQUEsRUFBMEIsSUFBQSxVQUFBLEVBQUE7QUFLdEIsSUFBQSwwQkFBQSxTQUFBLFNBQUEsOERBQUE7QUFBQSxNQUFBLDZCQUFBLElBQUE7QUFBQSxZQUFBLFNBQUEsNkJBQUE7QUFBQSxhQUFBLDJCQUFTLE9BQUEsY0FBQSxPQUFBLG9CQUFBLFlBQUEsT0FBQSxvQkFBQSxNQUFBLENBQXlFO0lBQUEsQ0FBQTtBQUNsRixJQUFBLHNCQUFBLEVBQUE7QUFDRixJQUFBLDRCQUFBO0FBQ0EsSUFBQSw4QkFBQSxJQUFBLFVBQUEsRUFBQTtBQUErQixJQUFBLDBCQUFBLFNBQUEsU0FBQSw4REFBQTtBQUFBLE1BQUEsNkJBQUEsSUFBQTtBQUFBLFlBQUEsU0FBQSw2QkFBQTtBQUFBLGFBQUEsMkJBQVMsT0FBQSxZQUFBLENBQWE7SUFBQSxDQUFBO0FBQUUsSUFBQSxzQkFBQSxJQUFBLFFBQUE7QUFBTSxJQUFBLDRCQUFBLEVBQVMsRUFDbEUsRUFDRjs7OztBQXJCQSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLDJCQUFBLElBQUEsR0FBQSxPQUFBLG1CQUFBLENBQUE7QUFjQSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDJCQUFBLGtCQUFBLE9BQUEsb0JBQUEsV0FBQSxRQUFBLEVBQWdFLGVBQUEsT0FBQSxvQkFBQSxXQUFBLFFBQUE7QUFHaEUsSUFBQSx5QkFBQTtBQUFBLElBQUEsa0NBQUEsS0FBQSxPQUFBLG9CQUFBLFdBQUEsV0FBQSx1QkFBQSxtQkFBQSxHQUFBOzs7Ozs7QUFXVixJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQTJCLElBQUEsMEJBQUEsU0FBQSxTQUFBLDBEQUFBO0FBQUEsTUFBQSw2QkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDZCQUFBO0FBQUEsYUFBQSwyQkFBUyxPQUFBLGtCQUFBLENBQW1CO0lBQUEsQ0FBQTtBQUNyRCxJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQThDLElBQUEsMEJBQUEsU0FBQSxTQUFBLHdEQUFBLFFBQUE7QUFBQSxhQUFTLE9BQUEsZ0JBQUE7SUFBd0IsQ0FBQTtBQUM3RSxJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBLEVBQTBCLEdBQUEsSUFBQTtBQUNwQixJQUFBLHNCQUFBLEdBQUEsZ0NBQUE7QUFBdUIsSUFBQSw0QkFBQTtBQUMzQixJQUFBLDhCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQTJCLElBQUEsMEJBQUEsU0FBQSxTQUFBLDZEQUFBO0FBQUEsTUFBQSw2QkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDZCQUFBO0FBQUEsYUFBQSwyQkFBUyxPQUFBLGtCQUFBLENBQW1CO0lBQUEsQ0FBQTtBQUFFLElBQUEsc0JBQUEsR0FBQSxRQUFBO0FBQUMsSUFBQSw0QkFBQSxFQUFTO0FBR3JFLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUEsRUFBd0IsR0FBQSx1QkFBQSxFQUFBO0FBSXBCLElBQUEsMEJBQUEsZUFBQSxTQUFBLGdGQUFBO0FBQUEsTUFBQSw2QkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDZCQUFBO0FBQUEsYUFBQSwyQkFBZSxPQUFBLGtCQUFBLENBQW1CO0lBQUEsQ0FBQTtBQUNwQyxJQUFBLDRCQUFBLEVBQXNCLEVBQ2xCLEVBQ0Y7Ozs7QUFMQSxJQUFBLHlCQUFBLENBQUE7QUFBQSxJQUFBLDBCQUFBLGtCQUFBLE9BQUEsZUFBQSxFQUFrQyxlQUFBLElBQUE7Ozs7OztBQVcxQyxJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQTJCLElBQUEsMEJBQUEsU0FBQSxTQUFBLDBEQUFBO0FBQUEsTUFBQSw2QkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDZCQUFBO0FBQUEsYUFBQSwyQkFBUyxPQUFBLHNCQUFBLENBQXVCO0lBQUEsQ0FBQTtBQUN6RCxJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBO0FBQTJCLElBQUEsMEJBQUEsU0FBQSxTQUFBLHdEQUFBLFFBQUE7QUFBQSxhQUFTLE9BQUEsZ0JBQUE7SUFBd0IsQ0FBQTtBQUMxRCxJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBLEVBQTBCLEdBQUEsSUFBQTtBQUNwQixJQUFBLHNCQUFBLEdBQUEsZ0NBQUE7QUFBdUIsSUFBQSw0QkFBQTtBQUMzQixJQUFBLDhCQUFBLEdBQUEsVUFBQSxFQUFBO0FBQTJCLElBQUEsMEJBQUEsU0FBQSxTQUFBLDZEQUFBO0FBQUEsTUFBQSw2QkFBQSxJQUFBO0FBQUEsWUFBQSxTQUFBLDZCQUFBO0FBQUEsYUFBQSwyQkFBUyxPQUFBLHNCQUFBLENBQXVCO0lBQUEsQ0FBQTtBQUFFLElBQUEsc0JBQUEsR0FBQSxRQUFBO0FBQUMsSUFBQSw0QkFBQSxFQUFTO0FBR3pFLElBQUEsOEJBQUEsR0FBQSxPQUFBLEVBQUE7QUFFRSxJQUFBLHlCQUFBLEdBQUEsMEJBQUEsRUFBQTtBQUlGLElBQUEsNEJBQUE7QUFFQSxJQUFBLDhCQUFBLEdBQUEsT0FBQSxFQUFBLEVBQTBCLElBQUEsVUFBQSxFQUFBO0FBQ08sSUFBQSwwQkFBQSxTQUFBLFNBQUEsOERBQUE7QUFBQSxNQUFBLDZCQUFBLElBQUE7QUFBQSxZQUFBLFNBQUEsNkJBQUE7QUFBQSxhQUFBLDJCQUFTLE9BQUEsc0JBQUEsQ0FBdUI7SUFBQSxDQUFBO0FBQUUsSUFBQSxzQkFBQSxJQUFBLFFBQUE7QUFBTSxJQUFBLDRCQUFBLEVBQVMsRUFDNUUsRUFDRjs7OztBQVJBLElBQUEseUJBQUEsQ0FBQTtBQUFBLElBQUEsMEJBQUEscUJBQUEsT0FBQSx1QkFBQSxpQkFBQSxPQUFBLHVCQUFBLEVBQUEsRUFBdUYsZUFBQSxJQUFBOzs7QUQzUjNGLElBQU8sYUFBUCxNQUFPLFlBQVU7RUFDYixlQUFlQyxRQUFPLFlBQVk7RUFDbEMsTUFBTUEsUUFBT0Msa0JBQWlCO0VBQzlCLFNBQVNELFFBQU9FLE9BQU07RUFDdkIsY0FBY0YsUUFBTyxXQUFXOztFQUd2QyxnQkFBeUI7RUFDekIsZ0JBQThCOztFQUc5QixrQkFBMkI7RUFDM0IsaUJBQTBCO0VBQzFCLHFCQUE4Qjs7RUFHOUIsV0FBb0I7RUFDcEIsV0FBMEI7SUFDeEIsY0FBYztJQUNkLGVBQWU7SUFDZixrQkFBa0I7SUFDbEIsb0JBQW9COzs7RUFJdEIsV0FBMkIsQ0FBQTtFQUMzQixVQUF5QixDQUFBO0VBQ3pCLGNBQWlDLENBQUE7O0VBR2pDLHNCQUEyQztFQUMzQyxlQUF3Qjs7RUFFeEIsa0JBQWlDO0VBRWpDLHlCQUFpRDtFQUNqRCx5QkFBa0M7RUFFbEMsV0FBUTtBQUNOLFNBQUssWUFBVztFQUNsQjtFQUVBLGVBQVk7QUFDVixTQUFLLGdCQUFnQixDQUFDLEtBQUs7RUFDN0I7O0VBR0EsZUFBZSxjQUEwQjtBQUN2QyxTQUFLLGdCQUFnQjtBQUNyQixTQUFLLGdCQUFnQjtBQUdyQixRQUFJLGlCQUFpQixjQUFjLENBQUMsS0FBSyxpQkFBaUI7QUFDeEQsV0FBSyxlQUFjO0lBQ3JCLFdBQVcsaUJBQWlCLGFBQWEsQ0FBQyxLQUFLLGdCQUFnQjtBQUM3RCxXQUFLLGNBQWE7SUFDcEIsV0FBVyxpQkFBaUIsaUJBQWlCLENBQUMsS0FBSyxvQkFBb0I7QUFDckUsV0FBSyxrQkFBaUI7SUFDeEI7RUFDRjtFQUVBLGNBQVc7QUFDVCxTQUFLLGVBQWM7QUFDbkIsU0FBSyxlQUFjO0VBQ3JCOztFQUdBLGlCQUFjO0FBQ1osU0FBSyxhQUFhLFlBQVcsRUFBRyxVQUFVO01BQ3hDLE1BQU0sQ0FBQyxRQUFZO0FBQ2pCLFlBQUksT0FBTyxJQUFJLFdBQVcsSUFBSSxVQUFVO0FBQ3RDLGVBQUssV0FBVyxJQUFJO1FBQ3RCO01BQ0Y7TUFDQSxPQUFPLENBQUMsUUFBUSxRQUFRLE1BQU0sZ0NBQTZCLEdBQUc7S0FDL0Q7RUFDSDs7RUFHQSxpQkFBYztBQUNaLFNBQUssV0FBVztBQUNoQixTQUFLLGFBQWEsWUFBVyxFQUFHLFVBQVU7TUFDeEMsTUFBTSxDQUFDLFFBQVk7QUFDakIsWUFBSSxPQUFPLElBQUksV0FBVyxJQUFJLFVBQVU7QUFDdEMsZUFBSyxXQUFXLElBQUk7UUFDdEI7QUFDQSxhQUFLLGtCQUFrQjtBQUN2QixhQUFLLFdBQVc7TUFDbEI7TUFDQSxPQUFPLENBQUMsUUFBTztBQUNiLGdCQUFRLE1BQU0sNkJBQTZCLEdBQUc7QUFDOUMsYUFBSyxrQkFBa0I7QUFDdkIsYUFBSyxXQUFXO01BQ2xCO0tBQ0Q7RUFDSDs7RUFHQSxnQkFBYTtBQUNYLFNBQUssV0FBVztBQUNoQixTQUFLLGFBQWEsV0FBVSxFQUFHLFVBQVU7TUFDdkMsTUFBTSxDQUFDLFFBQVk7QUFDakIsWUFBSSxPQUFPLElBQUksV0FBVyxJQUFJLFNBQVM7QUFDckMsZUFBSyxVQUFVLElBQUk7UUFDckIsV0FBVyxNQUFNLFFBQVEsR0FBRyxHQUFHO0FBQzdCLGVBQUssVUFBVTtRQUNqQjtBQUNBLGFBQUssaUJBQWlCO0FBQ3RCLGFBQUssV0FBVztNQUNsQjtNQUNBLE9BQU8sQ0FBQyxRQUFPO0FBQ2IsZ0JBQVEsTUFBTSx3Q0FBd0MsR0FBRztBQUN6RCxhQUFLLGlCQUFpQjtBQUN0QixhQUFLLFdBQVc7TUFDbEI7S0FDRDtFQUNIOztFQUdBLG9CQUFpQjtBQUNmLFNBQUssV0FBVztBQUNoQixTQUFLLGFBQWEsZUFBYyxFQUFHLFVBQVU7TUFDM0MsTUFBTSxDQUFDLFFBQVk7QUFDakIsWUFBSSxPQUFPLElBQUksV0FBVyxJQUFJLGFBQWE7QUFDekMsZUFBSyxjQUFjLElBQUk7UUFDekIsV0FBVyxNQUFNLFFBQVEsR0FBRyxHQUFHO0FBQzdCLGVBQUssY0FBYztRQUNyQjtBQUNBLGFBQUsscUJBQXFCO0FBQzFCLGFBQUssV0FBVztNQUNsQjtNQUNBLE9BQU8sQ0FBQyxRQUFPO0FBQ2IsZ0JBQVEsTUFBTSw0Q0FBNEMsR0FBRztBQUM3RCxhQUFLLHFCQUFxQjtBQUMxQixhQUFLLFdBQVc7TUFDbEI7S0FDRDtFQUNIOztFQUdBLGdCQUFnQixVQUFnQjtBQUM5QixRQUFJLFFBQVEsdURBQWlELFFBQVEsd0JBQXdCLEdBQUc7QUFDOUYsV0FBSyxhQUFhLGVBQWUsUUFBUSxFQUFFLFVBQVU7UUFDbkQsTUFBTSxDQUFDLFFBQXFCO0FBQzFCLGNBQUksSUFBSSxTQUFTO0FBQ2Ysa0JBQU0sV0FBVyxRQUFRLDBCQUF1QjtBQUNoRCxpQkFBSyxVQUFVLEtBQUssUUFBUSxPQUFPLE9BQUssRUFBRSxjQUFjLFFBQVE7VUFDbEU7UUFDRjtRQUNBLE9BQU8sQ0FBQyxRQUFRLFFBQVEsTUFBTSw2QkFBNkIsR0FBRztPQUMvRDtJQUNIO0VBQ0Y7O0VBR0EsZUFBZSxVQUEwQztBQUN2RCxRQUFJLENBQUM7QUFBVSxhQUFPO0FBQ3RCLFVBQU0sUUFBUSxJQUFJLEtBQUssUUFBUTtBQUMvQixRQUFJLE1BQU0sTUFBTSxRQUFPLENBQUU7QUFBRyxhQUFPO0FBRW5DLFdBQU8sTUFBTSxtQkFBbUIsU0FBUztNQUN2QyxLQUFLO01BQ0wsT0FBTztNQUNQLE1BQU07S0FDUDtFQUNIO0VBRUEscUJBQXFCLFVBQTRDLGVBQXVCLElBQUU7QUFDeEYsUUFBSSxDQUFDO0FBQVUsYUFBTyxFQUFFLFlBQVksYUFBYSxNQUFNLEdBQUcsWUFBWSxLQUFJO0FBRTFFLFVBQU0sU0FBUyxJQUFJLEtBQUssUUFBUTtBQUNoQyxRQUFJLE1BQU0sT0FBTyxRQUFPLENBQUU7QUFBRyxhQUFPLEVBQUUsWUFBWSxhQUFhLE1BQU0sR0FBRyxZQUFZLEtBQUk7QUFFeEYsVUFBTSxNQUFNLElBQUksS0FBSyxNQUFNO0FBQzNCLFFBQUksUUFBUSxPQUFPLFFBQU8sSUFBSyxPQUFPLFlBQVksQ0FBQztBQUVuRCxVQUFNLE1BQU0sb0JBQUksS0FBSTtBQUNwQixVQUFNLGVBQWUsSUFBSSxRQUFPLElBQUssSUFBSSxRQUFPO0FBQ2hELFVBQU0sZ0JBQWdCLEtBQUssS0FBSyxnQkFBZ0IsTUFBTyxLQUFLLEtBQUssR0FBRztBQUVwRSxRQUFJLGlCQUFpQixHQUFHO0FBQ3RCLGFBQU8sRUFBRSxZQUFZLGNBQWMsTUFBTSxHQUFHLFlBQVksS0FBSTtJQUM5RDtBQUVBLFdBQU87TUFDTCxZQUFZO01BQ1osTUFBTTtNQUNOLFlBQVk7O0VBRWhCOztFQUdGLGNBQWMsV0FBbUIsY0FBb0I7QUFFbkQsVUFBTSxXQUFXLGNBQWMsU0FBUSxFQUFHLEtBQUksRUFBRyxZQUFXLE1BQU87QUFDbkUsVUFBTSxjQUFjLFdBQVcsYUFBYTtBQUU1QyxTQUFLLGFBQWEscUJBQXFCLFdBQVcsV0FBVyxFQUFFLFVBQVU7TUFDdkUsTUFBTSxDQUFDLFFBQXFCO0FBQzFCLFlBQUksSUFBSSxTQUFTO0FBRWYsZ0JBQU0sTUFBTSxLQUFLLFNBQVMsS0FBSyxPQUFLLEVBQUUsZUFBZSxTQUFTO0FBQzlELGNBQUksS0FBSztBQUNQLGdCQUFJLFNBQVM7VUFDZjtBQUdBLGNBQUksS0FBSyx1QkFBdUIsS0FBSyxvQkFBb0IsZUFBZSxXQUFXO0FBQ2pGLGlCQUFLLG9CQUFvQixTQUFTO1VBQ3BDO0FBR0EsZUFBSyxJQUFJLGNBQWE7UUFDeEIsT0FBTztBQUVMLGdCQUFNLElBQUksV0FBVyw2Q0FBNkM7UUFDcEU7TUFDRjtNQUNBLE9BQU8sQ0FBQyxRQUFPO0FBQ2IsZ0JBQVEsTUFBTSw0QkFBNEIsR0FBRztBQUM3QyxjQUFNLHFEQUFrRDtNQUMxRDtLQUNEO0VBQ0g7RUFDRSxXQUFXLFNBQXFCO0FBQzlCLFNBQUssc0JBQXNCO0FBQzNCLFNBQUssZUFBZTtFQUN0QjtFQUVBLGNBQVc7QUFDVCxTQUFLLGVBQWU7QUFDcEIsU0FBSyxzQkFBc0I7RUFDN0I7O0VBRUEsbUJBQW1CLFdBQWlCO0FBQ2xDLFNBQUssa0JBQWtCO0VBQ3pCO0VBRUEsb0JBQWlCO0FBQ2pCLFNBQUssa0JBQWtCO0VBQ3pCOztFQUdFLHFCQUFxQixZQUEyQjtBQUM5QyxTQUFLLHlCQUF5QjtBQUM5QixTQUFLLHlCQUF5QjtFQUNoQztFQUVBLHdCQUFxQjtBQUNuQixTQUFLLHlCQUF5QjtBQUM5QixTQUFLLHlCQUF5QjtFQUNoQzs7RUFHQSxlQUFZO0FBQ1YsU0FBSyxZQUFZLE9BQU07QUFDdkIsU0FBSyxPQUFPLFNBQVMsQ0FBQyxTQUFTLENBQUM7RUFDbEM7O0VBR0EsZ0JBQWdCLE9BQStCO0FBQzdDLFdBQU8sTUFBTSxTQUFRO0VBQ3ZCO0VBRUEsZUFBZSxPQUErQjtBQUM1QyxVQUFNLFFBQVEsS0FBSyxnQkFBZ0IsS0FBSyxFQUFFLFlBQVc7QUFDckQsVUFBTSxnQkFBZ0IsQ0FBQyxZQUFZLGNBQWMsU0FBUyxRQUFRLE9BQU87QUFDekUsV0FBTyxDQUFDLGNBQWMsU0FBUyxLQUFLO0VBQ3RDO0VBRUEsZUFBZSxPQUErQjtBQUM1QyxXQUFPLEtBQUssZ0JBQWdCLEtBQUssRUFBRSxRQUFRLE1BQU0sR0FBRyxFQUFFLFlBQVc7RUFDbkU7O3FDQWhSVyxhQUFVO0VBQUE7OEVBQVYsYUFBVSxXQUFBLENBQUEsQ0FBQSxpQkFBQSxDQUFBLEdBQUEsT0FBQSxJQUFBLE1BQUEsSUFBQSxRQUFBLENBQUEsQ0FBQSxHQUFBLGtCQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxXQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxVQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxpQkFBQSxHQUFBLENBQUEsR0FBQSxXQUFBLEdBQUEsQ0FBQSxHQUFBLGVBQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsUUFBQSxHQUFBLENBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsYUFBQSxHQUFBLFVBQUEsV0FBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSw0QkFBQSxHQUFBLGNBQUEsTUFBQSxHQUFBLENBQUEsR0FBQSxxQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsZUFBQSxHQUFBLENBQUEsR0FBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLGFBQUEsR0FBQSxDQUFBLEdBQUEsVUFBQSxHQUFBLENBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLGVBQUEsR0FBQSxDQUFBLFNBQUEsc0JBQUEsR0FBQSxZQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsU0FBQSx5QkFBQSxHQUFBLFlBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFlBQUEsR0FBQSxDQUFBLEdBQUEsU0FBQSxVQUFBLEdBQUEsQ0FBQSxHQUFBLFNBQUEsUUFBQSxHQUFBLENBQUEsR0FBQSxjQUFBLGtCQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxZQUFBLEdBQUEsT0FBQSxHQUFBLENBQUEsR0FBQSxpQkFBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsaUJBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsR0FBQSxDQUFBLEdBQUEsY0FBQSxHQUFBLE9BQUEsR0FBQSxDQUFBLEdBQUEsWUFBQSxHQUFBLENBQUEsR0FBQSxZQUFBLEdBQUEsQ0FBQSxHQUFBLGNBQUEsR0FBQSxDQUFBLEdBQUEsa0JBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLFdBQUEsR0FBQSxDQUFBLEdBQUEsaUJBQUEsc0JBQUEsR0FBQSxPQUFBLEdBQUEsQ0FBQSxHQUFBLGVBQUEsa0JBQUEsYUFBQSxHQUFBLENBQUEsR0FBQSxxQkFBQSxhQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsb0JBQUEsSUFBQSxLQUFBO0FBQUEsUUFBQSxLQUFBLEdBQUE7QUMxQnZCLE1BQUEsOEJBQUEsR0FBQSxPQUFBLENBQUEsRUFBOEIsR0FBQSxTQUFBLENBQUEsRUFFTCxHQUFBLEtBQUEsRUFDaEIsR0FBQSxLQUFBLENBQUE7QUFDQSxNQUFBLDBCQUFBLFNBQUEsU0FBQSx5Q0FBQTtBQUFBLGVBQUEsSUFBQSxnQkFBeUI7TUFBSSxDQUFBO0FBQTBELE1BQUEsc0JBQUEsR0FBQSx3Q0FBQTtBQUF1QixNQUFBLDRCQUFBO0FBQ2pILE1BQUEsOEJBQUEsR0FBQSxLQUFBLENBQUE7QUFBRyxNQUFBLDBCQUFBLFNBQUEsU0FBQSx5Q0FBQTtBQUFBLFlBQUEsZ0JBQXlCO0FBQUssZUFBRSxJQUFBLGVBQWUsYUFBYTtNQUFDLENBQUE7QUFBOEYsTUFBQSxzQkFBQSxHQUFBLHVCQUFBO0FBQWMsTUFBQSw0QkFBQTtBQUM1SyxNQUFBLDhCQUFBLEdBQUEsS0FBQSxDQUFBO0FBQUcsTUFBQSwwQkFBQSxTQUFBLFNBQUEseUNBQUE7QUFBQSxZQUFBLGdCQUF5QjtBQUFLLGVBQUUsSUFBQSxlQUFlLFVBQVU7TUFBQyxDQUFBO0FBQTJGLE1BQUEsc0JBQUEsR0FBQSxvQkFBQTtBQUFXLE1BQUEsNEJBQUE7QUFDbkssTUFBQSw4QkFBQSxHQUFBLEtBQUEsQ0FBQTtBQUFHLE1BQUEsMEJBQUEsU0FBQSxTQUFBLHlDQUFBO0FBQUEsWUFBQSxnQkFBeUI7QUFBSyxlQUFFLElBQUEsZUFBZSxTQUFTO01BQUMsQ0FBQTtBQUEwRixNQUFBLHNCQUFBLElBQUEsbUJBQUE7QUFBVSxNQUFBLDRCQUFBO0FBQ2hLLE1BQUEsOEJBQUEsSUFBQSxLQUFBLENBQUE7QUFBRyxNQUFBLDBCQUFBLFNBQUEsU0FBQSwwQ0FBQTtBQUFBLFlBQUEsZ0JBQXlCO0FBQUssZUFBRSxJQUFBLGVBQWUsZUFBZTtNQUFDLENBQUE7QUFBZ0csTUFBQSxzQkFBQSxJQUFBLHlCQUFBO0FBQWdCLE1BQUEsNEJBQUEsRUFBSTtBQUcxTCxNQUFBLDhCQUFBLElBQUEsVUFBQSxDQUFBO0FBQXVCLE1BQUEsMEJBQUEsU0FBQSxTQUFBLCtDQUFBO0FBQUEsZUFBUyxJQUFBLGFBQUE7TUFBYyxDQUFBO0FBQUUsTUFBQSxzQkFBQSxJQUFBLGtCQUFBO0FBQWEsTUFBQSw0QkFBQSxFQUFTO0FBSXRFLE1BQUEsOEJBQUEsSUFBQSxPQUFBLENBQUEsRUFBNkIsSUFBQSxJQUFBO0FBQ3ZCLE1BQUEsc0JBQUEsSUFBQSwyREFBQTtBQUE2QyxNQUFBLDRCQUFBO0FBQ2pELE1BQUEsOEJBQUEsSUFBQSxLQUFBLENBQUE7QUFBcUIsTUFBQSxzQkFBQSxJQUFBLG1FQUFBO0FBQTJELE1BQUEsNEJBQUE7QUFHaEYsTUFBQSw4QkFBQSxJQUFBLE9BQUEsQ0FBQSxFQUEyQixJQUFBLE9BQUEsQ0FBQTtBQUl2QixNQUFBLDBCQUFBLFNBQUEsU0FBQSw0Q0FBQTtBQUFBLGVBQVMsSUFBQSxlQUFlLFVBQVU7TUFBQyxDQUFBO0FBQ25DLE1BQUEsOEJBQUEsSUFBQSxRQUFBLENBQUE7QUFBcUIsTUFBQSxzQkFBQSxFQUFBO0FBQTRCLE1BQUEsNEJBQUE7QUFDakQsTUFBQSw4QkFBQSxJQUFBLFFBQUEsQ0FBQTtBQUFvQixNQUFBLHNCQUFBLElBQUEsc0JBQUE7QUFBb0IsTUFBQSw0QkFBQSxFQUFPO0FBR2pELE1BQUEsOEJBQUEsSUFBQSxPQUFBLENBQUE7QUFHRSxNQUFBLDBCQUFBLFNBQUEsU0FBQSw0Q0FBQTtBQUFBLGVBQVMsSUFBQSxlQUFlLFNBQVM7TUFBQyxDQUFBO0FBQ2xDLE1BQUEsOEJBQUEsSUFBQSxRQUFBLENBQUE7QUFBcUIsTUFBQSxzQkFBQSxFQUFBO0FBQTJCLE1BQUEsNEJBQUE7QUFDaEQsTUFBQSw4QkFBQSxJQUFBLFFBQUEsQ0FBQTtBQUFvQixNQUFBLHNCQUFBLElBQUEsb0JBQUE7QUFBa0IsTUFBQSw0QkFBQSxFQUFPO0FBRy9DLE1BQUEsOEJBQUEsSUFBQSxPQUFBLENBQUE7QUFHRSxNQUFBLDBCQUFBLFNBQUEsU0FBQSw0Q0FBQTtBQUFBLGVBQVMsSUFBQSxlQUFlLGFBQWE7TUFBQyxDQUFBO0FBQ3RDLE1BQUEsOEJBQUEsSUFBQSxRQUFBLENBQUE7QUFBcUIsTUFBQSxzQkFBQSxFQUFBO0FBQStCLE1BQUEsNEJBQUE7QUFDcEQsTUFBQSw4QkFBQSxJQUFBLFFBQUEsQ0FBQTtBQUFvQixNQUFBLHNCQUFBLElBQUEseUJBQUE7QUFBdUIsTUFBQSw0QkFBQSxFQUFPO0FBR3BELE1BQUEsOEJBQUEsSUFBQSxPQUFBLEVBQUE7QUFHRSxNQUFBLDBCQUFBLFNBQUEsU0FBQSw0Q0FBQTtBQUFBLFlBQUEsZ0JBQXlCO0FBQUssZUFBRSxJQUFBLGVBQWUsZUFBZTtNQUFDLENBQUE7QUFFL0QsTUFBQSw4QkFBQSxJQUFBLFFBQUEsQ0FBQTtBQUFxQixNQUFBLHNCQUFBLEVBQUE7QUFBaUMsTUFBQSw0QkFBQTtBQUN0RCxNQUFBLDhCQUFBLElBQUEsUUFBQSxDQUFBO0FBQW9CLE1BQUEsc0JBQUEsSUFBQSx1QkFBQTtBQUFxQixNQUFBLDRCQUFBLEVBQU8sRUFDNUM7QUFJUixNQUFBLDhCQUFBLElBQUEsT0FBQSxFQUFBO0FBR0UsTUFBQSxtQ0FBQSxJQUFBLG9DQUFBLEdBQUEsQ0FBQTtBQTJEQSxNQUFBLG1DQUFBLElBQUEsb0NBQUEsR0FBQSxDQUFBO0FBdURBLE1BQUEsbUNBQUEsSUFBQSxvQ0FBQSxHQUFBLENBQUE7QUFnREEsTUFBQSxtQ0FBQSxJQUFBLG9DQUFBLEdBQUEsR0FBQSxtQkFBQTtBQUlGLE1BQUEsNEJBQUE7QUFHQSxNQUFBLDhCQUFBLElBQUEsT0FBQSxFQUFBLEVBQWdFLElBQUEsVUFBQSxFQUFBO0FBQzVCLE1BQUEsMEJBQUEsU0FBQSxTQUFBLCtDQUFBO0FBQUEsZUFBUyxJQUFBLGFBQUE7TUFBYyxDQUFBO0FBQ3ZELE1BQUEsc0JBQUEsRUFBQTtBQUNGLE1BQUEsNEJBQUEsRUFBUztBQUlYLE1BQUEsbUNBQUEsSUFBQSxvQ0FBQSxHQUFBLEdBQUEsWUFBQTtBQUdGLE1BQUEsNEJBQUE7QUFHQSxNQUFBLG1DQUFBLElBQUEsb0NBQUEsSUFBQSxHQUFBLE9BQUEsRUFBQTtBQXFDRixNQUFBLG1DQUFBLElBQUEsb0NBQUEsR0FBQSxHQUFBLE9BQUEsRUFBQTtBQW9CQSxNQUFBLG1DQUFBLElBQUEsb0NBQUEsSUFBQSxHQUFBLE9BQUEsRUFBQTtBQXNCQSxNQUFBLDRCQUFBOzs7QUE1VHdDLE1BQUEseUJBQUEsQ0FBQTtBQUFBLE1BQUEsMkJBQUEsVUFBQSxJQUFBLGFBQUE7QUFDZ0MsTUFBQSx5QkFBQSxDQUFBO0FBQUEsTUFBQSwyQkFBQSxVQUFBLElBQUEsa0JBQUEsaUJBQUEsQ0FBQSxJQUFBLGFBQUE7QUFDSCxNQUFBLHlCQUFBLENBQUE7QUFBQSxNQUFBLDJCQUFBLFVBQUEsSUFBQSxrQkFBQSxjQUFBLENBQUEsSUFBQSxhQUFBO0FBQ0QsTUFBQSx5QkFBQSxDQUFBO0FBQUEsTUFBQSwyQkFBQSxVQUFBLElBQUEsa0JBQUEsYUFBQSxDQUFBLElBQUEsYUFBQTtBQUNNLE1BQUEseUJBQUEsQ0FBQTtBQUFBLE1BQUEsMkJBQUEsVUFBQSxJQUFBLGtCQUFBLG1CQUFBLENBQUEsSUFBQSxhQUFBO0FBZWxFLE1BQUEseUJBQUEsRUFBQTtBQUFBLE1BQUEsMkJBQUEsVUFBQSxJQUFBLGtCQUFBLFVBQUE7QUFFcUIsTUFBQSx5QkFBQSxDQUFBO0FBQUEsTUFBQSxpQ0FBQSxJQUFBLFNBQUEsYUFBQTtBQU1yQixNQUFBLHlCQUFBLENBQUE7QUFBQSxNQUFBLDJCQUFBLFVBQUEsSUFBQSxrQkFBQSxTQUFBO0FBRXFCLE1BQUEseUJBQUEsQ0FBQTtBQUFBLE1BQUEsaUNBQUEsSUFBQSxTQUFBLFlBQUE7QUFNckIsTUFBQSx5QkFBQSxDQUFBO0FBQUEsTUFBQSwyQkFBQSxVQUFBLElBQUEsa0JBQUEsYUFBQTtBQUVxQixNQUFBLHlCQUFBLENBQUE7QUFBQSxNQUFBLGlDQUFBLElBQUEsU0FBQSxnQkFBQTtBQU1yQixNQUFBLHlCQUFBLENBQUE7QUFBQSxNQUFBLDJCQUFBLFVBQUEsSUFBQSxrQkFBQSxlQUFBO0FBR3FCLE1BQUEseUJBQUEsQ0FBQTtBQUFBLE1BQUEsaUNBQUEsSUFBQSxTQUFBLGtCQUFBO0FBU3ZCLE1BQUEseUJBQUEsQ0FBQTtBQUFBLE1BQUEsNkJBQUEsSUFBQSxrQkFBQSxhQUFBLEtBQUEsRUFBQTtBQTJEQSxNQUFBLHlCQUFBO0FBQUEsTUFBQSw2QkFBQSxJQUFBLGtCQUFBLFlBQUEsS0FBQSxFQUFBO0FBdURBLE1BQUEseUJBQUE7QUFBQSxNQUFBLDZCQUFBLElBQUEsa0JBQUEsZ0JBQUEsS0FBQSxFQUFBO0FBZ0RBLE1BQUEseUJBQUE7QUFBQSxNQUFBLDZCQUFBLElBQUEsa0JBQUEsa0JBQUEsS0FBQSxFQUFBO0FBU0UsTUFBQSx5QkFBQSxDQUFBO0FBQUEsTUFBQSxrQ0FBQSxLQUFBLElBQUEsZ0JBQUEsd0NBQUEsbUNBQUEsR0FBQTtBQUtKLE1BQUEseUJBQUE7QUFBQSxNQUFBLDZCQUFBLElBQUEsZ0JBQUEsS0FBQSxFQUFBO0FBTUYsTUFBQSx5QkFBQTtBQUFBLE1BQUEsNkJBQUEsSUFBQSxnQkFBQSxJQUFBLHNCQUFBLEtBQUEsRUFBQTtBQXFDRixNQUFBLHlCQUFBO0FBQUEsTUFBQSw2QkFBQSxJQUFBLGtCQUFBLEtBQUEsRUFBQTtBQW9CQSxNQUFBLHlCQUFBO0FBQUEsTUFBQSw2QkFBQSxJQUFBLDBCQUFBLElBQUEseUJBQUEsS0FBQSxFQUFBOztvQkRwUllHLGVBQVksYUFBQSx1QkFBQSxhQUFBLFVBQUEsc0JBQUEsYUFBQSxjQUFBLGtCQUFBLHFCQUFBLGNBQUEsa0JBQUUsUUFBUSxtQkFBbUIsZ0JBQWdCLHdCQUFzQixlQUFBLG1CQUFBLG1CQUFBLGNBQUEsZUFBQSxpQkFBQSxpQkFBQSxtQkFBQSxrQkFBQSxjQUFBLG9CQUFBLG9CQUFBLGdCQUFBLEdBQUEsUUFBQSxDQUFBLDZrb0JBQUEsRUFBQSxDQUFBOzs7aUZBSTlFLFlBQVUsQ0FBQTtVQVB0QkM7dUJBQ1csbUJBQWlCLFlBQ2YsTUFBSSxTQUNQLENBQUNELGVBQWMsUUFBUSxtQkFBbUIsZ0JBQWdCLHNCQUFzQixHQUFDLFVBQUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1NBQUEsUUFBQSxDQUFBLHd2WUFBQSxFQUFBLENBQUE7Ozs7a0ZBSS9FLFlBQVUsRUFBQSxXQUFBLGNBQUEsVUFBQSx5Q0FBQSxZQUFBLEdBQUEsQ0FBQTtBQUFBLEdBQUE7Ozs7Ozs7Z0VBQVYsWUFBVSxFQUFBLFNBQUEsQ0FBQUUsTUFBQUMsR0FBQSxHQUFBLENBQUFILGVBQUEsUUFBQSxtQkFBQSxnQkFBQSx3QkFBQUMsVUFBQSxHQUFBLGFBQUEsRUFBQSxDQUFBO0VBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGNBQUEsbUJBQUEsS0FBQSxJQUFBLENBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGVBQUEsWUFBQSxPQUFBLFlBQUEsSUFBQSxHQUFBLDRCQUFBLE9BQUEsRUFBQSxPQUFBLE1BQUEsbUJBQUEsRUFBQSxTQUFBLENBQUE7QUFBQSxHQUFBOzs7QUsxQnZCLFNBQVMsVUFBQUcsZ0JBQWM7QUFDdkIsU0FBd0IsVUFBQUMsZUFBYztBQUcvQixJQUFNLFlBQTJCLENBQUMsT0FBTyxVQUFTO0FBQ3ZELFFBQU0sY0FBY0MsU0FBTyxXQUFXO0FBQ3RDLFFBQU0sU0FBU0EsU0FBT0MsT0FBTTtBQUU1QixNQUFJLFlBQVksV0FBVSxHQUFJO0FBQzVCLFdBQU87RUFDVDtBQUVBLFNBQU8sT0FBTyxjQUFjLENBQUMsU0FBUyxDQUFDO0FBQ3pDOzs7QUNiQSxTQUFTLFVBQUFDLGdCQUFjO0FBQ3ZCLFNBQXdCLFVBQUFDLGVBQWM7QUFHL0IsSUFBTSxhQUE0QixDQUFDLE9BQU8sVUFBUztBQUN4RCxRQUFNLGNBQWNDLFNBQU8sV0FBVztBQUN0QyxRQUFNLFNBQVNBLFNBQU9DLE9BQU07QUFHNUIsTUFBSSxDQUFDLFlBQVksV0FBVSxHQUFJO0FBQzdCLFdBQU8sT0FBTyxjQUFjLENBQUMsU0FBUyxDQUFDO0VBQ3pDO0FBR0EsTUFBSSxZQUFZLGVBQWMsTUFBTyxTQUFTO0FBQzVDLFdBQU87RUFDVDtBQUdBLFFBQU0sTUFBTSxZQUFZLGVBQWM7QUFDdEMsTUFBSSxRQUFRLFdBQVc7QUFDckIsV0FBTyxPQUFPLGNBQWMsQ0FBQyx5QkFBeUIsQ0FBQztFQUN6RDtBQUVBLFNBQU8sT0FBTyxjQUFjLENBQUMsb0JBQW9CLENBQUM7QUFDcEQ7OztBQ3pCQSxTQUFTLFVBQUFDLGdCQUFjO0FBQ3ZCLFNBQXdCLFVBQUFDLGVBQWM7QUFHL0IsSUFBTSxrQkFBaUMsTUFBSztBQUNqRCxRQUFNLGNBQWNDLFNBQU8sV0FBVztBQUN0QyxRQUFNLFNBQVNBLFNBQU9DLE9BQU07QUFFNUIsTUFBSSxZQUFZLFdBQVUsS0FBTSxZQUFZLGVBQWMsTUFBTyxjQUFjO0FBQzdFLFdBQU87RUFDVDtBQUNBLFNBQU8sT0FBTyxjQUFjLENBQUMsU0FBUyxDQUFDO0FBQ3pDOzs7QUNaQSxTQUFTLFVBQUFDLGdCQUFjO0FBQ3ZCLFNBQXdCLFVBQUFDLGdCQUFjO0FBRy9CLElBQU0sZUFBOEIsTUFBSztBQUM5QyxRQUFNLGNBQWNDLFNBQU8sV0FBVztBQUN0QyxRQUFNLFNBQVNBLFNBQU9DLFFBQU07QUFFNUIsTUFBSSxZQUFZLFdBQVUsS0FBTSxZQUFZLGVBQWMsTUFBTyxXQUFXO0FBQzFFLFdBQU87RUFDVDtBQUNBLFNBQU8sT0FBTyxjQUFjLENBQUMsU0FBUyxDQUFDO0FBQ3pDOzs7QUNNTyxJQUFNLFNBQWlCOzs7O0VBSTVCLEVBQUUsTUFBTSxJQUFJLFdBQVcsVUFBUztFQUNoQyxFQUFFLE1BQU0sVUFBVSxXQUFXLE9BQU07RUFDbkMsRUFBRSxNQUFNLGFBQWEsV0FBVyxjQUFhO0VBQzdDLEVBQUUsTUFBTSx3QkFBd0IsV0FBVyxvQkFBbUI7RUFDOUQsRUFBRSxNQUFNLHFCQUFxQixXQUFXLGlCQUFnQjs7RUFHeEQsRUFBRSxNQUFNLFdBQVcsV0FBVyxRQUFPOztFQUlyQztJQUNFLE1BQU07SUFDTixXQUFXO0lBQ1gsYUFBYSxDQUFDLFlBQVk7Ozs7O0VBSzVCO0lBQ0UsTUFBTTtJQUNOLGVBQWUsTUFDYixPQUFPLHFCQUFtRCxFQUFFLEtBQUssT0FBSyxFQUFFLGNBQWM7SUFDeEYsYUFBYSxDQUFDLFNBQVM7O0VBRXpCO0lBQ0UsTUFBTTtJQUNOLGVBQWUsTUFDYixPQUFPLHFCQUF5RCxFQUFFLEtBQUssT0FBSyxFQUFFLGlCQUFpQjtJQUNqRyxhQUFhLENBQUMsU0FBUzs7Ozs7O0VBT3pCO0lBQ0UsTUFBTTtJQUNOLFdBQVc7SUFDWCxhQUFhLENBQUMsU0FBUzs7O0VBSXpCO0lBQ0UsTUFBTTtJQUNOLFdBQVc7SUFDWCxhQUFhLENBQUMsU0FBUzs7RUFHekI7SUFDRSxNQUFNO0lBQ04sV0FBVztJQUNYLGFBQWEsQ0FBQyxVQUFVOzs7OztFQU0xQjtJQUNFLE1BQU07SUFDTixlQUFlLE1BQ2IsT0FBTyxxQkFBbUMsRUFBRSxLQUFLLE9BQUssRUFBRSxPQUFPO0lBQ2pFLGFBQWEsQ0FBQyxTQUFTO0lBQ3ZCLFVBQVU7TUFDUjtRQUNFLE1BQU07UUFDTixlQUFlLE1BQ2IsT0FBTyxxQkFBeUQsRUFBRSxLQUFLLE9BQUssRUFBRSxpQkFBaUI7UUFDakcsYUFBYSxDQUFDLGVBQWU7O01BRS9CO1FBQ0UsTUFBTTtRQUNOLGVBQWUsTUFDYixPQUFPLHFCQUF5QyxFQUFFLEtBQUssT0FBSyxFQUFFLFVBQVU7UUFDMUUsYUFBYSxDQUFDLGVBQWU7O01BRS9CO1FBQ0UsTUFBTTtRQUNOLGVBQWUsTUFDYixPQUFPLHFCQUFtRCxFQUFFLEtBQUssT0FBSyxFQUFFLGNBQWM7UUFDeEYsYUFBYSxDQUFDLFlBQVk7OztNQUk1QjtRQUNFLE1BQU07UUFDTixlQUFlLE1BQ2IsT0FBTyxxQkFBNEIsRUFBRSxLQUFLLE9BQUssRUFBRSxRQUFROztNQUU3RDtRQUNFLE1BQU07UUFDTixlQUFlLE1BQ2IsT0FBTyxxQkFBNEIsRUFBRSxLQUFLLE9BQUssRUFBRSxRQUFROzs7Ozs7O0VBUWpFLEVBQUUsTUFBTSxNQUFNLFlBQVksR0FBRTs7OztBMUJuSDlCLFNBQVMsd0JBQXdCLHVCQUF1Qjs7O0EyQk54RCxTQUFTLFVBQUFDLFVBQVEsbUJBQW1CO0FBQ3BDLFNBQVMseUJBQXlCO0FBQ2xDLFNBQVMsVUFBQUMsZ0JBQWM7QUFDdkIsU0FBUyxZQUFZLGtCQUFrQjtBQUVoQyxJQUFNLGtCQUFxQyxDQUFDLEtBQUssU0FBUTtBQUM5RCxRQUFNLGFBQWFELFNBQU8sV0FBVztBQUNyQyxRQUFNLFNBQVNBLFNBQU9DLFFBQU07QUFFNUIsTUFBSSxRQUF1QjtBQUUzQixNQUFJLGtCQUFrQixVQUFVLEdBQUc7QUFDakMsVUFBTSxXQUFXLGFBQWEsUUFBUSxPQUFPO0FBRTdDLFFBQUksVUFBVTtBQUNaLGNBQVE7SUFDVixPQUFPO0FBQ0wsWUFBTSxnQkFBZ0IsYUFBYSxRQUFRLFNBQVM7QUFDcEQsVUFBSSxlQUFlO0FBQ2pCLFlBQUk7QUFDRixnQkFBTSxVQUFVLEtBQUssTUFBTSxhQUFhO0FBQ3hDLGtCQUFRLFFBQVEsU0FBUyxRQUFRLE9BQU87UUFDMUMsU0FBUyxHQUFHO0FBQ1Ysa0JBQVEsTUFBTSw4Q0FBOEMsQ0FBQztRQUMvRDtNQUNGO0lBQ0Y7QUFHQSxRQUFJLE9BQU87QUFDVCxjQUFRLE1BQU0sUUFBUSxVQUFVLEVBQUUsRUFBRSxLQUFJO0lBQzFDO0VBQ0Y7QUFHQSxRQUFNLFVBQVUsUUFDWixJQUFJLE1BQU07SUFDUixZQUFZO01BQ1YsZUFBZSxVQUFVLEtBQUs7O0dBRWpDLElBQ0Q7QUFFSixTQUFPLEtBQUssT0FBTyxFQUFFLEtBQ25CLFdBQVcsQ0FBQyxVQUE0QjtBQUN0QyxRQUFJLGtCQUFrQixVQUFVLEdBQUc7QUFFakMsVUFBSSxNQUFNLFdBQVcsS0FBSztBQUN4QixxQkFBYSxXQUFXLE9BQU87QUFDL0IscUJBQWEsV0FBVyxTQUFTO0FBRWpDLFlBQUksT0FBTyxRQUFRLFdBQVc7QUFDNUIsaUJBQU8sU0FBUyxDQUFDLFNBQVMsQ0FBQztRQUM3QjtNQUNGLFdBRVMsTUFBTSxXQUFXLEtBQUs7QUFDN0IsZ0JBQVEsS0FBSyw2RUFBMEU7TUFDekY7SUFDRjtBQUVBLFdBQU8sV0FBVyxNQUFNLEtBQUs7RUFDL0IsQ0FBQyxDQUFDO0FBRU47OztBM0J0REEsbUJBQW1CLFFBQVE7QUFFcEIsSUFBTSxZQUErQjtFQUMxQyxXQUFXO0lBQ1QsbUNBQWtDO0lBQ2xDLGNBQWMsTUFBTTtJQUNwQix1QkFBdUIsZ0JBQWUsQ0FBRTtJQUN4QyxrQkFDRSxVQUFTLEdBQ1QsaUJBQWlCLENBQUMsZUFBZSxDQUFDLENBQUM7SUFFckMsRUFBRSxTQUFTLFdBQVcsVUFBVSxLQUFJOzs7OztBNEJ0QnhDLFNBQVMsYUFBQUMsYUFBVyxjQUFjO0FBQ2xDLFNBQVMsZ0JBQUFDLHFCQUFvQjs7O0FFRDdCLFNBQVMsYUFBQUMsYUFBVyxVQUFBQyxnQkFBYztBQUVsQyxTQUFTLGNBQUFDLGFBQVksVUFBQUMsZ0JBQWM7Ozs7QUNVN0IsSUFBQSw4QkFBQSxHQUFBLEtBQUEsQ0FBQTtBQUEyQixJQUFBLHNCQUFBLEdBQUEsYUFBQTtBQUFXLElBQUEsNEJBQUE7QUFDdEMsSUFBQSw4QkFBQSxHQUFBLEtBQUEsQ0FBQTtBQUF3QixJQUFBLHNCQUFBLEdBQUEsbUJBQUE7QUFBYyxJQUFBLDRCQUFBOzs7OztBQU1wQyxJQUFBLDhCQUFBLEdBQUEsS0FBQSxDQUFBO0FBQTZCLElBQUEsc0JBQUEsR0FBQSxhQUFBO0FBQVcsSUFBQSw0QkFBQTs7Ozs7QUFLeEMsSUFBQSw4QkFBQSxHQUFBLEtBQUEsQ0FBQTtBQUF3QixJQUFBLHNCQUFBLEdBQUEsY0FBQTtBQUFZLElBQUEsNEJBQUE7Ozs7OztBQU50QyxJQUFBLG1DQUFBLEdBQUEsNkNBQUEsR0FBQSxHQUFBLEtBQUEsQ0FBQTtBQUtBLElBQUEsbUNBQUEsR0FBQSw2Q0FBQSxHQUFBLEdBQUEsS0FBQSxDQUFBO0FBS0EsSUFBQSw4QkFBQSxHQUFBLEtBQUEsQ0FBQTtBQUFHLElBQUEsMEJBQUEsU0FBQSxTQUFBLG1EQUFBO0FBQUEsTUFBQSw2QkFBQSxHQUFBO0FBQUEsWUFBQSxTQUFBLDZCQUFBO0FBQUEsYUFBQSwyQkFBUyxPQUFBLGFBQUEsQ0FBYztJQUFBLENBQUE7QUFBMkIsSUFBQSxzQkFBQSxHQUFBLGtCQUFBO0FBQWEsSUFBQSw0QkFBQTs7OztBQVZsRSxJQUFBLDZCQUFBLE9BQUEsWUFBQSxlQUFBLE1BQUEsVUFBQSxJQUFBLEVBQUE7QUFLQSxJQUFBLHlCQUFBO0FBQUEsSUFBQSw2QkFBQSxPQUFBLFlBQUEsZUFBQSxNQUFBLGdCQUFBLE9BQUEsWUFBQSxlQUFBLE1BQUEsWUFBQSxJQUFBLEVBQUE7OztBRFhBLElBQU8sU0FBUCxNQUFPLFFBQU07RUFDVixjQUFjQyxTQUFPLFdBQVc7RUFDL0IsU0FBUUEsU0FBT0MsUUFBTTtFQUU3QixlQUFZO0FBQ1YsU0FBSyxZQUFZLE9BQU07QUFDdkIsU0FBSyxPQUFPLFNBQVMsQ0FBQyxTQUFTLENBQUM7RUFDbEM7RUFHRixXQUFRO0FBRU4sVUFBTSxPQUFPLGFBQWEsUUFBUSxNQUFNO0FBRXhDLFFBQUcsU0FBUyxXQUFVO0FBRXBCLFdBQUssT0FBTyxTQUFTLENBQUMsaUJBQWlCLENBQUM7SUFFMUMsV0FBUyxTQUFTLGNBQWE7QUFFN0IsV0FBSyxPQUFPLFNBQVMsQ0FBQyxvQkFBb0IsQ0FBQztJQUU3QyxPQUFLO0FBRUgsV0FBSyxPQUFPLFNBQVMsQ0FBQyxTQUFTLENBQUM7SUFFbEM7RUFFRjs7cUNBNUJhLFNBQU07RUFBQTs4RUFBTixTQUFNLFdBQUEsQ0FBQSxDQUFBLFlBQUEsQ0FBQSxHQUFBLE9BQUEsSUFBQSxNQUFBLEdBQUEsUUFBQSxDQUFBLENBQUEsY0FBQSxZQUFBLEdBQUEsQ0FBQSxPQUFBLGlCQUFBLE9BQUEsWUFBQSxHQUFBLGFBQUEsR0FBQSxDQUFBLGNBQUEsVUFBQSxHQUFBLENBQUEsY0FBQSxZQUFBLEdBQUEsQ0FBQSxjQUFBLFNBQUEsR0FBQSxDQUFBLGNBQUEsY0FBQSxHQUFBLENBQUEsY0FBQSxTQUFBLEdBQUEsQ0FBQSxHQUFBLFVBQUEsV0FBQSxHQUFBLE9BQUEsQ0FBQSxHQUFBLFVBQUEsU0FBQSxnQkFBQSxJQUFBLEtBQUE7QUFBQSxRQUFBLEtBQUEsR0FBQTtBQ1puQixNQUFBLDhCQUFBLEdBQUEsUUFBQSxFQUFRLEdBQUEsS0FBQSxFQUVILEdBQUEsS0FBQSxDQUFBO0FBR0MsTUFBQSx5QkFBQSxHQUFBLE9BQUEsQ0FBQTtBQUNGLE1BQUEsNEJBQUE7QUFDQSxNQUFBLDhCQUFBLEdBQUEsS0FBQSxDQUFBO0FBQTJCLE1BQUEsc0JBQUEsR0FBQSxRQUFBO0FBQU0sTUFBQSw0QkFBQTtBQUNqQyxNQUFBLDhCQUFBLEdBQUEsS0FBQSxDQUFBO0FBQXlCLE1BQUEsc0JBQUEsR0FBQSxlQUFBO0FBQWEsTUFBQSw0QkFBQTtBQUd0QyxNQUFBLG1DQUFBLEdBQUEsK0JBQUEsR0FBQSxDQUFBLEVBQWlDLEdBQUEsK0JBQUEsR0FBQSxDQUFBO0FBbUJuQyxNQUFBLDRCQUFBLEVBQU07OztBQW5CSixNQUFBLHlCQUFBLENBQUE7QUFBQSxNQUFBLDZCQUFBLENBQUEsSUFBQSxZQUFBLFdBQUEsSUFBQSxJQUFBLENBQUE7O29CREhRQyxXQUFVLEdBQUEsUUFBQSxDQUFBLHN1REFBQSxFQUFBLENBQUE7OztpRkFJVCxRQUFNLENBQUE7VUFQbEJDO3VCQUNXLGNBQVksWUFDVixNQUFJLFNBQ1AsQ0FBQ0QsV0FBVSxHQUFDLFVBQUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQUFBLFFBQUEsQ0FBQSw0OUNBQUEsRUFBQSxDQUFBOzs7O2tGQUlWLFFBQU0sRUFBQSxXQUFBLFVBQUEsVUFBQSxvQ0FBQSxZQUFBLEdBQUEsQ0FBQTtBQUFBLEdBQUE7Ozs7Ozs7Z0VBQU4sUUFBTSxFQUFBLFNBQUEsQ0FBQUUsSUFBQSxHQUFBLENBQUFGLGFBQUFDLFdBQUEsR0FBQSxhQUFBLEVBQUEsQ0FBQTtFQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxjQUFBLGVBQUEsS0FBQSxJQUFBLENBQUE7QUFBQSxHQUFBLE9BQUEsY0FBQSxlQUFBLGVBQUEsWUFBQSxPQUFBLFlBQUEsSUFBQSxHQUFBLDRCQUFBLE9BQUEsRUFBQSxPQUFBLE1BQUEsZUFBQSxFQUFBLFNBQUEsQ0FBQTtBQUFBLEdBQUE7OztBRVpuQixTQUFTLGFBQUFFLG1CQUFpQjs7QUFRcEIsSUFBTyxTQUFQLE1BQU8sUUFBTTs7cUNBQU4sU0FBTTtFQUFBOzhFQUFOLFNBQU0sV0FBQSxDQUFBLENBQUEsWUFBQSxDQUFBLEdBQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxRQUFBLENBQUEsQ0FBQSxRQUFBLGdDQUFBLENBQUEsR0FBQSxVQUFBLFNBQUEsZ0JBQUEsSUFBQSxLQUFBO0FBQUEsUUFBQSxLQUFBLEdBQUE7QUNSbkIsTUFBQSxpQ0FBQSxHQUFBLFFBQUEsRUFBUSxHQUFBLElBQUE7QUFFSixNQUFBLHNCQUFBLEdBQUEsd0ZBQUE7QUFBcUYsTUFBQSwrQkFBQTtBQUN6RixNQUFBLGlDQUFBLEdBQUEsR0FBQTtBQUFHLE1BQUEsc0JBQUEsR0FBQSxZQUFBO0FBQVUsTUFBQSxpQ0FBQSxHQUFBLEtBQUEsQ0FBQTtBQUF5QyxNQUFBLHNCQUFBLEdBQUEseUJBQUE7QUFBdUIsTUFBQSwrQkFBQSxFQUFJLEVBQUk7Ozs7O2lGREt4RSxRQUFNLENBQUE7VUFObEJBO3VCQUNXLGNBQVksU0FDYixDQUFBLEdBQUUsVUFBQSxxTkFBQSxRQUFBLENBQUEsc25CQUFBLEVBQUEsQ0FBQTs7OztrRkFJQSxRQUFNLEVBQUEsV0FBQSxVQUFBLFVBQUEsb0NBQUEsWUFBQSxFQUFBLENBQUE7QUFBQSxHQUFBOzs7Ozs7O2dFQUFOLFFBQU0sRUFBQSxTQUFBLENBQUFDLElBQUEsR0FBQSxDQUFBRCxXQUFBLEdBQUEsYUFBQSxFQUFBLENBQUE7RUFBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsY0FBQSxlQUFBLEtBQUEsSUFBQSxDQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxlQUFBLFlBQUEsT0FBQSxZQUFBLElBQUEsR0FBQSw0QkFBQSxPQUFBLEVBQUEsT0FBQSxNQUFBLGVBQUEsRUFBQSxTQUFBLENBQUE7QUFBQSxHQUFBOzs7O0FKS2IsSUFBTyxNQUFQLE1BQU8sS0FBRztFQUNLLFFBQVEsT0FBTyxXQUFTLEdBQUEsWUFBQSxDQUFBLEVBQUEsV0FBQSxRQUFBLENBQUE7O0lBQUEsQ0FBQTtHQUFBOztxQ0FEaEMsTUFBRztFQUFBOzhFQUFILE1BQUcsV0FBQSxDQUFBLENBQUEsVUFBQSxDQUFBLEdBQUEsT0FBQSxHQUFBLE1BQUEsR0FBQSxVQUFBLFNBQUEsYUFBQSxJQUFBLEtBQUE7QUFBQSxRQUFBLEtBQUEsR0FBQTtBQ2JoQixNQUFBLHlCQUFBLEdBQUEsWUFBQTtBQUNBLE1BQUEsOEJBQUEsR0FBQSxNQUFBO0FBQ0UsTUFBQSx5QkFBQSxHQUFBLGVBQUE7QUFDRixNQUFBLDRCQUFBO0FBRUEsTUFBQSx5QkFBQSxHQUFBLFlBQUE7O29CRElZRSxlQUFjLFFBQVEsTUFBTSxHQUFBLGVBQUEsRUFBQSxDQUFBOzs7aUZBSTNCLEtBQUcsQ0FBQTtVQVBmQzt5QkFDYSxNQUFJLFVBQ04sWUFBVSxTQUNYLENBQUNELGVBQWMsUUFBUSxNQUFNLEdBQUMsVUFBQSx1SEFBQSxDQUFBOzs7O2tGQUk1QixLQUFHLEVBQUEsV0FBQSxPQUFBLFVBQUEsY0FBQSxZQUFBLEdBQUEsQ0FBQTtBQUFBLEdBQUE7Ozs7Ozs7Z0VBQUgsS0FBRyxFQUFBLFNBQUEsQ0FBQUUsSUFBQSxHQUFBLENBQUFGLGVBQUEsUUFBQSxRQUFBQyxXQUFBLEdBQUEsYUFBQSxFQUFBLENBQUE7RUFBQTtBQUFBLEdBQUEsT0FBQSxjQUFBLGVBQUEsY0FBQSxZQUFBLEtBQUEsSUFBQSxDQUFBO0FBQUEsR0FBQSxPQUFBLGNBQUEsZUFBQSxlQUFBLFlBQUEsT0FBQSxZQUFBLElBQUEsR0FBQSw0QkFBQSxPQUFBLEVBQUEsT0FBQSxNQUFBLFlBQUEsRUFBQSxTQUFBLENBQUE7QUFBQSxHQUFBOzs7QTdCVGhCLHFCQUFxQixLQUFLLFNBQVMsRUFDaEMsTUFBTSxDQUFDLFFBQVEsUUFBUSxNQUFNLEdBQUcsQ0FBQzsiLCJuYW1lcyI6WyJDb21wb25lbnQiLCJSb3V0ZXJMaW5rIiwiUm91dGVyTGluayIsIkNvbXBvbmVudCIsImkwIiwiQ29tcG9uZW50IiwiaTAiLCJpMSIsIkNvbXBvbmVudCIsImluamVjdCIsIkZvcm1Db250cm9sIiwiRm9ybUdyb3VwIiwiUmVhY3RpdmVGb3Jtc01vZHVsZSIsIlZhbGlkYXRvcnMiLCJSb3V0ZXIiLCJSb3V0ZXJMaW5rIiwiaW5qZWN0IiwiQ29tcG9uZW50IiwiaTAiLCJpMSIsIkNvbXBvbmVudCIsImluamVjdCIsIkZvcm1Db250cm9sIiwiRm9ybUdyb3VwIiwiUmVhY3RpdmVGb3Jtc01vZHVsZSIsIlZhbGlkYXRvcnMiLCJDb21tb25Nb2R1bGUiLCJSb3V0ZXIiLCJSb3V0ZXJMaW5rIiwiaW5qZWN0IiwiQ29tcG9uZW50IiwiaTAiLCJpMSIsImkyIiwiQ29tcG9uZW50IiwiVmFsaWRhdG9ycyIsIlJlYWN0aXZlRm9ybXNNb2R1bGUiLCJDb21tb25Nb2R1bGUiLCJpbmplY3QiLCJJbmplY3RhYmxlIiwiaW5qZWN0IiwiSHR0cENsaWVudCIsIl9mb3JUcmFjazEiLCJfZm9yVHJhY2swIiwiVmFsaWRhdG9ycyIsIlJlYWN0aXZlRm9ybXNNb2R1bGUiLCJDb21tb25Nb2R1bGUiLCJDb21wb25lbnQiLCJpMCIsImkxIiwiQ29tcG9uZW50IiwiaW5qZWN0IiwiQ2hhbmdlRGV0ZWN0b3JSZWYiLCJDb21tb25Nb2R1bGUiLCJSb3V0ZXIiLCJfZm9yVHJhY2swIiwiaW5qZWN0IiwiQ2hhbmdlRGV0ZWN0b3JSZWYiLCJSb3V0ZXIiLCJDb21tb25Nb2R1bGUiLCJDb21wb25lbnQiLCJpMCIsImkxIiwiQ29tcG9uZW50IiwiaW5qZWN0IiwiQ2hhbmdlRGV0ZWN0b3JSZWYiLCJDb21tb25Nb2R1bGUiLCJSb3V0ZXIiLCJDb21wb25lbnQiLCJpbmplY3QiLCJDb21tb25Nb2R1bGUiLCJGb3JtQnVpbGRlciIsIlJlYWN0aXZlRm9ybXNNb2R1bGUiLCJWYWxpZGF0b3JzIiwiRm9ybXNNb2R1bGUiLCJJbmplY3RhYmxlIiwiaW5qZWN0IiwiSHR0cENsaWVudCIsIl9mb3JUcmFjazAiLCJpbmplY3QiLCJGb3JtQnVpbGRlciIsIlZhbGlkYXRvcnMiLCJDb21tb25Nb2R1bGUiLCJSZWFjdGl2ZUZvcm1zTW9kdWxlIiwiRm9ybXNNb2R1bGUiLCJDb21wb25lbnQiLCJpMCIsImkxIiwiaTIiLCJfZm9yVHJhY2swIiwiX2ZvclRyYWNrMSIsIl9mb3JUcmFjazIiLCJpbmplY3QiLCJDaGFuZ2VEZXRlY3RvclJlZiIsIlJvdXRlciIsIkNvbW1vbk1vZHVsZSIsIkNvbXBvbmVudCIsImkwIiwiaTEiLCJpbmplY3QiLCJSb3V0ZXIiLCJpbmplY3QiLCJSb3V0ZXIiLCJpbmplY3QiLCJSb3V0ZXIiLCJpbmplY3QiLCJSb3V0ZXIiLCJpbmplY3QiLCJSb3V0ZXIiLCJpbmplY3QiLCJSb3V0ZXIiLCJpbmplY3QiLCJSb3V0ZXIiLCJpbmplY3QiLCJSb3V0ZXIiLCJpbmplY3QiLCJSb3V0ZXIiLCJDb21wb25lbnQiLCJSb3V0ZXJPdXRsZXQiLCJDb21wb25lbnQiLCJpbmplY3QiLCJSb3V0ZXJMaW5rIiwiUm91dGVyIiwiaW5qZWN0IiwiUm91dGVyIiwiUm91dGVyTGluayIsIkNvbXBvbmVudCIsImkwIiwiQ29tcG9uZW50IiwiaTAiLCJSb3V0ZXJPdXRsZXQiLCJDb21wb25lbnQiLCJpMCJdfQ==